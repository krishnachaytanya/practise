/*! last.js */
/*! Script expected to go at the bottom of the page, after all the libraries are loaded is included here */
	$(document).ready(function(){
                // Expand/collapse mobile submenus
                $('.submenu-header').on('click', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    $(this).siblings('.submenu-header-links').toggleClass('d-none d-lg-block');
                });
            });

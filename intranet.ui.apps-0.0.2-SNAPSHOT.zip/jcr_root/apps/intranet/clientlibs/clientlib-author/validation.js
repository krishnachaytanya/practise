(function (document, $, ns) {
    "use strict";
  
    $(document).on("click", ".cq-dialog-submit", function (e) {
        e.stopPropagation();
        e.preventDefault();
 
        var $form = $(this).closest("form.foundation-form"),
            message = "";
        
        if(/contact$/.test($form.attr("action"))){
	        var elementValue,
	            clazz = "coral-Button ",
	            patterns = {
	        		name: /^[a-zA-Z\s]+$/i,
	        		department: /^[a-zA-Z\s\.]+$/i,
	        		phonenumber: /^\d{3}\.\d{3}\.\d{4}$/i,
	        		emailadd: /^[a-z\d\.]+@usbank\.com$/i
	        	};
	        
	        elementValue = $form.find("[name='./name']").val();
	        
	        if(elementValue != "" && !patterns.name.test(elementValue) && (elementValue != null)){
	        	message = "Please Enter a valid Contact Name (alpha and space characters)";
	        }
	        
	        elementValue = $form.find("[name='./department']").val();
	        
	        if(elementValue != "" && !patterns.department.test(elementValue) && (elementValue != null)){
	        	message = "<br/>Please Enter a valid Department Name (alpha, space and . characters)";
	        }
	        
	        elementValue = $form.find("[name='./phone']").val();
	        
	        if(elementValue != "" && !patterns.phonenumber.test(elementValue) && (elementValue != null)){
	        	message = "<br/>Please Enter a valid Phone Number (xxx.xxx.xxxx)";
	        }
	        
	        elementValue = $form.find("[name='./email']").val();
	        
	        if(elementValue != "" && !patterns.emailadd.test(elementValue) && (elementValue != null)){
	        	message += "<br/>Please Enter a valid Email Address (firstname.lastname@usbank.com)";
	        }
        }
        else if(/contactlist$/.test($form.attr("action"))){
	        var elementValue,
            clazz = "coral-Button ",
            patterns = {
        		contactname: /^[a-zA-Z\s]+$/i,
        		title: /^[a-zA-Z\s]+$/i,
        		phonenumber: /^\d{3}\.\d{3}\.\d{4}$/i,
        		emailadd: /^[a-z\d\.]+@usbank\.com$/i
        	};
        
	        var elementArray = $form.find("[name='./contactname']");
	        
	        for(var i = 0; i < elementArray.length; i++){
	        	if(elementArray[i].value != "" && !patterns.contactname.test(elementArray[i].value) && (elementArray[i].value != null)){
		        	message += "<br/>Contact #" + (i+1) + ": Please Enter a valid Contact Name (alpha and space characters)";
		        }
	        }	        
	        
	        elementArray = $form.find("[name='./title']");
	        
	        for(var i = 0; i < elementArray.length; i++){
	        	if(elementArray[i].value != "" && !patterns.title.test(elementArray[i].value) && (elementArray[i].value != null)){
		        	message += "<br/>Contact #" + (i+1) + ": Please Enter a valid Title for Contact (alpha and space characters)";
		        }
	        }
	        
	        elementArray = $form.find("[name='./phone']");
	        
	        for(var i = 0; i < elementArray.length; i++){
	        	if(elementArray[i].value != "" && !patterns.phonenumber.test(elementArray[i].value) && (elementArray[i].value != null)){
		        	message += "<br/>Contact #" + (i+1) + ": Please Enter a valid Phone Number (xxx.xxx.xxxx)";
		        }
	        }
	        
	        elementArray = $form.find("[name='./email']");
	        
	        for(var i = 0; i < elementArray.length; i++){
	        	if(elementArray[i].value != "" && !patterns.emailadd.test(elementArray[i].value) && (elementArray[i].value != null)){
		        	message += "<br/>Contact #" + (i+1) + ": Please Enter a valid Email Address (firstname.lastname@usbank.com)";
		        }
	        }
	    }
 
        if(message != "") {
                ns.ui.helpers.prompt({
                	title: Granite.I18n.get("Invalid Input"),
                	message: message,
                	actions: [{
                		id: "CANCEL",
                		text: "CANCEL",
                		className: "coral-Button"
                	}],
                	callback: function (actionId) {
                		if (actionId === "CANCEL") {}
                	}
                }); 
        }
        else{
                 $form.submit();
        }
    });
})(document, Granite.$, Granite.author);
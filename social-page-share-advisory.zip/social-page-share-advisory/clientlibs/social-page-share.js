(function(KPMG, jQuery) {
    'use strict';
    KPMG.Namespace(KPMG, 'KPMG.Components.Classes.SocialPageShare');
    KPMG.Components.Classes.SocialPageShare = new KPMG.Class();
    KPMG.Components.Classes.SocialPageShare.include({
        $fbIcons: undefined,
        init: function($facebookIcons) {
            this.$fbIcons = $facebookIcons;
            this.bindClicks();
        },
	    bindClicks: function() {
            // facebook binding
            if (this.$fbIcons && this.$fbIcons.length) {
              jQuery.each(this.$fbIcons, function() {
                  var shareUrl = jQuery(this).attr("data-url");
                  if (shareUrl) {
                      jQuery(this).on('click', function(e) {
                        e.preventDefault();
                        FB.ui({
                            method: 'share',
                            href: shareUrl,
                        });
                      });
                  }
              });
            }
	    }
    });
    jQuery(document).on('ready', function() {
        var $facebookIcons = jQuery('.social-page-share-advisory .facebook-share-button');
        if($facebookIcons.length) {
            new KPMG.Components.Classes.SocialPageShare($facebookIcons);
        }
    });
}(KPMG, jQuery));


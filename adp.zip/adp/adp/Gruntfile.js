module.exports = function (grunt) {

    // measures the time each task takes
    require('time-grunt')(grunt);

    // load grunt configs located in the <project-root>/grunt directory
    require('load-grunt-config')(grunt);

    // load grunt tasks automatically with the grunt-* nomenclature
    require('load-grunt-tasks')(grunt);

    /**
     * REGISTER TASKS
     */
    grunt.registerTask('default', 'default usage statement', function () {
        grunt.log.writeln('\n\n\nrun grunt -h for specific tasks\n\n');
    });
};
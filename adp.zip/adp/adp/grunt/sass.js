module.exports = function (grunt) {

    function debug() {
        return !!(grunt.option('debug') || grunt.config.get('debug'));

    }

    function clean() {
        return !grunt.option('clean');

    }

    return {
        sass: {
            options: {
                sourcemap: false,
                includePaths: ['packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss',
                              'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/base/scss']
            },
            files: [{
                expand: true,
                src: [
                    'packages/adp-application/src/**/clientlibs/**/*.scss',
                    '!packages/adp-application/src/**/clientlibs/**/vendor/**/*.scss',
                    '!packages/adp-application/target/**/*.scss'
                ],
                ext: '.css',
                rename: function (dest, src) {
                    return src.replace('/scss', '/css');
                }
            }]
        }
    }
};
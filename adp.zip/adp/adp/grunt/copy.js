// e.g. grunt copy:boostrap
module.exports = {
    bootstrap: {
        files: [
            {
                expand: true,
                cwd: 'node_modules/bootstrap-sass/assets/stylesheets/bootstrap/',
                src: ['./**'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/bootstrap/'
            },
            {
                expand: true,
                cwd: 'node_modules/bootstrap-sass/assets/javascripts/',
                src: ['bootstrap.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/bootstrap/'
            }
        ]
    },
    js: {
         files: [
            {
                expand: true,
                cwd: 'node_modules/list.js/dist/',
                src: ['list.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/list.js/'
            },
            {
                expand: true,
                cwd: 'node_modules/handlebars/dist',
                src: ['handlebars.runtime.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/handlebars'
            },
            {
                expand: true,
                cwd: 'node_modules/moment/min',
                src: ['moment.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/moment'
            },
            {
                expand: true,
                cwd: 'node_modules/urijs/src',
                src: ['URI.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/urijs'
            },
            {
                expand: true,
                cwd: 'node_modules/js-cookie/src',
                src: ['js.cookie.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/js/js-cookie'
            }
        ]
    },
    slickCarousel: {
        files: [
            {
                expand: true,
                cwd: 'node_modules/slick-carousel/slick/',
                src: ['slick.min.js'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/base/js/'
            },
            {
                expand: true,
                cwd: 'node_modules/slick-carousel/slick/',
                src: ['slick.scss'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/slick-carousel/'
            },
            {
                expand: true,
                cwd: 'node_modules/slick-carousel/slick/',
                src: ['slick-theme.scss'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/slick-carousel/'
            },
            {
                expand: true,
                cwd: 'node_modules/slick-carousel/slick/',
                src: ['ajax-loader.gif'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/slick-carousel/'
            },
            {
                expand: true,
                cwd: 'node_modules/slick-carousel/slick/fonts',
                src: ['./**'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/slick-carousel/fonts/'
            }
        ]
    },
    materialIcons: {
        files: [
            {
                expand: true,
                cwd: 'node_modules/material-design-icons-font/iconfont/',
                src: ['material-icons.scss'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/scss/material-icons/'
            },
            {
                expand: true,
                cwd: 'node_modules/material-design-icons-font/iconfont/',
                src: ['MaterialIcons-Regular.eot'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/fonts/'
            },
            {
                expand: true,
                cwd: 'node_modules/material-design-icons-font/iconfont/',
                src: ['MaterialIcons-Regular.ttf'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/fonts/'
            },
            {
                expand: true,
                cwd: 'node_modules/material-design-icons-font/iconfont/',
                src: ['MaterialIcons-Regular.woff'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/fonts/'
            },
            {
                expand: true,
                cwd: 'node_modules/material-design-icons-font/iconfont/',
                src: ['MaterialIcons-Regular.woff2'],
                dest: 'packages/adp-application/src/main/content/jcr_root/etc/clientlibs/adp/vendor/fonts/'
            }
        ]
    }
};



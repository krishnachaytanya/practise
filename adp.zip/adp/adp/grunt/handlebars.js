module.exports = function(grunt) {
  return {
    handlebars: {
      options: {
        namespace: 'HBS',
        processName: function(filePath) {
          return filePath.replace(/.*\//, '').replace(/\.hbs$/, '');
        }
      },
      files: [{
        expand: true,
        src: [
          'packages/adp-application/src/**/clientlibs/**/*.hbs',
          '!packages/adp-application/target/**/*.hbs'
        ],
        ext: '.js',
        rename: function(dest, src) {
          return src.replace('/hbs', '/hbsjs');
        }
      }]
    }
  }
};
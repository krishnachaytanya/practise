module.exports = function (grunt) {

    grunt.config.set('debug', grunt.option('debug'));

    return {
        sass: {
            'files': [
                'packages/adp-application/src/**/clientlibs/**/*.scss',
                '!packages/adp-application/src/**/clientlibs/**/vendor/**/*.scss'
            ],
            'tasks': [
                'sass'
            ],
            'options': {
                'spawn': false,
                'livereload': false
            }
        },
        handlebars: {
            'files': [
                'packages/adp-application/src/**/clientlibs/**/*.hbs'
            ],
            'tasks': [
                'handlebars'
            ],
            'options': {
                'spawn': false,
                'livereload': false
            }
        }
    }
};
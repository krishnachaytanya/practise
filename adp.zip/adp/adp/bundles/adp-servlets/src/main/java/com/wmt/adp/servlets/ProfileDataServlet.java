package com.wmt.adp.servlets;

import com.wmt.adp.services.utils.CommonsUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import java.io.IOException;
import java.util.Enumeration;

/**
 * Created by bfitzpatrick on 9/28/17.
 */
@SlingServlet(
        paths = "/bin/adp/profile/data",
        methods = "GET",
        extensions = "json",
        metatype = false
)
public class ProfileDataServlet extends SlingSafeMethodsServlet {
    private static final Logger logger = LoggerFactory.getLogger(ProfileDataServlet.class);

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String name = request.getHeader("displayname");
        String initials = "";

        Enumeration<String> headersNames = request.getHeaderNames();

        JSONObject jsonObject = new JSONObject();
        JSONObject headerObject = new JSONObject();
        while (headersNames.hasMoreElements()) {
            String headerName = headersNames.nextElement();
            String headerValue = request.getHeader(headerName);
            try {
                headerObject.put(headerName, headerValue);
            } catch (JSONException e) {
                logger.error("could not make header json", e);
            }
        }

        JSONObject cookieObject = new JSONObject();
        Cookie[] cookies = request.getCookies();
        for (Cookie cookie: cookies) {
            String cookieName = cookie.getName();
            String cookieValue = cookie.getValue();
            try {
                cookieObject.put(cookieName, cookieValue);
            } catch (JSONException e) {
                logger.error("Could not make cookie json", e);
            }
        }

        try {
            jsonObject.put("headers", headerObject);
            jsonObject.put("cookies", cookieObject);
        } catch (JSONException e) {
            logger.error("could not make the big json", e);
        }

        if (name != null) {
            initials = CommonsUtils.extractInitials(name);
        }

        response.setContentType("application/json");
        response.getWriter().write(jsonObject.toString());
    }
}

/**
 * 
 */
package com.wmt.adp.servlets;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.util.Collections;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.fluent.Executor;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.fluent.Response;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.apache.jackrabbit.util.Base64;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.settings.SlingSettingsService;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.adp.services.ConstantsService;
import com.wmt.adp.services.LanguageService;

/**
 * Simple HTTP Proxy for SDL Enterprise Translation Server service calls
 */
@SlingServlet(
        paths = "/bin/adp/translatetext",
        resourceTypes = "adp/components/page/generic",  // global/language-selector 
        methods = { "GET", "POST" },
//        selectors = "translate",
        extensions = { "json" },
        name="com.wmt.adp.servlets.TranslateTextServlet",
        label = "ADP - SDL ETS Proxy Servlet ",
        description = "ADP - SDL Enterprise Translation Server endpoint HTTP proxy",
        metatype = true
)
@Service
@Properties({
             @Property(name = "service.vendor", value = "Walmart"),
             @Property(name = "service.description", value = "ADP - SDL Enterprise Translation Server endpoint HTTP proxy."),
})
public class TranslateTextServlet extends SlingAllMethodsServlet {

    private static final Logger logger = LoggerFactory.getLogger( TranslateTextServlet.class );

    private static final String RESPONSE_OK = "SUCCESS";
    
    private static final String DEFAULT_TIMEOUT_SEC = "5"; // 5 sec + Service Config call timeout
    private static final String PROP_TIMEOUT        = "services.timeout";

    @Property(name = PROP_TIMEOUT, value = DEFAULT_TIMEOUT_SEC, label = "Call (extra) timeout (sec)", description = "SDL Enterprise Translation Server call (extra) timeout (seconds).")
    private int servicesTimeoutSec      = Integer.valueOf( DEFAULT_TIMEOUT_SEC );
 
    private static final String DEFAULT_PARAM_SERVICE_TYPE = "serviceType";
    private static final String PROP_PARAM_SERVICE_TYPE    = "services.service.name";

    @Property(name = PROP_PARAM_SERVICE_TYPE, value = DEFAULT_PARAM_SERVICE_TYPE, label = "ETS service call type", description = "SDL Enterprise Translation Server call type.")
    private String paramServiceType = DEFAULT_PARAM_SERVICE_TYPE;



    private static final String ERROR = "{ \"error\": \"%s\" }";

    private Map<String,String> isoToLang = Collections.emptyMap(); //currentLanguages( );

    @Reference
    private LanguageService languageService;
    
    @Reference
    private SlingSettingsService settingsService;

    @Activate
    @Modified
    protected void activate(final Map< String, Object > config) {
        if (config != null) {
            setServicesTimeoutSec( PropertiesUtil.toInteger( config.get(PROP_TIMEOUT), getServicesTimeoutSec() ));
            setParamServiceType( PropertiesUtil.toString( config.get(PROP_PARAM_SERVICE_TYPE) , getParamServiceType() ));

            String serverTmp = ( languageService != null ? languageService.getSdlTranslateUrl() : null );
            String apiKeyTmp = ( languageService != null ? languageService.getSdlTranslateApiKey() : null );
            setIsoToLang(  languageService != null ? languageService.currentLanguages() : Collections.emptyMap() );
            logger.info( "Using ETS url '{}', api key '{}', timeout {}, service key '{}', langs {}.", serverTmp, apiKeyTmp,
                         getServicesTimeoutSec(), getParamServiceType(), getIsoToLang() );

        } else {
        	    logger.error("Missing config values.");
        } // config

        if ( settingsService != null) {
            // run modes	
            	logger.info( "Got current sling runmode " + settingsService.getRunModes() + "." );
        } // settingsService
        
    } // activate


    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        response.setContentType( "application/json;charset=utf-8" );
        response.setCharacterEncoding( "UTF-8" );

        final PrintWriter writer = response.getWriter();
        String values = "";
        String results = null;

        try {
            String serviceTypeParam = getParamServiceType();	
            Map<String,String[]> params = request.getParameterMap();
            String serviceType = findServiceType( serviceTypeParam, params );
            
            Map<String,String> isoCodesToLang = getIsoToLang();
            String paramsTmp = paramsToString(serviceTypeParam, params, serviceType );

            String serverTmp = ( languageService != null ? StringUtils.trimToEmpty( languageService.getSdlTranslateUrl() ) : "" );
            String apiKeyTmp = ( languageService != null ? StringUtils.trimToEmpty( languageService.getSdlTranslateApiKey() ) : "" );
            boolean isValid = ( serverTmp.length() > 0 && apiKeyTmp.length() > 0 && paramsTmp.length() > 0 );
            if ( !isValid )
            {
                logger.warn( "Missing server url '{}', api key '{}', params '{}', ", serverTmp, apiKeyTmp, paramsTmp );
                writer.printf( ERROR, "Missing server url for " + paramsTmp + "." );
            } else {

                serverTmp += (serverTmp.endsWith("/") ? "" : "/") + serviceType;
                logger.info("Try url '{}' and params '{}'.", serverTmp, paramsTmp );

                serverTmp += ( paramsTmp.length() > 0 ? ( "?" + paramsTmp ) : "" );

                Request serviceRequest = Request.Get( serverTmp );
                if (getServicesTimeoutSec() > 0) {
                    serviceRequest.socketTimeout( getServicesTimeoutSec() * 1000 );  // connect timeout msec
                }

                URI targetTmp = new URI( serverTmp );
                HttpHost target = new HttpHost( targetTmp.getHost(), targetTmp.getPort(), targetTmp.getScheme() );

                Executor executor = Executor.newInstance();
                
                executor = executor.auth( target, apiKeyTmp, "" );  // basic auth with user name
                // serviceRequest.addHeader( new BasicHeader( "Authorization", "LC apiKey=" + apiKeyTmp ) );  // custom auth

                serviceRequest.addHeader( new BasicHeader( "Authorization", "Basic " + Base64.encode( apiKeyTmp + ":" ) ) );  // basic auth

                results = executor.execute( serviceRequest ).returnContent().asString();

                String tmp =  checkResponse( results, serverTmp ); // log response status

                writer.print( results );
                serviceRequest = null;  // done
            } // valid

        } catch (Exception ex) {
            logger.error("Error {} is {}", values, ex.getMessage(), ex);
            writer.printf(ERROR, ex.getMessage() );
        } // try

        return;
    } // doGet


    /**
     * @param serviceTypeParam  the service call type key
     * @param params            all the query parameters
     * @param serviceType       the service call type
     * @return  the query parameters string
     * @throws UnsupportedEncodingException if problems with values
     */
    protected String paramsToString(String serviceTypeParam, Map<String, String[]> params, String serviceType )
                	throws UnsupportedEncodingException {
        int cnt = 0;
        String paramsTmp = "";
        for (String key : params.keySet() ) {
            String requestVals[]  = params.get(key);
            for (int idx = 0; idx < requestVals.length; ++idx) {
                String val = requestVals[ idx ];
                if ( serviceTypeParam != null && serviceTypeParam.equals(key) ) {
                    continue;  // skip service call type
                } // serviceTypeParam 

                paramsTmp += ((cnt > 0) ? "&" : "") + key + "=" + URLEncoder.encode( val, "UTF-8");
                ++cnt;
                logger.info("Add param '{}' = '{}' for '{}'.", key, val, serviceType );
            } // idx
        } // key
        return paramsTmp;
    }


    /**
     * @param serviceTypeParam  the service type parameter name
     * @param params the query parameters to check
     * @return the service call type, if found
     */
    protected String findServiceType(String serviceTypeParam, Map<String, String[]> params) {
        String serviceType = "";
        for (String key : params.keySet() ) {
            String requestVals[]  = params.get(key);
            for (int idx = 0; idx < requestVals.length; ++idx) {
                String val = requestVals[ idx ];
                if ( serviceTypeParam != null && serviceTypeParam.equals(key) ) {
                    serviceType = val;
                    break;
                } // serviceTypeParam
            } // idx
        }  // key
        return serviceType;
    }


    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType( "application/json;charset=utf-8" );
        response.setCharacterEncoding( "UTF-8" );

        final PrintWriter    writer = response.getWriter();
        final BufferedReader reader = request.getReader();
        final String requestType    = request.getContentType();
        final int    requestSize    = request.getContentLength();
        String values = "";

        String results = null;

        logger.debug("Try POST {} of {}, length {}.", request.getContextPath(), requestType, requestSize );
        try {
            // get Post contents
            String lineTmp = reader.readLine();
            int lineSiz = (lineTmp != null ? lineTmp.length() : -1);
            logger.debug("Got request {}, {} length ", lineTmp, lineSiz );
            values += (lineSiz > 0 ? lineTmp : "");

            logger.info("Got post '{}'.", values );

            String serviceTypeParam = getParamServiceType();	
            String serviceType      = getJsonValue( values, serviceTypeParam );
            JSONObject paramsTmp = new JSONObject( values );

            Map<String,String> isoCodesToLang = getIsoToLang();
            String serverTmp = ( languageService != null ? StringUtils.trimToEmpty( languageService.getSdlTranslateUrl() ) : "" );
            String apiKeyTmp = ( languageService != null ? StringUtils.trimToEmpty( languageService.getSdlTranslateApiKey() ) : "" );
            boolean isValid = ( serverTmp.length() > 0 && apiKeyTmp.length() > 0 &&
                                serviceType.length() > 0 && paramsTmp.length() > 0 );
            if ( !isValid )
            {
                logger.warn( "Missing server url '{}', api key '{}', params '{}', ", serverTmp, apiKeyTmp, paramsTmp );
                writer.printf( ERROR, "Missing server url for " + paramsTmp + "." );
            } else {

                serverTmp += (serverTmp.endsWith("/") ? "" : "/") + serviceType;
            	
                Request serviceRequest = Request.Post( serverTmp );
                if (getServicesTimeoutSec() > 0) {
                    serviceRequest.socketTimeout( getServicesTimeoutSec() * 1000 );  // connect timeout msec
                }

                // build HTML Form from query parameters
                Form formParams = paramsToForm( values, serviceTypeParam, serviceType, paramsTmp, serverTmp);

                URI targetTmp = new URI( serverTmp );
                HttpHost target = new HttpHost( targetTmp.getHost(), targetTmp.getPort(), targetTmp.getScheme() );

                Executor executor = Executor.newInstance();
                
                executor = executor.auth( target, apiKeyTmp, "" );  // basic auth with user name

                // SDL sand box free translation
                // serviceRequest.bodyString( values, ContentType.APPLICATION_JSON );  // json post
                // serviceRequest.addHeader( new BasicHeader( "Authorization", "LC apiKey=" + apiKeyTmp ) );

                serviceRequest.bodyForm( formParams.build() );  // form post
                serviceRequest.addHeader( new BasicHeader( "Authorization", "Basic " + Base64.encode( apiKeyTmp + ":" ) ) );  // basic auth

                Response responseTmp = executor.execute( serviceRequest );
                HttpResponse tmpResponse = ( responseTmp != null ? responseTmp.returnResponse() : null ); 
                HttpEntity tmpEntity = (tmpResponse != null ? tmpResponse.getEntity() : null);
                final int statusCode = ( ( tmpResponse != null && tmpResponse.getStatusLine() != null ) ?
                                           tmpResponse.getStatusLine().getStatusCode() : -1 );
                if ( statusCode != HttpServletResponse.SC_OK ) {
                    logger.warn( "Bad status code {} {} for '{}'.", statusCode,
                                 tmpResponse.getStatusLine().getReasonPhrase(),
                                 serverTmp );

                    response.setStatus(statusCode);  // relay status
                    
                    String hdrs = "";
                    for ( org.apache.http.Header hdr : tmpResponse.getAllHeaders() )
                    {
                         hdrs += hdr.getName() + ": " + hdr.getValue() + "\n";
                    } // hdr
                    logger.info("Bad response headers {}", hdrs );
                } // statusCode

                results = (tmpEntity != null ?  EntityUtils.toString( tmpEntity, "UTF-8" ) : " " );

                String tmp =  checkResponse( results, serverTmp ); // log response status

                writer.print( results );
                serviceRequest = null;  // done

            } // isValid

        } catch (Exception ex) {
            logger.error("Error {} is {}", values, ex.getMessage(), ex);
            writer.printf(ERROR, ex.getMessage() );
        } // try

        return;
    }  // doPost


    /**
     * @param values
     * @param serviceTypeParam    the service call parameter key
     * @param serviceType         the service call type
     * @param paramsTmp           all the query parameters
     * @param serverTmp           target url
     * @return HTML Form parameters 	
     * @throws JSONException if problems 
     * @throws UnsupportedEncodingException if problems
     */
    protected Form paramsToForm(String values, String serviceTypeParam, String serviceType, JSONObject paramsTmp,
        String serverTmp) throws JSONException, UnsupportedEncodingException {
        int cnt = 0;
        Form formParams = Form.form();
        for ( String key : JSONObject.getNames( paramsTmp ) )
        {
            String val = paramsTmp.getString(key);

            if ( key.equals( serviceTypeParam ) ) {
                continue;  // skip service call type
            }
            logger.info("Add param '{}' = '{}' for '{}'.", key, val, serviceType );
            val = URLEncoder.encode( val, "UTF-8");
            formParams.add( key, val );
            ++cnt;
        } // key

        logger.debug("Try {} POST {} params from '{}'.", serverTmp, cnt, values );
        return formParams;
    }

    /**
     * @param request    the JSON string
     * @param paramName  the JSON parameter name
     * @return the parameter value; empty string otherwise
     */
    private String getJsonValue( String request, String paramName ) {
        String found = "";
        if ( paramName != null && paramName.length() > 0 ) {
            try {
                JSONObject tmp = new JSONObject(request);

                found = tmp.getString( paramName );

            } catch (JSONException ex) {
                // bad request string
                logger.error("Bad {} for request {}.", ex.getMessage(), request, ex );
            } // try
        }  // serviceTypeParam
        return found;
    }  // getJsonValue
    

    
    /**
     * 
     * @param response  the HTTP response
     * @param request   the HTTP request
     * @return status ok if translation text found
     */
    protected String checkResponse(String response, String request) {
        String status = "ERROR";
        try {
            String   responseTmp = StringUtils.trimToNull( response );
            JSONObject tmp = ( ( responseTmp != null && 
                                 responseTmp.length() > 2  && responseTmp.indexOf( "{") >= 0 
                                 && responseTmp.indexOf( "}") >= 0 ) ?
                                new JSONObject( response ) : null );

            status = ( tmp != null ? StringUtils.trimToNull( tmp.getString("translation") ) : null);
            if ( status == null ) {
                logger.debug("Got {} from {}.", response, request );
            } else if ( status.length() > 0 ) {
                logger.info("Got {} translation from {}.", response, request );
                status = RESPONSE_OK;
            } else {
                logger.debug("Got {} from {}.", response, request );
            } // status 
        } catch (JSONException ex) {
            // bad response string
            status = ex.getMessage();	
            logger.error("Bad {} response {} for request {}.", status, response, request );
        } // try
        
        return status;
    }  // checkResponse
    
    
    /**
     * Get response body as string
     *
     * @param tmpResponse the HTTP response
     * @return response cotent body  
     * @throws IOException if problems
     */
    private String getResponseBody( HttpResponse tmpResponse ) throws IOException {
        BufferedReader bufReader = null;
        String results = "";
        try {
            bufReader = new BufferedReader( new InputStreamReader( tmpResponse.getEntity().getContent() ));
            results = "";
            int lineCnt = 0;
            String line;
            while ( (line = bufReader.readLine() ) != null ) {
                results += line;
                ++lineCnt;
                logger.debug("Got line {} len '{}'.", line.length(), results);
            }

            logger.debug("Got status {}, result {} len '{}', {} lines.", getRsponseStatusCode( tmpResponse ), results.length(), results, lineCnt );

        } finally {
                if ( bufReader != null) {
                    bufReader.close();
                }
        	
        }
        return results;
    }  // getResponseBody

    /**
     * @param tmpResponse the HTTP response
     * @return the response status code
     */
    private int getRsponseStatusCode( HttpResponse tmpResponse ) {
        StatusLine tmpStatus     = (tmpResponse != null ? tmpResponse.getStatusLine() : null);
        return (tmpStatus != null ? tmpStatus.getStatusCode() : -1);
    }
    
    /**
     * @return custom http client
     */
    private HttpClient getHttpClient() {
        HttpClient client = null;
        SSLContextBuilder contextBuilder = new SSLContextBuilder();
        TrustStrategy strategy = new TrustStrategy() {
            @Override
            public boolean isTrusted(java.security.cert.X509Certificate[] certs, String authType) throws CertificateException {
                return true;
            } // isTrusted
        }; // TrustStrategy
        
        try {
            contextBuilder.loadTrustMaterial(null, strategy);

            SSLConnectionSocketFactory connFactory = new SSLConnectionSocketFactory( contextBuilder.build(),
                                                                SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER );

            HttpClientBuilder httpBuilder = HttpClientBuilder.create();
            
            httpBuilder.setSslcontext( contextBuilder.build() );
            
            Registry<ConnectionSocketFactory> sockRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                                        .register("http", PlainConnectionSocketFactory.getSocketFactory() )
                                        .register( "https" , connFactory).build();

            PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager( sockRegistry );
            
            httpBuilder.setConnectionManager( connMgr );

            client = httpBuilder.build();
        } catch (Exception ex) {
            logger.error("Bad http client create {}", ex.getMessage(), ex);
        }  // try

        return client;
    }

    
    /**
     * @return the services timeout ( secconds )
     */
    private int getServicesTimeoutSec() {
        return servicesTimeoutSec;
    }

    /**
     * @param servicesTimeoutSec the services timeout ( secconds ) to set
     */
    private void setServicesTimeoutSec(int servicesTimeoutSec) {
        	this.servicesTimeoutSec = servicesTimeoutSec;
    }


    /**
     * @return the service type request parameter key
     */
    private String getParamServiceType() {
        return paramServiceType;
    }


    /**
     * @param paramServiceType the service type request parameter key to set
     */
    private void setParamServiceType(String paramServiceType) {
        this.paramServiceType = StringUtils.trimToNull( paramServiceType );
    }


	/**
	 * @return the isoToLang the IETF BCP 47 alpha-2 code to ETS alpha-3 ( almost ISO 639 ) code  
	 */
	private Map<String, String> getIsoToLang() {
		return isoToLang;
	}


	/**
	 * @param isoToLang the iso code to lang code to set
	 */
	private void setIsoToLang(Map<String, String> isoToLang) {
		this.isoToLang = isoToLang;
	}
    
    

}

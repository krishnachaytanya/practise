package com.wmt.adp.servlets;

import com.wmt.adp.services.CurrencyExchangeService;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import javax.servlet.ServletException;
import java.io.IOException;

@SlingServlet(
        paths = "/bin/adp/currencyexchange",
        methods = "GET",
        extensions = "json",
        metatype = false
)

public class CurrencyExchangeServlet extends SlingSafeMethodsServlet {

    @Reference
    private CurrencyExchangeService currencyExchangeService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String currencyExchangeResult = currencyExchangeService.getCurrencyExchanges();

        response.setContentType("application/json");
        response.getWriter().write(currencyExchangeResult);
    }
}
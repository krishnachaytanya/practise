package com.wmt.adp.servlets;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.SearchSolrService;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Servlet used by the SolrSearch Component
 *
 * @author Merkle / Axis41
 */
@SlingServlet(
        resourceTypes = "adp/components/general/search/search-solr",
        selectors = "searchResults",
        methods = "GET",
        extensions = "json",
        metatype = false
)
public class SearchSolrServlet extends SlingSafeMethodsServlet {

    /**
     * Logger
     */
    private static final Logger logger = LoggerFactory.getLogger(SearchSolrServlet.class);

    /** Search Solr Service */
    @Reference
    private SearchSolrService searchSolrService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String[] selectors = request.getRequestPathInfo().getSelectors();
        String tags = "";
        RequestParameter tagsParam = request.getRequestParameter("tags");
        if (tagsParam != null) {
            tags = request.getRequestParameter("tags").getString();
        }

        ResourceResolver resourceResolver = request.getResourceResolver();
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

        Page requestPage = pageManager.getContainingPage(request.getResource());
        Page languageRoot = PageUtils.getLanguageRoot(requestPage, pageManager);
        String languageRootPath = languageRoot != null ? languageRoot.getPath() : "";

        String parentTagStr = requestPage.getProperties().get("parentTag", "/etc/tags/icp/article-type");

        try {
            JSONObject json = searchSolrService.getSearchResults(parentTagStr, languageRootPath, selectors, tags, requestPage.getLanguage(false));
            response.setContentType("application/json");
            response.getWriter().write(json.toString());
        } catch (LoginException e) {
            logger.error("Error calling searchSolrService", e);
        }
    }
}




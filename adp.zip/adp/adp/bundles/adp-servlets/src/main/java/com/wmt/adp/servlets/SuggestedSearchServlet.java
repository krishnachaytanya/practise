package com.wmt.adp.servlets;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import org.apache.commons.io.IOUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;


/**
 * Created by dkenison on 2/15/18.
 */
@SlingServlet(
        paths = {"/bin/adp/suggested-search/results"},
        methods = "GET",
        extensions = "json",
        metatype = false
)
public class SuggestedSearchServlet extends SlingSafeMethodsServlet {

    private static final String SOLR_HOST = "http://solrcloud.prod.crawler.aep.prod.walmart.com:8983/solr/ce-walmart/suggest?suggest=true&suggest.build=true&wt=json&indent=on&suggest.q=";
    private CloseableHttpClient httpClient;

    /**
     * Logger
     */
    private static final Logger logger = LoggerFactory.getLogger(SearchSolrServlet.class);

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String searchTerm = "";
        RequestParameter searchTermParam = request.getRequestParameter("searchTerm");
        if (searchTermParam != null) {
            searchTerm = request.getRequestParameter("searchTerm").getString();
        }

        JSONObject json = this.getSuggestedSearch(searchTerm);
        response.setContentType("application/json");
        response.getWriter().write(json.toString());
    }

    private JSONObject getSuggestedSearch(String searchTerm) {
        JSONObject jsonObject = null;

        try {
            this.httpClient = HttpClientBuilder
                    .create()
                    .setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
                    .setMaxConnTotal(32).build();
            final HttpGet getRequest = new HttpGet(SOLR_HOST + searchTerm);

            final URI uri = new URIBuilder(getRequest.getURI()).build();
            getRequest.setURI(uri);
            getRequest.addHeader("Accept", "application/json");

            if (logger.isDebugEnabled()) logger.debug("SOLR Query URL: " + getRequest);

            final HttpResponse response = httpClient.execute(getRequest);

            if (response.getStatusLine().getStatusCode() != 200) {
                logger.error("SOLR query returned non 200 response: " + response.getStatusLine().getStatusCode());
                logger.error("SOLR Response: " + CharStreams.toString(new InputStreamReader(response.getEntity().getContent(), Charsets.UTF_8)));
                return null;
            }

            jsonObject = getJSONObject(response);

        } catch (IOException e) {
            logger.error("IOException while calling getSuggestedSearch", e);
        } catch (IllegalStateException e) {
            logger.error("IllegalStateException while calling getSuggestedSearch", e);
        } catch (URISyntaxException e) {
            logger.error("URISyntaxException while calling getSuggestedSearch", e);
        } catch (JSONException e) {
            logger.error("JSONException while calling getSuggestedSearch", e);
        }

        return jsonObject;
    }

    /**
     * Get a JSONObject from a http response
     * @param response
     * @return
     * @throws IOException
     * @throws JSONException
     */
    private JSONObject getJSONObject(final HttpResponse response) throws IOException, JSONException {
        final StringWriter writer = new StringWriter();
        IOUtils.copy(response.getEntity().getContent(), writer, "UTF-8");
        if(logger.isDebugEnabled())logger.debug("SOLR Query Response: "+new GsonBuilder().setPrettyPrinting().create().toJson(new JsonParser().parse(writer.toString()).getAsJsonObject()));
        final JSONObject responseObj = new JSONObject(writer.toString());
        return responseObj;
    }
}
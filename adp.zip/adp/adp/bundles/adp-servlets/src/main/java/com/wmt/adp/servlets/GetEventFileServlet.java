package com.wmt.adp.servlets;

import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.utils.DateUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;

/**
 * --------------------------------------------------------------------------------------
 * GetEventFileServlet
 * --------------------------------------------------------------------------------------
 * Composes an .ics file based on an event details from the page properties
 * --------------------------------------------------------------------------------------
 * Change History
 * --------------------------------------------------------------------------------------
 * Version | Date          | Developer       | Changes
 * 1.0     | 11/29/2017    | VN93135         | Initial Creation
 * --------------------------------------------------------------------------------------
 */
@SlingServlet(
        paths = "/bin/adp/events/data",
        methods = "POST",
        extensions = "json",
        metatype = false
)
public class GetEventFileServlet extends SlingAllMethodsServlet {

    private static final Logger logger = LoggerFactory.getLogger(GetEventFileServlet.class);
    public static final String DATETIME_FORMAT_NO_DASH = "yyyyMMdd'T'HHmmss";

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/calendar");
        response.setHeader("Content-Disposition", "attachment; filename=\"event.ics\"");

        String path = request.getParameter("path");
        String location = request.getParameter("location") + "\r\n";
        String description = request.getParameter("title") + "\r\n";
        Page page = request.getResourceResolver().getResource(path).adaptTo(Page.class);
        Calendar calendarStart = page.getProperties().get("eventStarts", Calendar.class);
        Calendar calendarEnd = page.getProperties().get("eventEnds", Calendar.class);
        String eventStarts = DateUtils.getFormattedDate(calendarStart, DATETIME_FORMAT_NO_DASH) + "\r\n";
        String eventEnds = DateUtils.getFormattedDate(calendarEnd, DATETIME_FORMAT_NO_DASH) + "\r\n";

        String BEGIN_VC = "BEGIN:VCALENDAR\r\n";
        String PRODID = "PRODID:-//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN\r\n";
        String VERSION = "VERSION:2.0\r\n";
        String METHOD = "METHOD:PUBLISH\r\n";
        String X_MS_OLK_FOR = "X-MS-OLK-FORCEINSPECTOROPEN:TRUE\r\n";
        String BEGIN_E = "BEGIN:VEVENT\r\n";
        String UID = "UID:10234562\r\n";
        String CLASS_P = "CLASS:PUBLIC\r\n";
        String DESCRIPTION = "DESCRIPTION:" + description;
        String DTEND = "DTEND:" + eventEnds;
        String LOCATION = "LOCATION:" + location;
        String DTSTART = "DTSTART:" + eventStarts;
        String PRIORITY = "PRIORITY:5\r\n";
        String SEQUENCE = "SEQUENCE:0\r\n";
        String SUMMARY = "SUMMARY;LANGUAGE=en-gb:" + description;
        String TRANS = "TRANSP:OPAQUE\r\n";
        String X_ALT = "X-ALT-DESC;FMTTYPE=text/html:" + description;
        String X_MIC_CDO = "X-MICROSOFT-CDO-BUSYSTATUS:OOF\r\n";
        String X_MIC_CDO_IMP = "X-MICROSOFT-CDO-IMPORTANCE:1\r\n";
        String X_MIC_DIS = "X-MICROSOFT-DISALLOW-COUNTER:FALSE\r\n";
        String X_MS_OLK_ALL = "X-MS-OLK-ALLOWEXTERNCHECK:TRUE\r\n";
        String X_MS_OLK_CONF = "X-MS-OLK-CONFTYPE:0\r\n";
        String X_MIC_CDO_ALL = "X-MICROSOFT-CDO-ALLDAYEVENT:TRUE\r\n";
        String X_MIC_MSN = "X-MICROSOFT-MSNCALENDAR-ALLDAYEVENT:TRUE\r\n";
        String END_E = "END:VEVENT\r\n";
        String END_VC = "END:VCALENDAR\r\n";

        StringBuilder sb = new StringBuilder();
        sb.append(BEGIN_VC).append(PRODID).append(VERSION).append(METHOD).append(X_MS_OLK_FOR).append(BEGIN_E).
           append(UID).append(CLASS_P).append(DESCRIPTION).append(DTEND).append(LOCATION).append(DTSTART).
           append(PRIORITY).append(SEQUENCE).append(SUMMARY).append(TRANS).append(X_ALT).
           append(X_MIC_CDO).append(X_MIC_CDO_IMP).append(X_MIC_DIS).append(X_MS_OLK_ALL).append(X_MS_OLK_CONF).
           append(X_MIC_CDO_ALL).append(X_MIC_MSN).append(END_E).append(END_VC);

        OutputStream outputStream = response.getOutputStream();
        outputStream.write(sb.toString().getBytes());
        outputStream.flush();
        outputStream.close();
    }
}

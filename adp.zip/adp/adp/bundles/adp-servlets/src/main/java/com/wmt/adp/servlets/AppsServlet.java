package com.wmt.adp.servlets;

import com.wmt.adp.services.AppService;
import com.wmt.adp.services.ConstantsService;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SlingServlet(
        paths = {"/bin/adp/apps/paths","/bin/adp/apps/objects"},
        methods = {"PUT, GET"},
        extensions = "json",
        metatype = false
)
public class AppsServlet extends SlingAllMethodsServlet {
    private static final Logger logger = LoggerFactory.getLogger(AppsServlet.class);

    @Reference
    AppService appService;

    @Reference
    ConstantsService constantsService;

    private static final Map<String, String> baseHeaders = new HashMap<String, String>(){{
        put("X-Experience-API-Version", "1.0.3");
        put("Content-Type", "application/json");
    }};

    private static final String APPS_COOKIE_KEY  = "ADP-APPS";

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("user");
        String path = request.getRequestPathInfo().getResourcePath();

        String appsResult = "";
        if (user != null && !user.isEmpty()) {
            if (path.contains("apps/paths")) {
                appsResult = appService.getUserAppsPaths(user, request.getCookie(APPS_COOKIE_KEY));
            } else {
                appsResult = appService.getUserAppsJSON(user, request.getCookie(APPS_COOKIE_KEY));
            }
        }

        response.setContentType("application/json");
        response.getWriter().write(appsResult);
    }

    @Override
    protected void doPut(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("user");

        String result = "";
        if (user != null && !user.isEmpty()) {
            result = appService.putUserAppsJSON(user, request.getParameterValues("apps"));
        }

        response.setContentType("application/json");
        response.getWriter().write(result);
    }
}

package com.wmt.adp.servlets;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.NotificationService;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;

@SlingServlet(
        resourceTypes = {"adp/components/global/header"},
        methods = "GET",
        extensions = "json",
        metatype = false
)
public class NotificationServlet extends SlingSafeMethodsServlet {
	private static final Logger logger = LoggerFactory.getLogger(NotificationServlet.class);

	@Reference
	private NotificationService notificationService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		ResourceResolver resourceResolver = request.getResourceResolver();
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

		Page requestPage = pageManager.getContainingPage(request.getResource());
		Page languageRoot = PageUtils.getLanguageRoot(requestPage, pageManager);
		String languageRootPath = languageRoot.getPath();

		JSONObject json = notificationService.getNotifications(languageRootPath);
		response.setContentType("application/json");
		response.getWriter().write(json.toString());
	}

}
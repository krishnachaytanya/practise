package com.wmt.adp.servlets;

import com.wmt.adp.services.ADPEmailService;
import com.wmt.adp.services.SlackService;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SlingServlet(
        resourceTypes = {"adp/components/general/feedback"},
        selectors={"send"}
)
public class FeedbackServlet extends SlingAllMethodsServlet {
	private static String EMAIL_TEMPLATE_PATH = "/etc/notification/email/adp/feedback/emailTemplate.html";
    private static String SLACK_HOOK_PROPERTY = "slackHook";
    private static String SUBMIT_EMAIL_PROPERTY = "emailAddress";
    private static String SLACK_CHANNEL_PROPERTY = "channel";

	private String category;
	private String channel;
	private String message;
    private String slackHookUrl;
    private String submitEmail;

	@Reference
	private SlackService slackService;

	@Reference
    private ADPEmailService emailService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        category = request.getParameter("category");
        message = request.getParameter("message");
        ValueMap formResource = request.getResource().adaptTo(ValueMap.class);
        slackHookUrl = formResource.get(SLACK_HOOK_PROPERTY, "");
        submitEmail = formResource.get(SUBMIT_EMAIL_PROPERTY, "");
        channel = formResource.get(SLACK_CHANNEL_PROPERTY, "#adp");
        if (!channel.startsWith("#")) {
            channel = "#" + channel;
        }
        if(!slackHookUrl.isEmpty()) {
            sendSlackMessage();
        }
        if(!submitEmail.isEmpty()) {
            sendEmail();
        }
        response.sendError(200);
	}

	private void sendEmail() {
        Map<String, String> params = new HashMap<String, String>(){{
           put("category", category);
           put("message", message);
        }};
        emailService.sendEmail(EMAIL_TEMPLATE_PATH, params, null, submitEmail);
    }

    private void sendSlackMessage() {
        slackService.postFeedback(channel, message, category, slackHookUrl);
    }


}
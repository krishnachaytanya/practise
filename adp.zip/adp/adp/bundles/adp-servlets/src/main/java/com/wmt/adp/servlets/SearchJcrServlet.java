package com.wmt.adp.servlets;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.SearchJcrService;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;

@SlingServlet(
        resourceTypes = "adp/components/general/search/search-jcr",
        selectors = "searchResults",
        methods = "GET",
        extensions = "json",
        metatype = false
)

public class SearchJcrServlet extends SlingSafeMethodsServlet {
    private static final Logger logger = LoggerFactory.getLogger(SearchJcrServlet.class);

    @Reference
    private SearchJcrService searchJcrService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String[] selectors = request.getRequestPathInfo().getSelectors();
        String tags = "";
        RequestParameter tagsParam = request.getRequestParameter("tags");
        if (tagsParam != null) {
            tags = request.getRequestParameter("tags").getString();
        }

        ResourceResolver resourceResolver = request.getResourceResolver();
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

        Page requestPage = pageManager.getContainingPage(request.getResource());
        Page languageRoot = PageUtils.getLanguageRoot(requestPage, pageManager);
        String languageRootPath = languageRoot.getPath();

        JSONObject json = searchJcrService.getSearchResults(languageRootPath, selectors, tags, requestPage.getLanguage(false));

        response.setContentType("application/json");
        response.getWriter().write(json.toString());
    }
}

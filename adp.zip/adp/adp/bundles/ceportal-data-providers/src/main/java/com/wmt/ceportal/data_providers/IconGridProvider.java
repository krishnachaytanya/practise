package com.wmt.ceportal.data_providers;
import com.adobe.cq.sightly.WCMUsePojo;
import java.util.*;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;

public class IconGridProvider extends WCMUsePojo {
	private List<Map<String,String>> imagesList = new ArrayList<Map<String,String>>();

    public List<Map<String,String>> getImagesList() {
     
     return imagesList;
	}


    @Override
    public void activate() throws Exception {
     
	   ValueMap properties = getProperties(); 
       String[] pageValues = properties.get("pages", String[].class);

        if(pageValues!=null) {
          for (int index = 0; index < pageValues.length; index++) {
                JSONObject jsonObj = new JSONObject(pageValues[index].toString());

				Map<String,String> map = new LinkedHashMap<String,String>();
    			map.put("title"+index, jsonObj.getString("title"));
    			map.put("path"+index, jsonObj.getString("path"));
                String linkUrl = jsonObj.getString("linkURL");
                if(linkUrl!=null && (!linkUrl.contains("/content/") || linkUrl.startsWith("http"))) {
					map.put("linkURL"+index, linkUrl);
                }else {    
                map.put("linkURL"+index, linkUrl+".html");
                }    
       		    imagesList.add(map);

            }
        }    
    }
}


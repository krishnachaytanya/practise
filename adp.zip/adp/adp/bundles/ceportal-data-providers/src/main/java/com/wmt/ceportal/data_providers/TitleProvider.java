package com.wmt.ceportal.data_providers;

import com.adobe.cq.sightly.WCMUse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;


public class TitleProvider extends WCMUse {

  private String text;
  
  @Override
  public void activate() {
	text = getProperties().get("text","Default Title").toUpperCase();
  }

  public String getText() {
    return text;
  }
}
package com.wmt.ceportal.data_providers;

import com.adobe.cq.sightly.WCMUsePojo;
import java.util.*;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;

public class CarouselProvider extends WCMUsePojo {
    private String playSpeed;
	private List<Map<String,String>> imagesList = new ArrayList<Map<String,String>>();

    public List<Map<String,String>> getImagesList() {
     
     return imagesList;
	}

    public String getPlaySpeed() {
        return playSpeed;
    }


    @Override
    public void activate() throws Exception {
     
	   ValueMap properties = getProperties(); 
       playSpeed = properties.get("playSpeed", "");
       String[] pageValues = properties.get("pages", String[].class);

        if(pageValues!=null) {
          for (int index = 0; index < pageValues.length; index++) {
                JSONObject jsonObj = new JSONObject(pageValues[index].toString());

				Map<String,String> map = new LinkedHashMap<String,String>();
    			map.put("title"+index, jsonObj.getString("title"));
    			map.put("path"+index, jsonObj.getString("path"));
                map.put("description"+index, jsonObj.getString("description"));
                map.put("textOnButton"+index, jsonObj.getString("textOnButton"));
                map.put("imageOrVideo"+index, jsonObj.getString("imageOrVideo"));
                map.put("videoPath"+index, jsonObj.getString("videoPath"));
       		    imagesList.add(map);

            }
        }    
    }
}


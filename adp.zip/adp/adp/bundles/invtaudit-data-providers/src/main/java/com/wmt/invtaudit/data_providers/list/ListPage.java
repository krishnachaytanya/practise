package com.wmt.invtaudit.data_providers.list;

import com.adobe.cq.sightly.WCMUse;
import com.day.cq.wcm.api.Page;
import java.util.Iterator;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.resource.Resource;
import java.util.List;
import java.util.ArrayList;
import java.lang.Object;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.JSONArray;


public class ListPage extends WCMUse {
    private Iterator<Page> currentPageContent;
    private Page childPage;
    private Resource pageResource;
    private Resource childResource;
    private Iterator<Resource> childrenResources;
    private List<Resource> textResources;
    private List<Resource> imageResources;
    private List<String> childNames;
    private List<Object> images;
    private List<Object> texts;
    private List<String> parentNames;
    private String type;
    private Object name;
    private int depth;
    private int parentPages;
    private ValueMap data;
    private JSONArray content;
    private JSONObject container;
    private JSONArray children;
    private JSONObject child;
    private JSONObject object;
    
    @Override
    public void activate() throws Exception {
        currentPageContent = getCurrentPage().listChildren(null,true);
        textResources = new ArrayList<>();
        imageResources = new ArrayList<>();
        childNames = new ArrayList<>();
        parentNames = new ArrayList<>();
        images = new ArrayList<>();
        texts = new ArrayList<>();
        content = new JSONArray();
        object = new JSONObject();
        container = new JSONObject();
        parentPages = 0;
        while(currentPageContent.hasNext()) {
            childPage = currentPageContent.next();
            depth = childPage.getDepth();
            if(depth == 4){ //This is a parent page
                if(parentNames.isEmpty() != true){
                    object.put("parent", parentNames.get(parentPages));
                    parentPages += 1;
                }
                if(imageResources.isEmpty() != true){
                    for (Iterator<Resource> iter = imageResources.iterator(); iter.hasNext();) {
                        Resource imageResource = iter.next();
                        data = imageResource.getValueMap();
                        name = data.get("fileReference");
                        images.add(name);
                    }
                    if(images.size() < childNames.size()){
                        while(images.size() != childNames.size()){
                            Object padding = new Object();
                            padding = "";
                            images.add(padding);
                        }
                    }
                    imageResources = new ArrayList<>();
                }
                if(textResources.isEmpty() != true){
                    for (Iterator<Resource> iter = textResources.iterator(); iter.hasNext();) {
                        Resource textResource = iter.next();
                        data = textResource.getValueMap();
                        name = data.get("text").toString().replaceAll("\\<.*?>","");
                        name = name.toString().replace("\n","");
                        name = name.toString().replace("&nbsp;","");
                        texts.add(name);
                    }
                    if(texts.size() < childNames.size()){
                        while(texts.size() != childNames.size()){
                            Object padding = new Object();
                            padding = "";
                            texts.add(padding);
                        }
                    }
                    textResources = new ArrayList<>();
                }
                if(childNames.isEmpty() != true){
                    children = new JSONArray();
                    for(int i = 0; i < childNames.size(); i++){
                        child = new JSONObject();
                        if(childNames.get(i) != null){
                            child.put("childName", childNames.get(i));
                        }
                        if(texts.get(i) != null && texts.get(i) != ""){
                            child.put("text", texts.get(i));
                        }
                        if(images.get(i) != null && images.get(i) != ""){
                            child.put("imageReference", images.get(i));
                        }
                        children.put(i, child);
                    }
                    childNames = new ArrayList<>();
                    texts = new ArrayList<>();
                    images = new ArrayList<>();
                    object.put("children", children);
                }
                if(object.has("parent") == true && object.has("children") == true){
                    content.put(object);
                    object = new JSONObject();
                }
                parentNames.add(childPage.getName());
            }
            else{
                childNames.add(childPage.getName());
                childResource = childPage.getContentResource();
                childrenResources = childResource.listChildren();
                while(childrenResources.hasNext()){
                    pageResource = childrenResources.next();
                    type = pageResource.getResourceType();
                    if(type.equals("invaudit/components/image")){
                        imageResources.add(pageResource);
                    }
                    else if(type.equals("invaudit/components/text")){
                        textResources.add(pageResource);
                    }
                }
            }
        }
        object.put("parent", parentNames.get(parentPages));
        if(imageResources.isEmpty() != true){
            for (Iterator<Resource> iter = imageResources.iterator(); iter.hasNext();) {
                Resource imageResource = iter.next();
                data = imageResource.getValueMap();
                name = data.get("fileReference");
                images.add(name);
            }
            if(images.size() < childNames.size()){
                while(images.size() != childNames.size()){
                    Object padding = new Object();
                    padding = "";
                    images.add(padding);
                }
            }
        }
        if(textResources.isEmpty() != true){
            for (Iterator<Resource> iter = textResources.iterator(); iter.hasNext();) {
                Resource textResource = iter.next();
                data = textResource.getValueMap();
                name = data.get("text").toString().replaceAll("\\<.*?>","");
                name = name.toString().replace("\n","");
                name = name.toString().replace("&nbsp;","");
                texts.add(name);
            }
            if(texts.size() < childNames.size()){
                while(texts.size() != childNames.size()){
                    Object padding = new Object();
                    padding = "";
                    texts.add(padding);
                }
            }
        }
        if(childNames.isEmpty() != true){
            children = new JSONArray();
            for(int i = 0; i < childNames.size(); i++){
                child = new JSONObject();
                if(childNames.get(i) != null){
                    child.put("childName", childNames.get(i));
                }
                if(texts.get(i) != null && texts.get(i) != ""){
                    child.put("text", texts.get(i));
                }
                if(images.get(i) != null && images.get(i) != ""){
                    child.put("imageReference", images.get(i));
                }
                children.put(i, child);
            }
            childNames = new ArrayList<>();
            texts = new ArrayList<>();
            images = new ArrayList<>();
            object.put("children", children);
        }
        content.put(object);
        container.put("contents",content);
    }
    
    public String getContainer(){
        return container.toString();
    }
}

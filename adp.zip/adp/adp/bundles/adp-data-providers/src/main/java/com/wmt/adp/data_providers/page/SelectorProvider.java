package com.wmt.adp.data_providers.page;

import com.adobe.cq.sightly.WCMUsePojo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class SelectorProvider  extends WCMUsePojo {

    private static Logger logger = LoggerFactory.getLogger(SelectorProvider.class);

    private List<String> selectors;
    private Boolean isExternalized;

    @Override
    public void activate() throws Exception {
        this.selectors = Arrays.asList(getRequest().getRequestPathInfo().getSelectors());
        this.isExternalized = this.selectors.contains("externalized");
    }

    public Boolean getExternalized() {
        return isExternalized;
    }
}

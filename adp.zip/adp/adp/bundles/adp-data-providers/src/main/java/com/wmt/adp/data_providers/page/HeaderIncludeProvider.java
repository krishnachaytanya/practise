package com.wmt.adp.data_providers.page;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.stylesheets.LinkStyle;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import com.wmt.adp.services.utils.PageUtils;

/**
* @author Merkle / Axis41
*
*/
public class HeaderIncludeProvider extends WCMUsePojo {
	
	/** logger */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    /** HEADER_SUB_PATH */
    private static final String HEADER_SUB_PATH = "/tools/header/jcr:content/header";
    /** NOTIFICATION_INBOX_PATH */
    private static final String NOTIFICATION_INBOX_PATH = "/notifications";
    /** resourceResolver */
    private ResourceResolver resourceResolver;
    /** path */
    private String path;
    /** faviconPath */
    private String faviconPath;
    /** seeAllPath */
    private String seeAllPath;

	@Override
    public void activate() throws Exception {
    	resourceResolver 			= getResourceResolver();
    	path 						= PageUtils.getLanguageRoot(getCurrentPage(), getPageManager()).getPath() + HEADER_SUB_PATH;
    	
    	Resource faviconResource 	= resourceResolver.getResource(path + "/favicon");
    	faviconPath 				= ImageUtils.getImagePath(faviconResource);
    	
    	
    	Page languageRoot			= PageUtils.getLanguageRoot(getCurrentPage(), getPageManager());
    	Resource resource			= resourceResolver.resolve(languageRoot.getPath() + NOTIFICATION_INBOX_PATH);

    	
		seeAllPath = LinkUtils.formatLink(resource.getPath(), resourceResolver);

    }
    /**
     * return path
     */
    public String getPath() {
        return path;
    }
    /**
     * return faviconPath
     */
    public String getFaviconPath() {
	// returns the URL of the favicon of the site
    	return faviconPath;
    }
    /**
     * return seeAllPath
     */
    public String getSeeAllPath() {
		return seeAllPath;
	}
}

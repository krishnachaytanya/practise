package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.ValueMap;

import java.util.ArrayList;
import java.util.List;

public class CourseDescriptionProvider extends WCMUsePojo {

    private List<String> stars;
    private String duration;

    @Override
    public void activate() throws Exception {
        ValueMap pageProps = getPageProperties();

        String ratingProp = pageProps.get("rating", "0");
        float rating = Float.parseFloat(ratingProp);
        rating = Math.round(rating * 2) / 2.0f;

        stars = new ArrayList<>();
        for (int i = 1; i < 6; i++) {
            String star = "fa-star-o";

            if (rating >= i) {
                star = "fa-star";
            } else if (rating == i - .5) {
                star = "fa-star-half-o";
            }
            stars.add(star);
        }

        String durationProp = pageProps.get("duration", "00:00:00");
        String[] durationParts = durationProp.split(":");

        String durationFormatted = "";
        for (int i = 0; i < 3; i++) {
            int partInt = Integer.parseInt(durationParts[i]);

            if (partInt != 0) {
                durationFormatted += " " + partInt;

                if (i == 0) {
                    durationFormatted += "h";
                } else if (i == 1) {
                    durationFormatted += "m";
                } else if (i == 2) {
                    durationFormatted += "s";
                }
            }
        }
        duration = durationFormatted;
    }

    public List<String> getStars() {
        return stars;
    }

    public String getDuration() {
        return duration;
    }
}

package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.utils.LinkUtils;
import com.wmt.adp.services.utils.PageUtils;

public class LearningChecklistProvider extends WCMUsePojo {
	
	private List<Map<String, String>> checkListItems;
	private String homePagePath;
    private String gotItPath;
    private String gotItText;
    private final String DEFAULT_GOT_IT_TEXT = "GOT IT";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public void activate() throws Exception {
		String[] checkListItemstItemsString = getProperties().get("links", String[].class);
		readCheckListItemsJSON(checkListItemstItemsString);
		ResourceResolver resourceResolver = getResourceResolver();
        Page currentPage = getCurrentPage();
        Page rootPage = PageUtils.getLanguageRoot(currentPage, getPageManager());
        String rootPath = rootPage.getPath();
        homePagePath = LinkUtils.formatLink(rootPath, resourceResolver);
        gotItPath = LinkUtils.formatLink(getProperties().get("gotItPath", rootPath), resourceResolver);
        gotItText = getProperties().get("gotItText", DEFAULT_GOT_IT_TEXT);
		// TODO Auto-generated method stub
		
	}

	
	public String getHomePagePath() {
        return homePagePath;
    }
	
	public List<Map<String, String>> getCheckListItems() {
		return checkListItems;
	}

	private void readCheckListItemsJSON(String[] checkListItemstItemsString) {
    	checkListItems = new ArrayList<>();
        if (checkListItemstItemsString !=  null) {
            for (String jsonChunk: checkListItemstItemsString) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonChunk);
                    Map<String, String> map = new HashMap<>();
                    map.put("text", jsonObject.getString("text"));
                    checkListItems.add(map);
                } catch (JSONException e) {
                    logger.error("CheckListItems: Cannot parse json chunks", e);
                }
            }
        }
	}

    public String getGotItPath() {
        return gotItPath;
    }

    public String getGotItText() {
        return gotItText;
    }
}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by vn56264 on 7/25/2017.
 */
public class ArticleTeaserProvider extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String imagePath;
    private String ctaPath;
    private String layout;
    private String color;
    private String title;
    private String text;
    private String alignment;
    private String ctaTarget;
    private String ctaText;


    @Override
    public void activate() throws Exception {
        ValueMap properties = getProperties();
        imagePath = ImageUtils.getImagePath(getResource());
        ctaPath = LinkUtils.formatLink(properties.get("ctaPath", "#"), getResourceResolver());
        layout = properties.get("layout", String.class);
        color = properties.get("color", String.class);
        title = properties.get("title", String.class);
        text = properties.get("text", String.class);
        alignment = properties.get("alignment", String.class);
        ctaTarget = properties.get("ctaTarget", String.class);
        ctaText = properties.get("ctaText", String.class);
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getCtaPath() { return ctaPath; }

    public String getLayout() {
        return layout;
    }

    public String getColor() {
        return color;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getAlignment() {
        return alignment;
    }

    public String getCtaTarget() {
        return ctaTarget;
    }

    public String getCtaText() {
        return ctaText;
    }
}

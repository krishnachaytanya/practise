package com.wmt.adp.data_providers.page;

import com.adobe.cq.sightly.WCMUsePojo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BodyProvider extends WCMUsePojo {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private String templateClass;

    @Override
    public void activate() throws Exception {
        String[] templatePathParts = getProperties().get("cq:template", "").split("/");
        templateClass = templatePathParts[templatePathParts.length-1];
    }

    public String getTemplateClass() {
        return templateClass;
    }
}

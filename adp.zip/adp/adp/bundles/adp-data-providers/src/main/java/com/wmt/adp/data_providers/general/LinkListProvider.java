package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.NavigationItem;
import com.wmt.adp.services.ListSearchService;
import com.wmt.adp.services.utils.LinkUtils;

/**
 * Created by vn61291 on 8/04/2017.
 */
public class LinkListProvider extends WCMUsePojo {

    /** tagSearchService */
    private ListSearchService tagSearchService;
    /** title */
    private String title;
    /** path */
    private String path;
    /** childProperties */
    private ValueMap childProperties;
    /** parentPath */
    private String parentPath;
    /** linkListType */
    private String linkListType;
    /** revealBox */
    private String revealBox;
    /** linkListItems */
    private List<Map<String, String>> linkListItems;
    /** childLinkList */
    private List<NavigationItem> childLinkList;
    /** childLinkListPojo */
    private List<com.wmt.adp.services.pojos.NavigationItem> childLinkListPojo;
    /** logger */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void activate() throws Exception {


        Resource childResource = getResource().getChild("title");
		if ( childResource != null ) {
           childProperties = childResource.adaptTo(ValueMap.class);
           this.title = childProperties.get("text", " ");          
		}
        this.linkListType = getProperties().get("linkListType", "");
        if( getProperties().get("revealBox", "") != null 
                && getProperties().get("revealBox", "").equals("on")) {
            this.revealBox = "true";
        } else {
            this.revealBox = "false";
        }
        if (linkListType.equals("manual")) {
            Resource childResLinks = getResource().getChild("links");
            readLinkListItems(childResLinks);
        } else if (linkListType.equals("tag")) {
            String[] tags = getProperties().get("tags", String[].class);
            if (tags.length > 0) {
                tagSearchService = getSlingScriptHelper().getService(ListSearchService.class);
                childLinkListPojo = tagSearchService.getTagSearch(tags, "/content");
            }
        } else {
            this.parentPath = getProperties().get("parentPath", "");
            Page parentPage = getPageManager().getContainingPage(parentPath);
            if (parentPage != null) {
                childLinkList = new ArrayList<>();
                Iterator<Page> rootPageIterator = parentPage.listChildren();
                while (rootPageIterator.hasNext()) {
                    childLinkList.add(buildNavigationItem(rootPageIterator.next()));
                }
            }
        }


    }

    /**
     * @return path
     */
    public String getPath() {

        return this.path;
    }

    /**
     * @return title
     */
    public String getTitle() {

        return this.title;
    }

    /**
     * @return parentPath
     */
    public String getParentPath() {

        return parentPath;
    }

    /**
     * @return linkListType
     */
    public String getLinkListType() {

        return linkListType;
    }

    /**
     * @return linkListItems
     */
    public List<Map<String, String>> getLinkListItems() {

        return linkListItems;
    }

    /**
     * @return childLinkList
     */
    public List<NavigationItem> getChildLinkList() {

        return childLinkList;
    }

    /**
     * Method readLinkListItems
     */
    private void readLinkListItems(Resource childResLinks) {

        linkListItems = new ArrayList<>();
        try {
            Iterator<Resource> iterLinks = childResLinks.getChildren()
                                                        .iterator();
            while (iterLinks.hasNext()) {
                Resource linkRes = iterLinks.next();
                Node nodeLink = linkRes.adaptTo(Node.class);
                Map<String, String> map = new HashMap<>();
                map.put("text", 
                        nodeLink.getProperty("text").getString());
                path = LinkUtils.
                        formatLink(nodeLink.getProperty("path")
                        .getString(),getResourceResolver());
                map.put("path", path);
                map.put("target", nodeLink.getProperty("target")
                                          .getString());
                linkListItems.add(map);

            }
        } catch (RepositoryException e) {
            logger.error(" RepositoryException " + e.getMessage());
        }

    }

    /**
     * Method buildNavigationItem creates a new NavigationItem from Page Object
     * @return NavigationItem
     */
    private NavigationItem buildNavigationItem(Page page) {

        NavigationItem navigationItem = new NavigationItem();
        navigationItem.setTitle(page.getTitle());
        navigationItem.setPath(page.getPath() + ".html");
        return navigationItem;
    }

    /**
     * @return revealBox
     */
    public String getRevealBox() {

        return revealBox;
    }

    /**
     * @return childLinkListPojo
     */
    public List<com.wmt.adp.services.pojos.NavigationItem> getChildLinkListPojo() {

        return childLinkListPojo;
    }

}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.ArticleItem;
import com.wmt.adp.services.ListSearchService;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import com.wmt.adp.services.utils.PropertyUtil;
import com.wmt.adp.services.TagService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by vn61291 on 8/04/2017.
 */
public class ArticleListProvider extends WCMUsePojo {

    /** tagSearchService */
    private ListSearchService tagSearchService;
    private ResourceResolver resourceResolver;
    private String articleListType;
    private List<HashMap<String, String>> articleListPaths;
    private List<ArticleItem> articleListItems;
    private TagService tagService;


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void activate() throws Exception {
        ValueMap props = getProperties();
        articleListType = props.get("articleListType", "");
        articleListItems = new ArrayList<>();
        resourceResolver = getResourceResolver();
        tagService = getSlingScriptHelper().getService(TagService.class);

        if (articleListType.equals("parent")) {
            String parentPath = props.get("parentPath", String.class);
            if (parentPath != null) {
                Resource folderResource = resourceResolver.getResource(parentPath);
                Iterator<Resource> children = folderResource.listChildren();
                while (children.hasNext()) {
                    Resource child = children.next();
                    Page childPage = child.adaptTo(Page.class);

                    if (childPage != null) {
                        articleListItems.add(buildArticleItem(childPage));
                    }
                }
            }
        } else if (articleListType.equals("manual")) {
            articleListPaths = PropertyUtil.getMultifieldArray(props.get("articleListManual", String[].class));
            for (Map<String, String> map: articleListPaths) {
                Resource pageResource = resourceResolver.getResource(map.get("path"));

                if (pageResource != null) {
                    Page articlePage = pageResource.adaptTo(Page.class);

                    if (articlePage != null) {
                        articleListItems.add(buildArticleItem(articlePage));
                    }
                }
            }
        }else if (articleListType.equals("tag")) {
            String[] tags = getProperties().get("tags", String[].class);
            if (tags.length > 0) {
                List<String> resources = tagService.getTaggedResourcePaths("/content", tags, true);

                for (String path: resources) {
                    Resource res = resourceResolver.getResource(path);
                    Page node = res.getParent().adaptTo(Page.class);
                    articleListItems.add(buildArticleItem(node));
                }
            }
        }
        sortList((ArrayList<ArticleItem>) articleListItems);
    }

	private void sortList(ArrayList<ArticleItem> articles) {
		Collections.sort(articles);
	}
    
    private ArticleItem buildArticleItem(Page page) {
        ValueMap pageProps = page.getProperties();
        ArticleItem articleItem = new ArticleItem();

        articleItem.setTitle(pageProps.get("jcr:title", ""));
        articleItem.setDescription(pageProps.get("jcr:description", ""));
        articleItem.setPath(LinkUtils.formatLink(page.getPath(), resourceResolver));
        articleItem.setTags(tagService.getTagStringList(page.getPath()));

        Calendar bestDate = DateUtils.getBestDate(page);
        /*--- The date format has to be the same used in the comparator in ArticleItem (SEARCH_FORMAT) ---*/
        articleItem.setDate(DateUtils.getFormattedDate(bestDate, DateUtils.SEARCH_FORMAT));
        
        Resource imageResource = page.getContentResource("image");
        articleItem.setThumbnail(ImageUtils.getImagePath(imageResource));

        return articleItem;
    }

    public List<ArticleItem> getArticleListItems() {
        return articleListItems;
    }

}

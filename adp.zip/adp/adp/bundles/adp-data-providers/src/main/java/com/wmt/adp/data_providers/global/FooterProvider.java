package com.wmt.adp.data_providers.global;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by vn56264 on 7/25/2017.
 */
public class FooterProvider extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private List<Map<String, String>> links;
    private String imagePath;
    private String copyrightText;
    private ValueMap properties;
    private ResourceResolver resourceResolver;
    private Externalizer externalizer;

    @Override
    public void activate() throws Exception {
        resourceResolver = getResourceResolver();
        externalizer = this.resourceResolver.adaptTo(Externalizer.class);
        List<String> selectors = Arrays.asList(getRequest().getRequestPathInfo().getSelectors());
        boolean externalized = selectors.contains("externalized");

        properties = getProperties();
        String[] linksString = properties.get("links", String[].class);
        readLinksJSON(linksString, externalized);

        imagePath = isExternalized(ImageUtils.getImagePath(getResource()), externalized, null);

        insertYear(properties.get("copyrightText",""));
    }

    private String isExternalized(String path, boolean externalize, Page page) {
        if(page != null && page.getProperties() != null && page.getProperties().get("cq:template", String.class).equals("/apps/adp/templates/link-page")){
            return page.getProperties().get("external_link", String.class);
         }else if(externalize && !this.externalizer.equals(null) && !path.equals("")) {
            return LinkUtils.externalizeUrl(path, this.externalizer, this.resourceResolver);
        }
        return path;
    }

    private void readLinksJSON(String[] linksString, boolean externalized) {
        links = new ArrayList<>();
        if (linksString !=  null) {
            for (String jsonChunk: linksString) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonChunk);
                    Map<String, String> map = new HashMap<>();
                    map.put("text", jsonObject.getString("text"));
                    String path = jsonObject.getString("path");
                    PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
                    path = LinkUtils.formatLink(path, getResourceResolver());
                    path = isExternalized(path, externalized, pageManager.getPage(path));
                    map.put("path", path);
                    map.put("target", jsonObject.getString("target"));
                    links.add(map);
                } catch (JSONException e) {
                    logger.error("Cannot parse json chunks", e);
                }
            }
        }
    }

    private void insertYear(String copyrightTextString) {
        int year = Calendar.getInstance().get(Calendar.YEAR);
        copyrightText = copyrightTextString.replace("{{year}}", year + "");
    }

    public List<Map<String, String>> getLinks() {
        return links;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getCopyrightText() {
        return copyrightText;
    }


}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class FeedbackProvider extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String iconPath;
    private String slackChannel;
    private String submitEmail;
    private LinkedHashSet<String> issues;

    @Override
    public void activate() {
        ValueMap properties = getProperties();
        this.iconPath = ImageUtils.getImagePath(getResource());
        this.slackChannel = properties.get("slackChannel", "");
        this.submitEmail = properties.get("emailAddress", "");
        String[] issueOptions = getProperties().get("options", String[].class);
        retrieveIssueOptions(issueOptions);
    }

    public String getIconPath() {
        return iconPath;
    }

    public String getSlackChannel() {
        return slackChannel;
    }

    public String getSubmitEmail() {
        return submitEmail;
    }

    public LinkedHashSet<String> getIssues() { return issues; }


    /**
     * Parses the multifield values.
     * @param options of issues
     */
    private void retrieveIssueOptions(String[] options) {
        issues = new LinkedHashSet<>();
        if (options !=  null) {
            for (String issue : options) {
                try {
                    JSONObject jsonObject = new JSONObject(issue);
                    issues.add(jsonObject.getString("issue"));
                } catch (JSONException e) {
                    logger.error("Error creating jsonObject from a string", e);
                }
            }
        }
    }    
}

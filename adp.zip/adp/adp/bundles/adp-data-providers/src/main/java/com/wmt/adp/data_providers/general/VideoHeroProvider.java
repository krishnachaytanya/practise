package com.wmt.adp.data_providers.general;

import java.util.Calendar;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.utils.CommonsUtils;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;

/**
 * Created by vn61291 on 9/08/2017.
 */
public class VideoHeroProvider extends WCMUsePojo {

    private String title;
    private String author;
    private String initials;
    private String publishDate;
	private String path;
    private String imagePath;
    private static final String DEFAULT_AUTHOR = "Unknown";
    
    @Override
    public void activate() throws Exception {
		this.path = getProperties().get("path","");
		this.setImagePath(ImageUtils.getImagePath(getResource()));
		if(path.length() > 0){
			Page videoPage = getPageManager().getContainingPage(path);
			this.path = LinkUtils.formatLink(path, getResourceResolver());
	    	this.title = (String) getProperties().get("title", videoPage.getTitle());
	    	this.author = videoPage.getProperties().get("author", DEFAULT_AUTHOR).toString();
	    	this.initials = CommonsUtils.extractInitials(this.author);
	    	Calendar articleDate = (Calendar) videoPage.getProperties().get("publishDate", Calendar.class);
	    	this.setPublishDate(DateUtils.getformattedDateWithSufix(articleDate));
		}
		
    }

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}

package com.wmt.adp.data_providers.general;

import com.day.cq.commons.Filter;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;

public class EventPageFilter implements Filter {
	
	@Override
	public boolean includes(Object element) {
		Page p = (Page) element;
		return (p.getProperties().get(NameConstants.NN_TEMPLATE, "").equals("/apps/adp/templates/events"));
	}
}

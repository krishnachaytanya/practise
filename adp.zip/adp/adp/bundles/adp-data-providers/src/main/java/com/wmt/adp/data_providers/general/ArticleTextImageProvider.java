package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;

/**
 * Created by vn61291 on 9/07/2017.
 */
public class ArticleTextImageProvider extends WCMUsePojo {

    private String imagePath;

    private String imageLink;

    @Override
    public void activate() throws Exception {
        imagePath = ImageUtils.getImagePath(getResource());
        imageLink =  LinkUtils.formatLink(getProperties().get("imageLink",String.class),this.getResourceResolver());
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getImageLink() { return imageLink; }
}

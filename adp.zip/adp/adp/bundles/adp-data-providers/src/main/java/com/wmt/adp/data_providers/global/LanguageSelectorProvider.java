package com.wmt.adp.data_providers.global;

import static com.wmt.adp.services.Constants.FOOTER_SUB_PATH;
import static com.wmt.adp.services.Constants.IGNORE_PAGE_CONTENT;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import com.wmt.adp.services.utils.PageUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.LanguageService;
import com.wmt.adp.services.pojos.LanguageItem;
import com.wmt.adp.services.utils.LinkUtils;

public class LanguageSelectorProvider extends WCMUsePojo {
    private static final Logger logger = LoggerFactory.getLogger( LanguageSelectorProvider.class );

    static private final String SDL_TOGGLE_PROPERTY = "enableTranslationService";

    private LanguageItem selectedLang;
    private Collection<LanguageItem> defaultLanguages;
    private ResourceResolver resourceResolver;

    @Override
    public void activate() throws Exception {
        resourceResolver = getResourceResolver();

        boolean isSDLEnable = IsSDLSeriveEnable( getCurrentPage() );

        // default languages from top locale paths in content tree
        List<LanguageItem> available = null;
        if (!isSDLEnable) {
            available = loadAvailablesLangs(getCurrentPage(), getPageManager());
            Collections.sort(available);
            setDefaultLanguages(available);
        } else {
            // dynamically available languages from ETS server
            LanguageService languageService = getSlingScriptHelper().getService(LanguageService.class);
            if (languageService == null) {
                logger.error("Missing language service.");
            } else {
                List<LanguageItem> others = languageService.loadOtherLangs(getCurrentPage(), getPageManager());
                int nOthers = (others != null ? others.size() : 0);

                logger.info("Languages to translate {} ", nOthers);
                Locale currentLocale = getCurrentPage().getLanguage( IGNORE_PAGE_CONTENT );
                String defaultLangPath = LinkUtils.formatLink(getCurrentPage().getPath(), resourceResolver);
                LanguageItem langPage = new LanguageItem("en", "English", true, defaultLangPath, "ca");
                setSelectedLang(langPage);
                others.add(langPage);
                Collections.sort(others);
                setDefaultLanguages(others);
            }
        }
    }  // activate

    /**
     * @return the current language / country based on the current page path
     */
    public LanguageItem getSelectedLang() {
        return selectedLang;
    }

    /**
     * @param selectedLang the current language / country to set
     */
    private void setSelectedLang(LanguageItem selectedLang) {
        this.selectedLang = selectedLang;
    }

    /**
     * @return the available language / countries from the current page
     */
    public Collection<LanguageItem> getDefaultLanguages() {
        return defaultLanguages;
    }

    /**
     * @param defaultLanguages  the available language / countries from the current page to set
     */
    private void setDefaultLanguages( Collection<LanguageItem> defaultLanguages) {
        this.defaultLanguages = defaultLanguages;
    }


    /**
     * Add the children under the path: {@code /content/adp/}
     * that respect the Locale standard name format as available
     * language option. i.e: en_us, en_ca, fr_ca
     * @param currentPage   the current page
     * @param pageManager   the page manager
     * @return sorted available locales of content
     */
    private List<LanguageItem> loadAvailablesLangs(Page currentPage, PageManager pageManager){
        List<LanguageItem> defaultLanguages = new ArrayList<LanguageItem>();
        Locale currentLocale = currentPage.getLanguage( IGNORE_PAGE_CONTENT );

        Page rootPath = PageUtils.getSiteRoot( getCurrentPage() );
        Iterator<Page> languagePages = rootPath.listChildren();
        while (languagePages.hasNext()) {
            Page page = languagePages.next();
            if ( page.getName().contains("_") ) {
                Locale locale = page.getLanguage(true);
                String urlToFordward = getFordwardLanguagePage(currentPage, page);
                boolean isSelected = (locale.getLanguage().equals( currentLocale.getLanguage() ) && locale.getCountry().equals( currentLocale.getCountry() ) );
                LanguageItem langPage = new LanguageItem(locale.getLanguage(), locale.getDisplayLanguage(locale), isSelected, urlToFordward, locale.getCountry().toLowerCase());
                if ( isSelected ) {
                    setSelectedLang(langPage);
                }
                defaultLanguages.add( langPage );
            } // page
        } // languagePages

        Collections.sort(defaultLanguages);
        return defaultLanguages;
    }
	
	/**
	 * Check if exists the currentPage in the corresponding language
	 * if not returns the homePage in the other language
	 * @param currentPage The page to evaluate
	 * @param page The attempting language
	 * @return The page in the corresponding language
	 */
	private String getFordwardLanguagePage(Page currentPage, Page page){
		String langPrefix = currentPage.getLanguage(true).getLanguage()+"_"+currentPage.getLanguage(true).getCountry().toLowerCase();
		String langSelected = page.getLanguage(true).getLanguage()+"_"+page.getLanguage(true).getCountry().toLowerCase();
		if(!langPrefix.equals("")){
			String pathToAttempt = currentPage.getPath().replaceFirst(Pattern.quote("/"+langPrefix), "/"+langSelected);
			Resource resource = resourceResolver.getResource(pathToAttempt);
			if(resource != null){
				return LinkUtils.formatLink(pathToAttempt, resourceResolver);
			}
		}
		return LinkUtils.formatLink(page.getPath(), resourceResolver);
	}

    /**
     * Retrieves the SDL Service property -
     * which determines whether to translate pages
     * @param currentPage
     * @return a true | false value
     */
	private boolean IsSDLSeriveEnable(final Page currentPage) {
	    boolean isSDLEnable = false;
        Page rootPath = currentPage.getAbsoluteParent(2);
        String footerPath = rootPath.getPath() + FOOTER_SUB_PATH;
        Resource footerNode = resourceResolver.getResource(footerPath);
        if (null != footerNode) {
            ValueMap valueMap = footerNode.getValueMap();
            if (valueMap.containsKey(SDL_TOGGLE_PROPERTY)) {
                String isSDLService = valueMap.get(SDL_TOGGLE_PROPERTY).toString();
                if (isSDLService.equals("true")) {
                    isSDLEnable = Boolean.valueOf(isSDLService);
                }
            }
        }
        return isSDLEnable;
    }
}

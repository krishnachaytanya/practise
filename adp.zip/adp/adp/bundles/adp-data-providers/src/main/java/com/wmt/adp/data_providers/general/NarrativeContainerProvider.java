package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.Resource;

import java.util.Iterator;

/**
 * --------------------------------------------------------------------------------------
 * NarrativeContainerProvider
 * --------------------------------------------------------------------------------------
 * Retrieves the number of narrative slides inserted into the parsys and returns the count
 * -­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-‐
 * Change History
 * --------------------------------------------------------------------------------------
 * Version | Date           | Developer       | Changes
 * 1.0     | 12/28/2017     | vn93135         | Initial Creation
 * --------------------------------------------------------------------------------------
 */

public class NarrativeContainerProvider extends WCMUsePojo {

    private Integer slidesInserted = 0;
    private String slidesPath;

    @Override
    public void activate() throws Exception {
        slidesPath = getResource().getChild("parsys").getPath();
    }

    /**
     * Determines the amount of slides inserted into the narrative container
     * @return the number of slidesInserted
     */
    public Integer getSlidesInserted() {
        Resource slidesParent = getResourceResolver().getResource(slidesPath);
        Iterator<Resource> slides = slidesParent.listChildren();
        while (slides != null && slides.hasNext()) {
            slides.next();
            slidesInserted += 1;
        }
        return slidesInserted;
    }
}

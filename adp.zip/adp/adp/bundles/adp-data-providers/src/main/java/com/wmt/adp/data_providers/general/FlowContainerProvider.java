package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import com.adobe.cq.sightly.WCMUsePojo;

public class FlowContainerProvider extends WCMUsePojo{
	
	private List<Map<String, String>> flowFrameList;
	private String firstFrameTitle;
	
	@Override
	public void activate() throws Exception {
		firstFrameTitle = "";
		flowFrameList = new ArrayList<>();
		Iterable<Resource> childListFlowFrames = getResource().getChild("par").getChildren();

		for (Resource resource : childListFlowFrames) {
			ValueMap properties = resource.adaptTo(ValueMap.class);
			Map<String, String> map = new HashMap<>();
			
			if (firstFrameTitle.equals("")) {
				firstFrameTitle = properties.get("title", "Frame title");
			}

			if (properties.get("hide", "false").equals("false")) {
				map.put("hide", "false");
			} else {
                map.put("hide", "true");
			}

			map.put("title", (properties.get("title", "Frame title")));
			map.put("id", resource.getName());
			
			flowFrameList.add(map);
		} 
	}
	
	public List<Map<String, String>> getFlowFrameList() {
		return flowFrameList;
	}
	
	public String getFirstFrameTitle() {
		return firstFrameTitle;
	}
}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.DateUtils;

import java.util.Calendar;

/**
 * --------------------------------------------------------------------------------------
 * FormatEventDateProvider
 * --------------------------------------------------------------------------------------
 * Provides a formatted date for the event details
 * -­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-‐
 * Change History
 * --------------------------------------------------------------------------------------
 * Version | Date         | Developer       | Changes
 * 1.0     | 12/1/2017    | VN93135         | Initial Creation
 * --------------------------------------------------------------------------------------
 */
public class FormatEventDateProvider extends WCMUsePojo {
    private String eventDate;

    @Override
    public void activate() throws Exception {
        if (getCurrentPage().getProperties().get("eventStarts") != null) {
            Calendar eventDateCal = (Calendar) getCurrentPage().getProperties().get("eventStarts", Calendar.class);
            Long eventDateL = eventDateCal.getTimeInMillis();
            this.setEventDate(DateUtils.getFormattedDate(eventDateL, "MMM d, yyyy"));
        }
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
}

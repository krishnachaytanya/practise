package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.LinkItem;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

public class BreadcrumbProvider extends WCMUsePojo {
	
	private List<LinkItem> navList = new ArrayList<LinkItem>();
	private boolean isRootPage;
	
	@Override
	public void activate() throws Exception {
		getBreadcrumbLinks();
	}
	
	/**
	 * Method to get the breadcrumb links.
	 * 
	 * @param page
	 *            Actual page
	 * 
	 * @return List of links
	 */
	private void getBreadcrumbLinks() {
		setIsRootPage(false);
		Page actualPage = getCurrentPage();

		// Get the path of the links for the current page
		while (actualPage!= null && actualPage.getDepth() > 2) {
			navList.add(getBreadcrumbLinkFromPage(actualPage));
			actualPage = actualPage.getParent();
		}
		if(navList.size() == 1){
			setIsRootPage(true);
		}
		// Reverse the list of links
		Collections.reverse(navList);
	}


	/**
	 * Method to adapt a page into a BreadcrumbLink object.
	 * 
	 * @param page
	 *            Actual Page
	 * 
	 * @return BreadcrumbLink object
	 */
	private LinkItem getBreadcrumbLinkFromPage(Page page) {
		LinkItem newBreadcrumbLink = new LinkItem();

		newBreadcrumbLink.setLink(page.getPath());
		newBreadcrumbLink.setTitle(PageUtils.getTitle(page));

		return newBreadcrumbLink;
	}
	
	public List<LinkItem> getNavList(){
		return navList;
	}

	public boolean getIsRootPage() {
		return isRootPage;
	}

	public void setIsRootPage(boolean isRootPage) {
		this.isRootPage = isRootPage;
	}

}
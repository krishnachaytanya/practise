package com.wmt.adp.data_providers.pojos;


/**
 * Created by jlopez on 30/10/17.
 */
public class FeaturedAppsItem  {
	
	private String title;
	private String path;
	private String iconImage;
	private String linkPath;
	private String description;	
    private String backColor;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIconImage() {
		return iconImage;
	}

	public void setIconImage(String iconImage) {
		this.iconImage = iconImage;
	}

	public String getLinkPath() {
		return linkPath;
	}

	public void setLinkPath(String linkPath) {
		this.linkPath = linkPath;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

    
    public String getBackColor() {
    
        return backColor;
    }

    
    public void setBackColor(String backColor) {
    
        this.backColor = backColor;
    }



}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.google.common.collect.Iterators;
import com.wmt.adp.services.utils.LinkUtils;
import com.wmt.adp.services.utils.PropertyUtil;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CoursePlaylistProvider extends WCMUsePojo {

    private ResourceResolver resourceResolver;
    private ArrayList<HashMap<String, String>> frames = new ArrayList<>();
    private List<String> uniqueAccountIds;

    private final String LEARNING_CHECK_CONTAINER_RELPATH = "par/learning-check-container";
    private final String LEARNING_CHECK_QUESTIONS_RELPATH = LEARNING_CHECK_CONTAINER_RELPATH + "/learning-par";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void activate() throws Exception {
        ValueMap props = getProperties();
        resourceResolver = getResourceResolver();

        String[] framesProperty = props.get("frames", String[].class);

        if (framesProperty != null) {
            frames = PropertyUtil.getMultifieldArray(framesProperty);
            frames = new ArrayList<>(frames.subList(0, Math.min(frames.size(), 10)));

            Set<String> uniqueAccountIdsSet = new HashSet<String>();
            for (HashMap<String, String> frame : frames) {
                String frameType = frame.get("type");
                String learningCheckPath = frame.get("learningCheckPath");
                String brightcoveURL = frame.get("brightcoveURL");

                if ("learningCheck".equals(frameType)) {
                    String learningCheckTitle = "";
                    String learningCheckDuration = "";
                    String learningCheckContainerPath = "";

                    if (!"".equals(learningCheckPath)) {
                        Resource learningCheckPageResource = resourceResolver.getResource(learningCheckPath);
                        frame.put("learningCheckLink", LinkUtils.formatLink(learningCheckPath, resourceResolver));

                        if (learningCheckPageResource != null) {
                            Page learningCheckPage = learningCheckPageResource.adaptTo(Page.class);
                            learningCheckTitle = learningCheckPage.getTitle();

                            Resource questionContainer = learningCheckPage.getContentResource(LEARNING_CHECK_QUESTIONS_RELPATH);
                            if (questionContainer != null) {
                                learningCheckContainerPath = learningCheckPath + "/jcr:content/" + LEARNING_CHECK_CONTAINER_RELPATH;
                                Iterator<Resource> questionsIterator = questionContainer.listChildren();

                                int questionCount = Iterators.size(questionsIterator);
                                learningCheckDuration = questionCount + " question" + (questionCount == 1 ? "" : "s");
                            }
                        }
                    }

                    frame.put("itemTitle", learningCheckTitle);
                    frame.put("itemDuration", learningCheckDuration);
                    frame.put("learningCheckContainerPath", learningCheckContainerPath);
                } else if ("brightcove".equals(frameType)) {
                    Pattern videoIDPattern 		= Pattern.compile("videoId=(\\d+)");
                    Matcher videoIDMatcher 		= videoIDPattern.matcher(brightcoveURL);

                    Pattern accountIDPattern 	= Pattern.compile("brightcove.net/(\\d+)/");
                    Matcher accountIDMatcher 	= accountIDPattern.matcher(brightcoveURL);

                    if (videoIDMatcher.find()) {
                        frame.put("brightcoveID", videoIDMatcher.group(1));
                    }

                    if (accountIDMatcher.find()) {
                        frame.put("brightcoveAccountId", accountIDMatcher.group(1));
                        uniqueAccountIdsSet.add(accountIDMatcher.group(1));
                    }
                }
            }
            uniqueAccountIds = new ArrayList<>(uniqueAccountIdsSet);
        }
    }

    public ArrayList<HashMap<String, String>> getFrames() {
        return frames;
    }

    public List<String> getUniqueAccountIds() {
        return uniqueAccountIds;
    }
    
}

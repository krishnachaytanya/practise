package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.wmt.adp.data_providers.pojos.DownloadListItem;
import com.wmt.adp.services.TagService;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by vn56264 on 7/25/2017.
 */
public class DownloadListProvider extends WCMUsePojo {

    private static Logger logger = LoggerFactory.getLogger(DownloadListProvider.class);
    private TagService tagService;

    private ResourceResolver resourceResolver;
    private ArrayList<DownloadListItem> downloadItems;

    @Override
    public void activate() throws Exception {

        resourceResolver = getResourceResolver();
        tagService = getSlingScriptHelper().getService(TagService.class);

        downloadItems = new ArrayList<>();
        String listType = getProperties().get("listType", "");
        if (listType.equals("manual")) {
            if(getResource().hasChildren() && null != getResource().getChild("lists") && getResource().getChild("lists").hasChildren()){
                Iterator<Resource> children = getResource().getChild("lists").listChildren();
                while (children.hasNext()) {
                    Resource child = children.next();
                    String assetPath = child.getValueMap().get("path",String.class);
                    Resource assetResource = resourceResolver.getResource(assetPath);
                    Asset asset = assetResource.adaptTo(Asset.class);
                    if (asset != null) {
                        downloadItems.add(buildDownloadListItem(asset));
                    }
                }
            }
        } else if (listType.equals("tag")) {
            String[] tags = getProperties().get("tags", String[].class);
            if (tags != null && tags.length > 0) {
                downloadItems.addAll(getTagSearch(tags, "/content/dam"));
            }
        } else {
            String folderPath = getProperties().get("path", String.class);
            if (folderPath != null) {
                Resource folderResource = resourceResolver.getResource(folderPath);
                Iterator<Resource> children = folderResource.listChildren();
                while (children.hasNext()) {
                    Resource child = children.next();
                    Asset childAsset = child.adaptTo(Asset.class);
                    if (childAsset != null) {
                        downloadItems.add(buildDownloadListItem(childAsset));
                    }
                }
            }
        }
    }

    private List<DownloadListItem> getTagSearch(String[] tags, String searchPath){
        List<DownloadListItem> tagList = new ArrayList<>();
        try {
            List<String> resourcePaths = tagService.getTaggedResourcePaths(searchPath, tags, true);
            for(String resourcePath : resourcePaths) {
                Resource res = resourceResolver.getResource(resourcePath);
                if (res != null) {
                    Asset asset = res.getParent().getParent().adaptTo(Asset.class);
                    downloadItems.add(buildDownloadListItem(asset));
                }
            }
        } catch (Exception e) {
            logger.error("getTagSearch: ", e);
        }
        return tagList;
    }

    private DownloadListItem buildDownloadListItem(Asset asset) {
        DownloadListItem downloadListItem = new DownloadListItem();

        String path = asset.getPath();
        path = LinkUtils.formatLink(path, resourceResolver);
        downloadListItem.setPath(path);

        // fall back to name if no title
        String title = asset.getMetadataValue("dc:title");
        if (title == null) {
            title = asset.getName();
        }
        downloadListItem.setTitle(title);

        // fall back to format if no Fileformat
        String type = asset.getMetadataValue("dam:Fileformat");
        if (type == null) {
            //something like application/pdf
            String format = asset.getMetadataValue("dc:format");
            int slashPosition = format.indexOf("/");
            if (slashPosition > 0 && slashPosition + 1 < format.length()) {
                type = format.substring(slashPosition + 1);
            } else {
                type = format;
            }
        }
        downloadListItem.setType(type);

        String description = asset.getMetadataValue("dc:description");
        downloadListItem.setDescription(description);

        Long time = asset.getLastModified();

        downloadListItem.setDate(DateUtils.getFormattedDate(time, DateUtils.SEARCH_FORMAT));
        downloadListItem.setTags(tagService.getAssetTags(path));

        return  downloadListItem;
    }

    public ArrayList<DownloadListItem> getDownloadItems() {
        return downloadItems;
    }
}
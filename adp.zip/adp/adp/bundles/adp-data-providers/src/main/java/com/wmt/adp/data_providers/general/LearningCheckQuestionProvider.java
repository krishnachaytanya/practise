package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.PropertyUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;

/**
 * Created by jvought on 10/30/17.
 */
public class LearningCheckQuestionProvider extends WCMUsePojo {

    private String answerType;
    private String question;
    private List<HashMap<String, String>> answers;
    private String correctAnswer;


    private String correctResponse;
    private String incorrectResponse;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void activate() throws Exception {
        ValueMap properties = getProperties();
        question = properties.getOrDefault("question", "Input a question.").toString();
        answerType = properties.get("answerType", "single");
        correctResponse = properties.getOrDefault("correctResponse", "Enter correct response.").toString();
        incorrectResponse = properties.getOrDefault("incorrectResponse" , "Enter incorrect response.").toString();
        correctAnswer = properties.getOrDefault("correctAnswer", "something").toString();
        answerTypeCheck(properties);
    }

    public String getIncorrectResponse() { return incorrectResponse; }

    public String getCorrectResponse() { return correctResponse; }

    public String getQuestion() { return question; }

    public String getAnswerType() { return answerType; }

    public List<HashMap<String, String>> getAnswers() { return answers; }

    public String getCorrectAnswer() { return correctAnswer; }

    //validate which type of answer the question is; single or multiple.
    private void answerTypeCheck(ValueMap properties) {
        String[] type = null;
        if (answerType.equals("single")) {
            type = properties.get("singleAnswerList", String[].class);
        } else if (answerType.equals("multiple")) {
            type = properties.get("multipleAnswerList", String[].class);
        }
        if(type != null) {
                answers = PropertyUtil.getMultifieldArray(type);
        }
    }

}

package com.wmt.adp.data_providers.general;

import java.util.Calendar;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.CommonsUtils;
import com.wmt.adp.services.utils.DateUtils;

/**
 * Created by vn61291 on 9/08/2017.
 */
public class VideoDetailsProvider extends WCMUsePojo {

    private String title;
    private String author;
    private String initials;
    private String publishDate;

    @Override
    public void activate() throws Exception {
    	this.title = (String) getProperties().get("title", getCurrentPage().getTitle());
    	this.author = getCurrentPage().getProperties().getOrDefault("author", CommonsUtils.DEFAULT_AUTHOR).toString();
    	this.initials = CommonsUtils.extractInitials(this.author);
    	Calendar articleDate = (Calendar) getCurrentPage().getProperties().get("publishDate", Calendar.class);
    	this.setPublishDate(DateUtils.getformattedDateWithSufix(articleDate));
    }

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	
}

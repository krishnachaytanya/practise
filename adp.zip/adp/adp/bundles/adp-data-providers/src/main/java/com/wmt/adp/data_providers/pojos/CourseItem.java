package com.wmt.adp.data_providers.pojos;

public class CourseItem {
	
	
    private String title;
    private String date;
    private String description;
    private String path;
    private String level;
	private String duration;
    private String thumbnail;
    private Boolean hideLevel;
    
    public Boolean getHideLevel() {
		return hideLevel;
	}

	public void setHideLevel(Boolean hideLevel) {
		this.hideLevel = hideLevel;
	}

	public Boolean getHideDate() {
		return hideDate;
	}

	public void setHideDate(Boolean hideDate) {
		this.hideDate = hideDate;
	}

	public Boolean getHideDuration() {
		return hideDuration;
	}

	public void setHideDuration(Boolean hideDuration) {
		this.hideDuration = hideDuration;
	}

	private Boolean hideDate;
    private Boolean hideDuration;
    
    public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}



    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }


}

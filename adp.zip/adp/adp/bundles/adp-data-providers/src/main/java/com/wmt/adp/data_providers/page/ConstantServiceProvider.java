package com.wmt.adp.data_providers.page;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.ConstantsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by jvought on 10/10/17.
 */

public class ConstantServiceProvider extends WCMUsePojo{
    private static Logger logger = LoggerFactory.getLogger(ConstantServiceProvider.class);

    private String dtmUrl;
    private String userLogoutUrl;
    private String externalizerBaseUrl;

    @Override
    public void activate() throws Exception {
        ConstantsService constantsService = getSlingScriptHelper().getService(ConstantsService.class);
        dtmUrl = constantsService.getDtmUrl();
        userLogoutUrl = constantsService.getUserLogoutUrl();
        externalizerBaseUrl = constantsService.getExternalizedBaseUrl();
    }

    public String getDtmUrl() { return dtmUrl; }
    public String getUserLogoutUrl() { return userLogoutUrl; }

    public String getExternalizerBaseUrl() {
        return externalizerBaseUrl;
    }
}

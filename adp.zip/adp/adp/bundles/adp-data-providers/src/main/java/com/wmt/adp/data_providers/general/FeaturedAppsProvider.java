package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.FeaturedAppsItem;
import com.wmt.adp.services.utils.LinkUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Merkle / Axis41
 *
 */
public class FeaturedAppsProvider extends WCMUsePojo {
    /** logger */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    /** resourceResolver */
    private ResourceResolver resourceResolver;
    /** resolverFactory */
    @Reference
    private ResourceResolverFactory resolverFactory;
    /** resourceResolver */
    private List<FeaturedAppsItem> featureListItems;

    @Override
    public void activate() throws Exception {

        featureListItems = new ArrayList<>();
        resourceResolver = getResourceResolver();
        logger.info("START FeaturedAppsProvider");
        
        Resource childResLinks = getResource().getChild("links");
        List<String> lstResultPages = readFeaturedItems(childResLinks);
        
        featureListItems = lstResultPages.stream()
                                         .map(strPages -> strPages.replaceAll(".html", ""))
                                         .map(urlObj -> getResourceResolver().getResource(urlObj))
                                         .map(objRes -> objRes.adaptTo(Page.class))
                                         .map(objPage -> buildFeatureItem(objPage))
                                         .collect(Collectors.toList());
    }
    
    
    /**
     * Method readFeaturedItems
     */
    private List<String> readFeaturedItems(Resource childResLinks) {

        List<String> lstResultPages = new ArrayList<>();
        try {
            Iterator<Resource> iterLinks = childResLinks.getChildren()
                                                        .iterator();
            while (iterLinks.hasNext()) {
                Resource linkRes = iterLinks.next();
                Node nodeLink = linkRes.adaptTo(Node.class);

                String path = LinkUtils.
                        formatLink(nodeLink.getProperty("path")
                        .getString(),getResourceResolver());
                lstResultPages.add(path);
            }
        } catch (RepositoryException e) {
            logger.error(" RepositoryException " + e.getMessage());
        }
        return lstResultPages;

    }

    /**
     * Method to get properties of the page app
     * @param page
     * @return
     */
    private FeaturedAppsItem buildFeatureItem(Page page) {

        String color = "";
        ValueMap pageProps = page.getProperties();
        FeaturedAppsItem featureItem = new FeaturedAppsItem();
        featureItem.setTitle(pageProps.get("jcr:title", ""));
        featureItem.setPath(LinkUtils.formatLink(pageProps.get("appLink", ""), resourceResolver));
        featureItem.setIconImage(pageProps.get("icon", ""));
        color = pageProps.get("appColor", "");
        if( color != null ) {
            color = color.equals("blue")?"blue-bck":"grey-bck";
        } else {
            color = "blue-bck";
        }
        featureItem.setBackColor(color);
        return featureItem;
    }

    /**
     * @return featureListItems
     */
    public List<FeaturedAppsItem> getFeatureListItems() {

        return featureListItems;
    }

}
package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;

public class TileProvider extends WCMUsePojo{

    private String title;
    private String description;
    private String imagePath;
    private String ctaPath;
    private String ctaText;
    private String color;
    private boolean isFullWidth = false;


    @Override
    public void activate() throws Exception {

        if(getProperties().containsKey("isFullWidth"))
            isFullWidth = getProperties().get("isFullWidth", Boolean.class);


        this.title = (String) getProperties().get("title","" );
        this.description = (String) getProperties().get("description","");
        this.ctaText = (String) getProperties().get("ctaText", "");
        this.color = (String) getProperties().get("color", "");
        imagePath = ImageUtils.getImagePath(getResource());
        ctaPath = LinkUtils.formatLink(getProperties().get("ctaPath", "#"), getResourceResolver());

        // TODO Auto-generated method stub

    }

    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public String getImagePath() {
        return imagePath;
    }


    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }


    public String getCtaPath() {
        return ctaPath;
    }


    public void setCtaPath(String ctaPath) {
        this.ctaPath = ctaPath;
    }


    public String getCtaText() {
        return ctaText;
    }


    public void setCtaText(String ctaText) {
        this.ctaText = ctaText;
    }


    public String getColor() {
        return color;
    }


    public void setColor(String color) {
        this.color = color;
    }

    public boolean getIsFullWidth() {
        return isFullWidth;
    }

}

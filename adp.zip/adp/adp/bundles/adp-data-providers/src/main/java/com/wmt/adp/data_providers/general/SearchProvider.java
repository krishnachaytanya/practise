package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.data_providers.pojos.ArticleItem;
import com.wmt.adp.services.TagService;
import com.wmt.adp.services.TemplateService;
import com.wmt.adp.services.pojos.ContentTag;
import com.wmt.adp.services.pojos.ContentTemplate;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SearchProvider extends WCMUsePojo {

    private List<ContentTag> tags;
    private List<ContentTemplate> templates;
    private TagService tagService;
    private TemplateService templateService;
    private String searchResultPath;

    private static final String SEARCH_PAGE_RESOURCE_TYPE = "adp/components/page/search";

    @Override
    public void activate() throws Exception {
        String tagRoot = getCurrentPage().getProperties().get("parentTag", "");
        tags = new ArrayList<>();

        tagService = getSlingScriptHelper().getService(TagService.class);
        tags = tagService.getAllTags(tagRoot, getCurrentPage().getLanguage(false));

        templateService = getSlingScriptHelper().getService(TemplateService.class);
        templates = templateService.getAllSearchableTemplates();
    }

	private void sortList(ArrayList<ArticleItem> articles) {
		Collections.sort(articles);
	}

    public List<ContentTag> getTags() {
        return tags;
    }

    public List<ContentTemplate> getTemplates() {
        return templates;
    }

    /**
     * Retrieves '/content/adp/{language}/{searchPage}' path.
     * @return searchResultPath string
     */
    public String getSearchResultPath() {
        PageManager pageManager = getResourceResolver().adaptTo(PageManager.class);
        Page languageRoot = PageUtils.getLanguageRoot(getCurrentPage(), pageManager);
        Iterator<Page> pageIterator = languageRoot.listChildren();

        while (null != pageIterator && pageIterator.hasNext()) {
            Page page = pageIterator.next();
            ValueMap properties = page.getProperties();
            if (SEARCH_PAGE_RESOURCE_TYPE
                    .equals(properties.get(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, ""))) {
                searchResultPath = page.getPath();
                break;
            }
        }
        return searchResultPath;
    }
}

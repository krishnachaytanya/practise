package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.designer.Style;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.wmt.adp.data_providers.pojos.TabItem;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class QuickActionTabsProvider extends WCMUsePojo {

    private List<TabItem> tabs;
    private List<TabItem> visibleTabs;
    private int tabsAmount;
    private Resource resource;
    private List<Resource> parsysTabs;
    private static final String  CONTAINER_PARSYS_PREFIX_NAME = "parsys_tab_";
    private static final String TITLE_RESOURCE_TYPE = "adp/components/general/title";

    @Override
    public void activate() throws Exception {
        this.resource = getResource();
        Style currentStyle = getCurrentStyle();
        this.tabsAmount = Integer.parseInt(currentStyle.get("maxAllowedTabs", "5"));
        this.tabs  =  new ArrayList<>();
        processTabs();
    }

    private void processTabs() {
        //Initialize
        this.visibleTabs = new ArrayList<>();
        for (int i = 0; i < this.tabsAmount; i++){
            tabs.add(new TabItem());
        }
        List<Resource> children = Lists.newArrayList(this.resource.getChildren().iterator());
        getContainerParsys(children);

        for (Resource resource: this.parsysTabs) {
            if(resource.hasChildren()){
                Resource childResource = Iterators.get(resource.getChildren().iterator(), 0);
                if(childResource != null && childResource.getResourceType().equals(TITLE_RESOURCE_TYPE)) {
                    ValueMap titleProperties = childResource.getValueMap();
                    String title = titleProperties.get("text", String.class);
                    if(!title.isEmpty()) {
                        setTitleToCurrentTab(resource, title);
                    }
                } else {
                    if(childResource.hasChildren()){
                        Resource titleResource = childResource.getChild("title");
                        if(titleResource != null) {
                            ValueMap titleProperties = titleResource.getValueMap();
                            String title = titleProperties.get("text", String.class);
                            if(!title.isEmpty()) {
                                setTitleToCurrentTab(resource, title);
                            }
                        }
                    }
                }
            }
        }
    }

    private void setTitleToCurrentTab(Resource resource, String title) {
        int tabSuffix = Integer.parseInt(resource.getName().replace(CONTAINER_PARSYS_PREFIX_NAME, ""));
        TabItem tab = tabs.get(tabSuffix);
        tab.setTitle(title);
        tab.setVisible(true);
        visibleTabs.add(tab);
    }

    private void getContainerParsys(List<Resource> mainList) {
        this.parsysTabs = mainList.stream().filter(resource -> resource != null && resource.getName().startsWith(CONTAINER_PARSYS_PREFIX_NAME) && resource.getResourceType().equals("foundation/components/parsys")).collect(Collectors.toList());
    }

    public List<TabItem> getTabs() {
        return tabs;
    }

    public List<TabItem> getVisibleTabs() {
        return visibleTabs;
    }
}

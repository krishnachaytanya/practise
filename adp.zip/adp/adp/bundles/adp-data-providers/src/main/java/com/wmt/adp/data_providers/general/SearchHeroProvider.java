package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by vn0007s on 2/16/2018.
 */
public class SearchHeroProvider extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String imagePath;

    @Override
    public void activate() throws Exception {
        imagePath   = ImageUtils.getImagePath(getResource());
    }

    public String getImagePath() {
        return imagePath;
    }

}

package com.wmt.adp.data_providers.general;

import org.apache.sling.api.resource.ValueMap;
import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;

public class NarrativeSlide extends WCMUsePojo {

    private String title;
    private String text;
    private String color;
    private String imagePath;
    
    @Override
	public void activate() throws Exception {
    	ValueMap properties = getProperties();
    	
    	setTitle(properties.get("title", ""));
    	setText(properties.get("text", ""));
    	setColor(properties.get("color", ""));
    	setImagePath(ImageUtils.getImagePath(getResource()));
	}
    
    public String getTitle() {
		return title;
	}
    
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public String getImagePath() {
		return imagePath;
	}
	
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
}
package com.wmt.adp.data_providers.general;

import java.util.Calendar;
import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.CommonsUtils;

public class PageAlertProvider extends WCMUsePojo {

	private boolean isAlertVisible;
	private String alertText;
	
	@Override
	public void activate() throws Exception {
		alertText = getCurrentPage().getProperties().get("alertText","");
        Calendar alertOnTime = getCurrentPage().getProperties().get("alertOnTime", Calendar.class);
        Calendar alertOffTime = getCurrentPage().getProperties().get("alertOffTime", Calendar.class);
        setAlertVisible(CommonsUtils.checkPageAlerts(alertText, alertOnTime, alertOffTime));
	}

	public boolean isAlertVisible() {
		return isAlertVisible;
	}

	public void setAlertVisible(boolean isAlertVisible) {
		this.isAlertVisible = isAlertVisible;
	}
	
	public String getAlertText() {
		return alertText;
	}

	public void setAlertText(String alertText) {
		this.alertText = alertText;
	}

}

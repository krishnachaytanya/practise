package com.wmt.adp.data_providers.general;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.ArticleItem;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.ImageUtils;

import java.util.List;
import java.util.ArrayList;

public class RelatedArticlesProvider extends WCMUsePojo {

	private List<ArticleItem> articleListItems;
	
	@Override
	public void activate() throws Exception {
		// TODO Auto-generated method stub
		articleListItems = new ArrayList<>();
		String pageOneLink= getProperties().get("page1", "");
		if(pageOneLink!="")
		{
			Page pageOne= getPageManager().getContainingPage(pageOneLink);
			articleListItems.add(buildArticleItem(pageOne));
		}
		String pageTwoLink= getProperties().get("page2", "");
		if(pageTwoLink!="")
		{
			Page pageTwo= getPageManager().getContainingPage(pageTwoLink);
			articleListItems.add(buildArticleItem(pageTwo));
		}
		String pageThreeLink= getProperties().get("page3", "");
		if(pageThreeLink!="")
		{
			Page pageThree= getPageManager().getContainingPage(pageThreeLink);
			articleListItems.add(buildArticleItem(pageThree));
		}
		String pageFourLink= getProperties().get("page4", "");
		if(pageFourLink!="")
		{
			Page pageFour= getPageManager().getContainingPage(pageFourLink);
			articleListItems.add(buildArticleItem(pageFour));
		}
	}
	
	 private ArticleItem buildArticleItem(Page page) {
		ValueMap pageProps = page.getProperties();
	 	ArticleItem articleItem = new ArticleItem();
	 	
	 	articleItem.setTitle(pageProps.get("jcr:title", ""));
	 	articleItem.setPath(page.getPath() + ".html");
	 	
	 	Long publishDate = pageProps.get("publishDate", Long.class);
	 	
        if (publishDate != null) {
            articleItem.setDate(DateUtils.getFormattedDate(publishDate));
        }
        
        Resource imageResource = page.getContentResource("image");
        articleItem.setThumbnail(ImageUtils.getImagePath(imageResource));
        
        if(isVideo(pageProps.get("cq:template", ""))) {
            articleItem.setTags("Video");
		} else {
	 		articleItem.setTags("Article");
		}
		
	 	return articleItem;
	 }
	

    public List<ArticleItem> getArticleListItems() {
        return articleListItems;
    }
    
    public boolean isVideo(String pathTemplate) {
        String[] articleType = pathTemplate.split("/");
        return (articleType[articleType.length-1].equals("video"));
    }
    
	public void setArticleListItems(List<ArticleItem> articleListItems) {
		this.articleListItems = articleListItems;
	}
}
package com.wmt.adp.data_providers.general; /**
 * 
 */
// package apps.adp.components.general.htmlform;  // com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.dam.commons.util.DamUtil;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 *  HTML Form as DAM asset
 */
public class HtmlFormDataProvider extends WCMUsePojo {
    private static final Logger logger = LoggerFactory.getLogger(HtmlFormDataProvider.class);
    
    private String sourcePath = "";

    @Override
    public void activate() {
        sourcePath = (String) getProperties().get( "sourcePath", "" );

        logger.info("Got html form source '{}'.", sourcePath );
    }

    /**
     * @return the form content, if found
     */
    public String getContent() {
        String tmp = getOriginalContent( sourcePath, getResourceResolver() );

        logger.info("Got {} len form from path '{}'.", (tmp != null ? tmp.length() : 0), sourcePath );
        return tmp;
    }

    private static String getOriginalContent( String path, ResourceResolver resourceResolver) {
      BufferedReader br = null;

      try {
          Resource formResource = resourceResolver.getResource( path );
          Asset fileAsset = DamUtil.resolveToAsset( formResource );
          Rendition orig = ( fileAsset != null ?  fileAsset.getOriginal() : null);
        
          if ( fileAsset == null ) {
              logger.error("Missing HTML Form at '{}'.", path );
              return null;
          } // fileAsset
        
          InputStream inStream = orig.getStream();

          br = new BufferedReader( new InputStreamReader( inStream, "UTF-8" ) );

          return  br.lines().collect( Collectors.joining( "\n") );

      } catch (Exception ex) {
          logger.error("Resolve HTML Form '{}' error {}.", path, ex.getMessage() );
      } finally {
          if (br != null) {
              try {
                  br.close();
              } catch (IOException ex) {
                logger.error( "HTML Form '{}' IO close Error: ", path, ex.getMessage() );
              } // try
          } // br
      } // try

        return null;
    }
    
    
}

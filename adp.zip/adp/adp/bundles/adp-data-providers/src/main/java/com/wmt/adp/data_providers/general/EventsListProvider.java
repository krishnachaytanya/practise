package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.data_providers.pojos.EventPage;
import com.wmt.adp.services.TagService;
import com.wmt.adp.services.pojos.ContentTag;
import com.wmt.adp.services.utils.PageUtils;

public class EventsListProvider extends WCMUsePojo {
    private ContentTag[] tags;
    private List<EventPage> events;
    
    private ResourceResolver resourceResolver; 
    private PageManager pageManager;
	private Resource currentResource;
	private Page currentPage;
    private TagService tagService;
    
	@Override
    public void activate() throws Exception {
		currentResource 	= getResource();
		resourceResolver 	= getResourceResolver();
		pageManager 		= resourceResolver.adaptTo(PageManager.class);
		currentPage 		= pageManager.getContainingPage(currentResource);
        tagService 			= getSlingScriptHelper().getService(TagService.class);
		
		setTags();
		searchEvents();
    }

	public ContentTag[] getTags() {
		return tags;
	}

	public List<EventPage> getEvents() {
		return events;
	}

	private void setTags() {
	// set the sets of available tags
		List<ContentTag> tagsList = tagService.getAllTags("canada:events", currentPage.getLanguage(false));
		
		tags = new ContentTag[tagsList.size()];
		tagsList.toArray(tags);
	}
	
	private void searchEvents() {
	// sets the set of events
		Page rootPage 			= PageUtils.getLanguageRoot(currentPage, pageManager);
		Iterator<Page> it;
		Calendar date;
		ValueMap props;
		
		events 		= new ArrayList<EventPage>();
		it 			= rootPage.listChildren(new EventPageFilter(), true);
		
		while (it.hasNext()) {
			currentPage 	= (Page) it.next();
			props 			= currentPage.getProperties();
			date  			= props.get("eventEnds", Calendar.class);
			
			if (date.compareTo(Calendar.getInstance()) >= 0) {
				events.add(new EventPage(currentPage, resourceResolver, tagService));
			}
		}
	}
}
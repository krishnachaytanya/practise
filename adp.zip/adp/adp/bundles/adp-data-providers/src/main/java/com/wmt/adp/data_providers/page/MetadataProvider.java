package com.wmt.adp.data_providers.page;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.TagService;
import com.wmt.adp.services.TemplateService;
import com.wmt.adp.services.pojos.ContentTemplate;
import com.wmt.adp.services.utils.DateUtils;

import java.util.Calendar;

/**
 * @author Merkle / Axis41
 */
public class MetadataProvider extends WCMUsePojo {

    private String template;
    private String tags;
    private String publishDate;
    private String fullIdTags;

    @Override
    public void activate() throws Exception {
        Page currentPage = getCurrentPage();

        /** Tag Service */
        TagService tagService = getSlingScriptHelper().getService(TagService.class);

        /** Template Service */
        TemplateService templateService = getSlingScriptHelper().getService(TemplateService.class);

        /** Content Service */
        ContentTemplate contentTemplate = templateService
                .getContentTemplate(getPageProperties().get("cq:template", String.class));

        /** Current Page Date */
        Calendar calendar = DateUtils.getBestDate(currentPage);

        template = contentTemplate.getSearchFacetTitle();

        publishDate = DateUtils.getFormattedDate(calendar, DateUtils.ISO_DATETIME_FORMAT);

        tags = tagService.getTagStringList(getCurrentPage().getPath());

        fullIdTags = tagService.getFullIdStringList(getCurrentPage().getPath());

    }

    /** @return template */
    public String getTemplate() {
        return template;
    }

    /** @return tags */
    public String getTags() {
        return tags;
    }

    /** @return publishDate */
    public String getPublishDate() {
        return publishDate;
    }

    /** @return fullIdTags */
    public String getFullIdTags() {
        return fullIdTags;
    }
}

package com.wmt.adp.data_providers.global;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.wmt.adp.data_providers.pojos.NavigationItem;
import com.wmt.adp.services.ConstantsService;
import com.wmt.adp.services.utils.CommonsUtils;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import com.wmt.adp.services.utils.PageUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by vn56264 on 7/25/2017.
 */
public class HeaderProvider extends WCMUsePojo {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String DEFAULT_ROOT_PAGE = "/content/adp/en_ca";

    private static final String PROFILE_RESOURCE_TYPE = "adp/components/global/profile";
    private static final String HEADER_ROOT_RESOURCE_PATH = "/tools/header/jcr:content/header";
	private static final int MAX_COUNT = 7;

    private String imagePath;
    private String homePagePath;
    private String searchPagePath;
    private List<NavigationItem> pages;
    private String globalAlertText;
    private boolean isGlobalAlertVisible;
    private String userLogoutUrl;
    private ResourceResolver resourceResolver;
    private Externalizer externalizer;
    private String searchPage;
    private boolean isAppsHidden;
    private boolean isProfileHidden;

    @Override
    public void activate() throws Exception {
        ConstantsService constantsService = getSlingScriptHelper().getService(ConstantsService.class);
        resourceResolver = getResourceResolver();
        globalAlertText = getProperties().get("alertText","");
        setHiddenFeatures();
        Calendar alertOnTime =  getProperties().get("alertOnTime", Calendar.class);
        Calendar alertOffTime =  getProperties().get("alertOffTime", Calendar.class);
        setGlobalAlertVisible(CommonsUtils.checkPageAlerts(globalAlertText, alertOnTime, alertOffTime));
        searchPage = getProperties().get("searchPagePath", String.class);
        List<String> selectors = Arrays.asList(getRequest().getRequestPathInfo().getSelectors());
        processUrls(constantsService, selectors.contains("externalized"));
    }

    private String isExternalized(String path, boolean externalize, Page page) {
    	if(page != null && page.getProperties() != null && page.getProperties().get("cq:template", "").equals("/apps/adp/templates/link-page")){
              return page.getProperties().get("external_link", String.class);
        }else{
            if(externalize && !this.externalizer.equals(null) && !path.equals("")) {
                 return LinkUtils.externalizeUrl(path, this.externalizer, this.resourceResolver);
            }
        }
        return path;
    }

    private void setHiddenFeatures() {
        Resource currentResource = getResource();
        ValueMap properties = getProperties();
        if(currentResource.getResourceType().equals(this.PROFILE_RESOURCE_TYPE)) {
           String languagePath = PageUtils.getLanguageRoot(getCurrentPage(), getPageManager()).getPath();
           Resource parentHeader = this.resourceResolver.getResource(languagePath + this.HEADER_ROOT_RESOURCE_PATH);
            properties = parentHeader.getValueMap();
            this.isAppsHidden = properties.get("hideApps", false);
            this.isProfileHidden = properties.get("hideProfile", false);
        } else {
            this.isAppsHidden = properties.get("hideApps", false);
            this.isProfileHidden = properties.get("hideProfile", false);
        }
    }

    private void processUrls(ConstantsService constantsService, boolean externalized) {
        externalizer = this.resourceResolver.adaptTo(Externalizer.class);

        userLogoutUrl = isExternalized(constantsService.getUserLogoutUrl(), externalized, null);
        imagePath = isExternalized(ImageUtils.getImagePath(getResource()), externalized, null);

        Page currentPage = getCurrentPage();
        Page rootPage = PageUtils.getLanguageRoot(currentPage, getPageManager());
        homePagePath = isExternalized(LinkUtils.formatLink(rootPage.getPath(), resourceResolver), externalized, rootPage);
        searchPagePath = isExternalized(LinkUtils.formatLink(searchPage, resourceResolver), externalized, null);

        Iterator<Page> pageIterator = rootPage.listChildren(new PageFilter(false, false)); // skip invalid and hidden pages
        pages = new ArrayList<>();
        String tempPath;
        while(pageIterator.hasNext()) {
            Page firstLayerPage = pageIterator.next();

            NavigationItem firstLayerNav = new NavigationItem();
            tempPath = LinkUtils.formatLink(firstLayerPage.getPath(), resourceResolver);
            firstLayerNav.setPath(isExternalized(tempPath, externalized, firstLayerPage));
            firstLayerNav.setTitle(PageUtils.getTitle(firstLayerPage));

            List<NavigationItem> secondLayerNavs = new ArrayList<>();
            Iterator<Page> secondLayerIterator = firstLayerPage.listChildren(new PageFilter(false, false)); // skip invalid and hidden pages
            while (secondLayerIterator.hasNext()) {
                Page secondLayerPage = secondLayerIterator.next();
                NavigationItem secondLayerNav = new NavigationItem();
                tempPath = LinkUtils.formatLink(secondLayerPage.getPath(), resourceResolver);
                secondLayerNav.setPath(isExternalized(tempPath, externalized, secondLayerPage));
                secondLayerNav.setTitle(PageUtils.getTitle(secondLayerPage));
                secondLayerNavs.add(secondLayerNav);

                List<NavigationItem> thirdLayerNavs = new ArrayList<>();
                Iterator<Page> thirdLayerIterator = secondLayerPage.listChildren(new PageFilter(false, false));
                while (thirdLayerIterator.hasNext()) {
                    Page thirdLayerPage = thirdLayerIterator.next();
                    NavigationItem thirdLayerNav = new NavigationItem();
                    tempPath = LinkUtils.formatLink(thirdLayerPage.getPath(), resourceResolver);
                    thirdLayerNav.setPath(isExternalized(tempPath, externalized, thirdLayerPage));
                    thirdLayerNav.setTitle(PageUtils.getTitle(thirdLayerPage));
                    thirdLayerNavs.add(thirdLayerNav);
                }
                secondLayerNav.setChildren(thirdLayerNavs);
            }

            firstLayerNav.setChildren(secondLayerNavs);
            pages.add(firstLayerNav);
        }
    }

    public String getImagePath() {
        return imagePath;
    }

    public List<NavigationItem> getPages() {
        return pages;
    }

    public String getHomePagePath() {
        return homePagePath;
    }

    public boolean isGlobalAlertVisible() {
        return isGlobalAlertVisible;
    }

    public void setGlobalAlertVisible(boolean isGlobalAlertVisible) {
        this.isGlobalAlertVisible = isGlobalAlertVisible;
    }

    public String getGlobalAlertText() {
        return globalAlertText;
    }

    public void setGlobalAlertText(String globalAlertText) {
        this.globalAlertText = globalAlertText;
    }

    public String getUserLogoutUrl() {
        return userLogoutUrl;
    }

    public String getSearchPagePath() {
        return searchPagePath;
    }

    public int getMaxcount() {
        return getProperties().get("maxcount", MAX_COUNT);
    }

    public boolean isAppsHidden() {
        return isAppsHidden;
    }

    public boolean isProfileHidden() {
        return isProfileHidden;
    }
}

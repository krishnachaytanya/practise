package com.wmt.adp.data_providers.general;

import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.LinkUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoProvider extends WCMUsePojo {
// class used by 
// 		- video component
// 		- b-roll video component
// gets a brightcove video URL and return account and video IDs
	private String videoID;
	private String accountID;
	private String ctaLink;

	@Override
	public void activate() throws Exception {
		ValueMap properties 		= getProperties();
		String videoURL 			= properties.get("videoURL", "");
		
		Pattern videoIDPattern 		= Pattern.compile("videoId=(\\d+)"); 
		Matcher videoIDMatcher 		= videoIDPattern.matcher(videoURL);
		
		Pattern accountIDPattern 	= Pattern.compile("brightcove.net/(\\d+)/"); 
		Matcher accountIDMatcher 	= accountIDPattern.matcher(videoURL);

		if (videoIDMatcher.find()) {
			setVideoID(videoIDMatcher.group(1));
		}
		
		if (accountIDMatcher.find()) {
			setAccountID(accountIDMatcher.group(1));
		}
		
		setCtaLink(LinkUtils.formatLink(properties.get("ctalink", ""), getResourceResolver()));
	}

	public String getVideoID() {
		return videoID;
	}

	public void setVideoID(String videoID) {
		this.videoID = videoID;
	}

	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public String getCtaLink() {
		return ctaLink;
	}

	public void setCtaLink(String ctalink) {
		this.ctaLink = ctalink;
	}
}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by vn56264 on 7/25/2017.
 */
public class BlockFiftyFiftyProvider extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String imagePath;
    private String ctaPath;

    @Override
    public void activate() throws Exception {
        imagePath = ImageUtils.getImagePath(getResource());
        ctaPath = LinkUtils.formatLink(getProperties().get("ctaPath", "#"), getResourceResolver());
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getCtaPath() { return ctaPath; }
}

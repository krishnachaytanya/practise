package com.wmt.adp.data_providers.pojos;

import java.util.List;

import com.wmt.adp.services.pojos.ContentTag;

/**
 * Created by vn56264 on 8/15/2017.
 */
public class DownloadListItem {
    private String title;
    private String type;
    private String date;
    private String description;
    private String path;
    private List<ContentTag> tags;
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<ContentTag> getTags() {
        return tags;
    }

    public void setTags(List<ContentTag> tags) {
        this.tags = tags;
    }


}

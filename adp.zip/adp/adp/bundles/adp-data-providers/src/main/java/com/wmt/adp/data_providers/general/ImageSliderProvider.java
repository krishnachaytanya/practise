package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.wmt.adp.services.utils.PropertyUtil;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.LinkUtils;

public class ImageSliderProvider extends WCMUsePojo {

    private static Logger log = LoggerFactory.getLogger(ImageSliderProvider.class);

    private List<HashMap<String, String>> slides;
    private final String SLIDE_CHILD = "slides";
    private List<String> requiredProperties = new ArrayList<String>();

    @Override
    public void activate() throws Exception {

        requiredProperties.add("title");
        requiredProperties.add("subtitle");
        requiredProperties.add("path");
        requiredProperties.add("bgcolor");
        requiredProperties.add("productImageRef");

        String[] oldSlides = getProperties().get("slides", String[].class);

        Resource resource = getResource();
        Resource slideParent = resource.getChild(SLIDE_CHILD);
        if (null != slideParent && slideParent.hasChildren()) {
            Iterator<Resource> resourceIterator = slideParent.listChildren();
            slides = new ArrayList<HashMap<String, String>>();
            while (resourceIterator.hasNext()) {
                HashMap<String, String> slide = new HashMap<String, String>();
                Resource slideResource = resourceIterator.next();
                ValueMap slideProperties = slideResource.getValueMap();

                for (String property : requiredProperties) {
                    if (null != slideProperties.get(property)) {
                        if (property.equals("path")) {
                            String path = LinkUtils.formatLink(slideProperties.get(property).toString(), getResourceResolver());
                            slide.put(property, path);
                        } else {
                            slide.put(property, slideProperties.get(property).toString());

                        }
                    }
                }
                slides.add(slide);
            }
        } else if (oldSlides != null) {
            ValueMap props = getProperties();
            slides = PropertyUtil.getMultifieldArray(props.get("slides", String[].class));
            String path;

            for (HashMap<String, String> slide : slides) {
                path = slide.get("path");
                path = LinkUtils.formatLink(path, getResourceResolver());

                slide.put("path", path);
            }
        }


    }

    public List<HashMap<String, String>> getSlides() {
        log.debug("returning slides" + slides);
        return slides;
    }
}

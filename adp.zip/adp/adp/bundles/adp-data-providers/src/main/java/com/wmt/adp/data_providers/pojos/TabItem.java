package com.wmt.adp.data_providers.pojos;

import java.util.UUID;

public class TabItem {
    private String id;
    private String title;
    private boolean isVisible;

    public TabItem() {
        this.id = "Tab_" + UUID.randomUUID().toString().replace("-", "_");
        this.isVisible = false;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean getIsVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }
}

package com.wmt.adp.data_providers.global;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.utils.PageUtils;

/**
 * Created by vn0007r on 11/22/2017.
 */
public class AppDrawerProvider extends WCMUsePojo {

    private String appCollectionPath;

    @Override
    public void activate() throws Exception {
        PageManager pageManager = getResourceResolver().adaptTo(PageManager.class);
        Page languageRoot = PageUtils.getLanguageRoot(getCurrentPage(), pageManager);
        String languageRootPath = languageRoot.getPath();
        appCollectionPath = languageRootPath + "/apps.html";
    }

    public String getAppCollectionPath() {
        return appCollectionPath;
    }
}

package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.LinkUtils;

public class CardsProvider extends WCMUsePojo{

    private String ctaPath1st;

    private String ctaPath2nd;

    private String ctaPath3rd;

    private String ctaPath4th;

    private String ctaPath;

	private String show;


	@Override
	public void activate() throws Exception {
        ctaPath = LinkUtils.formatLink(getProperties().get("ctaPath", ""), getResourceResolver());

		ctaPath1st = LinkUtils.formatLink(getProperties().get("ctaPath1stTile", "#"), getResourceResolver());

        ctaPath2nd = LinkUtils.formatLink(getProperties().get("ctaPath2ndTile", "#"), getResourceResolver());

        ctaPath3rd = LinkUtils.formatLink(getProperties().get("ctaPath3rdTile", "#"), getResourceResolver());

        ctaPath4th = LinkUtils.formatLink(getProperties().get("ctaPath4thTile", "#"), getResourceResolver());

        show = getProperties().get("show", "");
        showHelper();
	}

	private void showHelper() {
		if(show.equals("2")){
			show = "card-two-column";
		}
		if(show.equals("3")){
			show = "card-three-column";
		}
		if(show.equals("4")) {
			show = "card-four-column";
		}
	}
	public String getCtaPath() {
		return ctaPath;
	}

	public String getShow() {
		return show;
	}
	public String getCtaPath1st() {
		return ctaPath1st;
	}

	public String getCtaPath2nd() {
		return ctaPath2nd;
	}

	public String getCtaPath3rd() {
		return ctaPath3rd;
	}

	public String getCtaPath4th() {
		return ctaPath4th;
	}
}

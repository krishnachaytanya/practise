package com.wmt.adp.data_providers.pojos;

import java.util.Calendar;
import java.util.List;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.wcm.api.Page;
import com.wmt.adp.services.TagService;
import com.wmt.adp.services.pojos.ContentTag;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.LinkUtils;

public class EventPage {
// holds the info of an event page
	
	private String title;
	private String description;
	private String imageURL;
	private ContentTag[] tags;
	private String date;
	private String link;
	private String[] tagsNames;
    
	public EventPage(String title, String desc, String image, ContentTag[] tags, String link, String date) {
	// loads data from the received parameters
		this.title  		= title;
		this.description 	= desc;
		this.imageURL 		= image;
		this.tags 			= tags;
		this.date 			= date;
		this.link 			= link;
		this.tagsNames 		= null;
	}
	
	public EventPage(Page page, ResourceResolver resourceResolver, TagService tagService) {
	// loads the data from the page received as parameter
		String pagePath 			= page.getPath();
		List<ContentTag> tagsList;
		
		ValueMap props;
		Calendar dateCalendar;
		
		props 			= page.getProperties();
		dateCalendar 	= props.get("eventEnds", Calendar.class);
		tagsList 		= tagService.getTagLinkList(page.getPath());
		
		title 			= props.get("title", "");
		description 	= props.get("description", "");
		imageURL 		= props.get("fileReference", "");
		link 			= LinkUtils.formatLink(pagePath, resourceResolver);
		date 			= DateUtils.getFormattedDate(dateCalendar, DateUtils.PUBLISH_DATE);
		tags 			= new ContentTag[tagsList.size()];
		tagsNames		= null;
		
		tagsList.toArray(tags);
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getImageURL() {
		return imageURL;
	}
	
	public ContentTag[] getTags() {
		return tags;
	}
	
	public String getDate() {
		return date;
	}
	
	public String getLink() {
		return link;
	}
	
	public String[] getTagsNames() {
	// returns the names of the tags as an array of string
		if (tagsNames == null) {
			tagsNames = new String[tags.length];
			
			for (int i=0; i<tags.length; i++) {
				tagsNames[i] = tags[i].getName();
			}
		}
		
		return tagsNames;
	}
}

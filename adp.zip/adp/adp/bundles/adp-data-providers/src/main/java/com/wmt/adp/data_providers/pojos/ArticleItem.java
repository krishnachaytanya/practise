package com.wmt.adp.data_providers.pojos;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import com.wmt.adp.services.utils.DateUtils;
import org.apache.felix.scr.impl.parser.ParseException;

/**
 * Created by dgeary on 9/6/17.
 */
public class ArticleItem implements Comparable<ArticleItem> {
	private String title;
	private String description;
	private String thumbnail;
	private String date;
	private String tags;
	private String path;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public int compareTo(ArticleItem articleTo) {
		return Comparators.DATE_DESC.compare(this, articleTo);
	}
	static class Comparators {
		
		private static int compareInternal(String dateA, String dateB, Boolean isDescending) {
			int order = 1;
			DateFormat dateFormat = new SimpleDateFormat(DateUtils.SEARCH_FORMAT);
			if((dateA == null || dateA.isEmpty()) && (dateB == null || dateB.isEmpty())){
				return 0;
			}
			if(dateA == null || dateA.isEmpty()){
				return 1;
			}
			if(dateB == null || dateB.isEmpty()){
				return -1;
			}
			try {
				order = dateFormat.parse(dateB).compareTo(dateFormat.parse(dateA));
				if(!isDescending) {
					order = order * -1;
				}
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return order;
		}
		public static Comparator<ArticleItem> DATE = new Comparator<ArticleItem>() {
			@Override
			public int compare(ArticleItem itemA, ArticleItem itemB) {
				return compareInternal(itemA.getDate(), itemB.getDate(), false);
			}
		};
		
		public static Comparator<ArticleItem> DATE_DESC = new Comparator<ArticleItem>() {
			@Override
			public int compare(ArticleItem itemA, ArticleItem itemB) {
				return compareInternal(itemA.getDate(), itemB.getDate(), true);
			}
		};
	}
}

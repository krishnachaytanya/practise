package com.wmt.adp.data_providers.general;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import com.wmt.adp.services.ConstantsService;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.wmt.adp.data_providers.pojos.CourseItem;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.ImageUtils;
import com.wmt.adp.services.utils.LinkUtils;

public class RecommendedListProvider extends WCMUsePojo {
		
	private String ListType;
	private String parentPath;
	private List<CourseItem> childLinkList;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
 	private long parentLimit;

	@Override
	public void activate() throws Exception {
        ConstantsService constantsService = getSlingScriptHelper().getService(ConstantsService.class);
		this.ListType = getProperties().get("recommendedListType","");
		this.parentLimit = constantsService.getDefaultLimitParentLists();
		if(ListType.equals("manual"))
    	{
    		String[] courseListItemsString = getProperties().get("links", String[].class);
    		readCourseListItemsJSON(courseListItemsString);
    	}
    	else
    	{
    		this.parentPath = getProperties().get("parentPath","");
			 Page parentPage= getPageManager().getContainingPage(parentPath);
			 if(parentPage!=null)
			 {
				 childLinkList = new ArrayList<>();
				 Iterator<Page>rootPageIterator = parentPage.listChildren();
				 int count = 0;
				 while(rootPageIterator.hasNext())
				 {
				 	 count++;
				 	 if(count > this.parentLimit) break;
					 Page actualPage = rootPageIterator.next();
					 childLinkList.add(buildCourseItem(actualPage));
				 }    		
			 }
    	}
		// TODO Auto-generated method stub	
	}
	
	private void readCourseListItemsJSON(String[] courseListItemsString) throws ParseException {
		childLinkList = new ArrayList<>();
        if (courseListItemsString !=  null) {
            for (String jsonChunk: courseListItemsString) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonChunk);
                    CourseItem courseItem = new CourseItem();
                    String path = jsonObject.getString("path");          
                    Page page= getPageManager().getContainingPage(path);
                    if(page!=null) courseItem = buildCourseItem(page);                 
                    if(!(jsonObject.getString("difficulty").equals(""))) courseItem.setLevel(jsonObject.getString("difficulty"));
                    if(!(jsonObject.getString("courseTitle").equals("")))  courseItem.setTitle(jsonObject.getString("courseTitle"));
                    if(!(jsonObject.getString("duration").equals(""))) courseItem.setDuration(DateUtils.getFormattedDuration(jsonObject.getString("duration")));
                    if(!(jsonObject.getString("date").equals("")))
                    {
                    	String d= jsonObject.getString("date");
                    	SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.ISO_DATETIME_FORMAT);
                    	sdf.parse(d);
                    	courseItem.setDate(DateUtils.getFormattedDate(sdf.getCalendar(), DateUtils.SEARCH_FORMAT));                  	
                    }
                    
                    courseItem.setHideDuration(jsonObject.getString("hideDuration").equals("true"));
                    courseItem.setHideDate(jsonObject.getString("hideDate").equals("true"));
                    courseItem.setHideLevel(jsonObject.getString("hideDifficulty").equals("true"));
                    path = LinkUtils.formatLink(path, getResourceResolver());
                    courseItem.setPath(path);          
                    childLinkList.add(courseItem);
                    
                } catch (JSONException e) {
                    logger.error("Recommended List: Cannot parse json chunks", e);
                }
            }
        }
    }


	
	private CourseItem buildCourseItem(Page page) {
		
        ValueMap pageProps = page.getProperties();
        CourseItem courseItem = new CourseItem();
        try{
        	
        	Resource resource = this.getResourceResolver().getResource(page.getPath() + "/jcr:content/par/tabbedcolumn/column_2/coursedescription");
        	courseItem.setDescription(resource.getValueMap().get("description",""));
        	courseItem.setTitle(resource.getValueMap().get("title",""));      
        	}catch(Exception e){
        	logger.error("Recommended List path not found",e);
        	
        }
        courseItem.setLevel(pageProps.get("difficulty", ""));
        courseItem.setPath(page.getPath() + ".html");
        courseItem.setDuration(DateUtils.getFormattedDuration(pageProps.get("duration", "")));
        Calendar bestDate = DateUtils.getBestDate(page);
        courseItem.setDate(DateUtils.getFormattedDate(bestDate, DateUtils.SEARCH_FORMAT));
        Resource imageResource = page.getContentResource("image");
        courseItem.setThumbnail(ImageUtils.getImagePath(imageResource));

        return courseItem;
    }
	
	public List<CourseItem> getChildLinkList() {
		return childLinkList;
	}


	public String getParentPath() {
		return parentPath;
	}
}

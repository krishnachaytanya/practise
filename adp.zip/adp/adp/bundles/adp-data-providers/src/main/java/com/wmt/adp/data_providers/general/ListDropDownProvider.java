package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.ListSearchService;
import com.wmt.adp.services.pojos.NavigationItem;

/**
 * @author Merkle / Axis41
 *
 */
public class ListDropDownProvider extends WCMUsePojo {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** title */
    private String title;

	/** path */
    private String path;

	/** tags */
    private String tags[];

	/** parentPath */
    private String parentPath;

	/** listType */
	private String listType;

	/** listItems */
	private List<Map<String, String>> listItems;

	/** childList */
    private List<NavigationItem> childList;

	/** listSearchService */
    private ListSearchService listSearchService;

	@Override
    public void activate() throws Exception {
		listSearchService = getSlingScriptHelper().getService(ListSearchService.class);
		this.title = getProperties().get("title"," ");
    	this.listType = getProperties().get("listType","");
    	logger.info("listType " + listType);
    	switch (this.listType) {
			case "manual":
				String[] links = getProperties().get("links", String[].class);
				listItems = listSearchService.getSearchManual(links);
				break;
			case "parent":
				this.parentPath = getProperties().get("parentPath","");
				childList = listSearchService.getParentSearch(parentPath);
				break;
			case "tag":
				this.tags = getProperties().get("tags", String[].class);
				childList = listSearchService.getTagSearch(tags, "/content/adp");
				break;

			default:
				listItems = new ArrayList<>();
				childList = new ArrayList<>();
				break;
		}
    }

	/** @return path */
	public String getPath() {
    	return this.path;
    }

	/** @return title */
    public String getTitle(){
    	return this.title;
    }

	/** @return parentPath */
    public String getParentPath() {
		return parentPath;
	}

	/** @return listType */
    public String getListType() {
		return listType;
	}

	/** @return listItems */
	public List<Map<String, String>> getListItems() {
		return listItems;
	}

	/** @return childList */
	public List<NavigationItem> getChildList() {
		return childList;
	}

}

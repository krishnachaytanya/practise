package com.wmt.adp.data_providers.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.adp.services.utils.LinkUtils;

/**
 * Created by vn61291 on 8/04/2017.
 */
public class QuickActionBlockProvider extends WCMUsePojo {

    private String title;
    private String fourItemLayout;
    private List<Map<String, String>> quickActionItems;
    private static final String FOUR_ITEM_LAYOUT_CSS_CLASS = "quick-actions-links-2-4";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    
	@Override
    public void activate() throws Exception {
    	this.title = (String) getProperties().getOrDefault("text", "Default Title");
    	String[] actionItemString = getProperties().get("actions", String[].class);
		readQuickActionItemsJSON(actionItemString);
		checkFourItemLayout();
    }

    public String getTitle(){
    	return this.title;
    }
    
	public String getFourItemLayout() {
		return fourItemLayout;
	}

	public void setFourItemLayout(String fourItemLayout) {
		this.fourItemLayout = fourItemLayout;
	}
	
	public List<Map<String, String>> getQuickActionItems() {
		return quickActionItems;
	}

	private void readQuickActionItemsJSON(String[] actionItemString) {
    	quickActionItems = new ArrayList<>();
        if (actionItemString !=  null) {
            for (String jsonChunk: actionItemString) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonChunk);
                    Map<String, String> map = new HashMap<>();
                    map.put("text", jsonObject.getString("text"));
                    String path = jsonObject.getString("path");
                    path = LinkUtils.formatLink(path, getResourceResolver());
                    map.put("path", path);
                    map.put("target", jsonObject.getString("target"));
                    map.put("icon", jsonObject.getString("icon"));
                    quickActionItems.add(map);
                } catch (JSONException e) {
                    logger.error("Cannot parse json chunks", e);
                }
            }
        }
    }
	
    private void checkFourItemLayout() {
    	if(quickActionItems.size() == 4 || quickActionItems.size() == 2){
    		setFourItemLayout(FOUR_ITEM_LAYOUT_CSS_CLASS);
    	}
	}
	
}

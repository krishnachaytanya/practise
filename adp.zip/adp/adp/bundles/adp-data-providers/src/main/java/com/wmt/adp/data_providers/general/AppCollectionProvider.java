package com.wmt.adp.data_providers.general;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.AppService;
import com.wmt.adp.services.pojos.AppGroup;
import com.wmt.adp.services.utils.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by vn61291 on 8/04/2017.
 */
public class AppCollectionProvider extends WCMUsePojo {

    private List<AppGroup> appGroups;
    private AppService appService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void activate() throws Exception {
        PageManager pageManager = getResourceResolver().adaptTo(PageManager.class);
        Page languageRoot = PageUtils.getLanguageRoot(getCurrentPage(), pageManager);
        String languageRootPath = languageRoot.getPath();

        appService = getSlingScriptHelper().getService(AppService.class);
        appGroups = appService.getAppGroups(languageRootPath);
    }

    public List<AppGroup> getAppGroups() {
        return appGroups;
    }
}

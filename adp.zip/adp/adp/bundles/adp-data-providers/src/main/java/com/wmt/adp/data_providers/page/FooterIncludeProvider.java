package com.wmt.adp.data_providers.page;

import static com.wmt.adp.services.Constants.FOOTER_SUB_PATH;

import com.adobe.cq.sightly.WCMUsePojo;
import com.wmt.adp.services.utils.PageUtils;

/**
 * Created by vn56264 on 8/21/2017.
 */
public class FooterIncludeProvider extends WCMUsePojo {

    private String path;

    @Override
    public void activate() throws Exception {
        path = PageUtils.getLanguageRoot(getCurrentPage(), getPageManager()).getPath() + FOOTER_SUB_PATH;
    }

    public String getPath() {
        return path;
    }
}

package com.wmt.adp.data_providers.pojos;

import java.util.List;

/**
 * Created by vn56264 on 7/28/2017.
 */
public class NavigationItem {
    private String path;
    private String title;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<NavigationItem> getChildren() {
        return children;
    }

    public void setChildren(List<NavigationItem> children) {
        this.children = children;
    }

    private List<NavigationItem> children;
}

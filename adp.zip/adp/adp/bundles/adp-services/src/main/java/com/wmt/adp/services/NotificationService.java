package com.wmt.adp.services;

import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.common.collect.Iterators;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by bfitzpatrick on 9/22/17.
 */
@Component(
        label = "Notification Service",
        description = "Gets pages marked as notifications",
        immediate = true)
@Service(value = { NotificationService.class })
public class NotificationService {
    private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";
    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);
    private static final String NOTIFICATION_TAG_ID = "adp:site-functions/notification";

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    /**
     * Gets all pages marked as notifications under a specified language root and converts them
     * to json
     * @param languageRoot path under which to look for notification pages
     * @return a json representing the notification pages
     */
    public JSONObject getNotifications(String languageRoot) {
        // prep service user login
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        ResourceResolver resourceResolver = null;

        JSONObject jsonObject = new JSONObject();
        try {
            // get session based objects
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
            PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            // pick up all pages based on notification tag
            String[] tagIDs = {NOTIFICATION_TAG_ID};
            RangeIterator<Resource> resourceIterator = tagManager.find(languageRoot, tagIDs);

            List<Resource> resourceList = new ArrayList<>();
            Iterators.addAll(resourceList, resourceIterator);

            Collections.sort(resourceList, (Resource o1, Resource o2) -> DateUtils.getBestDate(pageManager.getContainingPage(o2)).compareTo(DateUtils.getBestDate(pageManager.getContainingPage(o1))));

            // convert the notification pages into json objects
            JSONArray jsonArray = new JSONArray();
            for (Resource resource : resourceList) {
                Page page = pageManager.getContainingPage(resource);
                try {
                    JSONObject jsonChunk = pageToJSON(page, resourceResolver);
                    jsonArray.put(jsonChunk);
                } catch (JSONException e) {
                    logger.error("Cannot write json",e);
                }
            }

            try {
                jsonObject.put("notifications", jsonArray);
            } catch (JSONException e) {
                logger.error("Cannot write json", e);
            }
        } catch (LoginException e) {
            logger.error("Can't login to resource resolver", e);
        } finally {
            if (resourceResolver != null && resourceResolver.isLive()) {
                resourceResolver.close();
            }
        }

        return jsonObject;
    }

    /**
     * Takes the path, title, and date from a Page and makes a simple JSONObject
     * @param page Page to convert
     * @return JSONObject with the path, title, and date of the Page
     * @throws JSONException
     */
    private JSONObject pageToJSON(Page page, ResourceResolver resourceResolver) throws JSONException {
        String path = page.getPath();
        path = LinkUtils.formatLink(path, resourceResolver);
        String title = page.getTitle();
        Calendar date = DateUtils.getBestDate(page);
        String description = page.getDescription();

        String dateString = DateUtils.getFormattedDate(date, DateUtils.ISO_DATETIME_FORMAT);

        JSONObject json = new JSONObject();
        json.put("path", path);
        json.put("title", title);
        json.put("date", dateString);
        json.put("description", description);

        return json;
    }
}

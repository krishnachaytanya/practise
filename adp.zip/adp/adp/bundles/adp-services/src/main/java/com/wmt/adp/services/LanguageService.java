/**
 * 
 */
package com.wmt.adp.services;

import org.apache.felix.scr.annotations.*;
import org.apache.sling.commons.osgi.PropertiesUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.pojos.LanguageItem;
import com.wmt.adp.services.utils.PageUtils;

/**
 *  Language services
 */
@Component( metatype = true,
            label = "Dynamic Language Translation Service",
            name = "com.wmt.adp.services.LanguageService",
            description = "Dynamic language translation services.",
            immediate = true )
@Service( LanguageService.class )
@Properties({
    @Property(name = "service.vendor", value = "Walmart"),
    @Property(name = "service.description", value = "ADP - SDL Enterprise Translation Service."),
})
public class LanguageService {

    private static final Logger logger = LoggerFactory.getLogger( LanguageService.class );

    static private final boolean IGNORE_PAGE_CONTENT = true;

    // SDL sandbox free translations
    // private static final String DEFAULT_SDL_TRANSLATE_URL        = "https://lc-api.sdl.com/"; // translate
    // private static final String DEFAULT_SDL_TRANSLATE_API_KEY    = "kY%2FMK3tMoI6VEbE2hjVkIg%3D%3D";

    // actual SDL ETS server
    private static final String DEFAULT_SDL_TRANSLATE_URL        = "http://llbnt10160usa.homeoffice.wal-mart.com:8001/api/v1/";
    private static final String DEFAULT_SDL_TRANSLATE_API_KEY    = "ag_ooNxrQkYrswP";

    private static final String SDL_TRANSLATE_URL_PARAM_NAME     = "constants.sdl_ets_translate_url";
    private static final String SDL_TRANSLATE_API_KEY_PARAM_NAME = "constants.sdl_ets_translate_api_key";

    // SDL Enterprise Translation Server custom 3-letter language codes (roughly ISO 649) to IETF tag ( BCP 47 ) 
    private static final String SDL_TRANSLATE_LANG_CODE_PARAM_NAME = "constants.sdl_ets_translate_codes";


    @Property(label = "SDL ETS Server URL", name = SDL_TRANSLATE_URL_PARAM_NAME, value = DEFAULT_SDL_TRANSLATE_URL,
              description="SDL Enterprise Translation Server URL" )
    private String sdlTranslateUrl = DEFAULT_SDL_TRANSLATE_URL;
    
    @Property(label = "SDL ETS Server API KEY", name = SDL_TRANSLATE_API_KEY_PARAM_NAME, value = DEFAULT_SDL_TRANSLATE_API_KEY,
            description="SDL Enterprise Translation Server API Key" )
    private String sdlTranslateApiKey = DEFAULT_SDL_TRANSLATE_API_KEY;

    // TODO: load all SDL ETS language code mappings 
    private static final String DEFAULT_LANG_ES = "spa=es";  // Spanish
    private static final String DEFAULT_LANG_PT = "por=pt";  // Portuguese
    private static final String DEFAULT_LANG_JA = "jpn=ja";  // Japanese
    private static final String DEFAULT_LANG_ZH_HANS = "chi=zh-hans";  // Chinese simplified
    private static final String DEFAULT_LANG_FR = "fra=fr";  // French
    // private static final String DEFAULT_LANG_ZH_HANT = "cht=zh-hant";  // Chinese traditional

    // other possible languages 
    //private static final String DEFAULT_LANG_DE = "ger=de";  // German
    //private static final String DEFAULT_LANG_IT = "ita=it";  // Italian
    // private static final String DEFAULT_LANG_NL = "dut=nl";  // Dutch
    // private static final String DEFAULT_LANG_RU = "rus=ru";  // Russian
    // private static final String DEFAULT_LANG_PL = "pol=po";  // Polish
    // private static final String DEFAULT_LANG_HI = "hin=hi";  // Hindi

    @Property( label = "SDL ETS Lang Codes", name = SDL_TRANSLATE_LANG_CODE_PARAM_NAME,
               value = { 
                         DEFAULT_LANG_ES, DEFAULT_LANG_PT,
                         DEFAULT_LANG_JA, DEFAULT_LANG_ZH_HANS, DEFAULT_LANG_FR,
                         // DEFAULT_LANG_NL, DEFAULT_LANG_DE,DEFAULT_LANG_IT,
                         //  DEFAULT_LANG_RU, DEFAULT_LANG_PL, DEFAULT_LANG_HI,
                       }, 
               unbounded = PropertyUnbounded.ARRAY,
            description="SDL ETS alpha-3 language code ( almost ISO 639-2/B ) to ISO 639-1 alpha-2 / BCP-47 codes (e.g., fra=fr , ger=de )" )
    private String[] sdlTranslateLangCodes = new String[0];


    @Activate
    @Modified
    protected void activate(final Map< String, Object > config) {
        if (config != null) {

            sdlTranslateUrl = StringUtils.trimToNull( PropertiesUtil.toString(config.get( SDL_TRANSLATE_URL_PARAM_NAME ), DEFAULT_SDL_TRANSLATE_URL ) );
            sdlTranslateApiKey = StringUtils.trimToNull( PropertiesUtil.toString(config.get( SDL_TRANSLATE_API_KEY_PARAM_NAME ), DEFAULT_SDL_TRANSLATE_API_KEY ) );
            sdlTranslateLangCodes = PropertiesUtil.toStringArray(config.get( SDL_TRANSLATE_LANG_CODE_PARAM_NAME ), new String[0] );
            logger.info( "Got SDL ETS api key '{}', server url '{}', {} lang codes.", sdlTranslateApiKey, sdlTranslateUrl, 
                         (sdlTranslateLangCodes != null ? sdlTranslateLangCodes.length : 0 ) ) ;
        	
        	
        } else {
            logger.warn( "Missing config values.");
        }  // config
    }  // activate

    
    
    /**
     * Find other languages available for translation in the current country locale
     * @param currentPage     the current page
     * @param pageManager     the page manager
     * @return other dynamic language choices for the current country
     */
    public List<LanguageItem> loadOtherLangs( Page currentPage, PageManager pageManager )
    {
        List<LanguageItem> otherLanguages = new ArrayList<LanguageItem>();

        Page currentLang = PageUtils.getLanguageRoot(currentPage, pageManager);
        Locale currentLocale = ( currentLang != null ?  currentLang.getLanguage( IGNORE_PAGE_CONTENT ) : null);
        String currentCountry = ( currentLocale != null ? currentLocale.getCountry().toLowerCase() : null ); // lower case country

        Map<String,String> isoToLang = currentLanguages( );
        for ( String iso639Code : isoToLang.keySet() ) {
            String langCode   = isoToLang.get(iso639Code);  // "ger=de";

            final boolean isSelected = false;
            final String path = "#";
            final Locale locale = new Locale( iso639Code, currentCountry );
            final String label = locale.getDisplayLanguage( locale );
            LanguageItem langPage = new LanguageItem( iso639Code, label, isSelected, path, currentCountry );
            langPage.setLangEts( langCode );
            otherLanguages.add( langPage );

        } // langs

        logger.info("Added {} languages ( {} ).", otherLanguages.size(), otherLanguages );
        return otherLanguages;
    }

    /**
     * @return map of ISO alpha-2 language code to SDL ETS alpha-3 code
     */
    public Map<String,String> currentLanguages( ) {
        Map<String,String> langs = new TreeMap<String,String>();

        for ( String langVal : getSdlTranslateLangCodes() ) {
            String parts[] = langVal.split("=");
            if ( parts == null || parts.length < 2) {
                logger.warn("Bad lang code pair '{}'.", langs );	
                continue;
            }
            String langCode   = parts[0];  // "ger=de";
            String iso639Code = parts[1];  // "ger=de";

            langs.put(iso639Code, langCode);
        }  // langVal
 
        return langs;
    } // currentLanguates
    
    
    /**
     * @return the SDL Enterprise Translation Server API URL
     */
    public String getSdlTranslateUrl() {
        	return sdlTranslateUrl;
    }

    /**
     * @return the SDL Enterprise Translation Server API Key
     */
    public String getSdlTranslateApiKey() {
        	return sdlTranslateApiKey;
    }

    /**
     * @return the configured SDL Enterprise Translation Server Language Codes
     */
    public String[] getSdlTranslateLangCodes() {
        	return sdlTranslateLangCodes;
    }
	
}

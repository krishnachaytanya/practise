package com.wmt.adp.services;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.pojos.ContentTag;
import com.wmt.adp.services.pojos.ContentTemplate;
import com.wmt.adp.services.utils.DateUtils;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.*;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;

@Component(
        label = "Search Service",
        description = "Gets pages based on search criteria",
        immediate = true)
@Service(value = { SearchJcrService.class })
public class SearchJcrService {
    private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";
    private static final int PAGE_SIZE = 10;
    private static final String TEMPLATE_PATH = "/apps/adp/templates/";
    private static final Logger logger = LoggerFactory.getLogger(SearchJcrService.class);

    private ResourceResolver resourceResolver;

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private TagService tagService;

    @Reference
    private TemplateService templateService;

    public JSONObject getSearchResults(String languageRoot, String[] selectors, String tags, Locale locale) {
        // prep service user login
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);

        List<Map<String, String>> selectedFiltersList = new ArrayList<>();

        Map<String, String> searchParams = new HashMap<>();
        searchParams.put("path", languageRoot);
        searchParams.put("type", "cq:Page");
        searchParams.put("p.limit", Integer.toString(PAGE_SIZE));

        // selectors: q, page, sort, category
        String key;
        String value;
        String q = "";
        String page = "1";
        String offset;
        String sort = "score";
        String category = "";
        String[] searchTags = {};

        for (String selector : selectors) {
            try {
                selector = URLDecoder.decode(selector, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                logger.error("Unable to decode selector: " + e);
            }

            String[] splitString = selector.split("=");
            if (splitString.length > 1) {
                key = splitString[0];
                value = splitString[1];
            } else {
                key = "";
                value="";
            }

            if ("q".equals(key)) {
                q = value;
            } else if ("page".equals(key)) {
                page = value;
            } else if ("sort".equals(key)) {
                sort = value;
            } else if ("category".equals(key)) {
                category = value;
            }
        }

        searchParams.put("3_group.p.or", "true");
        searchParams.put("3_group.1_fulltext.relPath", "jcr:content");
        searchParams.put("3_group.1_fulltext", q);
        searchParams.put("3_group.2_fulltext.relPath", "jcr:content/@cq:tags");
        searchParams.put("3_group.2_fulltext", q);

        offset = Integer.toString((Integer.parseInt(page) - 1) * PAGE_SIZE);
        searchParams.put("p.offset", offset);

        if ("date".equals(sort)) {
            searchParams.put("1_orderby", "@jcr:content/publishDate");
            searchParams.put("1_orderby.sort", "desc");
            searchParams.put("2_orderby", "@jcr:score");
            searchParams.put("2_orderby.sort", "desc");
        } else {
            searchParams.put("1_orderby", "@jcr:score");
            searchParams.put("1_orderby.sort", "desc");
        }

        if (!category.isEmpty()) {
            ContentTemplate contentTemplate = templateService.getContentTemplate(TEMPLATE_PATH + category);

            if (contentTemplate != null) {
                Map<String,String> selectedFilter = new HashMap<>();
                selectedFilter.put("id", contentTemplate.getSearchFacetData());
                selectedFilter.put("title", contentTemplate.getSearchFacetTitle());

                selectedFiltersList.add(selectedFilter);
            }

            searchParams.put("4_group.property", "jcr:content/cq:template");
            searchParams.put("4_group.property.value", TEMPLATE_PATH + category);
        } else {
            searchParams.put("4_group.property", "jcr:content/cq:template");

            List<ContentTemplate> templates = templateService.getAllSearchableTemplates();
            for (int i = 0; i < templates.size(); i++) {
                searchParams.put("4_group.property." + i + "_value", templates.get(i).getPath());
            }
        }

        if (!tags.isEmpty()) {

            searchTags = tags.split("\\|");
            for (int i = 0; i < searchTags.length; i++) {
                ContentTag contentTag = tagService.getContentTag(searchTags[i], locale);

                if (contentTag != null) {
                    Map<String, String> selectedFilter = new HashMap<>();
                    selectedFilter.put("id", contentTag.getTagId());
                    selectedFilter.put("title", contentTag.getTitle());

                    selectedFiltersList.add(selectedFilter);
                }

                searchParams.put("5_group." + i + "_tagid", searchTags[i]);
                searchParams.put("5_group." + i + "_tagid.property", "jcr:content/cq:tags");
            }
            searchParams.put("5_group.p.or", "true");
        }

        searchParams.put("6_group.property", "@jcr:content/hideInSearch");
        searchParams.put("6_group.property.operation", "not");
        
        JSONObject jsonObject = new JSONObject();
        try {
            // get session based objects
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
            PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

            QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
            Session session = resourceResolver.adaptTo(Session.class);
            Query query = builder.createQuery(PredicateGroup.create(searchParams), session);

            SearchResult result = query.getResult();

            List<Hit> hits = result.getHits();
            long totalHits = result.getTotalMatches();

            try {
                jsonObject.put("page", page);
                jsonObject.put("pageSize", PAGE_SIZE);
                jsonObject.put("pageTotal", hits.size());
                jsonObject.put("total", totalHits);

                long pages = totalHits / PAGE_SIZE;
                if (totalHits % PAGE_SIZE != 0) {
                    pages++;
                }
                pages = Math.min(pages, 10);
                jsonObject.put("pages", pages);
            } catch (JSONException e) {
                logger.error("Error writing search metadata to JSON: " + e);
            }

            JSONArray jsonArray = new JSONArray();
            for (Hit hit : hits) {
                Resource resource = null;
                JSONArray pageTagsArray = new JSONArray();

                try {
                    resource = hit.getResource();
                } catch (RepositoryException e) {
                    logger.error("Repository exception getting search hit: " + e);
                }

                if (resource != null) {
                    Page pageObject = pageManager.getContainingPage(resource);
                    try {
                        JSONObject jsonChunk = pageToJSON(pageObject);

                        String templatePath = pageObject.getProperties().get("cq:template", "");
                        ContentTemplate contentTemplate = templateService.getContentTemplate(templatePath);
                        jsonChunk.put("category", contentTemplate.getSearchFacetTitle());

                        Tag[] pageTags = pageObject.getTags();
                        for (Tag pageTag : pageTags) {
                            pageTagsArray.put(pageTag.getTitle());

                            ContentTag contentTag = new ContentTag();
                            contentTag.setTitle(pageTag.getTitle());
                            contentTag.setTagId(pageTag.getTagID());
                        }

                        jsonChunk.put("tags", pageTagsArray);
                        jsonArray.put(jsonChunk);
                    } catch (JSONException e) {
                        logger.error("Cannot write json", e);
                    }
                }
            }

            try {
                jsonObject.put("results", jsonArray);

                JSONArray selectedFiltersJSON = new JSONArray();
                for (Map<String,String> filter : selectedFiltersList) {
                    JSONObject filterJSON = new JSONObject(filter);
                    selectedFiltersJSON.put(filterJSON);
                }
                jsonObject.put("selectedFilters", selectedFiltersJSON);
            } catch (JSONException e) {
                logger.error("Cannot write json", e);
            }
        } catch (LoginException e) {
            logger.error("Can't login to resource resolver", e);
        } finally {
            if (resourceResolver != null && resourceResolver.isLive()) {
                resourceResolver.close();
            }
        }

        return jsonObject;
    }

    /**
     * Takes the path, title, and date from a Page and makes a simple JSONObject
     * @param page Page to convert
     * @return JSONObject with the path, title, and date of the Page
     * @throws JSONException
     */
    private JSONObject pageToJSON(Page page) throws JSONException {
        String path = page.getPath();
        path = LinkUtils.formatLink(path, resourceResolver);
        String title = page.getTitle();

        ValueMap pageProperties = page.getProperties();

        // Not using best date b/c sorting will look wrong
        String dateString = DateUtils.getFormattedDate(pageProperties.get("publishDate", Calendar.class), DateUtils.ISO_DATETIME_FORMAT);

        JSONObject json = new JSONObject();
        json.put("path", path);
        json.put("title", title);
        json.put("date", dateString);

        return json;
    }
}

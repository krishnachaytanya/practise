package com.wmt.adp.services;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.IOUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;


/**
 * @author Merkle / Axis41
 */
@Component(
		label = "Solr Search Service",
		description = "Gets pages based on search criteria",
		immediate = true)
@Service(value = { SearchSolrService.class })
@Properties({ @Property(label = "Search Solr Host",
						name = SearchSolrService.USER_SOLR_HOST,
						value = SearchSolrService.DEFAULT_SOLR_HOST)})
public class SearchSolrService {

	/** Logger */
	private static final Logger logger = LoggerFactory.getLogger(SearchSolrService.class);

	/** Service Account Identifier */
	private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";

	/** Page Size */
	private static final int PAGE_SIZE = 10;

	/** Default Solr Host */
	public static final String DEFAULT_SOLR_HOST = "http://solrcloud.prod.crawler.aep.prod.walmart.com:8983/solr/ce-walmart/select";

	/** User Solr Host */
	public static final String USER_SOLR_HOST = "search.solrHost";

	/** Solr Host */
	private String solrHost = DEFAULT_SOLR_HOST;
	
	private CloseableHttpClient httpClient;

	private ResourceResolver resourceResolver = null;

	@Reference
    private ResourceResolverFactory resourceResolverFactory;

	@Activate
	protected void activate(final Map< String, Object > config) throws LoginException {
		if (config != null) {
			solrHost = PropertiesUtil.toString(config.get(USER_SOLR_HOST), DEFAULT_SOLR_HOST);
		}
		this.httpClient = HttpClientBuilder
				.create()
				.setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
				.setMaxConnTotal(32).build();
	}
	
	@Deactivate
	protected void stop() throws IOException{
		this.httpClient.close();
	}

	/**
	 * @param languageRoot String of language root
	 * @param selectors Array of selectors
	 * @param tags String Tags
	 * @param locale Locale locale
	 * @return jsonObject JSONObject of Search Results
	 * @throws LoginException
	 * @throws URISyntaxException
	 */
	public final JSONObject getSearchResults(String parentTagStr, String languageRoot, String[] selectors, String tags, Locale locale) throws LoginException {
		final Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        try {
	        resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
			final TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
		    final Tag parentTag = tagManager.resolve(parentTagStr);
			String parentTagId = parentTag.getTagID().replaceAll(":", "\\\\:");//escape the colon for Solr
			final Map<String, String> selectorsMap = selectorsToMap(selectors);
			final List<NameValuePair> nvPairList = getRequestParams(parentTagId, selectorsMap, tags);
			return requestSolr(nvPairList);
        }finally {
        		if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }
	}

	private JSONObject requestSolr(final List<NameValuePair> nvPairList) {
		try{
			final HttpGet getRequest = new HttpGet(solrHost);
			final URI uri = new URIBuilder(getRequest.getURI()).addParameters(nvPairList).build();
			getRequest.setURI(uri);
			getRequest.addHeader("Accept", "application/json");
			
			if(logger.isDebugEnabled())logger.debug("SOLR Query URL: "+getRequest);
			final HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				logger.error("SOLR query returned non 200 response: "+response.getStatusLine().getStatusCode());
				logger.error("SOLR Reponse: "+CharStreams.toString(new InputStreamReader(response.getEntity().getContent(), Charsets.UTF_8)));
				return null;
			}
			final JSONObject jsonObject = getJSONObject(response);
			return jsonObject;

		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	public static void main(String[] args) throws InterruptedException, JSONException, LoginException{
		SearchSolrService service = new SearchSolrService();
		service.httpClient = HttpClientBuilder.create().setConnectionReuseStrategy(new DefaultConnectionReuseStrategy()).build();
		System.out.println("SOLR Query Response: "+service.getSearchResults("icp:article-type", "", new String[]{"q=test", "sort=score", "page=1"}, "", Locale.US).toString(4));
		System.out.print("\n################################################################################\n");
		System.out.println("SOLR Query Response: "+service.getSearchResults("icp:article-type", "", new String[]{"q=walmart video youtube", "sort=score", "page=1"}, "", Locale.US).toString(4));
		System.out.print("\n################################################################################\n");
		try{
			final HttpGet getRequest = new HttpGet("http://localhost:4502/content/adp/search-solr/jcr:content/search.searchResults.q=test.sort=score.page=1.json?tags=");
			getRequest.addHeader(BasicScheme.authenticate(new UsernamePasswordCredentials("admin", "admin"), "UTF-8", false));
			getRequest.addHeader("Accept", "application/json");
			System.out.println("AEM Query URL: "+getRequest.getURI());
			final HttpResponse response = service.httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				System.out.println("AEM query returned non 200 response: "+response.getStatusLine().getStatusCode());
			}
			
			System.out.println("AEM Query Response: "+new GsonBuilder().setPrettyPrinting().create().toJson(new JsonParser().parse(CharStreams.toString(new InputStreamReader(response.getEntity().getContent(), Charsets.UTF_8))).getAsJsonObject()));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * Dynamically constructs a SOLR query and sets all SOLR query params
	 * @param parentTagId
	 * @param selectorsMap
	 * @param tags
	 * @return
	 */
	private List<NameValuePair> getRequestParams(String parentTagId, Map<String, String> selectorsMap, String tags) {
		final StringBuilder queryStringBuilder = new StringBuilder();
		StringBuilder filters = new StringBuilder();
		
		if("".equals(selectorsMap.getOrDefault("q", ""))){//append query term
			queryStringBuilder.append("*:*");//empty query
		}else if(selectorsMap.getOrDefault("q", "").matches("(?i)^.*?video.*$")){//someone searched for a term that includes the word video
			//In theory, a document with a html <video> tag should have the word 'video' somewhere in it, 
			//so the following should be unnecessary, since searching the  content and title fields should return that document. 
			//Unfortunately, this may not always be the case, so we added in the CustomNutchPlugin.java (https://bitbucket.org/axis41/walmart-adp-solr/src/c3aa6dbccb5e863d38d037609952b85dbbc3a253/src/main/java/com/boxymoron/nutch/plugin/CustomNutchPlugin.java?at=master&fileviewer=file-view-default)
			//logic to add a SOLR boolean field named 'hasVideo' which is set to true when a document has a video tag.
			//The correct way to filter on video articles is to tag them with a video tag (cq tag) and make the user select that tag in the search page filter.
			//Anyway, here we go...
			
			queryStringBuilder.append("hasVideo:true^4");//boolean query for document with a html <video> tag, add a boost
			
			queryStringBuilder.append(" OR content:video^2");//search content for term 'video', add smaller boost to term 'video'
			queryStringBuilder.append(" OR title:video^2");//search title for term 'video', add smaller boost to term 'video'

			//logic to handle other search terms besides 'video' in a phrase like 'production video 123'
			final Pattern pattern = Pattern.compile("(?i)^(.*)?video(.*)$");
			final Matcher matcher = pattern.matcher(selectorsMap.get("q"));
			if(matcher.matches()){
				String pre = matcher.group(1).trim();
				if(!pre.isEmpty()){
					queryStringBuilder.append(" OR content:").append(pre.trim());//other term are not boosted
					queryStringBuilder.append(" OR title:").append(pre.trim());//other term are not boosted
				}
				String post = matcher.group(2).trim();
				if(!post.isEmpty()){
					queryStringBuilder.append(" OR content:").append(post.trim());//other term are not boosted
					queryStringBuilder.append(" OR title:").append(post.trim());//other term are not boosted
				}
			}
		}else{
			//search content and title fields
			queryStringBuilder.append("content:").append(selectorsMap.getOrDefault("q", ""));
			queryStringBuilder.append(" OR title:").append(selectorsMap.getOrDefault("q", ""));
		}
		
		if(selectorsMap.containsKey("category")){//search the category (tag)
            filters.append("fullIdTags:(").append("test"+"/"+selectorsMap.get("category"));
            if((null == tags || tags.isEmpty()) && !selectorsMap.containsKey("template")){
                filters.append(")");
            }
        }
        
        if(selectorsMap.containsKey("template")){
            if(filters.toString().contains("fullIdTags:(")){
                filters.append(" or template:" ).append(selectorsMap.get("template"));
            }else{
                filters.append("fullIdTags:( template:" ).append(selectorsMap.get("template"));
            }
            if(null == tags || tags.isEmpty()){
                filters.append(")");
            }
        }
        
        if(null != tags && !tags.isEmpty()){//search the free-form tags
            final String[] tagz = tags.split("\\|");
            for(int i=0; i<tagz.length; i++){
                if(tagz[i].trim().length() == 0)continue;
                
                if(!selectorsMap.containsKey("category") && i==0){
                    filters.append("fullIdTags:(").append(tagz[i].replaceAll(":", "\\\\:"));
                }else{
                    filters.append(" or ").append(tagz[i].replaceAll(":", "\\\\:"));
                }
                if(i==(tagz.length-1)){
                    filters.append(")");
                }
                
            }
        }
		
		
		final List<NameValuePair> nvPairList = new ArrayList<>();
			nvPairList.add(new BasicNameValuePair("q", queryStringBuilder.toString()));//the query
			nvPairList.add(new BasicNameValuePair("rows",Integer.toString(PAGE_SIZE)));//the number of rows
			nvPairList.add(new BasicNameValuePair("start", getStartAt(selectorsMap)));//start at row
			nvPairList.add(new BasicNameValuePair("sort", getSortBy(selectorsMap)));//sort by
			nvPairList.add(new BasicNameValuePair("wt","json"));//use json responses
			nvPairList.add(new BasicNameValuePair("fl","*,score"));//include all fields, and pseudo field score
			nvPairList.add(new BasicNameValuePair("indent","on"));//indent json
			
			nvPairList.add(new BasicNameValuePair("fq",filters.toString()));//add filters
			
			
		return nvPairList;
	}

	/**
	 * Get the SOLR start at parameter
	 * @param selectorsMap
	 * @return
	 */
	private String getStartAt(final Map<String, String> selectorsMap) {
		String startAtStr = selectorsMap.getOrDefault("page", "1");
		Integer startAt = 0;
		try{
			startAt = Integer.parseInt(startAtStr) - 1;//subtract 1 because Solr starts at 0
		}catch(NumberFormatException nfe){
			nfe.printStackTrace();
		}
		return startAt.toString();
	}

	/**
	 * Get the SOLR sort parameter
	 * @param selectorsMap
	 * @return
	 */
	private String getSortBy(final Map<String, String> selectorsMap) {
		String sort = "score desc";
		if("date".equals(selectorsMap.getOrDefault("sort", "score desc"))){
			sort="tstamp desc";
		}
		return sort;
	}

	/**
	 * Get a JSONObject from a http response
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 */
	private JSONObject getJSONObject(final HttpResponse response) throws IOException, JSONException {
		final StringWriter writer = new StringWriter();
		IOUtils.copy(response.getEntity().getContent(), writer, "UTF-8");
		if(logger.isDebugEnabled())logger.debug("SOLR Query Response: "+new GsonBuilder().setPrettyPrinting().create().toJson(new JsonParser().parse(writer.toString()).getAsJsonObject()));
		final JSONObject responseObj = new JSONObject(writer.toString());
		final JSONObject jsonObject = getRequiredJSON(responseObj);
		return jsonObject;
	}

	/**
	 * Convert a String array of selectors to a Map of selector k-v pairs
	 * @param selectors
	 * @return
	 */
	private Map<String, String> selectorsToMap(String[] selectors) {
		Map<String, String> selectorsMap = Arrays.stream(selectors).flatMap(str ->{
			if(str == null || str.trim().isEmpty()){
				return Stream.empty();
			}else{
				String[] parts = str.split("=");
				if(parts.length == 2){
					return Stream.of(new AbstractMap.SimpleEntry<String, String>(parts[0], parts[1]));
				}else{
					return Stream.empty();
				}
			}
		}).collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> e2, () -> new HashMap<>()));
		return selectorsMap;
	}

	/**
	 *
	 * @param responseJSON JSON Object of request
	 * @return requiredJSON JSON Object with JSON Array of properties
	 */
	private final JSONObject getRequiredJSON(JSONObject responseJSON) throws JSONException {
		final JSONObject requiredJSON = new JSONObject();
		final JSONArray requiredJSONdocArr = new JSONArray();
		if (responseJSON.has("response")) {
			final JSONObject respObj = responseJSON.getJSONObject("response");
			final Object object = respObj.get("docs");
			final JSONArray jsonArray;
			if (object instanceof JSONArray) {
				jsonArray = (JSONArray) object;
				for (int i = 0; i < jsonArray.length(); i++) {
					final JSONObject requiredInnerJSON = new JSONObject();
					final JSONObject docObj = (JSONObject) jsonArray.get(i);
					if (docObj.has("id")) {
						requiredInnerJSON.put("id", docObj.getString("id"));
					}
					if (docObj.has("title")) {
						requiredInnerJSON.put("title", docObj.getString("title"));
					}
					if (docObj.has("path")) {
						requiredInnerJSON.put("path", docObj.getString("path"));
					}else{
						requiredInnerJSON.put("path", docObj.getString("url"));
					}
					if (docObj.has("template")) {
						requiredInnerJSON.put("category", docObj.getString("template"));
					}
					if (docObj.has("tags")) {
						requiredInnerJSON.put("tags",docObj.getJSONArray("tags"));
					}
					if (docObj.has("publishDate")) {
						requiredInnerJSON.put("date", docObj.getString("publishDate"));
					}
					requiredJSONdocArr.put(requiredInnerJSON);
				}
			}
			requiredJSON.put("results", requiredJSONdocArr);
			requiredJSON.put("total", respObj.getInt("numFound"));
			requiredJSON.put("page", respObj.getInt("start")+1);//(GUI starts at 1)
			long pages = respObj.getInt("numFound") / PAGE_SIZE;
            if (respObj.getInt("numFound") % PAGE_SIZE != 0) {
                pages++;
            }
            pages = Math.min(pages, 10);
            requiredJSON.put("pages", pages);
		}
		return requiredJSON;
	}
}

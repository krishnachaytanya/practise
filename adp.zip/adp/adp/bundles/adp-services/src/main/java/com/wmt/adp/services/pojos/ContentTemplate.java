package com.wmt.adp.services.pojos;

/**
 * Created by dgeary on 9/7/17.
 */
public class ContentTemplate implements Comparable<ContentTemplate> {
    private String path;
    private String title;
    private String searchFacet;
    private String searchFacetTitle;
    private String searchFacetData;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSearchFacet() {
        return searchFacet;
    }

    public void setSearchFacet(String searchFacet) {
        this.searchFacet = searchFacet;
    }

    public String getSearchFacetTitle() {
        return searchFacetTitle;
    }

    public void setSearchFacetTitle(String searchFacetTitle) {
        this.searchFacetTitle = searchFacetTitle;
    }

    public String getSearchFacetData() {
        return searchFacetData;
    }

    public void setSearchFacetData(String searchFacetData) {
        this.searchFacetData = searchFacetData;
    }

    @Override
    public int compareTo(ContentTemplate contentTemplate) {
        return this.getTitle().compareTo(contentTemplate.getTitle());
    }
}

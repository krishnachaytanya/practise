package com.wmt.adp.services.utils;

import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by vn56264 on 8/15/2017.
 */
public class DateUtils {
	private static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

	public static final String METADATA_FORMAT = "yyyy-MM-dd";
    public static final String SEARCH_FORMAT = "MMM d, yyyy";
    public static final String PUBLISH_DATE = "MMM d, yyyy";
    public static final String LAST_REPLICATED = "MMM d, yyyy";
    public static final String JCR_CREATED = "MMM d, yyyy";
	public static final String ISO_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

    public static String getFormattedDate(Calendar calendar) {
        return getFormattedDate(calendar, METADATA_FORMAT);
    }

    public static String getFormattedDate(Calendar calendar, String format) {
        String formattedDate = "";

        if (calendar != null) {
            SimpleDateFormat formatter = new SimpleDateFormat(format);
			formatter.setTimeZone(calendar.getTimeZone());
            formattedDate = formatter.format(calendar.getTime());
        }

        return formattedDate;
    }

    public static String getFormattedDate(Long time) {
        return getFormattedDate(time, SEARCH_FORMAT);
    }

    public static String getFormattedDate(Long time, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(new Date(time));
    }
    
    /**
	 * Format the date to : Month, day[suffix]
	 * @param articleDate Date to format
	 * @return Return the date formated
	 */
	public static String getformattedDateWithSufix(Calendar articleDate) {
		if(articleDate != null){
			int day=articleDate.get(Calendar.DAY_OF_MONTH);
			if(day >= 11 && day <= 13){
				return new SimpleDateFormat("MMMM dd'th'").format(articleDate.getTime());
			}
			switch(day % 10){
			case 1:
				return new SimpleDateFormat("MMMM dd'st'").format(articleDate.getTime());
			case 2:
				return new SimpleDateFormat("MMMM dd'nd'").format(articleDate.getTime());
			case 3:
				return new SimpleDateFormat("MMMM dd'rd'").format(articleDate.getTime());
			default:
				return new SimpleDateFormat("MMMM dd'th'").format(articleDate.getTime());
			}
		}
		return "";
	}

	/**
	 * Gets a date off of the page. publishDate -> cq:lastReplicated -> jcr:created
	 * @param page the Page we want a date from
	 * @return Calendar of the best fitting date
	 */
	public static Calendar getBestDate(Page page) {
		ValueMap properties = page.getContentResource().getValueMap();
		if (properties.containsKey("publishDate")) {
			return properties.get("publishDate", Calendar.class);
		}

		if (properties.containsKey("cq:lastReplicated")) {
			return properties.get("cq:lastReplicated", Calendar.class);
		}

		return properties.get("jcr:created", Calendar.class);
	}
	
	
	/**
	 * Gets a duration time displayed 02:40:37 , returning  duration in the next format 2h 40m 37s
	 */
	
	public static String getFormattedDuration(String duration){
		String formatDuration ="";
		if(duration.isEmpty() ||  duration == null) {
			return "0h 0m 0s";
		}
		String[] parts = duration.split ( ":" );
		String hours= getHours(parts[0]);
		String minutes = getMinutes(parts[1]);
		String seconds= getSeconds(parts[2]);
		formatDuration = hours + minutes + seconds;
		return formatDuration;
	}
	
	public static String getHours(String hours)
	{
		String formattedHours="";
		if(!hours.equals("00"))
		{
			if(hours.charAt(0)== '0') formattedHours= hours.charAt(1) + "h ";
			else
				formattedHours= hours + "h ";
		}
			
		return formattedHours;
	}
	
	public static String getMinutes(String minutes)
	{
		String formattedMinutes="";
		if(!minutes.equals("00"))
		{
			if(minutes.charAt(0) == '0') formattedMinutes =  minutes.charAt(1) + "m ";
			else
				formattedMinutes= minutes + "m ";
		}
			
		return formattedMinutes;
	}
	
	public static String getSeconds(String seconds)
	{
		String formattedSeconds="";
		if(!seconds.equals("00"))
		{
			if(seconds.charAt(0) == '0') formattedSeconds =  seconds.charAt(1) + "s";
			else
				formattedSeconds= seconds + "s ";
		}
			
		return formattedSeconds;
	}
}


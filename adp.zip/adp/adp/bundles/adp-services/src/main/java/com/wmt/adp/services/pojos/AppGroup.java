package com.wmt.adp.services.pojos;

import com.wmt.adp.services.pojos.App;

import java.util.ArrayList;

/**
 * Created by dgeary on 9/6/17.
 */
public class AppGroup {
	private String title;
	private ArrayList<App> apps;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public ArrayList<App> getApps() {
		return apps;
	}

	public void setApps(ArrayList<App> apps) {
		this.apps = apps;
	}
}

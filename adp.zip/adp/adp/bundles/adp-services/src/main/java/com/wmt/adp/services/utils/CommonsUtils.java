package com.wmt.adp.services.utils;

import java.util.Calendar;
import java.util.Date;

public class CommonsUtils {
	
	
	public static final String DEFAULT_AUTHOR = "Unknown";
    
    
	/**
	 * Extract the first char from the first
	 * and last word in the name parameter
	 * i.e: Some Name = SN, Some Middle LastName = SL
	 * @param name The name in a format {@code Name LastName} or 
	 * {@code Name MiddleName LastName} 
	 * @return Returns the initials for a given name
	 */
	public static String extractInitials(String name) {
		
		if(!name.equalsIgnoreCase(DEFAULT_AUTHOR)){
			String allInitials = name.replaceAll("(?<=\\w)\\w", "").replaceAll("\\s","");
			return allInitials.charAt(0)+""+allInitials.charAt(allInitials.length()-1);
		}
		return "UK";
	}

	/**
	 * Checks if the alert should be displayed
	 * by checking the text is not empty  
	 * and the the alert has not expired
	 * @param alertText The text to be displayed
	 * @param alertOnTime The date when the alert should begin
	 * @param alertOffTime The date when the alert should expire
	 * @return Returns if the alert is visible
	 */
	public static boolean checkPageAlerts(String alertText, Calendar alertOnTime, Calendar alertOffTime){
		if(!alertText.trim().isEmpty() && alertOnTime != null  && alertOffTime != null){
			return alertOffTime.getTime().after(new Date());
		}
		return false;
	}
}

package com.wmt.adp.services.pojos;

/**
 * Created by dgeary on 9/6/17.
 */
public class App {
	private String title;
	private String appLink;
	private String icon;
	private String appColor;
	private String appPath;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAppLink() {
		return appLink;
	}

	public void setAppLink(String appLink) {
		this.appLink = appLink;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getAppColor() {
		return appColor;
	}

	public void setAppColor(String appColor) {
		this.appColor = appColor;
	}

	public String getAppPath() {
		return appPath;
	}

	public void setAppPath(String appPath) {
		this.appPath = appPath;
	}
}

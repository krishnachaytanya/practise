package com.wmt.adp.services.utils;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by dgeary on 9/6/17.
 */
public class PropertyUtil {
    private static final Logger logger = LoggerFactory.getLogger(PropertyUtil.class);

    public static ArrayList<HashMap<String, String>> getMultifieldArray(String[] multifieldProperty) {
        ArrayList<HashMap<String, String>> multifieldList = new ArrayList<>();
        //loop on objects
        for (String jsonString : multifieldProperty) {
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(jsonString);
                HashMap<String, String> map = new HashMap<>();
                Iterator<String> keys = jsonObject.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = jsonObject.getString(key);
                    map.put(key, value);
                }
                multifieldList.add(map);
            } catch (JSONException e) {
                logger.error("Error Getting Multifield Valuemap",e);
            }
        }

        return multifieldList;
    }
}

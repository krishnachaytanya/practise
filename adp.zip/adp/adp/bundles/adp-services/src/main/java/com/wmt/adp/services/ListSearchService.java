package com.wmt.adp.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.pojos.NavigationItem;
import com.wmt.adp.services.utils.LinkUtils;


/**
 * @author Merkcle / Axis41
 *
 */
@Component(
        label = "List Search Service",
        description = "Gets different search by type",
        immediate = true)
@Service(value = { ListSearchService.class })
public class ListSearchService {

	/** logger */
    private static final Logger logger = LoggerFactory.getLogger(ListSearchService.class);

	/** resourceResolver */
    private ResourceResolver resourceResolver;

	/** resourceResolverFactory */
    @Reference
    private ResourceResolverFactory resourceResolverFactory;

	/** tagService */
    @Reference
    private TagService tagService;

	/**
	 * @param links
	 * @return listItems An List of items representing search elements.
	 */
    public List<Map<String, String>> getSearchManual(String[] links) {
    	List<Map<String, String>> listItems = new ArrayList<>();
    	try {
    		this.resourceResolver = this.resourceResolverFactory.getAdministrativeResourceResolver(null);
            if (links !=  null) {
               
                List<String> jsonList =  Arrays.asList(links);
                listItems = jsonList.stream()
                        .flatMap(jsonChunk -> {
                            try {
                                return Stream.of(new JSONObject(jsonChunk));
                            } catch (JSONException e) {
                                System.err.println("Error parsing JSON: "+jsonChunk);
                                System.err.println("Error was: "+e.getMessage());
                                return null;
                            }
                        })
                        .filter(jsonObject -> {
                            try{
                                if("".equals(jsonObject.optString("title"))){//check that it has a title
                                    System.err.println("Missing key ‘title’ for JSON: "+jsonObject.toString(4));
                                    return false;
                                }
                                if("".equals(jsonObject.optString("path"))){//check that it has a path
                                    System.err.println("Missing key ‘path’ for JSON: "+jsonObject.toString(4));
                                    return false;
                                }
                                if("".equals(jsonObject.optString("target"))){//check that it has a target
                                    logger.error("Missing key ‘target’ for JSON: "+jsonObject.toString(4));
                                    return false;
                                }
                                return true;
                            }catch(JSONException e){
                                e.printStackTrace();
                                return false;
                            }
                        })
                        .flatMap(jsonObject -> {
                            try{
                                final Map<String, String> map = new HashMap<>();
                                map.put("title", jsonObject.getString("title"));
                                String path = jsonObject.getString("path");
                                path = LinkUtils.formatLink(path, resourceResolver);
                                map.put("path", path);
                                map.put("target", jsonObject.getString("target"));
                                return Stream.of(map);
                            }catch(JSONException e){
                                logger.error("", e);
                                return null;
                            }
                        })
                        .collect(Collectors.toList());
               
                logger.info("listItems " + listItems.size());
            }
            return listItems;
		} catch (Exception e) {
			logger.error("getSearchManual: ", e);
		}finally {
            if (resourceResolver.isLive() && resourceResolver != null) {
                resourceResolver.close();
            }
        }
    	return listItems;
    }

	/**
	 * @param parentPath
	 * @return childList - List of items representing parent search elements.
	 */
    public List<NavigationItem> getParentSearch(String parentPath){
    	List<NavigationItem> childList = new ArrayList<>();
    	try {
	    	 this.resourceResolver = this.resourceResolverFactory.getAdministrativeResourceResolver(null);
	         PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	         Page parentPage= pageManager.getContainingPage(parentPath);

			 if (parentPage!=null) {
				 Iterator<Page>rootPageIterator = parentPage.listChildren();
				 while (rootPageIterator.hasNext()) {
					 childList.add(buildNavigationItem(rootPageIterator.next()));
				 }    		
			 }
    	} catch (Exception e) {
			logger.error("getParentSearch: ", e);
		} finally {
            if (resourceResolver.isLive() && resourceResolver != null) {
                resourceResolver.close();
            }
        }
    	return childList;
    }

	/**
	 * @param tags
	 * @param searchPath
	 * @return tagList - List of items representing parent search elements.
	 */
    public List<NavigationItem> getTagSearch(String[] tags, String searchPath){
    	List<NavigationItem> tagList = new ArrayList<>();
    	try {
    		this.resourceResolver = this.resourceResolverFactory.getAdministrativeResourceResolver(null);
    		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
    		logger.info("tags " + tags.length);
    		RangeIterator<Resource> resources = tagManager.find(searchPath, tags, true);
    		while (resources.hasNext()) {
    			Resource res = resources.next();
    			Page node = res.getParent().adaptTo(Page.class);
    			tagList.add(buildNavigationItem(node));
    		}
    		logger.info("tagList " + tagList.size());
    	} catch (Exception e) {
			logger.error("getTagSearch: ", e);
		} finally {
            if (resourceResolver.isLive() && resourceResolver != null) {
                resourceResolver.close();
            }
        }
    	return tagList;
		
    }

	/**
	 * @param page
	 * @return navigationItem
	 */
	private NavigationItem buildNavigationItem(Page page) {
		NavigationItem navigationItem = new NavigationItem();
		navigationItem.setTitle(page.getTitle());
		navigationItem.setPath(page.getPath() + ".html");
		return navigationItem;
	}
 
   
}

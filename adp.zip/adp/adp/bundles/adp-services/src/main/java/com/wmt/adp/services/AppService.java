package com.wmt.adp.services;

import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.pojos.App;
import com.wmt.adp.services.pojos.AppGroup;
import com.wmt.adp.services.utils.LinkUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.resource.*;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.Cookie;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.*;

/**
 * Created by dgeary on 9/7/17.
 */
@Component(
        label = "App Service",
        description = "Provides methods with proper system user access to manipulate tags",
        immediate = true)
@Service(value = { AppService.class })

public class AppService {
    private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";
    private ResourceResolver resourceResolver = null;
    private static final String APP_TAG_ID = "adp:app-groups";
    private static final String APP_PAGE_RESOURCE_TYPE = "adp/components/page/app";

    @Reference
    ResourceResolverFactory resourceResolverFactory;
    private static final Logger logger = LoggerFactory.getLogger(AppService.class);

    @Reference
    private ConstantsService constantsService;

    public List<AppGroup> getAppGroups(String languageRoot) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);

        List<AppGroup> appGroups = new ArrayList<>();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
            PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);

            Tag appTag = tagManager.resolve(APP_TAG_ID);
            Iterator<Tag> appGroupTags = appTag.listChildren();

            while (appGroupTags != null && appGroupTags.hasNext()) {
                Tag appGroupTag = appGroupTags.next();

                AppGroup appGroup = new AppGroup();
                appGroup.setTitle(appGroupTag.getTitle());

                ArrayList<App> apps = new ArrayList<>();

                String[] appIDs = {appGroupTag.getTagID()};
                RangeIterator<Resource> resources = tagManager.find(languageRoot, appIDs, true);

                while (resources != null && resources.hasNext()) {
                    Resource resource = resources.next();
                    Page page = pageManager.getContainingPage(resource);
                    ValueMap appProperties = page.getProperties();

                    if (APP_PAGE_RESOURCE_TYPE.equals(appProperties.get("sling:resourceType", ""))) {

                        App app = new App();
                        app.setTitle(page.getTitle());
                        app.setAppPath(page.getPath());
                        app.setAppLink(LinkUtils.formatLink(appProperties.get("appLink", ""), resourceResolver));
                        app.setAppColor(appProperties.get("appColor", ""));
                        app.setIcon(appProperties.get("icon", ""));

                        apps.add(app);
                    }
                }

                appGroup.setApps(apps);
                appGroups.add(appGroup);
            }
        } catch  (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e);
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return appGroups;
    }

    public HttpGet getApiRequest(String profileId) {
        URI uri = null;
        try {
            uri = new URIBuilder()
                    .setScheme("https")
                    .setHost(constantsService.getLearningLockerHost())
                    .setPath(constantsService.getLearningLockerPath())
                    .setParameter("activityId", constantsService.getLearningLockerActivityIdApps())
                    .setParameter("profileId", profileId)
                    .build();
        } catch (URISyntaxException e) {
            logger.error("Error creating learning locker uri: ", e);
        }

        HttpGet httpGet = new HttpGet(uri);
        httpGet.addHeader("X-Experience-API-Version", "1.0.3");

        String encodedBasicAuth = "";
        try {
            encodedBasicAuth = Base64.getEncoder().encodeToString((constantsService.getLearningLockerClientKey() + ":" + constantsService.getLearningLockerClientSecret()).getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            logger.error("Error encoding learning locker basic auth: ", e);
        }

        httpGet.addHeader("Authorization", "Basic " + encodedBasicAuth);

        return httpGet;
    }

    public String getUserAppsPaths(String profileId, Cookie cookie) {
        String learningLockerResult = "";

        if (cookie != null) {
            try {
                learningLockerResult = URLDecoder.decode(cookie.getValue(), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                logger.error("Error decoding apps cookie: ", e);
            }
        } else {
            HttpGet httpGet = getApiRequest(profileId);

            try(CloseableHttpClient httpClient = HttpClients.createDefault()) {
                CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity entity = httpResponse.getEntity();

                learningLockerResult = EntityUtils.toString(entity);
            } catch (IOException e) {
                logger.error("Error getting learning locker apps: ", e);
            }
        }

        return learningLockerResult;
    }

    public String getUserAppsJSON(String profileId, Cookie cookie) {
        String appsData = getUserAppsPaths(profileId, cookie);

        return parseApps(appsData);
    }

    public String putUserAppsJSON(String profileId, String[] apps) {
        String learningLockerResult = "";
        JSONObject resultJson = new JSONObject();

        HttpGet httpGet = getApiRequest(profileId);

        try(CloseableHttpClient httpClient = HttpClients.createDefault()) {
            CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
            String eTag = httpResponse.getFirstHeader("ETag").getValue();

            HttpPut httpPut = new HttpPut(httpGet.getURI());
            httpPut.setHeaders(httpGet.getAllHeaders());
            httpPut.setHeader("If-Match", eTag);

            JSONObject appsObject = new JSONObject();
            JSONArray appsArray = new JSONArray();
            if (apps != null) {
                for(String app : apps) {
                    appsArray.put(app);
                }
            }
            appsObject.put("apps", appsArray);

            httpPut.setEntity(new StringEntity(appsObject.toString()));

            CloseableHttpResponse httpPutResponse = httpClient.execute(httpPut);

            if (httpPutResponse.getStatusLine().getStatusCode() == 204) {
                resultJson.put("result", "User apps updated successfully");
                logger.error("200");
            } else {
                HttpEntity entity = httpPutResponse.getEntity();
                String entityString = EntityUtils.toString(entity);
                resultJson.put("result", new JSONObject(entityString));
                logger.error(httpPutResponse.getStatusLine().getStatusCode() + ": " + entityString);
            }
        } catch (IOException e) {
            logger.error("Error getting learning locker apps: ", e);
        } catch (JSONException e) {
            logger.error("Error writing learning locker update results", e);
        }

        learningLockerResult = resultJson.toString();

        return learningLockerResult;
    }

    private String parseApps(String appsData) {
        String apps = "";

        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
        } catch (LoginException e) {
            logger.error("Error logging in to get apps while parsing: ", e);
        }

        try {
            JSONArray appsJsonArray = new JSONArray();
            JSONObject appsJson = new JSONObject();

            JSONObject appsObject = new JSONObject(appsData);

            if (appsObject.has("apps")) {

                JSONArray appsArray = appsObject.getJSONArray("apps");

                for (int i = 0; i < appsArray.length(); i++) {
                    Resource resourceApp = resourceResolver.getResource(appsArray.getString(i));
                    if(resourceApp != null) {
                        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

                        if (pageManager != null) {
                            Page pageApp = pageManager.getContainingPage(resourceApp);
                            if (pageApp == null) continue;
                            ValueMap appProperties = pageApp.getProperties();

                            if (APP_PAGE_RESOURCE_TYPE.equals(appProperties.get("sling:resourceType", ""))) {
                                JSONObject appJson = new JSONObject();
                                appJson.put("title", pageApp.getTitle());
                                appJson.put("appPath", pageApp.getPath());
                                appJson.put("appLink", LinkUtils.formatLink(appProperties.get("appLink", ""), resourceResolver));
                                appJson.put("appColor", appProperties.get("appColor", ""));
                                appJson.put("icon", appProperties.get("icon", ""));
                                appsJsonArray.put(appJson);
                            }
                        }
                    }
                }
            }

            appsJson.put("apps", appsJsonArray);
            apps = appsJson.toString();
        } catch (JSONException e) {
            logger.error("Error parsing learning locker apps data into JSONObject: ", e);
        }

        return apps;
    }
}

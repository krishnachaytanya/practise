package com.wmt.adp.services;

import com.day.cq.wcm.api.Template;
import com.day.cq.wcm.api.TemplateManager;
import com.wmt.adp.services.pojos.ContentTemplate;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by dgeary on 9/7/17.
 */
@Component(
        label = "ContentTag Service",
        description = "Provides methods with proper system user access to manipulate tags",
        immediate = true)
@Service(value = { TemplateService.class })

public class TemplateService {
    private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";
    private static final String ADP_TEMPLATE_ROOT = "/apps/adp/templates";
    private ResourceResolver resourceResolver = null;

    @Reference
    ResourceResolverFactory resourceResolverFactory;
    private static final Logger logger = LoggerFactory.getLogger(TemplateService.class);

    @Activate
    protected void activate() {

    }

    public List<ContentTemplate> getAllSearchableTemplates() {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        Set<ContentTemplate> templateSet = new TreeSet<>();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);

            TemplateManager templateManager = resourceResolver.adaptTo(TemplateManager.class);

            List<Template> templates = templateManager.getAllTemplates();

            for (Template template : templates) {
                String templatePath = template.getPath();
                ValueMap templateProperties = template.getProperties();
                String templateSearchFacet = templateProperties.get("searchFacet", "true");

                if (templatePath.contains(ADP_TEMPLATE_ROOT) && "true".equals(templateSearchFacet)) {
                    ContentTemplate contentTemplate = new ContentTemplate();
                    contentTemplate.setPath(templatePath);
                    contentTemplate.setTitle(template.getTitle());

                    String templateSearchFacetTitle = templateProperties.get("searchFacetTitle", template.getTitle());
                    contentTemplate.setSearchFacetTitle(templateSearchFacetTitle);

                    String[] templatePathParts = templatePath.split("\\/");
                    contentTemplate.setSearchFacetData(templatePathParts[templatePathParts.length - 1]);

                    templateSet.add(contentTemplate);
                }
            }
        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        List<ContentTemplate> templateList = new ArrayList<>(templateSet);

        return templateList;
    }

    public ContentTemplate getContentTemplate(String templatePath) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        ContentTemplate contentTemplate = null;

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);
            TemplateManager templateManager = resourceResolver.adaptTo(TemplateManager.class);

            Template template = templateManager.getTemplate(templatePath);
            contentTemplate = new ContentTemplate();

            if (template != null) {
                contentTemplate.setSearchFacetTitle(template.getProperties().get("searchFacetTitle", ""));
            }

            String[] templatePathParts = templatePath.split("\\/");
            contentTemplate.setSearchFacetData(templatePathParts[templatePathParts.length - 1]);
        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return contentTemplate;
    }
}

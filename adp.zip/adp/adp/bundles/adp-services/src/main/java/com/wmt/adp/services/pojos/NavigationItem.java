package com.wmt.adp.services.pojos;

import java.util.List;

/**
 * @author Merckle / Axis41
 *
 */
public class NavigationItem {

    /** path */
    private String path;

    /** title */
    private String title;

    /** children */
    private List<NavigationItem> children;

    /** @return event */
    public String getPath() {
        return path;
    }

    /**
     * @param path the navigation item path to set
     */
    public void setPath(String path) {
        this.path = path;
    }


    /** @return event */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the navigation item title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }


    /** @return event */
    public List<NavigationItem> getChildren() {
        return children;
    }

    /**
     * @param children the navigation list children to set
     */
    public void setChildren(List<NavigationItem> children) {
        this.children = children;
    }
}

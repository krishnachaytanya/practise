package com.wmt.adp.services;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@Component(
        label = "CurrencyExchange Service",
        description = "Gets results from quickbase",
        immediate = true)
@Service(value = { CurrencyExchangeService.class })
public class CurrencyExchangeService {

    private static final Logger logger = LoggerFactory.getLogger(CurrencyExchangeService.class);

    @Reference
    ConstantsService constantsService;

    public String getCurrencyExchanges() {
        String currencyExchangeUrl = constantsService.getCurrencyExchangeUrl();
        String currencyExchangeResult = "";

        CloseableHttpResponse response = null;

        HttpPost httpPost = new HttpPost(currencyExchangeUrl +  "/getCurrencyExchanges");
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");

        try(CloseableHttpClient httpClient = HttpClients.createDefault()) {
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();

            currencyExchangeResult = EntityUtils.toString(entity);
        } catch (IOException e) {
            logger.error("Error reading http entity getting currency exchanges: ", e);
        }

        return currencyExchangeResult;
    }
}
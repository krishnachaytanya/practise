package com.wmt.adp.services.pojos;

public class LanguageItem implements Comparable<LanguageItem>{

    private String langIso;  // IETF BCP 47 alpha-2 lang code
    private String name;
    private Boolean selected;
    private String path;
    private String countryIso;
    private String langEts = null;  // SDL ETS alpha-3 lang code

    public LanguageItem(String langIso, String name, Boolean selected, String path, String countryIso) {
        super();
        setLangIso( langIso );
        setName( name );
        setSelected( selected );
        setPath( path );
        setCountryIso( countryIso );
    }

    /**
     * @return ISO / BCP 47 alpha-2 language code
     */
    public String getLangIso() {
        return langIso;
    }

    /**
     * @param langIso ISO / BCP 47 alpha-2 language code
     */
    private void setLangIso(String langIso) {
        this.langIso = langIso;
    }

    /**
     * @return ISO alpha-2 country code
     */
    public String getCountryIso() {
        return countryIso;
    }

    /**
     * @param countryIso the ISO alpha-2 country code to set
     */
    private void setCountryIso(String countryIso) {
        this.countryIso = countryIso;
    }

    /**
     * @return the language display name
     */
    public String getName() {
            return name;
    }

    /**
     * @param name the language display name to set
     */
    private void setName(String name) {
        this.name = name;
    }

    /**
     * @return true if current selected language / country
     */
    public Boolean getSelected() {
        	return selected;
    }

    /**
     * @param selected the current selected language / country flag to set
     */
    private void setSelected(Boolean selected) {
        this.selected = selected;
    }

    	/**
     * @return the lang / country content root
     */
    public String getPath() {
        return path;
    }

    /**
     * @param rootPath the lang / country content root 
     */
    private void setPath(String rootPath) {
        this.path = rootPath;
    }

    /**
     * @return the SDL ETS alpha-3 language code ( almost ISO 639 )
     */
    public String getLangEts() {
        return langEts;
    }

    /**
     * @param langEts the langEts to set
     */
    public void setLangEts(String langEts) {
        this.langEts = langEts;
    }

    @Override
    public int compareTo(LanguageItem o) {
        String otherName = ( o != null ? o.getName() : null);

        if ( name == null || otherName == null ) {
            int val = 0;
            if ( name != null && otherName == null ) {
                val = 1;
            } else if ( name == null && otherName != null ) {
                val = -1;
            } // val
            return val;
        } // name

        return getName().compareTo(o.getName());
    }

}

package com.wmt.adp.services.customworkflowsteps;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.wmt.adp.services.utils.EmailUtil;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.felix.scr.annotations.*;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

@Component(name = "com.wmt.adp.services.customworkflowsteps.ADPPublisherEmailService", description = "ADP - Email Service", label = "ADP - EmailService", specVersion = "1.1", metatype = true, immediate = true)
@Service
@Properties({
        @Property(name = "service.description", value = "Sends email to Translation Reviewers based on the payload."),
        @Property(name = "process.label", value = "ADP Email Process Step"),

})
public class ADPPublisherEmailService implements WorkflowProcess {


    private static Logger log = LoggerFactory.getLogger(ADPPublisherEmailService.class);


    @Reference
    private MessageGatewayService messageGatewayService;

    @Reference
    private ConfigurationAdmin configAdmin;

    @Reference
    protected ResourceResolverFactory resolverFactoryService;
    @Reference
    WorkflowService workflowService;
    /**
     * dictionary properties.
     */
    private Dictionary<String, Object> properties = null;


    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        try {

            MessageGateway<Email> messageGateway;
            WorkflowData workflowData = workItem.getWorkflowData();
            String payloadPath = workflowData.getPayload().toString();
            String userid = ADPPublisher.getCurrentCountryUser(payloadPath);
            UserManager userManager = getUserManager(workflowSession.getSession());
            if(null != userid){

                Authorizable authorizable = userManager.getAuthorizable(userid);
                log.info("authorizable : {} for id : {}",authorizable,userid);

            }
            Map<String, String> payloadProps = new HashMap<String, String>();
            EmailUtil eUtil = new EmailUtil();
            eUtil.execute(workItem, metaDataMap, payloadProps, userid, resolverFactoryService, messageGatewayService, workflowService, configAdmin);


        } catch (EmailException e) {
            log.error("Email Exception", e);
        } catch (Exception e) {
            log.error("Exception", e);
        }

    }

    /**
     * This method will get the UserManager instance from javax.jcr.session
     * instance.
     *
     * @param session
     * @return UserManager instance
     * @throws Exception
     */

    public UserManager getUserManager(Session session) throws Exception {
        if ((session == null) || (!session.isLive())) {
            throw new Exception("given session instance is null, unable to proceed");
        }
        JackrabbitSession jackrabbitSession = null;
        UserManager userManager = null;
        try {
            jackrabbitSession = (JackrabbitSession) session;
            if (jackrabbitSession != null) {
                userManager = jackrabbitSession.getUserManager();
            }
        } catch (Exception e) {
            throw new Exception(e);
        }
        return userManager;
    }


}


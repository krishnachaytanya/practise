package com.wmt.adp.services;

import com.adobe.acs.commons.email.EmailService;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.activation.DataSource;
import java.util.Map;

/**
 * Created by gcalandria on 10/12/17.
 */
@Component(
        label = "Email Service",
        description = "Provides methods to send Emails",
        immediate = true)
@Service(value = { ADPEmailService.class })
public class ADPEmailService {
    private static final Logger logger = LoggerFactory.getLogger(ADPEmailService.class);

    @Reference
    private EmailService emailService;

    public void sendEmail(String templatePath, Map<String, String> emailParams, Map<String, DataSource> attachments, String... recipient) {
        try {
            emailService.sendEmail(templatePath, emailParams, attachments, recipient);
        } catch(Exception e){
            logger.error("There was an error on ADPEmailService", e);
        }
    }
}

package com.wmt.adp.services.pojos;

/**
 * Created by dgeary on 9/7/17.
 */
public class ContentTag implements Comparable<ContentTag> {
    private String path;
    private String pagePath;
    private String name;
    private String title;
    private String description;
    private String tagId;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPagePath() {
        return pagePath;
    }

    public void setPagePath(String pagePath) {
        this.pagePath = pagePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    @Override
    public int compareTo(ContentTag contentTag) {
        return this.getTitle().compareTo(contentTag.getTitle());
    }
}

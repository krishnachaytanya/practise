package com.wmt.adp.services.utils;

import com.day.cq.dam.api.Asset;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageUtils {
	private static final Logger logger = LoggerFactory.getLogger(ImageUtils.class);

	/*public static String getImagePath(Resource resource, String dimensions, String quality, Boolean useOriginal) {
		String path = "";
		String subPath = "";
		if (resource == null) {
			return path;
		}
		String assetPath = resource.getValueMap().get("fileReference", "");
		// if we have an asset, we want to use the current resource
		if (resource.getResourceType().equals("dam:Asset")) {
			assetPath = resource.getPath();
		} else if (assetPath.isEmpty()) {
			return "";
		}
		String extension = getFileExtension(assetPath, resource.getResourceResolver());
		String selector = ".img";
		if (dimensions != null && !dimensions.isEmpty()) {
			if (quality == null || quality.isEmpty()) {
				quality = QUALITY_82;
			}
			selector = ".transform/" + dimensions + "/" + quality + "/feature/image";
		}
		if (useOriginal) {
			subPath = "/jcr:content/renditions/original." + extension;
		}
		if (!assetPath.isEmpty()) {
			path = assetPath + subPath + selector + "." + extension;
		}
		return path;
	}*/

	public static String getImagePath(Resource resource) {
		if (resource == null) {
			return "";
		}

		String imagePath = "";
		ValueMap properties = resource.getValueMap();
		String fileReference = properties.get("fileReference", "");
		if (!fileReference.isEmpty()) {
			ResourceResolver resourceResolver = resource.getResourceResolver();
			Resource referencedResource = resourceResolver.getResource(fileReference);
			if (referencedResource != null) {
				String resourceType = referencedResource.getResourceType();
				if ("dam:Asset".equals(resourceType)) {
					if (fileReference.endsWith(".svg")) {
						imagePath = fileReference;
					} else {
						imagePath = resource.getPath() + ".img." + getFileExtension(fileReference, resourceResolver);
					}
				} else if ("nt:file".equals(resourceType)) {
					imagePath = fileReference;
				}
			}
		}
		return imagePath;
	}

	public static String getFileExtension(String fileReference, ResourceResolver resourceResolver) {
		String extension = "jpeg";
		Resource assetResource = resourceResolver.getResource(fileReference);
		if (assetResource != null) {
			Asset asset = assetResource.adaptTo(Asset.class);
			if (asset != null) {
				String metadataValue = asset.getMetadataValue("dam:Fileformat");
				if(metadataValue != null) {
					extension = metadataValue;
				}
			}
		}
		return extension.toLowerCase();
	}

}
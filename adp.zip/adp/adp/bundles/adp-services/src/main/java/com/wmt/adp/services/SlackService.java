package com.wmt.adp.services;

import com.wmt.adp.services.utils.ExternalCallsUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by gcalandria on 9/12/17.
 */
@Component(
        label = "Slack Service",
        description = "Provides methods regarded to Slack",
        immediate = true)
@Service(value = { SlackService.class })
public class SlackService {
    private static final Logger logger = LoggerFactory.getLogger(SlackService.class);

    public void postFeedback(String channel, String message, String category, String url) {

        Map<String, String> headers = new HashMap<String, String>(){{
            put("Content-type", "application/json");
        }};
        String content = "{\"channel\": \"" + channel + "\", " +
                "\"text\": \"" + category + "\n" + message + "\"," +
                "\"username\": \"Feedback Bot\", " +
                "\"icon_emoji\": \":speech_balloon:\"}";
        try {
            ExternalCallsUtils.executeApiPOST(url, headers, "", "", content, new ArrayList<>());
        } catch (IOException e) {
            logger.error("There was an error on SlackService", e);
        }
    }
}

package com.wmt.adp.services.utils;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import com.google.gson.*;
import org.apache.sling.commons.json.JSONException;

import javax.jcr.Binary;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFactory;
import javax.net.ssl.HttpsURLConnection;

import java.io.IOException;
import java.util.*;

public class ExternalCallsUtils {

    public static JsonObject executeApiGET(String urlString, Map<String, String> headers, String authorizationUser, String authorizationPassword, List<String> headersToGet) throws IOException, JsonIOException {
        return executeApi(urlString, headers, authorizationUser, authorizationPassword, "GET", "", headersToGet);
    }

    public static JsonObject executeApiPOST(String urlString, Map<String, String> headers, String authorizationUser, String authorizationPassword, String content, List<String> headersToGet) throws IOException, JsonIOException {
        return executeApi(urlString, headers, authorizationUser, authorizationPassword, "POST", content, headersToGet);
    }

    public static JsonObject executeApiPUT(String urlString, Map<String, String> headers, String authorizationUser, String authorizationPassword, String content, List<String> headersToGet) throws IOException, JsonIOException {
        return executeApi(urlString, headers, authorizationUser, authorizationPassword, "PUT", content, headersToGet);
    }

    private static JsonObject executeApi(String urlString, Map<String, String> headers, String authorizationUser, String authorizationPassword, String method, String content, List<String> headersToGet) throws IOException, JsonIOException {
        final URL url = new URL(urlString);
        final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(method);
        if(!authorizationUser.equals("")) {
            String encoding = Base64.getEncoder().encodeToString((authorizationUser + ":" + authorizationPassword).getBytes("UTF-8"));
            connection.setRequestProperty("Authorization", "Basic " + encoding);
        }
        Iterator iterator = headers.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<String, String> entry = (Map.Entry) iterator.next();
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        if(!content.equals("")){
            connection.setDoOutput(true);
            OutputStream outputStream = connection.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
            outputStreamWriter.write(content);
            outputStreamWriter.flush();
            outputStreamWriter.close();
            outputStream.close();
        }
        final InputStream is = connection.getInputStream();
        if(connection.getResponseCode() == 204) return null;
        final JsonObject jsonResult = getJsonfromStream(is);
        //GET HEADERS
        if(headersToGet == null) return jsonResult;
        Iterator headerIterator = headersToGet.iterator();
        while(headerIterator.hasNext()) {
            String entry = (String) headerIterator.next();
            jsonResult.addProperty("header_" + entry, connection.getHeaderField(entry));
        }
        return jsonResult;
    }

    private static JsonObject getJsonfromStream(InputStream responseStream) throws JsonIOException, IOException {
        JsonParser parser = new JsonParser();
        JsonObject jsonObject;
        JsonElement jsonElement  = parser.parse(new InputStreamReader(responseStream));
        try {
            jsonObject = jsonElement.getAsJsonObject();
        } catch(IllegalStateException e) {
            if(e.getMessage().contains("Not a JSON Object")) {
                Gson gson = new Gson();
                String flatJson = "{ \"output\": \"" + jsonElement.getAsString() + "\" }";
                jsonObject = parser.parse(flatJson).getAsJsonObject();
            } else {
                jsonObject = parser.parse("{}").getAsJsonObject();
            }
        }
        return jsonObject;
    }
    private static Binary getBinaryFromStream(InputStream responseStream, ValueFactory valueFactory) throws IOException,RepositoryException {
        return valueFactory.createBinary(responseStream);
    }
}
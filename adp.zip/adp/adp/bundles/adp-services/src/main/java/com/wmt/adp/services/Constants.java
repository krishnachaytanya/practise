package com.wmt.adp.services;

/**
 * --------------------------------------------------------------------------------------
 * Constants
 * --------------------------------------------------------------------------------------
 * Holds and organize all reusable constant values
 * -­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-­‐-‐
 * Change History
 * --------------------------------------------------------------------------------------
 * Version | Date         | Developer       | Changes
 * 1.0     | 01/23/2017   | isosa           | Initial Creation
 * --------------------------------------------------------------------------------------
 */

public class Constants {

    public static final String FOOTER_SUB_PATH = "/tools/footer/jcr:content/footer";
    public static final boolean IGNORE_PAGE_CONTENT = true;


}

package com.wmt.adp.services.utils;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.CountingInputStream;
import org.apache.commons.lang.text.StrLookup;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.osgi.framework.Constants;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import javax.mail.Header;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.InternetHeaders;
import java.io.*;
import java.util.*;

@Component(name = "com.wmt.adp.services.utils.EmailUtil", label = "ADP - Email Util Service", immediate = true)
@Service(value = { EmailUtil.class })
@Properties({
		@Property(name = Constants.SERVICE_DESCRIPTION, value = "Email Util Service."),
		@Property(name = Constants.SERVICE_VENDOR, value = "walmart") })
public class EmailUtil{
	
	protected ResourceResolverFactory resolverFactoryService;
	protected WorkflowService workflowService;
	private MessageGatewayService messageGatewayService;
	private ConfigurationAdmin configAdmin;
	private static final Logger log = LoggerFactory.getLogger(EmailUtil.class);

	private static final String DEFAULT_CHARSET = "utf-8";

	private static final String JCR_CONTENT = "/jcr:content";

	private static final String METADATA = "/metadata";

	/**
	 * {@inheritDoc}
	 * <p/>
	 * Process arguments:
	 * <p/>
	 * args[0]: mail template
	 * 
	 * @param payloadProps
	 * 
	 * @param resolverFactoryService
	 */


	public void execute(WorkItem item, MetaDataMap metaData, Map<String, String> payloadProps, String participant,ResourceResolverFactory resolverFactoryService,MessageGatewayService  messageGatewayService,WorkflowService  workflowService,ConfigurationAdmin configAdmin) throws WorkflowException {
		Session session = null;
		JackrabbitSession jSession = null;
		try {
		this.messageGatewayService=messageGatewayService;
		this.configAdmin = configAdmin;
		this.messageGatewayService = messageGatewayService;
		this.resolverFactoryService = resolverFactoryService;


		MessageGateway<HtmlEmail> messageGateway;
		
		ResourceResolver resourceResolver = getResourceResolver(resolverFactoryService);
		session = resourceResolver.adaptTo(Session.class);
		jSession = (JackrabbitSession) session;

			try {

				String[] args = buildArguments(metaData);

				// load mail template
				String template = null;
				String charset = DEFAULT_CHARSET;
				if (args.length > 0 && args[0].length() > 0) {
					String emailTemplate = "";
					emailTemplate = args[0];
					charset = getCharSet(jSession, emailTemplate);
					template = loadTemplate(jSession, emailTemplate, charset);

				} else if (args.length > 1 && args[1].length() > 0) {
					template = args[1];
				}

				if (template != null) {

					UserManager userManager = jSession.getUserManager();

					StrSubstitutor substitutor = new StrSubstitutor(
							new PayloadLookup(item, payloadProps, jSession,
									userManager, configAdmin,
									resourceResolver, participant));

					HtmlEmail email = createEmail(template, charset,
							substitutor);
					if (email.getToAddresses().size() > 0) {
						messageGateway = messageGatewayService
								.getGateway(HtmlEmail.class);

						messageGateway.send((HtmlEmail) email);

						log.info("Email sent based on {}", template);
					} else {
						log.warn("did not send email, no recipient addresses available.");
					}
				} else {
					log.warn("Cannot send mail. No email template defined");
				}
			} catch (EmailException e) {
				log.warn("cannot send email: ", e);
			} catch (RepositoryException e) {
				throw new WorkflowException(e);
			} catch (Exception e) {
				throw new WorkflowException(e);
			} finally {
				if (session != null)
					session.logout();
				if (jSession != null)
					jSession.logout();
			}


		} catch (Exception e) {
			log.error("Exception",e);
		} finally {
			if (jSession != null) {
				jSession.logout();
			}
		}

	}

	public String[] buildArguments(MetaDataMap metaData) {
		String processArgs = (String) metaData.get("PROCESS_ARGS", String.class);
		if ((processArgs != null) && (!processArgs.equals(""))) {
			return processArgs.split(",");
		}
		else {
			List<String> args = new ArrayList<String>();
			String templatePath = metaData.get("templatePath", String.class);
			String template = metaData.get("template", String.class);
			if (templatePath != null && !templatePath.equals("")) {
				args.add(templatePath);
			} else if (template != null && !template.equals("")) {
				args.add("");
				args.add(template);
			}
			return args.toArray(new String[args.size()]);
		}
	}

	private HtmlEmail createEmail(String template, String charSet,
			StrSubstitutor substitutor) throws Exception {
		CountingInputStream in = new CountingInputStream(
				new ByteArrayInputStream(template.getBytes(charSet)));
		InternetHeaders iHdrs = new InternetHeaders(in);
		Map<String, String[]> hdrs = new HashMap<String, String[]>();
		Enumeration<?> e = iHdrs.getAllHeaders();
		while (e.hasMoreElements()) {
			Header hdr = (Header) e.nextElement();
			String name = hdr.getName().toLowerCase();
			hdrs.put(name, iHdrs.getHeader(name));
		}

		// use the counting stream reader to read the mail body
		String templateBody = template.substring(in.getCount());


		// create email
		HtmlEmail email = new HtmlEmail();
		email.setCharset(charSet);

		// spool headers
		StringBuilder rcpts = new StringBuilder();
		for (String to : saveRemoveHeader(hdrs, "to")) {
			to = substitutor.replace(to);
			InternetAddress[] afarray = InternetAddress.parse(to, true);
			for (InternetAddress af : afarray) {
				email.addTo(af.getAddress(), af.getPersonal());

			}

			rcpts.append(to).append(", ");
		}

		for (String from : saveRemoveHeader(hdrs, "from")) {
			from = substitutor.replace(from);
			InternetAddress af = new InternetAddress(from);
			email.setFrom(af.getAddress(), af.getPersonal());
		}
		String[] subject = saveRemoveHeader(hdrs, "subject");
		if (subject.length > 0) {
			email.setSubject(substitutor.replace(subject[0]));
		}

		// add all remaining headers
		for (String name : hdrs.keySet()) {
			for (String value : hdrs.get(name)) {
				value = substitutor.replace(value);
				email.addHeader(name, value);
			}
		}
		// set message body
		templateBody = substitutor.replace(templateBody);
		email.setMsg(templateBody);
		return email;
	}

	private static String[] saveRemoveHeader(Map<String, String[]> hdrs,
			String name) {
		String[] ret = hdrs.remove(name);
		return ret == null ? new String[0] : ret;
	}

	private String getCharSet(Session session, String path) {
		String encoding = DEFAULT_CHARSET;
		try {
			Node content = session.getNode(path + "/"
					+ JcrConstants.JCR_CONTENT);
			encoding = content.hasProperty(JcrConstants.JCR_ENCODING) ? content
					.getProperty(JcrConstants.JCR_ENCODING).getString()
					: DEFAULT_CHARSET;

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return encoding;
	}

	/**
	 * Loads the mail templates from the repository
	 * 
	 * @param path
	 *            mail templates root path
	 * @param session
	 *            session
	 * @return a reader to the template or <code>null</code> if not valid.
	 */
	public String loadTemplate(Session session, String path, String charSet) {
		InputStream is = null;
		try {
			Node content = session.getNode(path + "/"
					+ JcrConstants.JCR_CONTENT);
			is = content.getProperty(JcrConstants.JCR_DATA).getBinary()
					.getStream();
			InputStreamReader r = new InputStreamReader(is, charSet);
			StringWriter w = new StringWriter();
			IOUtils.copy(r, w);
			return w.toString();
		} catch (Exception e) {
			log.error("Error while loading mail template {}:{}", path,
					e.toString());
		} finally {
			IOUtils.closeQuietly(is);
		}
		return null;
	}

	private static class PayloadLookup extends StrLookup {

		private ValueMap properties = new ValueMapDecorator(
				new HashMap<String, Object>());

		private Node content = null;

		private PayloadLookup(WorkItem workItem,
				Map<String, String> payloadProps, Session session,
				UserManager userManager, ConfigurationAdmin configAdmin,
				ResourceResolver resourceResolver,
				String participant) throws RepositoryException {


			Workflow workflow = workItem.getWorkflow();

			// instance
			put("instance.id", workflow.getId());
			put("instance.state", workflow.getState());
			putAll(workflow.getMetaDataMap(), "instance.data.");
			// model
			put("model.title", workflow.getWorkflowModel().getTitle());

			//Completing Setting Assignees
			putAll(workflow.getWorkflowModel().getMetaDataMap(), "model.data.");

			// initiator
			String Users = "";
			String First = "";
			String initiatorId = workflow.getInitiator();
			Authorizable initiator = null;
			try {
				initiator = userManager.getAuthorizable(initiatorId);
			} catch (RepositoryException e1) {
				log.error("RepositoryException",e1);
			}
			String firstName1 = getFirstName(initiator, resourceResolver);
			String lastName1 = getLastName(initiator, resourceResolver);
			Users = firstName1 + " " + lastName1;
			First = firstName1;
			put("initiator.firstname", Users);
			put("initiator.first", First);
			putAll(initiator, "initiator.");

			put("initiator.email", getEmail(initiator, resourceResolver));

			// Workflow Current Assignee
			Authorizable assignee = null;

			try {
				assignee = userManager.getAuthorizable(participant);
				if (assignee != null) {
					log.info("Assignee is: " + assignee);
				} else {
					log.info("Assignee is null");
				}

			} catch (RepositoryException e1) {
				log.error("RepositoryException",e1);
			}

			put("workflow.currentAssignee", participant);

			String users_list = "";
			String listUsers = "";

			if (assignee.isGroup()) {

				Group grp = (Group) assignee;

				try {
					for (Iterator<Authorizable> it = grp.getMembers(); it.hasNext(); ) {

						Authorizable user = (Authorizable) it.next();
						String firstName = getFirstName(user, resourceResolver);
						String lastName = getLastName(user, resourceResolver);
						listUsers = listUsers + firstName + " " + lastName + ", ";

						String mail = getEmail(user, resourceResolver);
						if (mail != null) {
							if (users_list.length() > 0) {
								users_list = users_list.toString() + "," + mail;

							} else {
								users_list = mail;

							}
						}
					}
				} catch (RepositoryException e) {
					log.error("RepositoryException",e);
				}
				if (listUsers.endsWith(", ")) {
					listUsers = listUsers.substring(0, listUsers.length() - 2) + " ";
				}
				put("assignee.id", users_list);
			} else {
				put("assignee.id", getEmail(assignee, resourceResolver));
			}

			if (listUsers != "") {
				put("assignee.FirstNames", listUsers);
			}

			String firstName = getFirstName(assignee, resourceResolver);

			String lastName = getLastName(assignee, resourceResolver);
			if (firstName != "") {
				put("participant.id", firstName);
			} else {
				put("participant.id", assignee.getID());
			}

			// Host Properties
			Configuration cfg = null;
			try {
				cfg = configAdmin.getConfiguration("com.day.cq.workflow.impl.email.EMailNotificationService");
			} catch (IOException e2) {
				log.error("IOException",e2);
			}
			if (cfg != null) {
				Dictionary<?, ?> props = cfg.getProperties();
				put("host.prefix", props.get("host.prefix"));
				//hostPrefix = props.get("host.prefix").toString();

			}

			// Workflow data
			WorkflowData workflowData = workflow.getWorkflowData();
			putAll(workflowData.getMetaDataMap(), "data.");
		}

		public String lookup(String key) {
			if (key.startsWith("payload.") && !key.equals("payload.path")) {
				String path = key.substring(8).replace('.', '/');
				try {
					if (content.hasProperty(path)) {
						javax.jcr.Property p = content.getProperty(path);
						if (p.getType() == PropertyType.BINARY) {
							return "[binary, " + p.getLength() + " bytes]";
						} else {
							return p.getString();
						}
					}
				} catch (RepositoryException e) {
					log.error("error while retrieving property for key {}: {}",
							key, e.toString());
				}
			}
			return properties.get(key, String.class);
		}

		private void put(String name, Object value) {

			if (value != null) {
				properties.put(name, value);
			}
		}

		private void putAll(MetaDataMap metaData, String prefix) {
			// add all data to the properties
			for (final String name : metaData.keySet()) {
				if (name.endsWith("template")) {
					String value = metaData.get(name, String.class);
					if (value != null) {
						value = escapeVariables(value);
						properties.put(prefix + name, value);
					}
				} else {
					properties.put(prefix + name,
							metaData.get(name, String.class));
				}

			}
		}

		private String escapeVariables(String value) {
			return value == null ? value : value.replaceAll(
					"\\$\\{([\\w.:_\\/]+)\\}", "\\$\\$\\{$1\\}");

		}

		private void putAll(Authorizable auth, String prefix) {
			try {

				Iterator<String> iter = auth.getPropertyNames();
				while (iter.hasNext()) {
					String name = iter.next();
					properties.put(prefix + name, auth.getProperty(name));
				}

				this.properties.put(prefix + "id", auth.getID());
				

			} catch (Exception e) {
				log.error("Exception",e);
			}
		}

		private String getEmail(
				Authorizable assignee,
				ResourceResolver resourceResolver) {
			String emailAddress = null;
			Resource userNodeResource = null;
			try {
					userNodeResource = resourceResolver.getResource(assignee
							.getPath());
					ValueMap props = userNodeResource.adaptTo(ValueMap.class);
					emailAddress = (String) props.get("profile/email");
			} catch (UnsupportedRepositoryOperationException e1) {
				log.error("UnsupportedRepositoryOperationException",e1);
			} catch (RepositoryException e1) {
				log.error("RepositoryException",e1);
			}
			return emailAddress;

		}

		private String getFirstName(
				Authorizable assignee,
				ResourceResolver resourceResolver) {
			String firstName = "";
			Resource userNodeResource = null;
			try {

					userNodeResource = resourceResolver.getResource(assignee
							.getPath());
					ValueMap props = userNodeResource.adaptTo(ValueMap.class);
					firstName = (String) props.get("profile/givenName");
					if(firstName==null){
						firstName="";
					}

			} catch (UnsupportedRepositoryOperationException e1) {
				log.error("UnsupportedRepositoryOperationException",e1);
			} catch (RepositoryException e1) {
				log.error("RepositoryException",e1);
			}
			return firstName;

		}
		
		
		private String getLastName(Authorizable assignee,
				ResourceResolver resourceResolver) {
			String lastName = "";
			Resource userNodeResource = null;
			try {
					userNodeResource = resourceResolver.getResource(assignee.getPath());
					ValueMap props = userNodeResource.adaptTo(ValueMap.class);
					lastName = (String) props.get("profile/familyName");

			} catch (UnsupportedRepositoryOperationException e1) {
				log.error("UnsupportedRepositoryOperationException",e1);
			} catch (RepositoryException e1) {
				log.error("RepositoryException",e1);
			}
			return lastName;

		}

	}

	private static ResourceResolver getResourceResolver(
			ResourceResolverFactory resolverFactoryService) {
		ResourceResolver resourceResolver = null;
		try {
			resourceResolver = resolverFactoryService
					.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			log.error("LoginException",e);
		}
		return resourceResolver;

	}

}
package com.wmt.adp.services.utils;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

/**
 * Created by vn56264 on 8/21/2017.
 */
public class PageUtils {

    public static Page getSiteRoot(Page currentPage) {
        return currentPage.getAbsoluteParent(1);
    }

    public static Page getLanguageRoot(Page currentPage, PageManager pageManager) {
        Page languageRoot = currentPage.getAbsoluteParent(2);
        if (languageRoot == null) {
            Page siteRoot = getSiteRoot(currentPage);
            languageRoot = pageManager.getPage(siteRoot.getPath() + "/en_ca");
        }
        return languageRoot;
    }
    
    public static String getTitle(Page page){
    	String title = page.getTitle();
    	if(page.getNavigationTitle() != null && !"".equals(page.getNavigationTitle())){
	    	title = page.getNavigationTitle();
	    }
	    return title;
    }
}

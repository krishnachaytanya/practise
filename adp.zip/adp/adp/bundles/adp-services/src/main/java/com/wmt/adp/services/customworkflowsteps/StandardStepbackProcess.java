package com.wmt.adp.services.customworkflowsteps;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Route;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.util.List;

@Component(name = "com.wmt.adp.services.customworkflowsteps.StandardStepbackProcess", description = "ADP - StepBack Process", label = "ADP - StepBack Process", specVersion = "1.1", metatype = true, immediate = true)
@Service
@org.apache.felix.scr.annotations.Property(name = "process.label", value = "ADP Standard Step Back Process Step")
public class StandardStepbackProcess implements WorkflowProcess {


    private static Logger log = LoggerFactory.getLogger(StandardStepbackProcess.class);

    public void execute(WorkItem workItem, WorkflowSession workflowSession,
            MetaDataMap margs) throws WorkflowException {
        Session session = null;
        List<Route> routes = null;
        
        
        try {
        	//Add new members to old group
        	session = workflowSession.getSession();
    		
        	// getting back routes
            routes = workflowSession.getBackRoutes(workItem);
            workflowSession.complete(workItem, routes.get(2));

        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.toString());
            throw new WorkflowException(e);

        }

    }



}

package com.wmt.adp.services;

import org.apache.felix.scr.annotations.*;
import org.apache.sling.commons.osgi.PropertiesUtil;

import java.util.Map;

/**
 * Created by dgeary on 9/27/17.
 */
@Component(metatype = true,
        label = "Constants Configuration Service",
        name = "com.wmt.adp.services.ConstantsService",
        description = "Configure API endpoints and other global level constants",
        policy = ConfigurationPolicy.REQUIRE,
        immediate = true)
@Service(value = { ConstantsService.class })
public class ConstantsService {
    private static final String DEFAULT_USER_LOGOUT_URL = "https://tstlogin.wal-mart.com/login/ct_logout.jsp";
    private static final String USER_LOGOUT_URL_PARAM_NAME = "constants.user_logout_url";
    private static final String DEFAULT_DTM_URL = "//assets.adobedtm.com/5495d9872198d574fae7791c47c0d2e1c24ef51d/satelliteLib-22904580f4d52fcae5000c53c4adc5338ac24ff8-staging.js";
    private static final String DTM_URL_PARAM_NAME = "constants.dtm_url";
    private static final String DEFAULT_EXTERNALIZED_BASE_URL = "http://wal-mart.com/";
    private static final String EXTERNALIZED_BASE_URL_PARAM_NAME = "constants.externalized_base_url";
    private static final long DEFAULT_LIMIT_PARENT_LISTS = 20;
    private static final String LIMIT_PARENT_LISTS_NAME = "constants.default_limit_parent_lists";

    private static final String CURRENCY_EXCHANGE_URL_PARAM_NAME = "constants.currency_exchange_url";
    private static final String CURRENCY_EXCHANGE_URL_DEFAULT = "http://labcrnts1101.homeoffice.cr.wal-mart.com:9205";

    //===========================================
    // Learning Locker defaults section

    private static final String DEFAULT_LEARNING_LOCKER_CLIENT_KEY = "762a0ffc33f2e9bb8fea99f07b2582abc2ddaa7a";
    private static final String LEARNING_LOCKER_CLIENT_KEY_NAME = "constants.learning_locker_client_key";
    private static final String DEFAULT_LEARNING_LOCKER_CLIENT_SECRET = "3aafc93590cd5f6cda02546af7f8de34f07ddd56";
    private static final String LEARNING_LOCKER_CLIENT_SECRET_NAME = "constants.learning_locker_client_secret";
    private static final String DEFAULT_LEARNING_LOCKER_ACTIVITY_ID_APPS = "http://wal-mart.com/users/apps";
    private static final String LEARNING_LOCKER_ACTIVITY_ID_APPS_NAME = "constants.learning_locker_activity_id";
    private static final String DEFAULT_LEARNING_LOCKER_ACTIVITY_PROFILE_URL = "https://walmart.learninglocker.net/data/xAPI/activities/profile";
    private static final String LEARNING_LOCKER_ACTIVITY_PROFILE_URL_NAME = "constants.learning_locker_activity_profile_url";
    private static final String LEARNING_LOCKER_HOST = "walmart.learninglocker.net";
    private static final String LEARNING_LOCKER_HOST_PARAM_NAME = "constants.learning_locker_host";
    private static final String LEARNING_LOCKER_PATH = "/data/xAPI/activities/profile";
    private static final String LEARNING_LOCKER_PATH_PARAM_NAME = "constants.learning_locker_path";

    //===========================================

    @Property(label = "User Logout URL", name = USER_LOGOUT_URL_PARAM_NAME, value = DEFAULT_USER_LOGOUT_URL)
    String userLogoutUrl = DEFAULT_USER_LOGOUT_URL;
    @Property(label = "DTM URL", name = DTM_URL_PARAM_NAME, value = DEFAULT_DTM_URL)
    private String dtmUrl = DEFAULT_DTM_URL;
    private String dtmUrlName = "dtmUrl";
    @Property(label = "Default Limit to lists based on parent paths", name = LIMIT_PARENT_LISTS_NAME, longValue = DEFAULT_LIMIT_PARENT_LISTS)
    private long defaultLimitParentLists = DEFAULT_LIMIT_PARENT_LISTS;

    @Property(label="Externalized Base URL", name = EXTERNALIZED_BASE_URL_PARAM_NAME, value = DEFAULT_EXTERNALIZED_BASE_URL)
    private String externalizedBaseUrl = DEFAULT_EXTERNALIZED_BASE_URL;

    @Property(label="Currency Exchange API URL", name = CURRENCY_EXCHANGE_URL_PARAM_NAME, value = CURRENCY_EXCHANGE_URL_DEFAULT)
    private String currencyExchangeUrl = CURRENCY_EXCHANGE_URL_DEFAULT;

    //===========================================
    // Learning Locker properties section
    @Property(label = "Learning Locker Client Secret", name = LEARNING_LOCKER_CLIENT_SECRET_NAME, value = DEFAULT_LEARNING_LOCKER_CLIENT_SECRET)
    private String learningLockerClientSecret = DEFAULT_LEARNING_LOCKER_CLIENT_SECRET;
    @Property(label = "Learning Locker Client Key", name = LEARNING_LOCKER_CLIENT_KEY_NAME, value = DEFAULT_LEARNING_LOCKER_CLIENT_KEY)
    private String learningLockerClientKey = DEFAULT_LEARNING_LOCKER_CLIENT_KEY;
    @Property(label = "Learning Locker Activity ID (Apps)", name = LEARNING_LOCKER_ACTIVITY_ID_APPS_NAME, value = DEFAULT_LEARNING_LOCKER_ACTIVITY_ID_APPS)
    private String learningLockerActivityIdApps = DEFAULT_LEARNING_LOCKER_ACTIVITY_ID_APPS;
    @Property(label = "Learning Locker Activity Profile Service URL", name = LEARNING_LOCKER_ACTIVITY_PROFILE_URL_NAME, value = DEFAULT_LEARNING_LOCKER_ACTIVITY_PROFILE_URL)
    private String learningLockerActivityProfileUrl = DEFAULT_LEARNING_LOCKER_ACTIVITY_PROFILE_URL;
    @Property(label = "Learning Locker Host", name = LEARNING_LOCKER_HOST_PARAM_NAME, value = LEARNING_LOCKER_HOST)
    private String learningLockerHost = LEARNING_LOCKER_HOST;
    @Property(label = "Learning Locker Path", name = LEARNING_LOCKER_PATH_PARAM_NAME, value = LEARNING_LOCKER_PATH)
    private String learningLockerPath = LEARNING_LOCKER_PATH;
    //===========================================

    @Activate
    protected void activate(final Map< String, Object > config) {
        if (config != null) {
            userLogoutUrl = PropertiesUtil.toString(config.get(USER_LOGOUT_URL_PARAM_NAME), DEFAULT_USER_LOGOUT_URL);
            dtmUrl = PropertiesUtil.toString(config.get(DTM_URL_PARAM_NAME), DEFAULT_DTM_URL);

            learningLockerActivityIdApps = PropertiesUtil.toString(config.get(LEARNING_LOCKER_ACTIVITY_ID_APPS_NAME), DEFAULT_LEARNING_LOCKER_ACTIVITY_ID_APPS);
            learningLockerClientKey = PropertiesUtil.toString(config.get(LEARNING_LOCKER_CLIENT_KEY_NAME), DEFAULT_LEARNING_LOCKER_CLIENT_KEY);
            learningLockerClientSecret = PropertiesUtil.toString(config.get(LEARNING_LOCKER_CLIENT_SECRET_NAME), DEFAULT_LEARNING_LOCKER_CLIENT_SECRET);
            learningLockerHost = PropertiesUtil.toString(config.get(LEARNING_LOCKER_HOST_PARAM_NAME), LEARNING_LOCKER_HOST);
            learningLockerPath = PropertiesUtil.toString(config.get(LEARNING_LOCKER_PATH_PARAM_NAME), LEARNING_LOCKER_PATH);
            externalizedBaseUrl = PropertiesUtil.toString(config.get(EXTERNALIZED_BASE_URL_PARAM_NAME), DEFAULT_EXTERNALIZED_BASE_URL);
            currencyExchangeUrl = PropertiesUtil.toString(config.get(CURRENCY_EXCHANGE_URL_PARAM_NAME), CURRENCY_EXCHANGE_URL_DEFAULT);
            defaultLimitParentLists = PropertiesUtil.toLong(config.get(LIMIT_PARENT_LISTS_NAME), DEFAULT_LIMIT_PARENT_LISTS);
        }
    }

    public String getUserLogoutUrl() {
        return userLogoutUrl;
    }

    public String getDtmUrl() { return dtmUrl; }

    public String getExternalizedBaseUrl() {
        return externalizedBaseUrl;
    }

    public String getCurrencyExchangeUrl() {
        return currencyExchangeUrl;
    }

    public String getLearningLockerActivityIdApps() {
        return learningLockerActivityIdApps;
    }

    public String getLearningLockerClientKey() {
        return learningLockerClientKey;
    }

    public String getLearningLockerClientSecret() {
        return learningLockerClientSecret;
    }

    public String getLearningLockerActivityProfileUrl() {
        return learningLockerActivityProfileUrl;
    }

    public String getLearningLockerHost() {
        return learningLockerHost;
    }

    public String getLearningLockerPath() {
        return learningLockerPath;
    }

    public long getDefaultLimitParentLists() { return defaultLimitParentLists; }

}

package com.wmt.adp.services.customworkflowsteps;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.ParticipantStepChooser;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.*;
import org.osgi.service.component.ComponentContext;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

@Component(name = "com.wmt.adp.services.customworkflowsteps.ADPPublisher", description = "ADP - Publisher", label = "ADP - Publisher", specVersion = "1.1", metatype = true, immediate = true)
@Service
@Properties({
        @Property(name = "service.description", value = "Dynamically chooses ADP Publishers based on the payload."),
        @Property(name = "service.vendor", value = "walmart"),
        @Property(name = ParticipantStepChooser.SERVICE_PROPERTY_LABEL, value = "ADP Publisher"),
        @Property(name = "countryusermap", value = {"/content/chile=chile-authorized-publishers","/content/mx=mexico-authorized-publishers","/content/ar=argentina-authorized-publishers","/content/central=central-america-authorized-publishers"}, cardinality = 20)
})
public class ADPPublisher implements ParticipantStepChooser {


    /** dictionary properties. */
    private Dictionary<String, Object> properties = null;

    public static HashMap<String,String> countryUserMap = new HashMap<String,String>();

    public String getParticipant(WorkItem workItem,
                                 WorkflowSession workflowSession, MetaDataMap margs)
            throws WorkflowException {

        String participant = "administrators";

        WorkflowData workflowData = workItem.getWorkflowData();
        String payloadPath = workflowData.getPayload().toString();
        String currentCoutryUser = getCurrentCountryUser(payloadPath);
        if(null != currentCoutryUser){
            return currentCoutryUser;
        }
        return participant;
    }

    public static String getCurrentCountryUser(String payloadPath){
        Iterator<String> iter = countryUserMap.keySet().iterator();
        while(iter.hasNext()){
            String siteAreaPath = iter.next();
            if(payloadPath.startsWith(siteAreaPath)){
                return countryUserMap.get(siteAreaPath);
            }

        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Activate
    public void activate(ComponentContext componentContext) {

        properties = componentContext.getProperties();
        // Retrieving values from OSGI configurations


        Object object = properties.get("countryusermap");
        String[] countryUserMapStrArr = null;

        if (null != object && object instanceof String[]) {
            countryUserMapStrArr = (String[]) object;
        } else if (null != object && object instanceof String) {
            String value = (String) object;
            countryUserMapStrArr = new String[1];
            countryUserMapStrArr[0] = value;
        }

        for (int i = 0; i < countryUserMapStrArr.length; i++) {
            if(countryUserMapStrArr[i].contains("=")){
                StringTokenizer stk = new StringTokenizer(countryUserMapStrArr[i], "=");
                countryUserMap.put(stk.nextToken(), stk.nextToken());
            }
        }


    }

}
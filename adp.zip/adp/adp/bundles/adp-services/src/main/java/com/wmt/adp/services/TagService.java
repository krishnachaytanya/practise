package com.wmt.adp.services;

import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.adp.services.pojos.ContentTag;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * @author Merkle / Axis41
 */
@Component(
        label = "ContentTag Service",
        description = "Provides methods with proper system user access to manipulate tags",
        immediate = true)
@Service(value = { TagService.class })

public class TagService {
    private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";
    private static final String ADP_TAG_ROOT = "/etc/tags/adp";
    private ResourceResolver resourceResolver = null;

    @Reference
    ResourceResolverFactory resourceResolverFactory;
    private static final Logger logger = LoggerFactory.getLogger(TagService.class);

    @Activate
    protected void activate() {

    }

    public List<ContentTag> getResourceTags(String path) {
	// receives the path of a resource and returns the tags of that resource
        Map<String, Object> params 			= new HashMap<>();
        ArrayList<ContentTag> contentTags 	= new ArrayList<>();

        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);

        try {        
        	resourceResolver 		= resourceResolverFactory.getServiceResourceResolver(params);
        	TagManager tagManager 	= resourceResolver.adaptTo(TagManager.class);
        	Resource res 			= resourceResolver.getResource(path);
            Tag[] tags 				= tagManager.getTags(res);

            if (tags != null) {
            	
                for (int i = 0; i < tags.length; i++) {
                    ContentTag tag = new ContentTag();
                    
                    tag.setTitle(tags[i].getTitle());
                    tag.setName(tags[i].getName());
                    
                    contentTags.add(tag);
                }
            }

        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return contentTags;
    }
    
    public List<ContentTag> getAssetTags(String path) {
	// receives the path of an asset and returns the tags of that asset
    	return getResourceTags(path + "/jcr:content/metadata");
    }

    // Takes a page path string and returns an arraylist of Tag objects
    public List<ContentTag> getTagLinkList(String currentPagePath) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        List<ContentTag> contentTags = new ArrayList<>();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);

            PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
            // get the page
            Page currentPage = pageManager.getPage(currentPagePath);
            Tag[] tags = currentPage.getTags();
            String tagRoot = currentPage.getAbsoluteParent(2).getPath();

            if(tags != null) {
                for (int i = 0; i < tags.length; i++) {
                    ContentTag tag = new ContentTag();

                    tag.setTitle(tags[i].getTitle());
                    tag.setName(tags[i].getName());
                    tag.setPath(tagRoot + "/" + tags[i].getName() + ".html");
                    tag.setTagId(tags[i].getTagID());

                    contentTags.add(tag);
                }
            }

        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return contentTags;
    }

    public String getTagStringList(String currentPagePath) {
        List<ContentTag> tags = getTagLinkList(currentPagePath);
		return String.join(";", tags.stream().map(t -> t.getTitle()).collect(Collectors.toList()));
    }

    public String getFullIdStringList(String currentPagePath) {
        final List<ContentTag> tags = getTagLinkList(currentPagePath);
        return String.join(";", tags.stream().map(t -> t.getTagId()).collect(Collectors.toList()));
    }

    public ContentTag getContentTag(String tagId, Locale locale) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        ContentTag contentTag = new ContentTag();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);

            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            Tag tag = tagManager.resolve(tagId);

            contentTag.setTagId(tagId);
            contentTag.setTitle(tag.getTitle(locale));

        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return contentTag;
    }

    public List<ContentTag> getAllTags(String tagRoot, Locale locale) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        Set<ContentTag> tagSet = new TreeSet<>();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);

            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            Tag rootTag = tagManager.resolve(tagRoot);

            if (rootTag != null) {
                Iterator<Tag> tagIterator = rootTag.listAllSubTags();

                while (tagIterator.hasNext()) {

                    Tag tag = (Tag) tagIterator.next();

                    ContentTag contentTag = new ContentTag();
                    contentTag.setTitle(tag.getTitle(locale));
                    contentTag.setName(tag.getName());
                    contentTag.setTagId(tag.getTagID());

                    tagSet.add(contentTag);
                }
            }
        } catch (LoginException e) {
            logger.error("Error getting resourceResolver in TagService", e.getMessage());
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        List<ContentTag> tagList = new ArrayList<>(tagSet);

        return tagList;
    }

    public List<ContentTag> getAllTags(Locale locale) {
        return this.getAllTags(ADP_TAG_ROOT, locale);
    }

    public List<String> getTaggedResourcePaths(String path, String[] tags, boolean oneMatchIsEnough) {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, SERVICE_ACCOUNT_IDENTIFIER);
        List<String> resourcePaths = new ArrayList<>();

        try {
            resourceResolver = resourceResolverFactory.getServiceResourceResolver(params);

            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            RangeIterator<Resource> resources = tagManager.find(path, tags, oneMatchIsEnough);
            if (resources != null) {
                while (resources.hasNext()) {
                    Resource res = resources.next();
                    resourcePaths.add(res.getPath());
                }
            }
        } catch (LoginException e) {
            logger.error("Error getting tagged resources in tag service", e);
        } finally {
            if(resourceResolver != null && resourceResolver.isLive()){
                resourceResolver.close();
            }
        }

        return resourcePaths;
    }
}

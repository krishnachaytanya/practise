package com.wmt.intl.data_providers.content;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.dam.api.Asset;
import com.wmt.intl.bean.DownloadListItemBean;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * Created by dcrajan on 10/15/2017.
 * Class to provide download list.
 */
public class DownloadListProvider extends IntlBaseProvider {
    final static String PROPERTY_PATH= "path";
    private static final String SEARCH_FORMAT = "MMM d, yyyy";

    private ResourceResolver resourceResolver;
    private ArrayList<DownloadListItemBean> downloadItems;
    public  ArrayList<DownloadListItemBean> getDownloadItems(){return downloadItems;}

    /**
     * Process method
     */
    @Override
    public void process() {
        resourceResolver = getResourceResolver();
        downloadItems = new ArrayList<>();
        String folderPath = getProperties().get(PROPERTY_PATH, String.class);
        if (!StringUtils.isEmpty(folderPath)) {
            Resource folderResource = resourceResolver.getResource(folderPath);
            Iterator<Resource> children = folderResource.listChildren();
            while (children.hasNext()) {
                Resource child = children.next();
                Asset childAsset = child.adaptTo(Asset.class);
                if (childAsset != null) {
                    downloadItems.add(buildDownloadListItem(childAsset));
                }
            }
        }
        else{
            addErrorMsg("Please configure folder path");
        }
    }
    /**
     * method for fetching the asset and build download list item
     *
     *@param asset
     * @return  DownloadListItemBean
     */
    private DownloadListItemBean buildDownloadListItem(Asset asset) {
        DownloadListItemBean downloadListItem = new DownloadListItemBean();

        String path = asset.getPath();
        path = IntlUtils.formatLink(path, resourceResolver);
        downloadListItem.setPath(path);

        // fall back to name if no title
        String title = asset.getMetadataValue("dc:title");
        if (title == null) {
            title = asset.getName();
        }
        downloadListItem.setTitle(title);

        // fall back to format if no Fileformat
        String type = asset.getMetadataValue("dam:Fileformat");
        if (type == null) {
            //something like application/pdf
            String format = asset.getMetadataValue("dc:format");
            int slashPosition = format.indexOf("/");
            if (slashPosition > 0 && slashPosition + 1 < format.length()) {
                type = format.substring(slashPosition + 1);
            } else {
                type = format;
            }
        }
        downloadListItem.setType(type);

        String description = asset.getMetadataValue("dc:description");
        downloadListItem.setDescription(description);

        Long time = asset.getLastModified();
        downloadListItem.setDate(IntlUtils.getFormattedDate(time, SEARCH_FORMAT));

        return  downloadListItem;
    }

}

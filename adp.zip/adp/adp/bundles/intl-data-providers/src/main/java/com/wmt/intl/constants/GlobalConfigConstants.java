package com.wmt.intl.constants;

/**
 * Constants for Global configuration
 * 
 *
 */
public class GlobalConfigConstants {
	public static final String LOGO_PATH = "/jcr:content/logoconfig";
	public static final String QUICK_LINK_PAR_PATH = "/jcr:content/quicklinkConfigContainer/QuicklinkPar";
	public static final String GLOBAL_CONFIG_PAGE_PATH = "/site-config/global-configuration";
	public static final String FOOTER_PAGE = "/jcr:content/footerconfig";
	public static final String TIMEZONE_CONFIG_PATH = "/jcr:content/timezoneconfig";
	public static final String ARTICLE_CAT_PAR_PATH = "/jcr:content/articleCatConfigContainer/articleCategoryPar";
	public static final String TRENDING_PAGE_PATH = "/jcr:content/trendingPageConfig";
	public static final String PROXY_CONFIG_PATH = "/jcr:content/proxyConfig";
	public static final String TRENDING_CONFIG_PATH = "/jcr:content/trendingPageConfig";

	public class ComponentDialogPaths {
		public static final String QUICKLINKS = "/apps/intl/components/content/quicklinks/_cq_dialog.html";
		public static final String DIALOG_PATH = "_cq_dialog.html";
	}
}

package com.wmt.intl.exception;

/**
 * Base Exception for Intl(ICP) site
 * 
 * @author vn93497
 *
 */
public class IntlBaseException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor with message and cause
	 * 
	 * @param message
	 *            The error message.
	 * @param cause
	 *            The original exception.
	 */
	public IntlBaseException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor with message
	 * 
	 * @param message
	 *            The error message.
	 */
	public IntlBaseException(final String message) {
		super(message);
	}

}

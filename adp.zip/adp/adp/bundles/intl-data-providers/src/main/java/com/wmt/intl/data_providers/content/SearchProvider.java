package com.wmt.intl.data_providers.content;

import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * SearchProvider for Search component
 * 
 * @author vn73762
 *
 */
public class SearchProvider extends IntlBaseProvider {

	private String localePath;

	/**
	 * To get the locale path
	 * 
	 * @return localePath - String
	 */
	public String getLocalePath() {
		return localePath;
	}

	@Override
	public void process() {
		localePath = IntlUtils.getContentLocalePath(getCurrentPage().getPath());
	}
}

package com.wmt.intl.data_providers.content;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.script.SimpleBindings;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.intl.bean.EventBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.pages.EventPageProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * EventListProvider for EventList Component
 * 
 * @author vn67566
 *
 */
public class EventListProvider extends IntlBaseProvider {

	private static final String EVENT_HOME_PAGE = "eventhomepagelink";
	private static final String EVENT_PAGE_TEMPLATE = "/apps/intl/templates/eventpagetemplate";
	private static final String NUMBER_OF_EVENTS = "numberOfEvents";
	private static final String LIST_HEIGHT = "listHeight";

	/**
	 * events contains list of events
	 */
	private List<EventBean> events;
	private int listHeight;
	private String noUpcomingEventsFound;

	/**
	 * To get EventList Height
	 * 
	 * @return
	 */
	public int getListHeight() {
		return listHeight;
	}

	/**
	 * getter method for getting list of EventBean object's
	 * 
	 * @return the eventList
	 */
	public List<EventBean> getEvents() {
		return events;
	}

	/**
	 * To get noUpcomingEventsFound
	 * 
	 * @return
	 */
	public String getNoUpcomingEventsFound() {
		return noUpcomingEventsFound;
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(EventListProvider.class);

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		populateEventList();

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To populate EventList component
	 */
	private void populateEventList() {

		if (getResource() != null) {

			String homePage = getProperties().get(EVENT_HOME_PAGE,
					(String) null);
			int numberOfEvents = getProperties().get(NUMBER_OF_EVENTS, (int) 0);
			listHeight = getProperties().get(LIST_HEIGHT, (int) 300);
			if (!(StringUtils.isEmpty(homePage))) {
				PageManager pageManager = getResource().getResourceResolver()
						.adaptTo(PageManager.class);
				Page eventHomepage = pageManager.getPage(homePage);
				if (eventHomepage != null) {
					events = new ArrayList<EventBean>();
					populateList(eventHomepage);
					if (events.size() > 0) {
						sortList(events);
						Collections.reverse(events);
						if (numberOfEvents < events.size()) {

							events = events.subList(0, numberOfEvents);

						}

					} else {
						noUpcomingEventsFound = GenericConstants.NO_UPCOMING_EVENTS_FOUND;
					}

				}

			} else {
				addErrorMsg("Please configure an Event Home Page");
			}
		}

		else {
			addErrorMsg("EventList Configuration details not found");
		}

	}

	/**
	 * To get EventPageProvider
	 * 
	 * @param page
	 * @return
	 */
	private EventPageProvider getEventPageProvider(Page page) {

		EventPageProvider eventPageProvider;

		SimpleBindings eventProviderBinding = IntlUtils.getBindingForPage(page);
		eventPageProvider = new EventPageProvider();

		eventPageProvider.init(eventProviderBinding);

		return eventPageProvider;
	}

	/**
	 * To populate List
	 * 
	 * @param page
	 */
	private void populateList(Page page) {
		Iterator<Page> rootPageIterator;

		rootPageIterator = page.listChildren();

		while (rootPageIterator.hasNext()) {

			Page childPage = rootPageIterator.next();

			String pageTemplate = childPage.getProperties().get("cq:template",
					"");

			if (pageTemplate.equalsIgnoreCase(EVENT_PAGE_TEMPLATE)) {
				LOGGER.info("page is created using eventpagetemplate ");

				EventPageProvider eventPageProvider = getEventPageProvider(childPage);
				if (eventPageProvider.isValid()) {
					if (eventPageProvider.getEvent().getEndDate().getTime()
							.after(new Date())) {
						events.add(eventPageProvider.getEvent());
					}
				}

			}

			if (childPage.listChildren().hasNext()) {
				populateList(childPage);

			}

		}
	}

	/**
	 * To sort the eventList
	 * 
	 * @param eventList
	 * @return
	 */
	private List<EventBean> sortList(List<EventBean> eventList) {
		Collections.sort(eventList);
		return eventList;
	}

}
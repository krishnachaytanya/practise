package com.wmt.intl.data_providers.content;

import com.wmt.intl.bean.SegmentBean;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.siteconfig.TrendingPageConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;

import java.util.List;
import java.util.Optional;

/**
 * Created by dcrajan on 11/8/2017.
 */
public class TrendingContentsProvider  extends IntlBaseProvider {

    private String userName;
    private String secretCode;
    private String reportSuiteId;
    private String pageLimit;
    private String endPoint;
    private String segmentId;
    private String segmentCategoryId;
    private String resourcePath;

    final static String PROPERTY_SEGMENT_ID = "segmentId";
    final static String ERROR_MESSAGE_USER_NAME = "Please configure user name";
    final static String ERROR_MESSAGE_SECRETE_CODE = "Please configure secret code";
    final static String ERROR_MESSAGE_REPORT_SUITE_ID = "Please configure report suite";
    final static String ERROR_MESSAGE_PAGE_LIMIT = "Please configure page limit";
    final static String ERROR_MESSAGE_END_POINT = "Please configure end point";

	public String getUserName() {
		return userName;
	}

	public String getReportSuiteId() {
		return reportSuiteId;
	}

	public String getSecretCode() {
		return secretCode;
	}

	public String getPageLimit() {
		return pageLimit;
	}

	public String getEndPoint() {
		return endPoint;
	}

    public String getResourcePath() {
        return resourcePath;
    }

    public String getSegmentId() {
        return segmentId;
    }


    public String getSegmentCategoryId() {
        return segmentCategoryId;
    }


    @Override
    public void process() {
        ValueMap valueMap = getResource().getValueMap();
        TrendingPageConfigProvider trendingPageConfig = GlobalConfigUtil
                .getProvider(getResource()).getTrendingPageConfig();
        userName = trendingPageConfig.getUserName();
        secretCode = trendingPageConfig.getSecretCode();
        reportSuiteId = trendingPageConfig.getReportSuiteId();
        pageLimit = trendingPageConfig.getPageLimit();
        endPoint = trendingPageConfig.getEndPoint();
        segmentCategoryId = valueMap.get(PROPERTY_SEGMENT_ID, (String) null);
        resourcePath = generateServletResourcePath();

        if (StringUtils.isEmpty(userName)) {
            addErrorMsg(ERROR_MESSAGE_USER_NAME);
        }

        if (StringUtils.isEmpty(secretCode)) {
            addErrorMsg(ERROR_MESSAGE_SECRETE_CODE);
        }

        if (StringUtils.isEmpty(reportSuiteId)) {
            addErrorMsg(ERROR_MESSAGE_REPORT_SUITE_ID);
        }

        if (StringUtils.isEmpty(endPoint)) {
            addErrorMsg(ERROR_MESSAGE_END_POINT);
        }

        if (StringUtils.isEmpty(pageLimit)) {
            addErrorMsg(ERROR_MESSAGE_PAGE_LIMIT);
        }
    }

    /**
     * Method to get the segment id from the global configuration
     *  @param segmentCategoryId
     *  @return ReportDescription
     */
    public String getSegmentIdFromConfig(String segmentCategoryId) {
        TrendingPageConfigProvider trendingPageConfig = GlobalConfigUtil
                .getProvider(getResource()).getTrendingPageConfig();
        String segmentId = null;
        if (trendingPageConfig.getSegmentList() != null &&
                trendingPageConfig.getSegmentList().size() > 0) {
            List<SegmentBean> segments = trendingPageConfig.getSegmentList();

             Optional<SegmentBean> segmentObj = segments.stream().filter(s -> s.getId().equals(segmentCategoryId)).findFirst();
            if (segmentObj != null ) {
                segmentId = segmentObj.get().getAnalyticsId();
            }
        }
        return segmentId;
    }

    /**
     * Method to generate the servlet path
     *  @return String
     */
    private String generateServletResourcePath() {
        String urlFormatWithSegment = "%s%s.analyticData.%s.html";
        String urlFormatWithOutSegment = "%s%s.analyticData.html";
        String servletPath;
        String globalConfigPath = GlobalConfigUtil.getGlobalConfigPath(getResource().getPath());
        if (StringUtils.isEmpty(segmentCategoryId)){
            servletPath = String.format(urlFormatWithOutSegment,
                    globalConfigPath, GlobalConfigConstants.TRENDING_PAGE_PATH);
        }
        else {
            servletPath = String.format(urlFormatWithSegment,
                    globalConfigPath, GlobalConfigConstants.TRENDING_PAGE_PATH,segmentCategoryId);
        }

        return servletPath;
    }

}

package com.wmt.intl.data_providers.siteconfig;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dcrajan on 10/24/2017.
 * Quick Link List Config Provider class
 */
public class QuickLinkListConfigProvider extends IntlBaseProvider {
    private final String COLOR_ITEMS_PROPERTY = "items";
    private final String BORDER_COLOR_PROPERTY = "borderColor";
    private final String QUICKLINK_ID_PROPERTY = "quicklinkID";
    private final String COLOR_VALUE_PROPERTY ="colorValue";

    final static String ERROR_MESSAGE_CONFIG_BORDER_COLOR = "Please configure border color";
    final static String ERROR_MESSAGE_CONFIG_QUICK_LINK_ID = "Please configure quick link id";
    final static String ERROR_MESSAGE_CONFIG_QUICK_LINK_COLOR = "Please configure quicklink color";

    private String quickLinkListConfigDetails;
    private String borderColor;
    private String quickLinkId;
    private String globalConfigResourcePath;

    public String getGlobalConfigResourcePath() {
        return globalConfigResourcePath;
    }

    public void setGlobalConfigResourcePath(String globalConfigResourcePath) {
        this.globalConfigResourcePath = globalConfigResourcePath;
    }

    public String getQuickLinkId() {
        return quickLinkId;
    }

    public String getBorderColor() {
        return borderColor;
    }

    private static final Logger LOGGER = LoggerFactory
            .getLogger(QuickLinkConfigProvider.class);

    public String getQuickLinkListConfigDetails() {
        return quickLinkListConfigDetails;
    }

    /**
     * Process method
     */
    @Override
    public void process() {
        LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
        JSONObject jsonObj = new JSONObject();
        ValueMap valueMap = getResource().getValueMap();
        borderColor = valueMap.get(BORDER_COLOR_PROPERTY, (String) null);
        if (!StringUtils.isEmpty(borderColor)) {
            jsonObj.put(BORDER_COLOR_PROPERTY, borderColor);
        }
        else{
            addErrorMsg(ERROR_MESSAGE_CONFIG_BORDER_COLOR);
        }

        quickLinkId = valueMap.get(QUICKLINK_ID_PROPERTY, (String) null);
        if(!StringUtils.isEmpty(quickLinkId)) {
            jsonObj.put(QUICKLINK_ID_PROPERTY, quickLinkId);
        }
        else{
            addErrorMsg(ERROR_MESSAGE_CONFIG_QUICK_LINK_ID);
        }

        String[] colorArray = getResource().getValueMap().get(COLOR_ITEMS_PROPERTY,
                new String[] {});
        if (colorArray.length > 0) {
            List<String> colorList = new ArrayList<>();
            for (int index = 0; index < colorArray.length; index++) {
                JSONObject colorListJSON = new JSONObject(colorArray[index]);
                colorList.add(colorListJSON.getString(COLOR_VALUE_PROPERTY));
            }
            jsonObj.put(COLOR_VALUE_PROPERTY, colorList);
        }
        else {
            addErrorMsg(ERROR_MESSAGE_CONFIG_QUICK_LINK_COLOR);
        }

        LOGGER.info("PROPERTIES: " + jsonObj.toString());

        quickLinkListConfigDetails = jsonObj.toString();

        LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
    }
}

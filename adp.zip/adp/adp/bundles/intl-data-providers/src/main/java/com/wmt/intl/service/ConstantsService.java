package com.wmt.intl.service;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;

import java.util.Map;

/**
 * Created by dcrajan on 11/20/2017.
 */
@Component(metatype = true, label = "ICP Constants Configuration Service", name = "com.wmt.intl.service.ConstantsService", description = "Configure API endpoints and other global level constants", immediate = true)
@Service(value = { ConstantsService.class })
public class ConstantsService {
	private static final String DEFAULT_DTM_URL = "//assets.adobedtm.com/42b7865351ade9893df151f4861f7aef9e418ec0/satelliteLib-2cdc50cf062884183d4287fa7e7d0aa68ceff75e-staging.js";
	private static final String DTM_URL_PARAM_NAME = "constants.dtm_url";
	@Property(label = "DTM URL", name = DTM_URL_PARAM_NAME, value = DEFAULT_DTM_URL)
	private String dtmUrl = DEFAULT_DTM_URL;

	@Activate
	protected void activate(final Map<String, Object> config) {
		if (config != null) {
			dtmUrl = PropertiesUtil.toString(config.get(DTM_URL_PARAM_NAME),
					DEFAULT_DTM_URL);
		}
	}

	public String getDtmUrl() {
		return dtmUrl;
	}
}

package com.wmt.intl.data_providers.content;

import com.wmt.intl.bean.TimeZoneBean;
import com.wmt.intl.data_providers.siteconfig.GlobalConfigProvider;
import com.wmt.intl.data_providers.siteconfig.TimeZoneConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;

import java.util.List;

/**
 * TimezoneProvider for Timezone Component
 * @author vn73762
 *
 */

public class TimezoneProvider extends IntlBaseProvider {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(TimezoneProvider.class);

	private static final String TIMEZONE_VISIBLE = "timezoneVisible";
	final static String ERROR_MESSAGE_CONFIGURATION = "Please configure Timezone from Global configuration";

	/**
	 * To check the visible status
	 * 
	 * @return
	 */
	private boolean visible;
	private String resourcePath;

	public String getResourcePath() {
		return getResource().getPath();
	}

	public boolean isVisible() {
		return visible;
	}

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		visible = getInheritedProperty(getCurrentPage(), TIMEZONE_VISIBLE,
				Boolean.TRUE);

		TimeZoneConfigProvider timezonConfigProvider = GlobalConfigUtil
				.getProvider(getResource()).getTimeZoneConfig();
		List<TimeZoneBean> timeZones = timezonConfigProvider.getTimeZoneList();
		if (timeZones == null || timeZones.isEmpty()){
			addErrorMsg(ERROR_MESSAGE_CONFIGURATION);
		}
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}
}
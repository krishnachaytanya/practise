package com.wmt.intl.bean;

import com.wmt.intl.data_providers.siteconfig.ArticleCategoryConfigProvider;

/**
 * Bean for Carousel
 *
 */
public class CarouselBean {
	private String title;
	private String description;
	private ImageRenditionsBean imageRenditionsBean;
	private String date;
	private ArticleCategoryConfigProvider categoryConfig;
	private String link;

	/**
	 * To get Title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * setting Title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * To get Description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * setting Description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * To get Image Renditions
	 * 
	 * @return
	 */
	public ImageRenditionsBean getImageRenditionsBean() {
		return imageRenditionsBean;
	}

	/**
	 * setting ImageRenditions
	 * 
	 * @param imageRenditionsBean
	 */
	public void setImageRenditionsBean(ImageRenditionsBean imageRenditionsBean) {
		this.imageRenditionsBean = imageRenditionsBean;
	}

	/**
	 * To get Date
	 * 
	 * @return
	 */
	public String getDate() {
		return date;
	}

	/**
	 * setting date
	 * 
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the categoryConfig
	 */
	public ArticleCategoryConfigProvider getCategoryConfig() {
		return categoryConfig;
	}

	/**
	 * @param categoryConfig
	 *            the categoryConfig to set
	 */
	public void setCategoryConfig(ArticleCategoryConfigProvider categoryConfig) {
		this.categoryConfig = categoryConfig;
	}

	/**
	 * To get page link
	 * 
	 * @return
	 */
	public String getLink() {
		return link;
	}

	/**
	 * Setting page link
	 * 
	 * @param link
	 */
	public void setLink(String link) {
		this.link = link;
	}

}
package com.wmt.intl.data_providers.siteconfig;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.wmt.intl.bean.SegmentBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dcrajan on 11/8/2017.
 */
public class TrendingPageConfigProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LogoConfigProvider.class);

	private final String USER_NAME = "userName";
	private final String SECRET_CODE = "secretCode";
	private final String REOPRT_SUITE_ID = "reportSuiteId";
	private final String PAGE_LIMIT = "pageLimit";
	private final String END_POINT = "endPoint";

	private final String SEGMENT_LIST = "segmentList";
	private List<SegmentBean> segmentList;

	final static String ERROR_MESSAGE_USER_NAME = "Please configure user name";
	final static String ERROR_MESSAGE_SECRETE_CODE = "Please configure secret code";
	final static String ERROR_MESSAGE_REPORT_SUITE_ID = "Please configure report suite";
	final static String ERROR_MESSAGE_PAGE_LIMIT = "Please configure page limit";
	final static String ERROR_MESSAGE_USE_GLOBAL_CONFIG = "Please use GlobalConfigProvider to get Trending page Config";
	final static String ERROR_MESSAGE_GLOBAL_CONFIG_NOT_FOUND = "Trending Page config details not found";
	final static String ERROR_MESSAGE_END_POINT = "Please configure End Point";

	private String userName;
	private String secretCode;
	private String reportSuiteId;
	private String pageLimit;
	private String endPoint;

	/**
	 * To get pageLimit
	 * 
	 * @return
	 */
	public String getPageLimit() {
		return pageLimit;
	}

	/**
	 * To get userName
	 * 
	 * @return
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * To get secretCode
	 * 
	 * @return
	 */
	public String getSecretCode() {
		return secretCode;
	}

	/**
	 * To get reportSuiteId
	 * 
	 * @return
	 */
	public String getReportSuiteId() {
		return reportSuiteId;
	}

	/**
	 * To get endPoint
	 * 
	 * @return
	 */
	public String getEndPoint() {
		return endPoint;
	}

	/**
	 * To get segmentList
	 * 
	 * @return
	 */
	public List<SegmentBean> getSegmentList() {
		return segmentList;
	}

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		LOGGER.info("inside process=");
		if (getResource() != null) {
			String trendingConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.TRENDING_PAGE_PATH;
			LOGGER.info("trending page config=" + trendingConfigPath);

			if (trendingConfigPath.equalsIgnoreCase(getResource().getPath())) {
				ValueMap valueMap = getResource().getValueMap();

				userName = valueMap.get(USER_NAME, (String) null);
				secretCode = valueMap.get(SECRET_CODE, (String) null);
				reportSuiteId = valueMap.get(REOPRT_SUITE_ID, (String) null);
				pageLimit = valueMap.get(PAGE_LIMIT, (String) null);
				endPoint = valueMap.get(END_POINT, (String) null);

				if (StringUtils.isEmpty(userName)) {
					addErrorMsg(ERROR_MESSAGE_USER_NAME);
				}

				if (StringUtils.isEmpty(secretCode)) {
					addErrorMsg(ERROR_MESSAGE_SECRETE_CODE);
				}

				if (StringUtils.isEmpty(reportSuiteId)) {
					addErrorMsg(ERROR_MESSAGE_REPORT_SUITE_ID);
				}
				if (StringUtils.isEmpty(endPoint)) {
					addErrorMsg(ERROR_MESSAGE_END_POINT);
				}
				if (StringUtils.isEmpty(pageLimit)) {
					addErrorMsg(ERROR_MESSAGE_PAGE_LIMIT);
				}

				populateSegmentDetails();

			} else {
				addErrorMsg(ERROR_MESSAGE_USE_GLOBAL_CONFIG);
			}
		} else {
			addErrorMsg(ERROR_MESSAGE_GLOBAL_CONFIG_NOT_FOUND);
		}

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To populate the Segment details based on the value array
	 */
	private void populateSegmentDetails() {
		LOGGER.info("START: populateSegmentDetails method");

		String[] valueArr = getResource().getValueMap().get(SEGMENT_LIST,
				new String[] {});

		if ( valueArr != null && valueArr.length != 0) {

			segmentList = new ArrayList<SegmentBean>();

			for (int index = 0; index < valueArr.length; index++) {
				SegmentBean segment = getBeanListFromJson(valueArr[index]);

				if (StringUtils.isEmpty(segment.getId())) {
					addErrorMsg("Please configure segment ID - {0}" , Integer.toString(index + 1));
				}
				if (StringUtils.isEmpty(segment.getTitle())) {
					addErrorMsg("Please configure segment Title - {0}",Integer.toString(index + 1));
				}
				if (StringUtils.isEmpty(segment.getAnalyticsId())) {
					addErrorMsg("Please configure analytic segment ID - {0}" ,Integer.toString(index + 1));
				}

				segmentList.add(segment);
			}

		} else {
			addErrorMsg("Please configure global segment details");
		}

	}

	/**
	 * To get the bean list from json
	 * 
	 * @param json
	 * @return
	 */
	private SegmentBean getBeanListFromJson(String json) {
		Type type = new TypeToken<SegmentBean>() {
		}.getType();
		Gson gson = new GsonBuilder().create();
		SegmentBean segment = gson.fromJson(json, type);
		return segment;
	}

}
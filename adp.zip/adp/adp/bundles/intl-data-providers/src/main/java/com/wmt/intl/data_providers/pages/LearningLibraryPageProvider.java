package com.wmt.intl.data_providers.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.bean.LearningBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.utils.IntlUtils;

/**
 * LearningLibraryPageProvider for LearningLibraryPage
 * 
 * @author vn67566
 *
 */
public class LearningLibraryPageProvider extends BasePageProvider {

	private static final String LIBARAY_IMAGE_REF = "libraryImageRef";
	private static final String LEARNINGPAGE_HOME = "learningPageHome";
	private static final String LEARNING_PAGE_TEMPLATE = "/apps/intl/templates/learningpagetemplate";
	private static final String LEARNING_CAT_TAGS = "learningCatTags";
	private static final String LIBRARY_THUMBNAIL_TITLE = "libraryThumbnailTitle";
	private static final String LIBRARY_BANNER_IMAGE = "libraryBannerImageRef";

	private ImageRenditionsBean libraryThumbnailRenditions;
	private List<String> learningListTags;
	private List<LearningBean> learningList;
	private String libraryThumbnailTitle;
	private String pagePath;
	private ImageRenditionsBean libraryLayoutImage;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LearningLibraryPageProvider.class);

	/**
	 * To get Page path
	 * 
	 * @return
	 */
	public String getPagePath() {
		return pagePath;
	}

	/**
	 * To get Library Thumbnail Title
	 * 
	 * @return
	 */
	public String getLibraryThumbnailTitle() {
		return libraryThumbnailTitle;
	}

	/**
	 * To get LearningPage List
	 * 
	 * @return
	 */

	public List<LearningBean> getLearningList() {
		return learningList;
	}

	/**
	 * To get Image Renditions
	 * 
	 * @return
	 */
	public ImageRenditionsBean getLibraryThumbnailRenditions() {
		return libraryThumbnailRenditions;
	}

	/**
	 * To get libraryLayoutImage
	 * 
	 * @return
	 */
	public ImageRenditionsBean getLibraryLayoutImage() {
		return libraryLayoutImage;
	}

	@Override
	protected void process() {

		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		super.process();
		populateLearningLibrary();

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * Populating LearningLibrary
	 */
	private void populateLearningLibrary() {
		if (getCurrentPage() != null) {

			ValueMap valueMap = getCurrentPage().getContentResource()
					.getValueMap();

			String libraryImageRef;
			String learningPageHome;
			String libraryBanImageRef;

			libraryImageRef = valueMap.get(LIBARAY_IMAGE_REF,
					GenericConstants.EMPTY_STRING);
			learningPageHome = valueMap.get(LEARNINGPAGE_HOME,
					GenericConstants.EMPTY_STRING);

			libraryThumbnailTitle = valueMap.get(LIBRARY_THUMBNAIL_TITLE,
					GenericConstants.EMPTY_STRING);

			learningListTags = Arrays.asList(valueMap.get(LEARNING_CAT_TAGS,
					new String[] {}));
			pagePath = getCurrentPage().getPath();
			libraryBanImageRef = valueMap.get(LIBRARY_BANNER_IMAGE,
					GenericConstants.EMPTY_STRING);
			if (StringUtils.isEmpty(libraryBanImageRef)) {
				libraryBanImageRef = GenericConstants.LIBRARYPAGE_LAYOUT_IMAGE;
			}
			libraryLayoutImage = IntlUtils.getImageRendition(getCurrentPage()
					.getContentResource(), libraryBanImageRef);

			if (StringUtils.isEmpty(libraryThumbnailTitle)) {
				addErrorMsg("Please configure  Library Thumbnail Title");
			}
			if (!StringUtils.isEmpty(libraryImageRef)) {
				libraryThumbnailRenditions = IntlUtils.getImageRendition(
						getCurrentPage().getContentResource(), libraryImageRef);
			}
			if (StringUtils.isEmpty(learningPageHome)) {
				learningPageHome = getCurrentPage().getPath();
			}

			if (getResource() != null && this.isValid()) {

				Page learningRootPage = IntlUtils.getPage(getResource()
						.getResourceResolver(), learningPageHome);

				if (learningRootPage != null) {
					learningList = new ArrayList<LearningBean>();

					populateList(learningRootPage);

					if (learningList.size() > 0) {
						sortList(learningList);

					} else {
						addErrorMsg("No LearningPage's found");
					}

				}
			}

		} else {
			addErrorMsg("Learning page not found");
		}

	}

	/**
	 * Populating Learning page list
	 * 
	 * @param page
	 */
	public void populateList(Page page) {
		Iterator<Page> rootPageIterator;

		rootPageIterator = page.listChildren();

		while (rootPageIterator.hasNext()) {

			Page childPage = rootPageIterator.next();

			String pageTemplate = childPage.getProperties().get("cq:template",
					GenericConstants.EMPTY_STRING);

			if (pageTemplate.equalsIgnoreCase(LEARNING_PAGE_TEMPLATE)) {
				LOGGER.info("page is created using LearningPage Template  ");

				LearningPageProvider learningPageProvider = new LearningPageProvider();

				learningPageProvider.init(IntlUtils
						.getBindingForPage(childPage));

				if (learningListTags.isEmpty()
						|| (isLearningTagMatch(learningListTags,
								learningPageProvider.getLearningCatList()))) {

					learningList.add(getLearningDetails(learningPageProvider));
				}

			}

			if (childPage.listChildren().hasNext()) {
				populateList(childPage);

			}

		}
	}

	/**
	 * To get Learning Page Details
	 * 
	 * @param page
	 * @return
	 */
	private LearningBean getLearningDetails(
			LearningPageProvider learningPageProvider) {

		LearningBean learningBean = new LearningBean();

		learningBean.setTitle(learningPageProvider.getTitle());

		learningBean.setLink(IntlUtils.addExtension(learningPageProvider
				.getPagePath()));
		learningBean.setPubDate(learningPageProvider.getDate());
		learningBean.setDescription(learningPageProvider.getDescription());
		learningBean.setLearningImageRendition(learningPageProvider
				.getLearningImageRenditions());
		learningBean.setFormattedPubDate(IntlUtils.getFormattedDate(
				learningPageProvider.getDate(),
				GenericConstants.DATE_FORMAT_D_MMMMM_YYYY));
		return learningBean;
	}

	/**
	 * Sorting LearningPage List
	 * 
	 * @param learningList
	 * @return
	 */
	private List<LearningBean> sortList(List<LearningBean> learningList) {
		Collections.sort(learningList);
		return learningList;
	}

	/**
	 * 
	 * @param learningListTags
	 * @param learningTags
	 * @return
	 */
	private boolean isLearningTagMatch(List<String> learningListTags,
			List<String> learningTags) {
		boolean matchStatus = false;

		if (learningListTags != null && learningTags != null) {
			matchStatus = CollectionUtils.containsAny(learningListTags,
					learningTags);
		}
		return matchStatus;
	}

}
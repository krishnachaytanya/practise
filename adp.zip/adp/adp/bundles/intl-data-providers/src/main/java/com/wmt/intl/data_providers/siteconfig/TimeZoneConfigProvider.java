package com.wmt.intl.data_providers.siteconfig;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.json.JSONArray;
import org.json.JSONObject;

import com.wmt.intl.bean.TimeZoneBean;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;

/**
 * Provider class for Timezone
 *
 */
public class TimeZoneConfigProvider extends IntlBaseProvider {
	private static final String CITY = "city";
	private final String TIMEZONE = "timezone";
	private static final String HH_MM = "HH:mm";

	private List<TimeZoneBean> timeZoneList;

	/**
	 * To get the timezone list
	 * 
	 * @return List<TimeZoneBean>
	 */
	public List<TimeZoneBean> getTimeZoneList() {
		return timeZoneList;
	}

	/**
	 * To get the resource path
	 * 
	 * @return String
	 */
	public String getResourcePath() {
		return getResource().getPath();
	}

	@Override
	protected void process() {
		if (getResource() != null) {
			String timezoneConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.TIMEZONE_CONFIG_PATH;
			if (timezoneConfigPath.equalsIgnoreCase(getResource().getPath())) {
				JSONObject timeJSON = null;
				TimeZoneBean timeZoneBean = null;
				timeZoneList = new ArrayList<TimeZoneBean>();

				ValueMap valueMap = getResource().getValueMap();
				if (valueMap.containsKey(TIMEZONE)) {
					String timezoneJSON = valueMap.get(TIMEZONE, String.class);
					if (!StringUtils.isEmpty(timezoneJSON)) {
						JSONArray timezoneArray = new JSONArray(timezoneJSON);
						if (timezoneArray.length() > 0) {
							for (int i = 0; i < timezoneArray.length(); i++) {
								timeJSON = timezoneArray.getJSONObject(i);
								if (timeJSON.has(CITY)
										&& timeJSON.has(TIMEZONE)) {
									timeZoneBean = new TimeZoneBean();
									timeZoneBean.setCity(timeJSON
											.getString(CITY));
									timeZoneBean.setTimezone(timeJSON
											.getString(TIMEZONE));
									timeZoneBean.setTime(LocalTime.now(
											ZoneId.of(timezoneArray
													.getJSONObject(i)
													.getString(TIMEZONE)))
											.format(DateTimeFormatter
													.ofPattern(HH_MM)));
									timeZoneList.add(timeZoneBean);
								} else {
									addErrorMsg("Please add city and timezone in JSON format as specified");
									return;
								}
							}
						} else {
							addErrorMsg("Please add city and timezone in JSON format as specified");
						}
					} else {
						addErrorMsg("Please add city and timezone in JSON format as specified");
					}
				} else {
					addErrorMsg("Please add city and timezone in JSON format as specified");
				}
			} else {
				addErrorMsg("Please configure global timezone component.");
			}
		} else {
			addErrorMsg("Please configure global timezone component.");
		}
	}

}

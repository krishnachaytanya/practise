package com.wmt.intl.data_providers.pages;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;

import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.utils.IntlUtils;

/**
 * LearningPageProvider for Learning Page
 * 
 * @author vn67566
 *
 */
public class LearningPageProvider extends BasePageProvider {

	private ImageRenditionsBean learningImageRenditions;
	private List<String> learningCatList;

	final static String LEARNING_IMAGE_REF = "learningImageRef";
	final static String LEARNING_CAT_TAGS = "learningCatTags";

	@Override
	protected void process() {
		if (getCurrentPage() != null) {
			super.process();

			ValueMap valueMap = getCurrentPage().getContentResource()
					.getValueMap();

			String learningImageRef;

			learningImageRef = valueMap.get(LEARNING_IMAGE_REF,
					GenericConstants.EMPTY_STRING);

			if (!StringUtils.isEmpty(learningImageRef)) {
				learningImageRenditions = IntlUtils
						.getImageRendition(getCurrentPage()
								.getContentResource(), learningImageRef);
			}

			String[] learningCatArr = valueMap.get(LEARNING_CAT_TAGS,
					new String[] {});

			learningCatList = Arrays.asList(learningCatArr);
		}
	}

	/**
	 * @return the imageRenditionsBean
	 */
	public ImageRenditionsBean getLearningImageRenditions() {
		return learningImageRenditions;
	}

	/**
	 * 
	 * @return the learningCatList
	 */
	public List<String> getLearningCatList() {
		return learningCatList;
	}
}

package com.wmt.intl.data_providers.content;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.wmt.intl.bean.QuickLinksBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.pages.ArticlePageProvider;
import com.wmt.intl.data_providers.siteconfig.QuickLinkConfigContainerProvider;
import com.wmt.intl.data_providers.siteconfig.QuickLinkConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

/**
 * QuickLinksProvider for QuickLinks component
 * 
 * @author vn67566
 *
 */
public class QuickLinksProvider extends IntlBaseProvider {

	private static final String QUICKLINKS_ITEMS = "items";
	private static final String QUICKLINK_STYLE = "quicklinkStyle";
	private static final String QUICKLINK_TYPE = "quicklinkType";
	private static final String QUICKLINK_LIST = "quicklinkList";
	private static final String QUICKLINK_HEADER = "quicklinkHeader";
	private static final String QUICKLINK_HEADER_COLOR = "quicklinkHeaderColor";
	private static final String QUICKLINK_TEXT_COLOR = "quicklinkTextColor";

	private static final String ERROR_QUICKLINK_STYLE = "Please provide a quick link style";
	private static final String ERROR_QUICKLINK_PARENT = "Please provide a page path";
	private static final String ERROR_QUICKLINK_ITEMS = "Please enter quick link items";
	private static final String ERROR_QUICK_LINK_CONFIG = "Please check quick link style - %s";
	private static final String ERROR_QUICKLINK_TYPE = "Please choose a quick link type";
	private static final String ERROR_QUICKLINK_TEXT_COLOR = "Please provide a text color";
	private static final String ERROR_QUICKLINK_NO_CONTENT = "No eligible contents to show";
	private String quickLinkHeader;
	private String quickLinkHeaderColor;
	private String quickLinkTextColor;

	/**
	 * quickLinksList contains list of quickLinks
	 */
	List<QuickLinksBean> quickLinksList = new ArrayList<QuickLinksBean>();

	/**
	 * getter method for getting list of QuickLinksBean object's
	 * 
	 * @return the quickLinksList
	 */
	public List<QuickLinksBean> getQuickLinksList() {
		return quickLinksList;
	}

	/**
	 * @return the quickLinkHeader
	 */
	public String getQuickLinkHeader() {
		return quickLinkHeader;
	}

	/**
	 * @return the quickLinkHeaderColor
	 */
	public String getQuickLinkHeaderColor() {
		return quickLinkHeaderColor;
	}

	/**
	 * @return the quickLinkTextColor
	 */
	public String getQuickLinkTextColor() {
		return quickLinkTextColor;
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(QuickLinksProvider.class);

	/**
	 * getBeanFromJson method for convert json into QuickLinksBean object
	 * 
	 * @param json
	 * @return
	 */
	private QuickLinksBean getBeanFromJson(String json) {
		Type type = new TypeToken<QuickLinksBean>() {
		}.getType();
		Gson gson = new GsonBuilder().create();
		QuickLinksBean quickLinkBean = gson.fromJson(json, type);

		quickLinkBean.setQuickLinks(IntlUtils.addExtension(quickLinkBean
				.getQuickLinks()));

		return quickLinkBean;
	}

	@Override
	public void process() {

		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		ValueMap valueMap = getResource().getValueMap();

		String styleId = valueMap.get(QUICKLINK_STYLE, (String) null);

		String quickLinkType = valueMap.get(QUICKLINK_TYPE, (String) null);

		String[] valueString = valueMap.get(QUICKLINKS_ITEMS, new String[] {});

		String quickLinkParentPage = valueMap
				.get(QUICKLINK_LIST, (String) null);

		String textColor = valueMap.get(QUICKLINK_TEXT_COLOR, (String) null);
		String headerColor = valueMap
				.get(QUICKLINK_HEADER_COLOR, (String) null);

		if (StringUtils.isEmpty(styleId)) {
			addErrorMsg(ERROR_QUICKLINK_STYLE);
		}

		if (StringUtils.isEmpty(quickLinkType)) {
			addErrorMsg(ERROR_QUICKLINK_TYPE);

		} else {

			if (quickLinkType.equals("parent")
					&& StringUtils.isEmpty(quickLinkParentPage)) {
				addErrorMsg(ERROR_QUICKLINK_PARENT);
			}

			if (quickLinkType.equals("manual") && valueString.length <= 0) {
				addErrorMsg(ERROR_QUICKLINK_ITEMS);
			}

		}

		if (StringUtils.isEmpty(QUICKLINK_TEXT_COLOR)) {
			addErrorMsg(ERROR_QUICKLINK_TEXT_COLOR);
		}

		if (this.isValid()) {
			// get style info.
			QuickLinkConfigProvider quickLinkConfigProvider = getQuickLinkConfig(styleId);

			if (quickLinkConfigProvider != null
					&& quickLinkConfigProvider.isValid()) {

				// Get List of QuickLinksBean
				List<QuickLinksBean> quickLinkList = null;

				if (quickLinkType.equals("parent")) {
					quickLinkList = getQuickLinkDetails(quickLinkParentPage);
				} else if (quickLinkType.equals("manual")) {
					quickLinkList = getQuickLinkDetails(valueString);
				}

				if (this.isValid()) {
					this.quickLinkTextColor = textColor;
					this.quickLinkHeaderColor = headerColor;

					this.quickLinksList = setStyle(quickLinkList,
							quickLinkConfigProvider);

					this.quickLinkHeader = valueMap.get(QUICKLINK_HEADER,
							(String) "Default Header");

					if (this.quickLinksList == null
							|| this.quickLinksList.isEmpty()) {
						addErrorMsg(ERROR_QUICKLINK_NO_CONTENT);
					}
				}

			} else {
				addErrorMsg(String.format(ERROR_QUICK_LINK_CONFIG, styleId));
			}

		}

		LOGGER.info("QuickLink List " + quickLinksList);

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);

	}

	private List<QuickLinksBean> getQuickLinkDetails(String quickLinkParentPage) {
		List<QuickLinksBean> quickLinksBeans = new ArrayList<QuickLinksBean>();
		QuickLinksBean quickLink;
		Page parentPath = IntlUtils.getPage(getResourceResolver(),
				quickLinkParentPage);

		Iterator<Page> rootPageIterator = parentPath.listChildren();
		while (rootPageIterator.hasNext()) {
			Page childPage = rootPageIterator.next();
			if (IntlUtils.checkResource(childPage,
					JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
					GenericConstants.ARTICLE_PAGE_TYPE)) {
				ArticlePageProvider articlePageProvider = new ArticlePageProvider();

				articlePageProvider
						.init(IntlUtils.getBindingForPage(childPage));

				if (articlePageProvider.isValid()
						&& articlePageProvider.isShowInQuickLink()) {
					quickLink = new QuickLinksBean();

					quickLink.setQuickLinksTitle(articlePageProvider
							.getQuickLinkTitle());

					quickLink.setQuickLinks(IntlUtils.addExtension(childPage
							.getPath()));

					quickLink.setImagefile(articlePageProvider
							.getQuickLinkImageRef());

					quickLinksBeans.add(quickLink);
				}
			}
		}

		return quickLinksBeans;
	}

	private List<QuickLinksBean> getQuickLinkDetails(String[] valueString) {
		List<QuickLinksBean> beanList = new ArrayList<QuickLinksBean>();

		for (int index = 0; index < valueString.length; index++) {

			JSONObject jsonObj = new JSONObject(valueString[index]);
			QuickLinksBean quickLinksBean = getBeanFromJson(jsonObj.toString());

			if (StringUtils.isEmpty(quickLinksBean.getQuickLinks())) {
				addErrorMsg("Please add an image for the quicklink - " + index + 1);

			}
			if (StringUtils.isEmpty(quickLinksBean.getQuickLinksTitle())) {
				addErrorMsg("Please add a title for the quick link -" + index + 1);
			}
			beanList.add(quickLinksBean);
		}
		return beanList;
	}

	private List<QuickLinksBean> setStyle(List<QuickLinksBean> quickLinkList,
			QuickLinkConfigProvider quickLinkConfigProvider) {
		if (quickLinkList != null) {

			for (int index = 0; index < quickLinkList.size(); index++) {

				List<String> colorList = quickLinkConfigProvider.getColorList();
				if (colorList != null && !colorList.isEmpty()) {
					// % operator is used to rotate the colorlist based on
					// the
					// number of quick link entries
					quickLinkList.get(index).setColor(
							colorList.get(index
									% quickLinkConfigProvider.getColorList()
											.size()));
				}
				quickLinkList.get(index).setBorderColor(
						quickLinkConfigProvider.getBorderColor());
			}
		}

		return quickLinkList;
	}

	private QuickLinkConfigProvider getQuickLinkConfig(String styleId) {
		QuickLinkConfigProvider configProvider = null;

		QuickLinkConfigContainerProvider quickLinkConfig = GlobalConfigUtil
				.getProvider(getResource()).getQuickLinkConfig();

		Object obj = quickLinkConfig.getQuickLinkConfigMap().get(styleId);
		if (obj instanceof Collection<?>) {
			Collection<QuickLinkConfigProvider> configLIst = (ArrayList<QuickLinkConfigProvider>) obj;

			for (QuickLinkConfigProvider quickLinkConfigProvider : configLIst) {
				configProvider = quickLinkConfigProvider;
				break;
			}
		}

		return configProvider;
	}
}
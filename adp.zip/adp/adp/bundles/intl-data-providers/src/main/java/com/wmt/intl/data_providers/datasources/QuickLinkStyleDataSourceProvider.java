package com.wmt.intl.data_providers.datasources;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;

import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.siteconfig.QuickLinkConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

public class QuickLinkStyleDataSourceProvider extends IntlBaseProvider {

	
	@Override
	protected void process() {
		ResourceResolver resolver = getResource().getResourceResolver();

		List<Resource> resourceList = new ArrayList<>();

		String requestURI = getRequest().getRequestURI();
		String dialogPath = GlobalConfigConstants.ComponentDialogPaths.QUICKLINKS;
		
		String componentResourcePath = IntlUtils.getResourcePathFromDialogDataSource(requestURI, dialogPath);
				
		ValueMap vm;
		resourceList.add(new ValueMapResource(resolver, new ResourceMetadata(),
				"nt:unstructured", new ValueMapDecorator(new HashMap<>())));

		List<QuickLinkConfigProvider> configList = GlobalConfigUtil
				.getProvider(getResource().getResourceResolver().getResource(componentResourcePath)).getQuickLinkConfig()
				.getQuickLinkConfigList();

		for (QuickLinkConfigProvider quickLinkConfigProvider : configList) {
			vm = new ValueMapDecorator(new HashMap<>());
			vm.put("value", quickLinkConfigProvider.getQuickLinkStyle());
			vm.put("text", quickLinkConfigProvider.getQuickLinkStyle());
			resourceList.add(new ValueMapResource(resolver,
					new ResourceMetadata(), "nt:unstructured", vm));
		}
		


		DataSource ds = new SimpleDataSource(resourceList.iterator());
		this.getRequest().setAttribute(DataSource.class.getName(), ds);

	}

}

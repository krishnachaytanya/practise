package com.wmt.intl.data_providers.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.script.SimpleBindings;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.bean.CarouselBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.pages.ArticlePageProvider;
import com.wmt.intl.data_providers.siteconfig.ArticleCatConfigContainerProvider;
import com.wmt.intl.data_providers.siteconfig.ArticleCategoryConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

/**
 * CarouselProvider for Carousel Component
 * 
 * @author vn67566
 *
 */
public class CarouselProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(CarouselProvider.class);

	private static final String PLAYSPEED = "playSpeed";
	private static final String LINK1 = "link1";
	private static final String LINK2 = "link2";
	private static final String LINK3 = "link3";
	private static final String LINK4 = "link4";
	private static final String LINKTOVIEWMORE = "linktoviewmore";

	private String linkToViewMore;
	private int playSpeed;
	private List<CarouselBean> carousel;

	/**
	 * To get carousel list
	 * 
	 * @return
	 */
	public List<CarouselBean> getCarousel() {
		return carousel;
	}

	/**
	 * To get linkToViewMore
	 * 
	 * @return
	 */
	public String getLinkToViewMore() {
		return linkToViewMore;
	}

	/**
	 * To get playSpeed
	 * 
	 * @return
	 */
	public int getPlaySpeed() {
		return playSpeed;
	}

	@Override
	protected void process() {

		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		populateCarousel();

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To populate carousel component details
	 */
	private void populateCarousel() {
		if (getResource() != null) {
			ValueMap valueMap = getProperties();

			String link1 = valueMap.get(LINK1, (String) null);
			String link2 = valueMap.get(LINK2, (String) null);
			String link3 = valueMap.get(LINK3, (String) null);
			String link4 = valueMap.get(LINK4, (String) null);

			linkToViewMore = valueMap.get(LINKTOVIEWMORE, (String) null);
			playSpeed = valueMap.get(PLAYSPEED, (int) 4000);
			carousel = new ArrayList<CarouselBean>();

			Map<String, ArticleCategoryConfigProvider> artlCatColorMap = getArticleCatColor();

			if (isValid()) {
				carousel.add(populatePage(link1, artlCatColorMap));
				carousel.add(populatePage(link2, artlCatColorMap));
				carousel.add(populatePage(link3, artlCatColorMap));
				carousel.add(populatePage(link4, artlCatColorMap));
			}

		} else {

			addErrorMsg("Carousel  config details not found ");
		}

	}

	/**
	 * To populatePage
	 * 
	 * @param pagePath
	 * @param artlCatColorMap
	 * @return
	 */
	public CarouselBean populatePage(String pagePath,
			Map<String, ArticleCategoryConfigProvider> artlCatColorMap) {
		CarouselBean carouselBean = new CarouselBean();

		if (!(StringUtils.isEmpty(pagePath))) {

			Page page = IntlUtils.getPage(getResourceResolver(), pagePath);

			if (!IntlUtils.checkResource(page, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, GenericConstants.ARTICLE_PAGE_TYPE)) {
				addErrorMsg("Page - {0} is not an article page",
						pagePath);
			}

			if (isValid()) {
				ArticlePageProvider articlePageProvider = getArticlePageProvider(pagePath);

				carouselBean.setTitle(articlePageProvider.getTitle());
				carouselBean.setDescription(articlePageProvider
						.getDescription());
				carouselBean.setCategoryConfig(getCategoryProv(
						articlePageProvider.getArticleCatList(),
						artlCatColorMap));
				carouselBean.setDate(IntlUtils.getFormattedDate(
						articlePageProvider.getDate(),
						GenericConstants.DATE_FORMAT_D_MMMMM_YYYY));
				carouselBean.setImageRenditionsBean(articlePageProvider
						.getArticleImageRenditions());
				carouselBean.setLink(pagePath);
				
				if(carouselBean.getCategoryConfig() == null){
					addErrorMsg(String.format("Category and color details not found for %s",pagePath));
				}
			}

		} else {
			addErrorMsg("Please configure an article page link");
		}
		return carouselBean;
	}

	private Map<String, ArticleCategoryConfigProvider> getArticleCatColor() {
		ArticleCatConfigContainerProvider categoryProv = GlobalConfigUtil
				.getProvider(getResource(), getSlingScriptHelper()).getArtlCatConfigProvider();
		Map<String, ArticleCategoryConfigProvider> catColorMap = null;

		if (categoryProv.isValid()) {
			catColorMap = categoryProv.getArticleCatMap();
		} else {
			addErrorMsg("Please configure Article Category from Global configuration");
		}

		return catColorMap;
	}

	private ArticleCategoryConfigProvider getCategoryProv(List<String> articleCatList,
			Map<String, ArticleCategoryConfigProvider> catColorMap) {
		ArticleCategoryConfigProvider articleCategoryProv = null;

		// Get the category bean of the 1st category associated with Article
		if (articleCatList != null && !articleCatList.isEmpty()
				&& !StringUtils.isEmpty(articleCatList.get(0))
				&& catColorMap != null) {
			articleCategoryProv = catColorMap.get(articleCatList.get(0));

		}
		return articleCategoryProv;
	}

	/**
	 * To get ArticlePageProvider
	 * 
	 * @param path
	 * @return
	 */
	public ArticlePageProvider getArticlePageProvider(String path) {

		ArticlePageProvider articlePageProvider;

		SimpleBindings ariticleProviderBinding = IntlUtils.getBindingForPage(
				getResource().getResourceResolver(), path);
		articlePageProvider = new ArticlePageProvider();

		articlePageProvider.init(ariticleProviderBinding);

		return articlePageProvider;
	}
}

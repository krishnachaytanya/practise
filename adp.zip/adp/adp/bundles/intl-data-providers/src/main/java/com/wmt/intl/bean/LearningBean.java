package com.wmt.intl.bean;

import java.util.Calendar;
import java.util.Comparator;

/**
 * LearningBean for LearningLibraryPageProvider
 * 
 * @author vn67566
 *
 */
public class LearningBean implements Comparable<LearningBean> {

	private String title;
	private Calendar pubDate;
	private String link;
	private String description;
	private ImageRenditionsBean learningImageRendition;
	private String formattedPubDate;

	/**
	 * To get published date
	 * 
	 * @return
	 */
	public Calendar getPubDate() {
		return pubDate;
	}

	/**
	 * To set published date
	 * 
	 * @param date
	 */
	public void setPubDate(Calendar date) {
		this.pubDate = date;
	}

	/**
	 * To get the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To set the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * To get Description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Setting Description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * To get Image Renditions
	 * 
	 * @return
	 */
	public ImageRenditionsBean getLearningImageRendition() {
		return learningImageRendition;
	}

	/**
	 * Setting Image Renditions
	 * 
	 * @param learningImageRendition
	 */
	public void setLearningImageRendition(
			ImageRenditionsBean learningImageRendition) {
		this.learningImageRendition = learningImageRendition;
	}

	/**
	 * To get Formatted PubDate
	 * 
	 * @return
	 */
	public String getFormattedPubDate() {
		return formattedPubDate;
	}

	/**
	 * Setting Formatted PubDate
	 * 
	 * @param formattedPubDate
	 */
	public void setFormattedPubDate(String formattedPubDate) {
		this.formattedPubDate = formattedPubDate;
	}

	@Override
	public int compareTo(LearningBean learningTo) {
		return Comparators.DATE_DESC.compare(this, learningTo);
	}

	static class Comparators {

		private static int compareInternal(Calendar calendar,
				Calendar calendar2, Boolean isDescending) {
			int order = 1;

			if ((calendar == null) && (calendar2 == null)) {
				return 0;
			}
			if (calendar == null) {
				return 1;
			}
			if (calendar2 == null) {
				return -1;
			}
			order = calendar2.compareTo(calendar);
			if (!isDescending) {
				order = order * -1;
			}
			return order;
		}

		public static Comparator<LearningBean> DATE = new Comparator<LearningBean>() {
			@Override
			public int compare(LearningBean itemA, LearningBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						false);
			}
		};

		public static Comparator<LearningBean> DATE_DESC = new Comparator<LearningBean>() {
			@Override
			public int compare(LearningBean itemA, LearningBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						true);
			}
		};
	}

}

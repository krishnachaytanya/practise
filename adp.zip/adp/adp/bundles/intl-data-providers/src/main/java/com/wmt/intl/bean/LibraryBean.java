package com.wmt.intl.bean;

import java.util.Calendar;
import java.util.Comparator;

/**
 * LibraryBean for LearningLibraryListProvider
 * 
 * @author vn67566
 *
 */
public class LibraryBean implements Comparable<LibraryBean> {

	private String title;
	private ImageRenditionsBean libraryImageRendition;
	private Calendar pubDate;
	private String link;

	/**
	 * To get published date
	 * 
	 * @return
	 */
	public Calendar getPubDate() {
		return pubDate;
	}

	/**
	 * To set published date
	 * 
	 * @param date
	 */
	public void setPubDate(Calendar date) {
		this.pubDate = date;
	}

	/**
	 * To get the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To set the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * To get libraryImageRendition
	 * 
	 * @return the libraryImageRendition
	 */
	public ImageRenditionsBean getLibraryImageRendition() {
		return libraryImageRendition;
	}

	/**
	 * To set libraryImageRendition
	 * 
	 * @param libraryImageRendition
	 * 
	 */
	public void setLibraryImageRendition(
			ImageRenditionsBean libraryImageRendition) {
		this.libraryImageRendition = libraryImageRendition;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * To set link
	 * 
	 * @param link
	 */
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public int compareTo(LibraryBean libraryTo) {
		return Comparators.DATE_DESC.compare(this, libraryTo);
	}

	static class Comparators {

		private static int compareInternal(Calendar calendar,
				Calendar calendar2, Boolean isDescending) {
			int order = 1;

			if ((calendar == null) && (calendar2 == null)) {
				return 0;
			}
			if (calendar == null) {
				return 1;
			}
			if (calendar2 == null) {
				return -1;
			}
			order = calendar2.compareTo(calendar);
			if (!isDescending) {
				order = order * -1;
			}
			return order;
		}

		public static Comparator<LibraryBean> DATE = new Comparator<LibraryBean>() {
			@Override
			public int compare(LibraryBean itemA, LibraryBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						false);
			}
		};

		public static Comparator<LibraryBean> DATE_DESC = new Comparator<LibraryBean>() {
			@Override
			public int compare(LibraryBean itemA, LibraryBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						true);
			}
		};
	}

}

/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;

/**
 * Logo config Provider to get all the configuration details for Logo component
 * 
 * @author vn93497
 *
 */
public class LogoConfigProvider extends IntlBaseProvider {

	private final String LOGO_IMAGEREFERENCE = "imagereference";
	private final String LOGO_URL = "link";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LogoConfigProvider.class);

	private String targetUrl;
	private String imagePath;

	/**
	 * To get the Target URL of Logo
	 * 
	 * @return targetUrl
	 */
	public String getTargetUrl() {
		return targetUrl;
	}

	/**
	 * To get the Logo Image Path
	 * 
	 * @return imagePath
	 */
	public String getImagePath() {
		return imagePath;
	}

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		if (getResource() != null) {
			String logoConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.LOGO_PATH;

			if (logoConfigPath.equalsIgnoreCase(getResource().getPath())) {
				ValueMap valueMap = getResource().getValueMap();

				targetUrl = valueMap.get(LOGO_URL, (String) null);
				imagePath = valueMap.get(LOGO_IMAGEREFERENCE, (String) null);

				if (StringUtils.isEmpty(targetUrl)) {
					addErrorMsg("Please configure logo target Url");
				}

				if (StringUtils.isEmpty(imagePath)) {
					addErrorMsg("Please configure logo image path");
				}
			} else {
				addErrorMsg("Please use GlobalConfigProvider to get Logo Config");
			}
		} else {
			addErrorMsg("Logo config details not found");
		}

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

}

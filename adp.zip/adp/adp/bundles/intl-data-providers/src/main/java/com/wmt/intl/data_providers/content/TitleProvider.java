package com.wmt.intl.data_providers.content;

import org.apache.commons.lang.StringUtils;

import com.wmt.intl.data_providers.IntlBaseProvider;

/**
 * Title Provider for Title Component
 * @author vn68454
 *
 */
public class TitleProvider extends IntlBaseProvider {

	private String title;
	private String headerType;
	
	/**
	 * To get title text
	 * @return
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * To get the header type (h2,h3,h4)
	 * @return
	 */
	public String getHeaderType() {
		return headerType;
	}

	@Override
	protected void process() {
		if (getResource() != null) {
			title = getProperties().get("title", (String) null);
			headerType = getProperties().get("headerType", "h4");
			if(StringUtils.isEmpty(title)){
				addErrorMsg("Please configure Title text");
			}
		}
		else{
			addErrorMsg("Title configuration details not found");
		}
	}
}
package com.wmt.intl.data_providers.layout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.bean.BreadcrumbBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * BreadcrumbProvider for Breadcrumb component
 * 
 * @author vn67566
 *
 */

public class BreadcrumbProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(BreadcrumbProvider.class);

	private static final String BREADCRUMB_VISIBLE = "breadcrumbVisible";

	List<BreadcrumbBean> breadcrumbBeanList = new ArrayList<BreadcrumbBean>();

	private boolean visible;

	/**
	 * To get list of BreadcrumbBean
	 * 
	 * @return
	 */
	public List<BreadcrumbBean> getBreadcrumbBeanList() {
		return breadcrumbBeanList;
	}

	/**
	 * To check the visible status
	 * 
	 * @return
	 */
	public boolean isVisible() {
		return visible;
	}

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		visible = getInheritedProperty(getCurrentPage(), BREADCRUMB_VISIBLE,
				Boolean.TRUE);
		if (visible) {
			// populating Breadcrumb page list
			populateBreadcrumb(getCurrentPage());
		}

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To populate breadcrumb details
	 * 
	 * @param currentPage
	 */
	private void populateBreadcrumb(Page currentPage) {
		String localePath = IntlUtils.getContentLocalePath(currentPage
				.getPath());
		while (currentPage != null) {
			if (currentPage.getPath().equalsIgnoreCase(localePath)) {
				currentPage = null;
			} else {
				if (!currentPage.getProperties().get("hideInNav", false)) {
					breadcrumbBeanList
							.add(getBreadcrumbLinkFromPage(currentPage));
				}
				currentPage = currentPage.getParent();
			}

		}

		Collections.reverse(breadcrumbBeanList);

	}

	/**
	 * To get breadCrumb link from a page
	 * 
	 * @param page
	 * @return BreadcrumbBean
	 */
	private BreadcrumbBean getBreadcrumbLinkFromPage(Page page) {
		BreadcrumbBean newBreadcrumbLink = new BreadcrumbBean();

		newBreadcrumbLink.setLink(page.getPath());
		newBreadcrumbLink.setTitle(page.getTitle());

		return newBreadcrumbLink;
	}

}

package com.wmt.intl.servlets;

import com.adobe.granite.analytics.client.AnalyticsClient;
import com.adobe.granite.analytics.client.AnalyticsClientBuilder;
import com.adobe.granite.analytics.client.ApiException;
import com.adobe.granite.analytics.client.domain.*;
import com.adobe.granite.analytics.client.methods.ReportMethods;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.content.TrendingContentsProvider;
import com.wmt.intl.data_providers.siteconfig.ProxyConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.script.SimpleBindings;
import javax.servlet.ServletException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * * Servlet class for fetching trending pages from adobe analytics Created by
 * dcrajan on 11/10/2017.
 */

@SlingServlet(resourceTypes = "/apps/intl/components/siteconfig/trendingPageConfig", selectors = "analyticData", extensions = "html", methods = "GET")
public class AnalyticDataFeedServlet extends SlingSafeMethodsServlet {
	final static String CONST_END_POINT = "api.omniture.com";
	final static String CONST_DATE_FROM = "2017-01-01";
	final static String CONST_DATE_GRANULARITY = "year";
	final static String CONST_METRICS = "pageviews";
	final static String CONST_ELEMENTS = "page";
	final static String DATE_FORMAT = "yyyy-MM-dd";
	final static String JSON_KEY_PAGE_NAME = "pageName";
	final static String JSON_KEY_PAGE_COUNT = "pageCount";
	final static String JSON_KEY_PAGE_URL = "pageUrl";
	final static String JSON_KEY_ERROR = "Error";
	final static String JSON_ERROR_DESC = "Error while fetching Analytic data";

	private String userName;
	private String secretCode;
	private String reportSuiteId;
	private String pageLimit;
	private String endPoint;
	private String dateFrom;
	private String dateTo;
	private String dateGranularity;
	private String metrics;
	private String elements;
	private String segmentId;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AnalyticDataFeedServlet.class);

	/**
	 * doget method for returning the servlets response
	 *
	 * @param request
	 *            ,response
	 */
	@Override
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		String reportJSON = "";
		try {
			LOGGER.info("START: Fetching the analytics servlets get method");
			Resource resource = request.getResource();
			SimpleBindings trendingContentBinding = IntlUtils.getBindingByPath(
					resource, resource.getPath());
			TrendingContentsProvider trendingProvider = new TrendingContentsProvider();
			trendingProvider.init(trendingContentBinding);
			setConfigValues(trendingProvider, request);

			ProxyConfigProvider proxyConfig = GlobalConfigUtil.getProvider(
					request.getResource()).getProxyConfig();

			ReportResponse analyticReportData = getAnalyticalData(proxyConfig);
			reportJSON = generateJSONData(analyticReportData);
			String host = request.getRemoteHost();
		} catch (Exception e) {
			LOGGER.error("ERROR : ", e);
			response.setStatus(SlingHttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			reportJSON = generateErrorJSON().toString();
		} finally {
			response.getWriter().write(reportJSON);
			LOGGER.info("END: Fetching the analytics servlets get method");
		}
	}

	/**
	 * Method to set the configuration values for calling the analytics service
	 *
	 * @param trendingContentProvider
	 */
	private void setConfigValues(
			TrendingContentsProvider trendingContentProvider,
			SlingHttpServletRequest request) {
		this.userName = trendingContentProvider.getUserName();
		this.secretCode = trendingContentProvider.getSecretCode();
		this.reportSuiteId = trendingContentProvider.getReportSuiteId();
		this.pageLimit = trendingContentProvider.getPageLimit();
		this.endPoint = trendingContentProvider.getEndPoint();
		this.segmentId = getSegmentId(request, trendingContentProvider);

		this.dateGranularity = CONST_DATE_GRANULARITY;
		this.metrics = CONST_METRICS;
		this.elements = CONST_ELEMENTS;

		setCurrentDate();
		setFromDate();
	}

	/**
	 * Method to set the current date in a yyyy-MM-dd format
	 *
	 */
	private void setCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		Date date = new Date();
		this.dateTo = dateFormat.format(date);
	}

	/**
	 * Method to set the from date in a yyyy-MM-dd format
	 *
	 */
	private void setFromDate() {
		DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_MONTH, -30);
		Date date = cal.getTime();
		this.dateFrom = dateFormat.format(date);

	}

	/**
	 * Method to get the analytical data
	 *
	 * @return ReportResponse
	 */
	private ReportResponse getAnalyticalData(ProxyConfigProvider proxyConfig)
			throws IOException, InterruptedException {
		AnalyticsClient client = new AnalyticsClientBuilder()
				.setEndpoint(this.endPoint)
				.authenticateWithSecret(this.userName, this.secretCode).build();

		if (proxyConfig != null && proxyConfig.getProxyRequired() == true) {
			client = new AnalyticsClientBuilder()
					.setEndpoint(this.endPoint)
					.withProxy(proxyConfig.getProxyHost(),
							proxyConfig.getProxyPort())
					.authenticateWithSecret(this.userName, this.secretCode)
					.build();
		}

		final ReportMethods methods = new ReportMethods(client);
		final ReportResponse reportResponse = fetchAnalyticalReport(methods);
		return reportResponse;
	}

	/**
	 * Method to fetch the analytical data from adobe analytics server
	 * 
	 * @param methods
	 * @return ReportResponse
	 */
	private ReportResponse fetchAnalyticalReport(final ReportMethods methods)
			throws IOException, InterruptedException, ApiException {
		ReportDescription desc = createReportDesc();
		LOGGER.info("Sending queue request...");
		final int reportId = methods.queue(desc);
		LOGGER.info("Got report id: " + reportId);

		ReportResponse response = null;
		LOGGER.info("Sending get request for report " + reportId);
		while (response == null) {
			try {
				response = methods.get(reportId);
			} catch (ApiException e) {
				if ("report_not_ready".equals(e.getError())) {
					LOGGER.info("Report not ready yet.");
					Thread.sleep(3000);
					continue;
				}
				throw e;
			}
		}
		LOGGER.info("Got report!");
		return response;
	}

	/**
	 * Method to create the report description for calling the service
	 *
	 * @return ReportDescription
	 */
	private ReportDescription createReportDesc() {
		final ReportDescription desc = new ReportDescription();
		desc.setReportSuiteID(this.reportSuiteId);
		desc.setDateFrom(this.dateFrom);
		desc.setDateTo(this.dateTo);

		final List<ReportDescriptionMetric> descMetrics = new ArrayList<>();
		ReportDescriptionMetric metric = new ReportDescriptionMetric();
		metric.setId(this.metrics);
		descMetrics.add(metric);
		desc.setMetrics(descMetrics);

		final List<ReportDescriptionElement> descElems = new ArrayList<>();
		ReportDescriptionElement elem = new ReportDescriptionElement();
		elem.setId(this.elements);
		int topPages = this.stringToInt(this.pageLimit);
		if (topPages == 0) {
			topPages = 10;
		}
		elem.setTop(topPages);
		descElems.add(elem);

		if (!StringUtils.isEmpty(this.segmentId)) {
			ReportDescriptionSegment segment = new ReportDescriptionSegment();
			segment.setId(this.segmentId);
			List<ReportDescriptionSegment> segments = new ArrayList<>();
			segments.add(segment);
			desc.setSegments(segments);
		}

		desc.setElements(descElems);
		return desc;
	}

	/**
	 * Method to generate the JSON data from the report response
	 * 
	 * @param analyticReportData
	 * @return String
	 */
	private String generateJSONData(ReportResponse analyticReportData) {
		ReportData reportData;
		JSONArray pageCollectionJSON = new JSONArray();
		String pageDataJSON;
		if (analyticReportData != null
				&& analyticReportData.getReport() != null) {
			Report report = analyticReportData.getReport();
			if (report != null && report.getData() != null
					&& report.getData().size() > 0) {

				for (ReportData page : report.getData()) {
					JSONObject pageJSON = new JSONObject();
					pageJSON.put(JSON_KEY_PAGE_NAME, page.getName());
					pageJSON.put(JSON_KEY_PAGE_COUNT, page.getCounts().get(0));
					pageJSON.put(JSON_KEY_PAGE_URL,
							page.getUrl().replace("http:","").replace("https:",""));
					pageCollectionJSON.put(pageJSON);
				}

			}
		}

		if (pageCollectionJSON != null && pageCollectionJSON.length() > 0) {
			pageDataJSON = pageCollectionJSON.toString();
		} else {
			pageDataJSON = generateErrorJSON().toString();
		}

		return pageDataJSON;
	}

	/**
	 * Method to generate the Error JSON data
	 *
	 * @return JSONObject
	 */
	private JSONObject generateErrorJSON() {
		JSONObject errorJSON = new JSONObject();
		errorJSON.put(JSON_KEY_ERROR, JSON_ERROR_DESC);
		return errorJSON;
	}

	/**
	 * Method to convert string to int
	 *
	 * @return int
	 * @param param
	 */
	private int stringToInt(String param) {
		try {
			return Integer.valueOf(param);
		} catch (NumberFormatException e) {
			return 0;
		}
	}

    /**
     * Method to get the segment Id
     *
     * @return String
     * @param request
     * @param trendingContentProvider
     */
	private String getSegmentId(SlingHttpServletRequest request,
			TrendingContentsProvider trendingContentProvider) {
        String resourcePath = request.getPathInfo()
                .substring(request.getPathInfo().indexOf(GlobalConfigConstants.TRENDING_CONFIG_PATH));

		int startIndex = StringUtils.ordinalIndexOf(resourcePath, ".",
				2);
		int endIndex = resourcePath.lastIndexOf(".");
		String segmentTitleId = null;
		String segmentId = null;
		if (startIndex < endIndex) {
			segmentTitleId = resourcePath.substring(startIndex + 1,
					endIndex);
		}
		if (!StringUtils.isEmpty(segmentTitleId)) {
			segmentId = trendingContentProvider
					.getSegmentIdFromConfig(segmentTitleId);
		}

		return segmentId;
	}
}

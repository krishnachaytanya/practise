/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;

/**
 * Quick Link Style Provider to get all the style config details for quick link
 * component.
 * 
 * @author vn93497
 *
 */
public class QuickLinkConfigProvider extends IntlBaseProvider {

	private static final String COLOR_LIST = "items";
	private static final String COLOR_PROPERTY = "colorValue";
	private static final String BORDER_COLOR_PROPERTY = "borderColor";
	private static final String QUICKLINK_STYLE_PROPERTY = "quicklinkStyle";

	final static String ERROR_MESSAGE_CONFIG_BORDER_COLOR = "Please configure border color or background color";
	final static String ERROR_MESSAGE_CONFIG_QUICK_LINK_STYLE = "Please configure quick link style";
	final static String ERROR_MESSAGE_CONFIG_QUICK_LINK_COLOR = "Please configure quicklink color";
	private static final String ERROR_MESSAGE_CONFIG_DUPLICATE_STYLE = "Duplicate quick link Style - %s";

	private String quickLinkStyle;
	private String borderColor;
	private List<String> colorList;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(QuickLinkConfigProvider.class);

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		if (getResource() != null) {
			String id = getResource().getValueMap().get(QUICKLINK_STYLE_PROPERTY,
					(String) null);
			String borderColor = getResource().getValueMap().get(
					BORDER_COLOR_PROPERTY, (String) null);

			String[] colorArray = getResource().getValueMap().get(COLOR_LIST,
					new String[] {});

			if (StringUtils.isEmpty(id)) {
				addErrorMsg(ERROR_MESSAGE_CONFIG_QUICK_LINK_STYLE);
			}

			if (colorArray.length <= 0 && StringUtils.isEmpty(borderColor)) {
				addErrorMsg(ERROR_MESSAGE_CONFIG_BORDER_COLOR);
			}

			if (getPageProperties() != null && isDuplicateId(id)) {
				addErrorMsg(String
						.format(ERROR_MESSAGE_CONFIG_DUPLICATE_STYLE, id));
			}

			if (this.isValid()) {
				this.quickLinkStyle = id;
				this.borderColor = borderColor;

				if (colorArray.length > 0) {
					this.colorList = new ArrayList<String>();

					for (int index = 0; index < colorArray.length; index++) {
						JSONObject jsonObj = new JSONObject(colorArray[index]);
						this.colorList.add(jsonObj.getString(COLOR_PROPERTY));
					}
				}
			}
		}
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	private boolean isDuplicateId(String id) {
		boolean duplicateStatus = false;
		Object obj = GlobalConfigUtil.getProvider(getResource())
				.getQuickLinkConfig().getQuickLinkConfigMap().get(id);

		if (obj instanceof Collection<?>) {
			Collection<QuickLinkConfigProvider> configLIst = (Collection<QuickLinkConfigProvider>) obj;

			if (configLIst.size() > 1) {
				duplicateStatus = true;
			}
		}

		return duplicateStatus;
	}

	/**
	 * @return the quickLinkStyle
	 */
	public String getQuickLinkStyle() {
		return quickLinkStyle;
	}

	/**
	 * @return the borderColor
	 */
	public String getBorderColor() {
		return borderColor;
	}

	/**
	 * To get the color list for quick links
	 * 
	 * @return
	 */
	public List<String> getColorList() {
		return colorList;
	}

}

package com.wmt.intl.servlets;

import com.wmt.intl.data_providers.content.FbGroupFeedProvider;
import com.wmt.intl.data_providers.siteconfig.ProxyConfigProvider;
import com.wmt.intl.service.FbGroupFeedService;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.script.SimpleBindings;
import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Servlet class for fetching facebook data
 * Created by dcrajan on 10/4/2017.
 */

@SlingServlet(
        resourceTypes = "intl/components/content/fbgroupfeed",
        selectors = "groupfeeds",
        extensions = "html",
        methods = "GET")

public class FbGroupFeedServlet extends SlingSafeMethodsServlet {
    final static String ERROR_KEY = "errormessage";
    final static String ERROR_MESSAGE = "Unable to fetch facebook data.";

    private static final Logger LOGGER = LoggerFactory
            .getLogger(FbGroupFeedServlet.class);

    /**
     *doget method for returning the servlets response
     *
     *@param request,response
     */
    @Override
    protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws
            ServletException, IOException {
        try{
            LOGGER.info("START: Fetching the facebook servlets get method");
            ProxyConfigProvider proxyConfig = GlobalConfigUtil
                    .getProvider(request.getResource()).getProxyConfig();


            Resource resource = request.getResource();
            SimpleBindings fbBinding = IntlUtils.getBindingByPath(resource, resource.getPath());
            FbGroupFeedProvider fbProvider =  new FbGroupFeedProvider();
            fbProvider.init(fbBinding);

            FbGroupFeedService fbService = new FbGroupFeedService();
            String groupFeeds = fbService.getFacebookFeeds(fbProvider,proxyConfig);

            JSONObject feedResponse = new JSONObject(groupFeeds);
            if (feedResponse == null || !feedResponse.has("data")){
                response.setStatus(SlingHttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                feedResponse.put(ERROR_KEY,ERROR_MESSAGE);
            }
            response.getWriter().write(feedResponse.toString());

            LOGGER.info("END: Fetching the facebook servlets get method");
        }
        catch(Exception e)
        {
            LOGGER.error("ERROR : ",e);
        }

    }
}
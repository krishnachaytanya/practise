package com.wmt.intl.bean;

/**
 * BreadcrumbLinksBean for BreadcrumbProvider
 * 
 * @author vn67566
 *
 */
public class BreadcrumbBean {

	/**
	 * link contains Breadcrumb page link
	 */
	private String link;
	/**
	 * title contains Breadcrumb page title
	 */
	private String title;

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

}

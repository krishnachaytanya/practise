package com.wmt.intl.service;

import com.wmt.intl.data_providers.content.FbGroupFeedProvider;
import com.wmt.intl.data_providers.siteconfig.ProxyConfigProvider;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Service class for fetching facebook feeds Created by dcrajan on 9/22/2017.
 */
public class FbGroupFeedService {

	final static String FACEBOOK_HOST = "graph.facebook.com";
	final static int FACEBOOK_PORT = 443;
	final static String FACEBOOK_URL = "/v2.10/%s/feed?access_token=%s&fields=from%%7Bname%%2C%%20picture.type(square)%%7D%%2Cshares%%2Creactions.summary(true).summary(true)%%2Ccomments.limit(1).summary(true)%%2Clikes.limit(1).summary(true)%%2Cfull_picture%%2Cpicture%%2Cid%%2Cmessage%%2Cname%%2Ccaption%%2Cdescription%%2Ccreated_time%%2Cupdated_time%%2Clink%%2Cicon%%2Cprivacy%%2Ctype%%2Cstatus_type%%2Capplication%%2Cobject_id%%2Cstory%%2Cstory_tags%%2Cactions%%2Cpermalink_url&format=json&limit=%s&method=get&pretty=0&suppress_http_code=1";

	final static String PROXY_HOST_NAME = "gec-proxy-svr.homeoffice.wal-mart.com";
	final static int PROXY_PORT = 8080;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(FbGroupFeedService.class);

	/**
	 * Method to fetch the facebook group feed details
	 *
	 * @param fbProvider
	 * @return String
	 */
	public String getFacebookFeeds(FbGroupFeedProvider fbProvider,ProxyConfigProvider proxyConfig) {

		LOGGER.info("START: Fetching the facebook service");
		DefaultHttpClient httpClient = new DefaultHttpClient();

		try {

			String url = String.format(FACEBOOK_URL, fbProvider.getGroupId(),
					fbProvider.getAuthKey(), fbProvider.getFeedLimit());

			if (proxyConfig != null && proxyConfig.getProxyRequired() == true) {
				HttpHost proxy = new HttpHost(proxyConfig.getProxyHost(),
						proxyConfig.getProxyPort(), "http");
				httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,
						proxy);
			}

			HttpHost target = new HttpHost(FACEBOOK_HOST, FACEBOOK_PORT,
					"https");

			HttpGet getRequest = new HttpGet(url);
			getRequest.addHeader("accept", "application/json");

			HttpResponse response = httpClient.execute(target, getRequest);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			String responseJSON = "";
			String output;
			while ((output = br.readLine()) != null) {
				responseJSON = responseJSON + output;
			}

			LOGGER.info("END: Fetching the facebook service");
			LOGGER.info("RESPONSE: " + responseJSON);
			return responseJSON;
		} catch (Exception e) {
			LOGGER.error("ERROR : ", e);
			return String.format("{%s}", e.getMessage());
		} finally {
			// When HttpClient instance is no longer needed,
			// shut down the connection manager to ensure
			// immediate deallocation of all system resources
			httpClient.getConnectionManager().shutdown();
		}
	}
}

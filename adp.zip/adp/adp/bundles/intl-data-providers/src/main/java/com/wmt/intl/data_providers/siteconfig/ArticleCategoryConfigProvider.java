/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.service.SystemAccountUtilService;

/**
 * Article Category Config Provider
 *
 */
public class ArticleCategoryConfigProvider extends IntlBaseProvider {

	private String articleCategoryTag;
	private String categoryName;
	private String colorValue;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ArticleCategoryConfigProvider.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wmt.intl.data_providers.IntlBaseProvider#process()
	 */
	@Override
	protected void process() {
		LOGGER.info(GenericConstants.LOG_START_PROCESS_TXT);
		if (getResource() != null) {

			String[] articleCategoryTagArr = getResource().getValueMap().get(
					"articleCategoryTag", new String[] {});
			String colorValue = getResource().getValueMap().get("colorValue",
					(String) null);

			if (articleCategoryTagArr.length <= 0
					|| articleCategoryTagArr.length > 1) {
				addErrorMsg("Please choose one article category tag");
			}

			if (colorValue == null) {
				addErrorMsg("Please provide a  color value");
			}

			if (this.isValid()) {
				this.articleCategoryTag = articleCategoryTagArr[0];
				this.colorValue = colorValue;
				
				String tagTitle= null;
				if (getSlingScriptHelper() != null) {
					//Calling service to get tag title using account service user.
					tagTitle = getSlingScriptHelper()
							.getService(SystemAccountUtilService.class)
							.getTagTitle(this.articleCategoryTag);
					
				}
				
				if (tagTitle != null) {
					this.categoryName = tagTitle;
				} else {
					addErrorMsg(String.format("Tag - %s not found",
							this.articleCategoryTag));
				}
			}
		} else {
			addErrorMsg("Article category Config details not found");
		}

		LOGGER.info(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * @return the articleCategoryTag
	 */
	public String getArticleCategoryTag() {
		return articleCategoryTag;
	}

	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @return the colorValue
	 */
	public String getColorValue() {
		return colorValue;
	}
}

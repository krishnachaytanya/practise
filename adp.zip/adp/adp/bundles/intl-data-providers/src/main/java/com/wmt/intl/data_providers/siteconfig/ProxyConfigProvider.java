package com.wmt.intl.data_providers.siteconfig;

import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;

/**
 * Created by dcrajan on 11/30/2017.
 */
public class ProxyConfigProvider extends IntlBaseProvider {

    private final String USE_PROXY = "useProxy";
    private final String PROXY_HOST = "proxyHost";
    private final String PROXY_PORT = "proxyPort";
    final static String ERROR_MESSAGE_PROXY_HOST = "Please provide a valid proxy host";
    final static String ERROR_MESSAGE_PROXY_PORT = "Please provide a valid proxy port";

    private Boolean isProxyRequired;
    private String proxyHost;
    private int proxyPort;

    public Boolean getProxyRequired() {
        return isProxyRequired;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    @Override
    public void process() {
        if (getResource() != null) {
            String proxyConfigPath = GlobalConfigUtil
                    .getGlobalConfigPath(getResource().getPath())
                    + GlobalConfigConstants.PROXY_CONFIG_PATH;
            if (proxyConfigPath.equalsIgnoreCase(getResource().getPath())) {
                ValueMap valueMap = getResource().getValueMap();

                isProxyRequired = Boolean.parseBoolean(valueMap.get(USE_PROXY, (String) null));
                if (isProxyRequired == true) {
                    proxyHost = valueMap.get(PROXY_HOST, (String) null);

                    if (isInteger(valueMap.get(PROXY_PORT, (String) null))) {
                        proxyPort =  Integer.parseInt(valueMap.get(PROXY_PORT, (String) null));
                    }
                    else{
                        addErrorMsg(ERROR_MESSAGE_PROXY_PORT);
                    }

                    if (StringUtils.isEmpty(proxyHost)) {
                        addErrorMsg(ERROR_MESSAGE_PROXY_HOST);
                    }
                }
            }
        }
    }

    /**
     *Method to check the provided value is an integer
     *
     *@param integerValue
     * @return boolean
     */
    private boolean isInteger(String integerValue) {
        try {
            Integer.parseInt(integerValue);
        } catch(NumberFormatException e) {
            return false;
        } catch(NullPointerException e) {
            return false;
        }
        return true;
    }
}

package com.wmt.intl.data_providers;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.i18n.I18n;
import com.day.cq.wcm.api.Page;
import com.wmt.intl.constants.GenericConstants;

/**
 * Base WCMUsePojo Provider for Intl application
 * 
 * @author vn93497
 *
 */
public abstract class IntlBaseProvider extends WCMUsePojo {

	final static String ENGLISH_LANGUAGE_CODE = "en";

	private List<String> errorMsgList = null;
	private boolean valid = true;
	@Reference
	ResourceResolverFactory resolverFactory;

	/**
	 * This abstract method is used to process the details needed for component.
	 */
	protected abstract void process();

	/**
	 * To get the error message list
	 * 
	 * @return errorMsgList
	 */
	public List<String> getErrorMsgList() {
		return errorMsgList;
	}

	/**
	 * To add error message to error message list
	 * 
	 * @param errorMsg
	 */
	protected void addErrorMsg(String errorMsg, String... arguments) {
		if (errorMsgList == null) {
			errorMsgList = new ArrayList<String>();
		}
		this.valid = false;
		String localeSpecificMessage = getTranslation(errorMsg, arguments);
		this.errorMsgList.add(localeSpecificMessage);
	}

	/**
	 * get location specific message
	 *
	 * @param message
	 * @return String
	 */
	public String getTranslation(String message, String... arguments) {
		String localeSpecificMessage;
		localeSpecificMessage = getMessage(message, arguments);
		return localeSpecificMessage;
	}

	/**
	 * get logged in user language
	 *
	 * @return String
	 */
	public String getUserLanguage() {
		String userLang = null;
		try {
			Set<String> runModeSet = getSlingScriptHelper().getService(
					SlingSettingsService.class).getRunModes();

			// If author mode, use user language setting.
			// If other than author(mainly publish), use the locale from the
			// page.
			if (runModeSet.contains("author")) {
				UserManager userManager = getResourceResolver().adaptTo(
						UserManager.class);
				Session session = getResourceResolver().adaptTo(Session.class);
				Authorizable auth = userManager.getAuthorizable(session
						.getUserID());
				userLang = auth.getProperty("./preferences/language")[0].toString();
			} else {
				if (getCurrentPage() != null) {
					userLang = getCurrentPage().getLanguage(true).getLanguage();
				}
			}
			if (StringUtils.isEmpty(userLang)) {
				userLang = ENGLISH_LANGUAGE_CODE;
			}
		} catch (Exception ex) {
			userLang = ENGLISH_LANGUAGE_CODE;
		}

		return userLang;
	}

	/**
	 * get message based on the logged in user language
	 *
	 * @param message
	 * @param arguments
	 * @return String
	 */
	private String getMessage(String message, String... arguments) {
		String errorMessage;
		Locale locale = setLocale(getUserLanguage());
		ResourceBundle resourceBundle = getRequest().getResourceBundle(locale);
		I18n i18n = new I18n(resourceBundle);
		if (arguments != null && arguments.length > 0) {
			ArrayList<String> argumentsList = new ArrayList<String>();
			for (int counter = 0; counter < arguments.length; counter++) {
				argumentsList.add(getMessageFromResource(i18n,
						arguments[counter]));
			}
			errorMessage = i18n.get(message, "", argumentsList.toArray());

		} else {
			errorMessage = getMessageFromResource(i18n, message);
		}
		return errorMessage;
	}

	/**
	 * set the locale
	 *
	 * @param language
	 * @return Locale
	 */
	private Locale setLocale(String language) {
		return new Locale(language);
	}

	/**
	 * get the message from resource
	 *
	 * @param i18n
	 * @param message
	 * @return String
	 */
	private String getMessageFromResource(I18n i18n, String message) {
		return i18n.get(message);
	}

	/**
	 * To check whether the provider is valid or has errors
	 * 
	 * @return valid
	 */
	public boolean isValid() {
		return valid;
	}

	@Override
	public void activate() throws Exception {
		process();

	}

	/**
	 * To get the Inherited property Value
	 * 
	 * @param currentPage
	 * @param propName
	 * @param defaultValue
	 * @return
	 */
	public Boolean getInheritedProperty(Page currentPage, String propName,
			Boolean defaultValue) {

		Boolean status = defaultValue;

		while (currentPage != null) {
			String propValue = currentPage.getProperties().get(propName, null);
			if (propValue == null) {
				propValue = GenericConstants.STATUS_INHERITED;
			}

			if (propValue.equalsIgnoreCase(GenericConstants.STATUS_INHERITED)) {
				currentPage = currentPage.getParent();
			} else if (propValue
					.equalsIgnoreCase(GenericConstants.STATUS_FALSE)) {
				status = Boolean.FALSE;
				break;
			} else {
				break;
			}
		}

		return status;
	}

}

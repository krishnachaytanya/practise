package com.wmt.intl.utils;

import javax.script.SimpleBindings;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.scripting.SlingScriptHelper;

import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.siteconfig.GlobalConfigProvider;

/**
 * Global Configuration Utility Class
 * 
 * @author vn93497
 *
 */
public class GlobalConfigUtil {
	// Use this class to get any global configuration details in Java class.
	// Individual configProvider class could be used in sightly directly.

	private static GlobalConfigProvider globalConfigProvider;

	/**
	 * To get the GlobalConfigProvider
	 * 
	 * @param res
	 * @return GlobalConfigProvider
	 */
	public static GlobalConfigProvider getProvider(Resource res) {

		globalConfigProvider = new GlobalConfigProvider();

		globalConfigProvider.init(getGlobalPageResouceBinding(res));

		return globalConfigProvider;
	}
	
	/**
	 * To get the GlobalConfigProvider with Resource and Sling binding.
	 * @param resource
	 * @param slingScriptHelper
	 * @return GlobalConfigProvider
	 */
	public static GlobalConfigProvider getProvider(Resource resource,
			SlingScriptHelper slingScriptHelper) {
		globalConfigProvider = new GlobalConfigProvider();

		SimpleBindings bindings = getGlobalPageResouceBinding(resource);
		
		bindings.put(SlingBindings.SLING, slingScriptHelper);
		
		globalConfigProvider.init(bindings);

		return globalConfigProvider;
	}

	/**
	 * To get the binding for global config page
	 * 
	 * @param resource
	 * @return SimpleBindings
	 */
	private static SimpleBindings getGlobalPageResouceBinding(Resource resource) {
		String globalConfPath = getGlobalConfigPath(resource.getPath());
		return IntlUtils.getBindingByPath(resource, globalConfPath);
	}

	/**
	 * To get the Global config path
	 * 
	 * @param resourcePath
	 * @return
	 */
	public static String getGlobalConfigPath(String resourcePath) {
		String globalConfPath = null;
		if (resourcePath != null) {
			globalConfPath = IntlUtils.getContentLocalePath(resourcePath)
					+ GlobalConfigConstants.GLOBAL_CONFIG_PAGE_PATH;
		}
		return globalConfPath;
	}
	

}

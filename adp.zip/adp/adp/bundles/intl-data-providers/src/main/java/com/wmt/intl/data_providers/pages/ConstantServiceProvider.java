package com.wmt.intl.data_providers.pages;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.service.ConstantsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by dcrajan on 11/20/2017.
 */
public class ConstantServiceProvider extends IntlBaseProvider {
    private static final Logger LOGGER = LoggerFactory
            .getLogger(ConstantServiceProvider.class);

    private String dtmUrl;

    @Override
    protected void process() {
        LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
        ConstantsService constantsService = getSlingScriptHelper().getService(ConstantsService.class);
        dtmUrl = constantsService.getDtmUrl();
        LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
    }
    public String getDtmUrl() { return dtmUrl; }
}

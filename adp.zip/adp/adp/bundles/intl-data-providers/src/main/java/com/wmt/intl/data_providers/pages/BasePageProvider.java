package com.wmt.intl.data_providers.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * Base Page Provider to get Page details.
 * 
 *
 */
public class BasePageProvider extends IntlBaseProvider {

	private String title;
	private String description;
	private Calendar date;
	private String pagePath;

	private String analyticSegmentId;

	final static String TITLE = "jcr:title";
	final static String DESCRIPTION = "jcr:description";
	final static String SEGMENT_TITLE = "segmentTitle";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wmt.intl.data_providers.IntlBaseProvider#process()
	 */
	@Override
	protected void process() {
		if (getCurrentPage() != null) {
			title = getCurrentPage().getContentResource().getValueMap()
					.get(TITLE, GenericConstants.EMPTY_STRING);
			description = getCurrentPage().getContentResource().getValueMap()
					.get(DESCRIPTION, GenericConstants.EMPTY_STRING);
			pagePath = getCurrentPage().getPath();

			if (StringUtils.isEmpty(title)) {
				addErrorMsg("Please enter page title");
			}

			date = IntlUtils.getBestDate(getCurrentPage());

			populateAnalyticSegment();
		}
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}

	/**
	 * To get Page path
	 * 
	 * @return
	 */
	public String getPagePath() {
		return pagePath;
	}

	/**
	 * To get analyticSegmentId
	 * 
	 * @return
	 */
	public String getAnalyticSegmentId() {
		return analyticSegmentId;
	}

	/**
	 * Populating Analytic's Segment
	 */
	private void populateAnalyticSegment() {
		List<String> segmentList = getSegmentList(getCurrentPage());
		analyticSegmentId = "";
		for (int i = 0; i < segmentList.size(); i++) {

			analyticSegmentId = analyticSegmentId + segmentList.get(i);
			if (i != segmentList.size() - 1) {
				analyticSegmentId = analyticSegmentId + "/";
			}
		}

	}

	/**
	 * 
	 * @param currentPage
	 */
	private List<String> getSegmentList(Page currentPage) {
		String localePath = IntlUtils.getContentLocalePath(currentPage
				.getPath());
		List<String> segmentList = new ArrayList<String>();
		while (currentPage != null) {
			if (currentPage.getPath().equalsIgnoreCase(localePath)) {

				currentPage = null;
			} else {
				String segment = currentPage.getProperties().get(SEGMENT_TITLE,
						GenericConstants.EMPTY_STRING);
				if (!StringUtils.isEmpty(segment)) {
					segmentList.add(segment);
				}

				currentPage = currentPage.getParent();
			}

		}

		Collections.reverse(segmentList);
		return segmentList;
	}
}

package com.wmt.intl.bean;

/**
 * ImageRenditionsBean for getting image renditions
 * 
 * @author vn67566
 *
 */
public class ImageRenditionsBean {
	private String extraSmallRendition;
	private String smallRendition;
	private String mediumRendition;
	private String largeRendition;
	private String original;

	/**
	 * To get extra small Rendition image
	 * 
	 * @return
	 */
	public String getExtraSmallRendition() {
		return extraSmallRendition;
	}

	/**
	 * Setting extraSmall Rendition
	 * 
	 * @param xSmallRendition
	 */
	public void setExtraSmallRendition(String xSmallRendition) {
		this.extraSmallRendition = xSmallRendition;
	}

	/**
	 * To get small Rendition image
	 * 
	 * @return
	 */
	public String getSmallRendition() {
		return smallRendition;
	}

	/**
	 * Setting small Rendition image
	 * 
	 * @param smallRendition
	 */
	public void setSmallRendition(String smallRendition) {
		this.smallRendition = smallRendition;
	}

	/**
	 * To get medium rendition image
	 * 
	 * @return
	 */
	public String getMediumRendition() {
		return mediumRendition;
	}

	/**
	 * Setting medium rendition image
	 * 
	 * @param mediumRendition
	 */
	public void setMediumRendition(String mediumRendition) {
		this.mediumRendition = mediumRendition;
	}

	/**
	 * To get large rendition
	 * 
	 * @return
	 */
	public String getLargeRendition() {
		return largeRendition;
	}

	/**
	 * Setting large rendition
	 * 
	 * @param largeRendition
	 */
	public void setLargeRendition(String largeRendition) {
		this.largeRendition = largeRendition;
	}

	/**
	 * To get Original Rendition
	 * 
	 * @return
	 */
	public String getOriginal() {
		return original;
	}

	/**
	 * Setting Original Rendition
	 * 
	 * @param original
	 */
	public void setOriginal(String original) {
		this.original = original;
	}
}

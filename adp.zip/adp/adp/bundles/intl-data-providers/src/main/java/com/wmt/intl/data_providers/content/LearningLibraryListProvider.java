package com.wmt.intl.data_providers.content;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.bean.LibraryBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.pages.LearningLibraryPageProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * LearningLibraryListProvider for LearningLibraryList
 * 
 * @author vn67566
 *
 */
public class LearningLibraryListProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LearningLibraryListProvider.class);

	private static final String TITLE = "title";
	private static final String LEARNING_LIBRARY_TEMPLATE = "/apps/intl/templates/learninglibrarytemplate";
	private static final String LIBRARY_HOME = "libraryHome";

	private String title;

	private List<LibraryBean> library;

	/**
	 * To get LibraryList
	 * 
	 * @return
	 */
	public List<LibraryBean> getLibrary() {
		return library;
	}

	/**
	 * To get Title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	@Override
	protected void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		populateLibraryList();

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * Populating Library List
	 */
	public void populateLibraryList() {
		if (getResource() != null) {
			String libraryHome = getProperties().get(LIBRARY_HOME,
					(String) null);
			title = getProperties().get(TITLE, (String) null);

			if (!(StringUtils.isEmpty(libraryHome))) {

				Page libraryHomepage = IntlUtils.getPage(getResource()
						.getResourceResolver(), libraryHome);

				if (libraryHomepage != null) {

					library = new ArrayList<LibraryBean>();

					populateLibrary(libraryHomepage);
					if (library.size() > 0) {
						sortList(library);

					} else {
						addErrorMsg("No Learning Libraries  found");
					}

				}

			} else {
				addErrorMsg("Please configure Library Home Page");
			}

		} else {
			addErrorMsg("LibraryList  config details not found");
		}

	}

	/**
	 * Populating Library Page
	 * 
	 * @param page
	 */
	private void populateLibrary(Page page) {
		Iterator<Page> rootPageIterator;

		rootPageIterator = page.listChildren();

		while (rootPageIterator.hasNext()) {

			Page childPage = rootPageIterator.next();

			String pageTemplate = childPage.getProperties().get("cq:template",
					GenericConstants.EMPTY_STRING);

			if (pageTemplate.equalsIgnoreCase(LEARNING_LIBRARY_TEMPLATE)) {
				LOGGER.info("page is created using LearningLibraryTemplate ");

				LearningLibraryPageProvider learningLibraryPageProvider = getLearningLibraryPageProvider(childPage);

				if (learningLibraryPageProvider.isValid()) {
					library.add(getLibraryBean(learningLibraryPageProvider));
				}

			}

			if (childPage.listChildren().hasNext()) {
				populateLibrary(childPage);

			}

		}
	}

	/**
	 * To get LearningLibraryPageProvider
	 * 
	 * @param page
	 * @return
	 */
	private LearningLibraryPageProvider getLearningLibraryPageProvider(Page page) {

		LearningLibraryPageProvider learningLibraryPageProvider = new LearningLibraryPageProvider();

		learningLibraryPageProvider.init(IntlUtils.getBindingForPage(page));

		return learningLibraryPageProvider;
	}

	/**
	 * To get Library Details
	 * 
	 * @param page
	 * @return
	 */
	private LibraryBean getLibraryBean(
			LearningLibraryPageProvider learningLibraryPageProvider) {

		LibraryBean libraryBean = new LibraryBean();

		libraryBean.setTitle(learningLibraryPageProvider
				.getLibraryThumbnailTitle());
		libraryBean.setLink(learningLibraryPageProvider.getPagePath());

		libraryBean.setPubDate(learningLibraryPageProvider.getDate());
		libraryBean.setLibraryImageRendition(learningLibraryPageProvider
				.getLibraryThumbnailRenditions());

		return libraryBean;
	}

	/**
	 * Sorting Library List
	 * 
	 * @param libraryList
	 * @return
	 */
	private List<LibraryBean> sortList(List<LibraryBean> libraryList) {
		Collections.sort(libraryList);
		return libraryList;
	}

}

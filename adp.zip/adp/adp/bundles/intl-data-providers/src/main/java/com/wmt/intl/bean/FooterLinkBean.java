package com.wmt.intl.bean;

/**
 * FooterLinkBean for FooterConfigProvider
 * 
 * @author vn67566
 *
 */
public class FooterLinkBean {
	/**
	 * footerText contains footer link text
	 */

	private String text;
	/**
	 * footerLink contains footer link page path
	 */

	private String link;

	/**
	 * getter method for getting FooterLink text
	 * 
	 * @return the footerText
	 */
	public String getText() {
		return text;
	}

	/**
	 * setter method for setting FooterLink text
	 * 
	 * @param text
	 * 
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * getter method for getting FooterLink link path
	 * 
	 * @return the footerLink
	 */
	public String getLink() {
		return link;
	}

	/**
	 * setter method for setting FooterLink link path
	 * 
	 * @param link
	 *            the footerLink to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

}

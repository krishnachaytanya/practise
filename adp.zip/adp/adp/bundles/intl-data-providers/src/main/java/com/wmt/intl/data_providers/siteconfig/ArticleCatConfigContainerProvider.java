/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.script.SimpleBindings;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

/**
 * Article Category Config Container Provider to get all the article category
 * config
 *
 */
public class ArticleCatConfigContainerProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ArticleCatConfigContainerProvider.class);

	private Map<String, ArticleCategoryConfigProvider> articleCatMap;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wmt.intl.data_providers.IntlBaseProvider#process()
	 */
	@Override
	protected void process() {
		LOGGER.info(GenericConstants.LOG_START_PROCESS_TXT);
		if (getResource() != null) {
			String articleCatConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.ARTICLE_CAT_PAR_PATH;

			if (articleCatConfigPath.equalsIgnoreCase(getResource().getPath())) {
				Iterable<Resource> resIter = getResource().getChildren();
				Iterator<Resource> it = resIter.iterator();

				articleCatMap = new HashMap<String, ArticleCategoryConfigProvider>();

				while (it.hasNext()) {
					Resource res = (Resource) it.next();

					if (IntlUtils.checkResource(res,
							JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
							GenericConstants.ARTICLE_CAT_CONFIG_TYPE)) {

						ArticleCategoryConfigProvider articleCatBean = getArticleCatConfigProv(res);

						articleCatMap.put(
								articleCatBean.getArticleCategoryTag(),
								articleCatBean);
					}

				}

				if (articleCatMap.isEmpty()) {
					addErrorMsg("No category configuration retrieved");
				}

			} else {
				addErrorMsg("Please use GlobalConfigProvider to get article category Config");
			}

		} else {
			addErrorMsg("Please configure global article category component.");
		}
		LOGGER.info(GenericConstants.LOG_END_PROCESS_TXT);
	}

	private ArticleCategoryConfigProvider getArticleCatConfigProv(Resource res) {
		ArticleCategoryConfigProvider provider = new ArticleCategoryConfigProvider();

		SimpleBindings bindings = new SimpleBindings();

		bindings.put(SlingBindings.RESOURCE, res);
		bindings.put(SlingBindings.SLING, getSlingScriptHelper());

		provider.init(bindings);

		return provider;
	}

	/**
	 * To get article category Map.
	 * 
	 * @return the articleCatMap
	 */
	public Map<String, ArticleCategoryConfigProvider> getArticleCatMap() {
		return articleCatMap;
	}

}

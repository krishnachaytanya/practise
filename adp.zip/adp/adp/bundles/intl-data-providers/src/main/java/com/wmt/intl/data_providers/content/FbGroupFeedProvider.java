package com.wmt.intl.data_providers.content;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

/**
 * Facebook provider class for facebook feeder component
 * Created by dcrajan on 10/10/2017.
 */
public class FbGroupFeedProvider extends IntlBaseProvider {

    final static String ERROR_MESSAGE_CONFIGURATION = "Please provide Facebook configuration details";
    final static String ERROR_MESSAGE_GROUPID = "Please configure Facebook Group ID";
    final static String ERROR_MESSAGE_AUTHKEY = "Please configure Authentication Key";
    final static String ERROR_MESSAGE_LIMIT = "Please configure Facebook Feed limit";

    final static String PROPERTY_GROUP_ID = "groupId";
    final static String PROPERTY_AUTH_KEY = "authKey";
    final static String PROPERTY_FEED_LIMIT = "feedLimit";

    private String groupId;
    private String authKey;
    private String feedLimit;
    private String resourcePath;

    public String getResourcePath() {
        return getResource().getPath();
    }
    public String getGroupId() {
        return groupId;
    }
    public String getAuthKey() {
        return authKey;
    }
    public String getFeedLimit() {
        return feedLimit;
    }

    private static final Logger LOGGER = LoggerFactory
            .getLogger(FbGroupFeedProvider.class);


    /**
     * Process method
     */
    @Override
    public void process() {
        LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

        if (getResource() == null) {
            addErrorMsg(ERROR_MESSAGE_CONFIGURATION);
            return;
        }

        ValueMap valueMap = getResource().getValueMap();

        groupId = valueMap.get(PROPERTY_GROUP_ID, (String) null);
        if(StringUtils.isEmpty(groupId)){
            addErrorMsg(ERROR_MESSAGE_GROUPID);
        }

        authKey =  valueMap.get(PROPERTY_AUTH_KEY, (String) null);
        if(StringUtils.isEmpty(authKey)){
            addErrorMsg(ERROR_MESSAGE_AUTHKEY);
        }

        feedLimit =  valueMap.get(PROPERTY_FEED_LIMIT, (String) null);
        if(StringUtils.isEmpty(feedLimit)){
            addErrorMsg(ERROR_MESSAGE_LIMIT);
        }

        LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
    }
}

/**
 * 
 */
package com.wmt.intl.data_providers.pages;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;

import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.utils.IntlUtils;

/**
 * Provider to get Article page details.
 *
 */
public class ArticlePageProvider extends BasePageProvider {

	private ImageRenditionsBean articleImageRenditions;
	private String quickLinkImageRef;
	private String quickLinkTitle;
	private Boolean showInQuickLink;
	private List<String> articleTypeList;
	private List<String> articleCatList;

	final static String ARTICLE_IMAGE_REF = "articleImageRef";
	final static String ARTICLE_QUICKLINK_IMAGE_REF = "quickLinkImageRef";
	final static String ARTICLE_QUICKLINK_TITLE = "quickLinkTitle";
	final static String ARTICLE_SHOW_IN_QUICKLINK = "showInQuickLink";
	final static String ARTICLE_TYPE_TAGS = "articleTypeTags";
	final static String ARTICLE_CAT_TAGS = "articleCatTags";

	@Override
	protected void process() {
		if (getCurrentPage() != null) {
			super.process();

			ValueMap valueMap = getCurrentPage().getContentResource()
					.getValueMap();

			String articleImageRef;
			String quickImageRef;

			articleImageRef = valueMap.get(ARTICLE_IMAGE_REF,
					GenericConstants.EMPTY_STRING);

			showInQuickLink = valueMap.get(ARTICLE_SHOW_IN_QUICKLINK,
					Boolean.FALSE);

			if (!StringUtils.isEmpty(articleImageRef)) {
				articleImageRenditions = IntlUtils.getImageRendition(
						getCurrentPage().getContentResource(), articleImageRef);
			}

			String[] articleTypeArr = valueMap.get(ARTICLE_TYPE_TAGS,
					new String[] {});

			String[] articleCatArr = valueMap.get(ARTICLE_CAT_TAGS,
					new String[] {});

			articleTypeList = Arrays.asList(articleTypeArr);
			articleCatList = Arrays.asList(articleCatArr);

			if (showInQuickLink) {
				quickImageRef = valueMap.get(ARTICLE_QUICKLINK_IMAGE_REF,
						GenericConstants.EMPTY_STRING);

				quickLinkTitle = valueMap.get(ARTICLE_QUICKLINK_TITLE,
						GenericConstants.EMPTY_STRING);

				// Use page title if quick link title not present.
				if (StringUtils.isEmpty(quickLinkTitle)) {
					quickLinkTitle = getTitle();
				}

				// Use Article Image if Quick link image is not present.
				if (StringUtils.isEmpty(quickImageRef)
						&& articleImageRenditions != null) {
					quickLinkImageRef = articleImageRenditions
							.getExtraSmallRendition();
				} else {
					String extraSmallRendition = IntlUtils.getImageRendition(
							getCurrentPage().getContentResource(),
							quickImageRef).getExtraSmallRendition();

					quickLinkImageRef = extraSmallRendition;
				}

			}
		} else {
			addErrorMsg("Article page not found");
		}

	}

	/**
	 * @return the imageRenditionsBean
	 */
	public ImageRenditionsBean getArticleImageRenditions() {
		return articleImageRenditions;
	}

	/**
	 * @return the quickLinkImageRef
	 */
	public String getQuickLinkImageRef() {
		return quickLinkImageRef;
	}

	/**
	 * @return the quickLinkTitle
	 */
	public String getQuickLinkTitle() {
		return quickLinkTitle;
	}

	/**
	 * @return the showInQuickLink
	 */
	public Boolean isShowInQuickLink() {
		return showInQuickLink;
	}

	/**
	 * @return the articleTypeList
	 */
	public List<String> getArticleTypeList() {
		return articleTypeList;
	}

	/**
	 * @return the articleCatList
	 */
	public List<String> getArticleCatList() {
		return articleCatList;
	}

}
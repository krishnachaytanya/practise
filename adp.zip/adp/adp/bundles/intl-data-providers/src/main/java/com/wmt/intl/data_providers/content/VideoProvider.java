package com.wmt.intl.data_providers.content;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;

/**
 * VideoProvider for Video component
 * 
 * @author vn67566
 *
 */
public class VideoProvider extends IntlBaseProvider {
	private static String TITLE = "title";

	private static String VIDEO_ID = "videoID";
	private static String AUTOPLAY = "autoplay";
	private static String ACCOUNT_ID = "accountId";
	private static String PLAYER_ID = "playerId";
	private static String DEFAULT_ACCOUNT_ID = "4863540640001";
	private static String DEFAULT_PLAYER_ID = "default";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(VideoProvider.class);

	private String title;

	private String videoID;
	private Boolean autoplay;
	private String  accountId;
	private String playerId;

	/**
	 * To get video title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To get video src
	 * 
	 * @return
	 */
	public String getVideoID() {
		return videoID;
	}

	/**
	 * To get video auto play enable / disable
	 * 
	 * @return
	 */
	public Boolean getAutoplay() {
		return autoplay;
	}


	public String getPlayerId() {
		return playerId;
	}

	public String getAccountId() {
		return accountId;
	}

	@Override
	protected void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		// To populate video component details
		populateVideo();
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * Populating video component
	 */
	private void populateVideo() {

		ValueMap valueMap = getProperties();

		title = valueMap.get(TITLE, (String) null);

		videoID = valueMap.get(VIDEO_ID, (String) null);
		autoplay = valueMap.get(AUTOPLAY, (Boolean) false);
		accountId = valueMap.get(ACCOUNT_ID, (String) null);
		playerId = valueMap.get(PLAYER_ID, (String) null);

		if (StringUtils.isEmpty(title)) {
			addErrorMsg("Please configure video title");
		}

		if (StringUtils.isEmpty(videoID)) {
			addErrorMsg("Please configure video ID");
		}
		if (StringUtils.isEmpty(accountId)) {
			accountId = DEFAULT_ACCOUNT_ID;
		}

		if (StringUtils.isEmpty(playerId)) {
			playerId = DEFAULT_PLAYER_ID;
		}
	}
}

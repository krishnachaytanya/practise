package com.wmt.intl.data_providers.content;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * ImageProvider for Image component
 * 
 * @author vn67566
 *
 */
public class ImageProvider extends IntlBaseProvider {

	final static String TITLE = "title";
	final static String LINK = "link";
	final static String IMAGE_FILE_REFERENCE = "imageFileReference";
	final static String ALT_TEXT = "alttext";
	final static String DESCRIPTION = "description";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ImageProvider.class);
	private ImageRenditionsBean imageRenditionsBean = null;
	private String title;
	private String altText;
	private String link;
	private String description;

	/**
	 * To get image Description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * To get image title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To get Alt Text
	 * 
	 * @return
	 */
	public String getAltText() {
		return altText;
	}

	/**
	 * To get image link
	 * 
	 * @return
	 */
	public String getLink() {
		return link;
	}

	public ImageRenditionsBean getImageRenditionsBean() {
		return imageRenditionsBean;
	}

	@Override
	protected void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		// To populate Image component details
		populateImage();
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);

	}

	/**
	 * To populate the image component details
	 */
	private void populateImage() {
		if (getResource() != null) {
			ValueMap valueMap = getProperties();
			String imageFileReference;
			title = valueMap.get(TITLE, (String) null);
			imageFileReference = valueMap.get(IMAGE_FILE_REFERENCE,
					(String) null);
			altText = valueMap.get(ALT_TEXT, (String) null);
			link = valueMap.get(LINK, (String) null);
			description = valueMap.get(DESCRIPTION, (String) null);

			if (!(StringUtils.isEmpty(imageFileReference))) {

				imageRenditionsBean = IntlUtils.getImageRendition(
						getResource(), imageFileReference);

			} else {
				addErrorMsg("Please configure Image");
			}

			if (StringUtils.isEmpty(altText)) {
				addErrorMsg("Please configure Alt Text");
			}
			if (!(StringUtils.isEmpty(link))) {
				link = IntlUtils.addExtension(link);

			}

		} else {

			addErrorMsg("Image Configuration details not found");
		}

	}

}

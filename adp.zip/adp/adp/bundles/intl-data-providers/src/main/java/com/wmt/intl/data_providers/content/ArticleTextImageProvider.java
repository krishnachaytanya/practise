package com.wmt.intl.data_providers.content;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.dam.api.Asset;
import com.wmt.intl.data_providers.IntlBaseProvider;

/**
 * Provider for ArticleTextImage component
 */
public class ArticleTextImageProvider extends IntlBaseProvider {

	private String imagePath;
	private String imageSize;
	private String layout;

	final static String PROPERTY_LAYOUT= "layout";
	final static String PROPERTY_IMAGE_SIZE= "imageSize";

	final static String ERROR_MESSAGE_IMAGE_SIZE = "Please configure Image size";
	final static String ERROR_MESSAGE_LAYOUT = "Please configure Layout";
	final static String ERROR_MESSAGE_IMAGE_PATH = "Please configure Image path";

	public String getLayout() {
		return layout;
	}
	public String getImageSize() {
		return imageSize;
	}

	@Override
	protected void process() {
		imagePath = getImagePath(getResource());
		if(StringUtils.isEmpty(imagePath)){
			addErrorMsg(ERROR_MESSAGE_IMAGE_PATH);
		}

		ValueMap valueMap = getResource().getValueMap();
		imageSize = valueMap.get(PROPERTY_IMAGE_SIZE, (String) null);
		if(StringUtils.isEmpty(imageSize)){
			addErrorMsg(ERROR_MESSAGE_IMAGE_SIZE);
		}

		layout =  valueMap.get(PROPERTY_LAYOUT, (String) null);
		if(StringUtils.isEmpty(layout)){
			addErrorMsg(ERROR_MESSAGE_LAYOUT);
		}
	}

	/**
	 * To get the image path
	 * 
	 * @param resource
	 * @return
	 */
	public static String getImagePath(Resource resource) {
		if (resource == null) {
			return "";
		}

		String imagePath = "";
		ValueMap properties = resource.getValueMap();
		String fileReference = properties.get("fileReference", "");
		if (!fileReference.isEmpty()) {
			ResourceResolver resourceResolver = resource.getResourceResolver();
			Resource referencedResource = resourceResolver
					.getResource(fileReference);
			if (referencedResource != null) {
				String resourceType = referencedResource.getResourceType();
				if ("dam:Asset".equals(resourceType)) {
					if (fileReference.endsWith(".svg")) {
						imagePath = fileReference;
					} else {
						imagePath = resource.getPath()
								+ ".img."
								+ getFileExtension(fileReference,
										resourceResolver);
					}
				} else if ("nt:file".equals(resourceType)) {
					imagePath = fileReference;
				}
			}
		}
		return imagePath;
	}

	public static String getFileExtension(String fileReference,
			ResourceResolver resourceResolver) {
		String extension = "jpeg";
		Resource assetResource = resourceResolver.getResource(fileReference);
		if (assetResource != null) {
			Asset asset = assetResource.adaptTo(Asset.class);
			if (asset != null) {
				String metadataValue = asset.getMetadataValue("dam:Fileformat");
				if (metadataValue != null) {
					extension = metadataValue;
				}
			}
		}
		return extension.toLowerCase();
	}

	public String getImagePath() {
		return imagePath;
	}

}

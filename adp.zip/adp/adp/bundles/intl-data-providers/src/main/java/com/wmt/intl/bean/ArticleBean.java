package com.wmt.intl.bean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Comparator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;

/**
 * Article Bean used for listing articles.
 * 
 *
 */
public class ArticleBean implements Comparable<ArticleBean> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ArticleBean.class);

	private String title;
	private String description;
	private ImageRenditionsBean articleImageRendition;
	private String pubDate;
	private String link;

	/**
	 * To get published date
	 * 
	 * @return
	 */
	public String getPubDate() {
		return pubDate;
	}

	/**
	 * To set published date
	 * 
	 * @param date
	 */
	public void setPubDate(String date) {
		this.pubDate = date;
	}

	/**
	 * To get the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To set the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * To get the description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * To set the title
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the articleImageRendition
	 */
	public ImageRenditionsBean getArticleImageRendition() {
		return articleImageRendition;
	}

	/**
	 * @param articleImageRendition the articleImageRendition to set
	 */
	public void setArticleImageRendition(ImageRenditionsBean articleImageRendition) {
		this.articleImageRendition = articleImageRendition;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public int compareTo(ArticleBean articleTo) {
		return Comparators.DATE_DESC.compare(this, articleTo);
	}

	static class Comparators {

		private static int compareInternal(String dateA, String dateB,
				Boolean isDescending) {
			int order = 1;
			DateFormat dateFormat = new SimpleDateFormat(
					GenericConstants.DATE_FORMAT_D_MMMMM_YYYY);
			if ((dateA == null || dateA.isEmpty())
					&& (dateB == null || dateB.isEmpty())) {
				return 0;
			}
			if (dateA == null || dateA.isEmpty()) {
				return 1;
			}
			if (dateB == null || dateB.isEmpty()) {
				return -1;
			}
			try {
				order = dateFormat.parse(dateB).compareTo(
						dateFormat.parse(dateA));
				if (!isDescending) {
					order = order * -1;
				}
			} catch (java.text.ParseException parseExcep) {
				LOGGER.error("Date parse exception ", parseExcep);
			}
			return order;
		}

		public static Comparator<ArticleBean> DATE = new Comparator<ArticleBean>() {
			@Override
			public int compare(ArticleBean itemA, ArticleBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						false);
			}
		};

		public static Comparator<ArticleBean> DATE_DESC = new Comparator<ArticleBean>() {
			@Override
			public int compare(ArticleBean itemA, ArticleBean itemB) {
				return compareInternal(itemA.getPubDate(), itemB.getPubDate(),
						true);
			}
		};
	}

}
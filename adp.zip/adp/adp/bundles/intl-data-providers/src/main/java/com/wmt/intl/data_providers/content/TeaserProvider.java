package com.wmt.intl.data_providers.content;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * TeaserProvider for Teaser component
 * 
 * @author vn67566
 *
 */
public class TeaserProvider extends IntlBaseProvider {

	final static String TITLE = "teaserTitle";
	final static String LINK = "teaserLink";
	final static String IMAGE_REF = "teaserImageRef";
	final static String ALT_TEXT = "teaserAltText";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TeaserProvider.class);

	private String title;
	private String imageRef;
	private String altText;
	private String link;
	private ImageRenditionsBean imageRenditionsBean;

	/**
	 * To get Title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To get Alternative Text
	 * 
	 * @return
	 */
	public String getAltText() {
		return altText;
	}

	/**
	 * To get Teaser Link
	 * 
	 * @return
	 */
	public String getLink() {
		return link;
	}

	public ImageRenditionsBean getImageRenditionsBean() {
		return imageRenditionsBean;
	}

	

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		// To populate Teaser component details
		populateTeaser();
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * populating Teaser component
	 */
	private void populateTeaser() {

		if (getResource() != null) {
			ValueMap valueMap = getResource().getValueMap();

			title = valueMap.get(TITLE, (String) null);
			imageRef = valueMap.get(IMAGE_REF, (String) null);
			
			altText = valueMap.get(ALT_TEXT, (String) null);
			link = valueMap.get(LINK, (String) null);

			if (StringUtils.isEmpty(title)) {
				addErrorMsg("Please configure Teaser Title");
			}
			if (!(StringUtils.isEmpty(imageRef))) {
				imageRenditionsBean=IntlUtils.getImageRendition(getResource(), imageRef);
				
			}
			else
			{
				addErrorMsg("Please configure Teaser Image");
			}
			if (StringUtils.isEmpty(altText)) {
				addErrorMsg("Please configure Teaser altText");
			}
			if (StringUtils.isEmpty(link)) {
				addErrorMsg("Please configure Teaser link");
			}

		} else {

			addErrorMsg("Teaser Configuration details not found");
		}

	}
}

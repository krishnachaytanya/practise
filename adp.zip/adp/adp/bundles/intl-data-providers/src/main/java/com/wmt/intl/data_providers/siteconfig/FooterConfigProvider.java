package com.wmt.intl.data_providers.siteconfig;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.wmt.intl.bean.FooterLinkBean;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

/**
 * Footer config Provider to get all the configuration details for Footer
 * component
 * 
 * @author vn67566
 */
public class FooterConfigProvider extends IntlBaseProvider {

	private final String COPYRIGHT_PROPERTY = "copyRight";
	private final String LINKS_PROPERTY = "links";

	private List<FooterLinkBean> footerLinkBeanList;
	private String copyRightText;

	/**
	 * getCopyRightText method for getting global configurable footer copyRight
	 * text
	 * 
	 * @return
	 */
	public String getCopyRightText() {
		return copyRightText;
	}

	/**
	 * getFooterLinkBeanList method for getting global configure footerLinkBean
	 * List
	 * 
	 * @return
	 */

	public List<FooterLinkBean> getFooterLinkBeanList() {
		return footerLinkBeanList;
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(FooterConfigProvider.class);

	@Override
	public void process() {

		// populating footer copy right text and footer links
		populateFooterDetails();
	}

	/**
	 * To populate the Footer details based on the value array
	 */
	private void populateFooterDetails() {
		LOGGER.info("START: populateFooterLinksList method");
		if (getResource() != null) {
			String footerConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.FOOTER_PAGE;

			if (footerConfigPath.equalsIgnoreCase(getResource().getPath())) {
				ValueMap valueMap = getResource().getValueMap();
				copyRightText = valueMap.get(COPYRIGHT_PROPERTY, (String) null);
				if (copyRightText == null) {

					addErrorMsg("Please configure global footer copyrightText");
				}

				String[] valueArr = getResource().getValueMap().get(
						LINKS_PROPERTY, new String[] {});

				if (valueArr.length != 0) {

					footerLinkBeanList = new ArrayList<FooterLinkBean>();

					for (int index = 0; index < valueArr.length; index++) {
						FooterLinkBean footerLinkBean = getBeanListFromJson(valueArr[index]);

						if (StringUtils.isEmpty(footerLinkBean.getLink())) {
							addErrorMsg("Please configure footer link -{0}"
									,Integer.toString(index + 1));
						} else {
							footerLinkBean.setLink(IntlUtils
									.addExtension(footerLinkBean.getLink()));
						}
						if (StringUtils.isEmpty(footerLinkBean.getText())) {
							addErrorMsg("Please configure footer link title -{0}"
									,Integer.toString(index + 1));
						}

						footerLinkBeanList.add(footerLinkBean);
					}

				} else {
					addErrorMsg("Please configure global footer links");
				}
			} else {
				addErrorMsg("Please use GlobalConfigProvider to get footer Config");
			}

		} else {
			addErrorMsg("Please configure global footer configuration component.");
		}

	}

	/**
	 * To get the bean list from json
	 * 
	 * @param json
	 * @return
	 */
	private FooterLinkBean getBeanListFromJson(String json) {
		Type type = new TypeToken<FooterLinkBean>() {
		}.getType();
		Gson gson = new GsonBuilder().create();
		FooterLinkBean footerLink = gson.fromJson(json, type);
		return footerLink;
	}

}

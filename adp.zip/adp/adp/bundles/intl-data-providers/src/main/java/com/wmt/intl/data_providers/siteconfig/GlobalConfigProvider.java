/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;
import org.apache.sling.api.scripting.SlingBindings;

import javax.script.SimpleBindings;

/**
 * Global Config Provider used to get all the global configurations.
 * 
 * @author vn93497
 *
 */
public class GlobalConfigProvider extends IntlBaseProvider {

	private LogoConfigProvider logoConfig;

	private QuickLinkConfigContainerProvider quickLinkConfig;

	private FooterConfigProvider footerConfig;

	private TimeZoneConfigProvider timeZoneConfig;

	private ArticleCatConfigContainerProvider artlCatConfigProvider;

	private TrendingPageConfigProvider trendingPageConfigProvider;

	private ProxyConfigProvider proxyConfigProvider;

	/**
	 * To get Logo Config Provider
	 * 
	 * @return LogoConfigProvider
	 */
	public LogoConfigProvider getLogoConfig() {

		SimpleBindings logoBinding = IntlUtils.getBindingByPath(getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.LOGO_PATH);

		logoConfig = new LogoConfigProvider();
		logoBinding.put(SlingBindings.SLING, getSlingScriptHelper());
		logoBinding.put(SlingBindings.REQUEST, getRequest());
		logoConfig.init(logoBinding);

		return logoConfig;
	}

	/**
	 * To get Footer Config Provider
	 * 
	 * @return
	 */
	public FooterConfigProvider getFooterConfig() {
		SimpleBindings footerBinding = IntlUtils.getBindingByPath(
				getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.FOOTER_PAGE);

		footerConfig = new FooterConfigProvider();
		footerBinding.put(SlingBindings.SLING, getSlingScriptHelper());
		footerBinding.put(SlingBindings.REQUEST, getRequest());
		footerConfig.init(footerBinding);

		return footerConfig;
	}

	/**
	 * To get Quick Link Config Provider
	 * 
	 * @return QuickLinkConfigProvider
	 */
	public QuickLinkConfigContainerProvider getQuickLinkConfig() {

		SimpleBindings quickLilnkBinding = IntlUtils.getBindingByPath(
				getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.QUICK_LINK_PAR_PATH);

		quickLinkConfig = new QuickLinkConfigContainerProvider();

		quickLinkConfig.init(quickLilnkBinding);

		return quickLinkConfig;
	}

	/**
	 * To get timezone config provider
	 * 
	 * @return TimeZoneConfigProvider
	 */
	public TimeZoneConfigProvider getTimeZoneConfig() {
		SimpleBindings timezoneBinding = IntlUtils.getBindingByPath(
				getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.TIMEZONE_CONFIG_PATH);

		timeZoneConfig = new TimeZoneConfigProvider();

		timeZoneConfig.init(timezoneBinding);
		return timeZoneConfig;
	}

	/**
	 * To get article category config provider
	 * 
	 * @return the artlCatConfigProvider
	 */
	public ArticleCatConfigContainerProvider getArtlCatConfigProvider() {

		SimpleBindings articleCatBinding = IntlUtils.getBindingByPath(
				getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.ARTICLE_CAT_PAR_PATH);

		artlCatConfigProvider = new ArticleCatConfigContainerProvider();

		articleCatBinding.put(SlingBindings.SLING, getSlingScriptHelper());

		artlCatConfigProvider.init(articleCatBinding);

		return artlCatConfigProvider;
	}

	/**
	 * To get Trending Page Config Provider
	 *
	 * @return TrendingPageConfigProvider
	 */
	public TrendingPageConfigProvider getTrendingPageConfig() {

		SimpleBindings trendingPageBinding = IntlUtils.getBindingByPath(getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.TRENDING_PAGE_PATH);

		trendingPageConfigProvider = new TrendingPageConfigProvider();

		trendingPageConfigProvider.init(trendingPageBinding);

		return trendingPageConfigProvider;
	}

	/**
	 * To get Trending Page Config Provider
	 *
	 * @return ProxyConfigProvider
	 */
	public ProxyConfigProvider getProxyConfig() {

		SimpleBindings proxyBinding = IntlUtils.getBindingByPath(getResource(),
				GlobalConfigUtil.getGlobalConfigPath(getResource().getPath())
						+ GlobalConfigConstants.PROXY_CONFIG_PATH);

		proxyConfigProvider = new ProxyConfigProvider();

		proxyConfigProvider.init(proxyBinding);

		return proxyConfigProvider;
	}
	@Override
	protected void process() {
		// TODO Auto-generated method stub

	}

}

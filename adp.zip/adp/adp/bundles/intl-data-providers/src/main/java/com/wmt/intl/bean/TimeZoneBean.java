package com.wmt.intl.bean;

/**
 * Bean for Timezone component
 *
 */
public class TimeZoneBean {
	/**
	 * City Name
	 */
	private String city;
	/**
	 * Time zone
	 */
	private String timezone;
	/**
	 * Time
	 */
	private String time;

	/**
	 * To get city
	 * 
	 * @return
	 */
	public String getCity() {
		return city;
	}

	/**
	 * To set city
	 * 
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * To get timezone
	 * 
	 * @return
	 */
	public String getTimezone() {
		return timezone;
	}

	/**
	 * To set timezone
	 * 
	 * @param timezone
	 */
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	/**
	 * To get time
	 * 
	 * @return
	 */
	public String getTime() {
		return time;
	}

	/**
	 * To set time
	 * 
	 * @param time
	 */
	public void setTime(String time) {
		this.time = time;
	}
}

package com.wmt.intl.utils;

import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import javax.script.SimpleBindings;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.asset.api.Asset;
import com.adobe.granite.asset.api.AssetManager;
import com.adobe.granite.asset.api.Rendition;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.intl.bean.ImageRenditionsBean;
import com.wmt.intl.constants.GenericConstants;

/**
 * Icputils class for intl-applicaton
 * 
 * @author vn67566
 */
/**
 * @author vn82178
 *
 */
/**
 * @author vn82178
 *
 */
public class IntlUtils {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(IntlUtils.class);

	/**
	 * To get the content path with locale root folder
	 * 
	 * @param path
	 * @return
	 */
	public static String getContentLocalePath(String path) {
		String localePath = null;
		if (path != null) {
			int index = StringUtils.ordinalIndexOf(path,
					GenericConstants.FORWARD_SLASH,
					GenericConstants.LOCALE_FOLDER_INDEX + 1);
			localePath = path.substring(0, index);
		}

		return localePath;
	}

	/**
	 * To get the Home Page path
	 * 
	 * @param path
	 * @return String
	 */
	public static String getHomePagePath(String path) {
		String homePagePath = null;
		String localePagePath = getContentLocalePath(path);

		if (localePagePath != null) {
			homePagePath = localePagePath + GenericConstants.FORWARD_SLASH
					+ GenericConstants.HOME_PAGE_NAME;
		}

		return homePagePath;
	}

	/**
	 * To get the binding based on the path
	 * 
	 * @param resource
	 * @param path
	 * @return SimpleBindings
	 */
	public static SimpleBindings getBindingByPath(Resource resource, String path) {

		LOGGER.debug("Resource path to get binding" + path);

		SimpleBindings binding = new SimpleBindings();

		binding.put("resource", resource.getResourceResolver()
				.getResource(path));

		LOGGER.debug("Setting Binding");

		return binding;
	}

	/**
	 * To get the binding based on resource resolver and page path
	 * 
	 * @param resourceResolver
	 * @param pagePath
	 * @return
	 */
	public static SimpleBindings getBindingForPage(
			ResourceResolver resourceResolver, String pagePath) {
		SimpleBindings binding = null;
		if (resourceResolver != null && !StringUtils.isEmpty(pagePath)) {
			binding = getBindingForPage(getPage(resourceResolver, pagePath));
		}

		return binding;
	}

	/**
	 * To get the binding based on the page
	 * 
	 * @param resource
	 * @param path
	 * @return SimpleBindings
	 */
	public static SimpleBindings getBindingForPage(Page page) {

		LOGGER.debug("Resource path to get binding");

		SimpleBindings binding = new SimpleBindings();

		binding.put("currentPage", page);

		LOGGER.debug("Setting Binding");

		return binding;
	}

	/**
	 * To get Page object from page path
	 * 
	 * @param resourceResolver
	 * @param pagePath
	 * @return
	 */
	public static Page getPage(ResourceResolver resourceResolver,
			String pagePath) {
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

		Page page = pageManager.getPage(pagePath);
		return page;
	}

	/**
	 * To add link extension
	 * 
	 * @param link
	 * @return
	 */
	public static String addExtension(String link) {

		if (link.contains(".") || link.contains("?") || link.contains("#")) {
			return link;
		} else {
			return link + GenericConstants.FILE_EXTENSION_HTML;
		}

	}

	/**
	 * To get Image Renditions
	 * 
	 * @param resource
	 * @param imageFileReference
	 * @return
	 */
	public static ImageRenditionsBean getImageRendition(Resource resource,
			String imageFileReference) {
		ImageRenditionsBean imageRenditions = new ImageRenditionsBean();
		AssetManager assetManager = resource.getResourceResolver().adaptTo(
				AssetManager.class);
		Asset asset = assetManager.getAsset(imageFileReference);
		if (asset != null) {
			Iterator<? extends Rendition> list = asset.listRenditions();
			while (list.hasNext()) {
				String rendition_319 = GenericConstants.EMPTY_STRING;
				Rendition ren = list.next();
				if (!(ren.getName().toString().equalsIgnoreCase("original"))) {
					String rendition = ren.getName();
					if (rendition.contains("140.100")) {
						imageRenditions.setExtraSmallRendition(ren.getPath());
					} else if (rendition.contains("375.375")) {
						imageRenditions.setSmallRendition(ren.getPath());
					} else if (rendition.contains("750.750")) {
						imageRenditions.setMediumRendition(ren.getPath());
					} else if (rendition.contains("1280.1280")) {
						imageRenditions.setLargeRendition(ren.getPath());
					}
					/*
					 * Workaround for image rendition workflow Code will be
					 * removed once workflow for all images are run in
					 * production
					 */
					else if (rendition.contains("319.319")) {
						rendition_319 = ren.getPath();
					}

				}

				if (StringUtils.isEmpty(imageRenditions.getSmallRendition())) {
					imageRenditions.setSmallRendition(rendition_319);
				}
				if (StringUtils.isEmpty(imageRenditions.getMediumRendition())) {
					imageRenditions.setMediumRendition(rendition_319);
				}
			}
		} else {
			LOGGER.info("Asset not found");
		}

		imageRenditions.setOriginal(imageFileReference);
		return imageRenditions;
	}

	/**
	 * Gets a date off of the page. publishDate -> cq:lastReplicated ->
	 * jcr:created
	 * 
	 * @param page
	 *            the Page we want a date from
	 * @return Calendar of the best fitting date
	 */
	public static Calendar getBestDate(Page page) {
		ValueMap properties = page.getContentResource().getValueMap();
		if (properties.containsKey("publishDate")) {
			return properties.get("publishDate", Calendar.class);
		}

		if (properties.containsKey("cq:lastReplicated")) {
			return properties.get("cq:lastReplicated", Calendar.class);
		}

		return properties.get("jcr:created", Calendar.class);
	}

	public static String getFormattedDate(Calendar calendar) {
		return getFormattedDate(calendar, GenericConstants.DEFAULT_DATE_FORMAT);
	}

	public static String getFormattedDate(Calendar calendar, String format) {
		String formattedDate = "";
		if (calendar != null) {
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			formattedDate = formatter.format(calendar.getTime());
		}

		return formattedDate;
	}

	/**
	 * To escape characters for JSON String
	 * 
	 * @param aText
	 * @return
	 */
	public static String escapeJson(String aText) {
		final StringBuilder result = new StringBuilder();
		StringCharacterIterator iterator = new StringCharacterIterator(aText);
		char character = iterator.current();
		while (character != StringCharacterIterator.DONE) {
			if (character == '\"') {
				result.append("\\\"");
			} else if (character == '\\') {
				result.append("\\\\");
			} else if (character == '/') {
				result.append("\\/");
			} else if (character == '\b') {
				result.append("\\b");
			} else if (character == '\f') {
				result.append("\\f");
			} else if (character == '\n') {
				result.append("\\n");
			} else if (character == '\r') {
				result.append("\\r");
			} else if (character == '\t') {
				result.append("\\t");
			} else {
				// the char is not a special one
				// add it to the result as is
				result.append(character);
			}
			character = iterator.next();
		}
		return result.toString();
	}

	/**
	 * To check whether the resource name in the object(Page or Resource)
	 * matches with the expected value.
	 * 
	 * @param obj
	 *            - Resource or Page.
	 * @param resourceName
	 *            - Name of the resource property.
	 * @param expectedResourceValue
	 *            - Expected value for the resource property.
	 * @return flag - boolean
	 */
	public static boolean checkResource(Object obj, String resourceName,
			String expectedResourceValue) {
		boolean flag = false;
		String actualResourceValue = null;
		if (obj != null) {
			if (obj instanceof Resource) {
				actualResourceValue = ((Resource) obj).getValueMap().get(
						resourceName, (String) null);

			} else if (obj instanceof Page) {
				actualResourceValue = ((Page) obj).getProperties().get(
						resourceName, (String) null);
			}
			if (actualResourceValue != null && expectedResourceValue != null) {
				flag = expectedResourceValue.equals(actualResourceValue);
			}
		}

		return flag;
	}

	/**
	 * Get Resource path from the dilog's RequestURI
	 * 
	 * @param dialogRequestURI
	 *            example:
	 *            /mnt/override/apps/intl/components/content/quicklinks/
	 *            _cq_dialog.html/content/icp/en_us/Home/jcr:content/par/
	 *            quicklinks_332158314
	 * @param componentDialogPath
	 *            example:
	 *            /apps/intl/components/content/quicklinks/_cq_dialog.html
	 * @return resource path output based on above parameter values:
	 *         /content/icp/en_us/Home/jcr:content/par/quicklinks_332158314
	 */
	public static String getResourcePathFromDialogDataSource(
			String dialogRequestURI, String componentDialogPath) {

		String componentResPath = "";
		int componentPathStart;

		if (dialogRequestURI.length() > componentDialogPath.length()) {
			componentPathStart = dialogRequestURI.indexOf(componentDialogPath)
					+ componentDialogPath.length();

			if (componentPathStart > 0) {
				componentResPath = dialogRequestURI
						.substring(componentPathStart);
			}
		}

		return componentResPath;
	}

	public static String formatLink(String linkStr,
			ResourceResolver resourceResolver) {
		if (linkStr == null || linkStr.length() < 2) {
			return "";
		} else if (!linkStr.contains("/content/")
				&& !linkStr.startsWith("http")) {
			return "http://" + linkStr;
		}

		Resource resource = resourceResolver.getResource(linkStr);
		if (resource != null) {
			Page page = resource.adaptTo(Page.class);
			Asset asset = resource.adaptTo(Asset.class);
			if (page != null) {
				linkStr = page.getPath() + ".html";
			} else if (asset != null) {
				linkStr = asset.getPath();
			}
		}
		return linkStr;
	}

	/**
	 * method for formatting the date
	 *
	 * @param time
	 * @return String
	 */
	public static String getFormattedDate(Long time, String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(new Date(time));
	}

	public static Page getSiteRoot(Page currentPage) {
		return currentPage.getAbsoluteParent(1);
	}

}

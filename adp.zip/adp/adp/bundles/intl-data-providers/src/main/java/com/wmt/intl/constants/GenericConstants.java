/**
 * 
 */
package com.wmt.intl.constants;

/**
 * Constants for Intl application
 * 
 * @author vn93497
 *
 */
public class GenericConstants {

	public static final int LOCALE_FOLDER_INDEX = 3;
	public static final String FORWARD_SLASH = "/";
	public static final String HOME_PAGE_NAME = "home";
	public static final String EMPTY_STRING = "";
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_FORMAT_D_MMMMM_YYYY = "d MMMMM yyyy";
	public static final String DATE_FORMAT_D_MMMMM_YYYY_HH_MM_AA = "d MMMMM yyyy - hh:mm aa";

	// Logging constants

	public static final String LOG_START_PROCESS_TXT = "START: process method";
	public static final String LOG_END_PROCESS_TXT = "END: process method";

	// file Extension constant
	public static final String FILE_EXTENSION_HTML = ".html";

	public static final String STATUS_INHERITED = "inherited";
	public static final String STATUS_FALSE = "false";
	public static final String ARTICLE_PAGE_TYPE = "intl/components/pages/articlepage";
	public static final String ARTICLE_CAT_CONFIG_TYPE = "intl/components/siteconfig/articleCategoryConfig";
	public static final String QUICKLINK_CONFIG_TYPE = "intl/components/siteconfig/quicklinkconfig";
	public static final String EVENT_PAGE_TYPE = "intl/components/pages/eventpage";

	public static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";

	public static final String LIBRARYPAGE_LAYOUT_IMAGE = "/content/dam/icp/images/common/content-specific/learning-library/LearningLibrary.png";

	public static final String NO_UPCOMING_EVENTS_FOUND = "No upcoming events found";

}
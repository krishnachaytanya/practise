package com.wmt.intl.servlets;

import java.io.IOException;
import java.net.SocketException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.Version;
import net.fortuna.ical4j.util.UidGenerator;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.wmt.intl.bean.EventBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.pages.EventPageProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * EventDownloadServlet for Event download
 * 
 * @author vn67566
 *
 */
@SlingServlet(paths = "/bin/service/intl/eventDownload", methods = "GET")
public class EventDownloadServlet extends SlingSafeMethodsServlet {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(EventDownloadServlet.class);

	/**
	 * doget method for returning the servlets response
	 *
	 * @param request
	 *            ,response
	 */
	@Override
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		try {
			LOGGER.info("START: Download Event  servlets get method");
			String eventPath = request.getParameter("eventPath");

			Resource resource = request.getResourceResolver().getResource(
					eventPath);

			Page eventPage = IntlUtils.getPage(request.getResourceResolver(),
					eventPath);

			if (IntlUtils.checkResource(eventPage,
					JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
					GenericConstants.EVENT_PAGE_TYPE)) {
				EventPageProvider eventPageProvider = new EventPageProvider();
				eventPageProvider.init(IntlUtils.getBindingForPage(eventPage));

				if (eventPageProvider.isValid()) {
					Calendar calendar = getCalendarDetails(resource,
							eventPageProvider);

					response.setContentType("text/calendar");
					response.setCharacterEncoding("UTF-8");
					response.setHeader("Content-Disposition",
							"attachment; filename=" + resource.getName()
									+ ".ics");

					ServletOutputStream fout = response.getOutputStream();
					CalendarOutputter outputter = new CalendarOutputter();
					outputter.output(calendar, fout);
					fout.flush();
				}

			} else {
				LOGGER.warn(String.format("%s is not an event", eventPath));
			}
			LOGGER.info("END: Download Event  servlets get method");
		} catch (Exception e) {
			LOGGER.error("ERROR while downloading event: ", e);
		}

	}

	/**
	 * To get Event Calendar
	 * 
	 * @param resource
	 * @param eventPageProvider
	 * @return
	 * @throws SocketException
	 * @throws ParseException
	 */
	private Calendar getCalendarDetails(Resource resource,
			EventPageProvider eventPageProvider) throws SocketException,
			ParseException {
		Calendar calendar = new net.fortuna.ical4j.model.Calendar();
		calendar.getProperties().add(new ProdId("ICP event"));
		calendar.getProperties().add(Version.VERSION_2_0);
		calendar.getProperties().add(CalScale.GREGORIAN);

		EventBean eventBean = eventPageProvider.getEvent();

		DateTime eventStartDate = new DateTime(eventBean.getStartDate()
				.getTime());
		DateTime eventEndDate = new DateTime(eventBean.getEndDate().getTime());
		Location location = new Location(eventBean.getLocation());

		VEvent event = null;
		event = new VEvent(eventStartDate, eventEndDate, eventBean.getTitle());

		Description description = new Description(eventBean.getDescription());
		event.getProperties().add(description);
		event.getProperties().add(location);
		LOGGER.info("start=" + eventStartDate);
		UidGenerator uidGenerator = new UidGenerator("1");
		event.getProperties().add(uidGenerator.generateUid());

		calendar.getComponents().add(event);

		return calendar;
	}
}

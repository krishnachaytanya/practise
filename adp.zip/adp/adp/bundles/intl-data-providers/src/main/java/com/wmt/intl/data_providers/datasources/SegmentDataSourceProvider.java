package com.wmt.intl.data_providers.datasources;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.wmt.intl.bean.SegmentBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.siteconfig.TrendingPageConfigProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * SegmentDataSourceProvider for all Template pages
 * 
 * @author vn67566
 *
 */
public class SegmentDataSourceProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SegmentDataSourceProvider.class);

	@Override
	protected void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		populateSegment();
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To populate Segment-- requestURI
	 *
	 */
	private void populateSegment() {
		ResourceResolver resolver = getResource().getResourceResolver();

		List<Resource> resourceList = new ArrayList<>();

		TrendingPageConfigProvider trendingPageConfigProvider = new TrendingPageConfigProvider();
		String requestURI = getRequest().getRequestURI();
		String dialogPath = GlobalConfigConstants.ComponentDialogPaths.DIALOG_PATH;
		/*
		 * 
		 * request uri path example:/mnt/override/apps/intl/components/pages
		 * /genericpage/_cq_dialog.html/content/icp/en_us/home/jcr:content
		 * componentResourcePath example :/content/icp/en_us/Article/jcr:content
		 */

		String componentResourcePath = IntlUtils
				.getResourcePathFromDialogDataSource(requestURI, dialogPath);

		trendingPageConfigProvider.init(IntlUtils.getBindingByPath(
				getResource(),
				IntlUtils.getContentLocalePath(componentResourcePath)
						+ GlobalConfigConstants.GLOBAL_CONFIG_PAGE_PATH
						+ GlobalConfigConstants.TRENDING_PAGE_PATH));

		ValueMap vm;
		vm = new ValueMapDecorator(new HashMap<>());
		vm.put("text", "Select");
		vm.put("value", "");

		resourceList.add(new ValueMapResource(resolver, new ResourceMetadata(),
				"nt:unstructured", vm));

		List<SegmentBean> configList = trendingPageConfigProvider
				.getSegmentList();

		for (SegmentBean segment : configList) {
			vm = new ValueMapDecorator(new HashMap<>());
			vm.put("text", segment.getTitle());
			vm.put("value", segment.getId());

			resourceList.add(new ValueMapResource(resolver,
					new ResourceMetadata(), "nt:unstructured", vm));
		}

		DataSource ds = new SimpleDataSource(resourceList.iterator());
		this.getRequest().setAttribute(DataSource.class.getName(), ds);
	}
}

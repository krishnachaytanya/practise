package com.wmt.intl.bean;

import java.util.List;

/**
 * NavigationBean to store navigation details.
 * 
 * @author vn76375
 *
 */

public class NavigationBean {

	private String pageTitle;
	private String pagePath;
	private List<NavigationBean> childList;

	/**
	 * To get the page title.
	 * 
	 * @return the pageTitle
	 */
	public String getPageTitle() {
		return pageTitle;
	}

	/**
	 * To set the page title.
	 * 
	 * @param pageTitle
	 *            the pageTitle to set
	 */
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	/**
	 * To get the page path.
	 * 
	 * @return the pagePath
	 */
	public String getPagePath() {
		return pagePath;
	}

	/**
	 * To set the page path.
	 * 
	 * @param pagePath
	 *            the pagePath to set
	 */
	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}

	/**
	 * To get child list
	 * 
	 * @return
	 */
	public List<NavigationBean> getChildList() {
		return childList;
	}

	/**
	 * To set child list
	 * 
	 * @param childList
	 */
	public void setChildList(List<NavigationBean> childList) {
		this.childList = childList;
	}

}
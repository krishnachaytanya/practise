package com.wmt.intl.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;

/**
 * System Account Util Service
 */
@Component(label = "System Account Util Service", description = "Provides util methods based on service account", immediate = true)
@Service(value = { SystemAccountUtilService.class })
public class SystemAccountUtilService {
	private static final String SERVICE_ACCOUNT_IDENTIFIER = "adp-service-user";

	@Reference
	ResourceResolverFactory resourceResolverFactory;
	private static final Logger logger = LoggerFactory
			.getLogger(SystemAccountUtilService.class);

	@Activate
	protected void activate() {

	}
	/**
	 * To get the tag title.
	 * @param tagId
	 * @return
	 */
	public String getTagTitle(String tagId) {
		String tagTitle= null;
		Map<String, Object> params = new HashMap<>();
		params.put(ResourceResolverFactory.SUBSERVICE,
				SERVICE_ACCOUNT_IDENTIFIER);

		ResourceResolver resourceResolver = null;
		try {
			resourceResolver = resourceResolverFactory
					.getServiceResourceResolver(params);

			TagManager tagManager = resourceResolver.adaptTo(TagManager.class);

			Tag tag = tagManager.resolve(tagId);
			
			if(tag != null){
				tagTitle = tag.getTitle();
			}

		} catch (LoginException loginExcp) {
			logger.error("Exception occurred in SystemAccountUtilService ",
					loginExcp);
		} finally {
			if (resourceResolver != null && resourceResolver.isLive()) {
				resourceResolver.close();
			}
		}
		return tagTitle;
	}
}

/**
 * 
 */
package com.wmt.intl.data_providers.siteconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.script.SimpleBindings;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.constants.GlobalConfigConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.GlobalConfigUtil;
import com.wmt.intl.utils.IntlUtils;

/**
 * @author vn93497
 *
 */
public class QuickLinkConfigContainerProvider extends IntlBaseProvider {

	private Map<String,QuickLinkConfigProvider> quickLinkConfigMap;
	
	private List<QuickLinkConfigProvider> quickLinkConfigList;
	
	private Set<String> quickLinkIdSet;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(QuickLinkConfigContainerProvider.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wmt.intl.data_providers.IntlBaseProvider#process()
	 */
	@Override
	protected void process() {
		LOGGER.info(GenericConstants.LOG_START_PROCESS_TXT);
		if (getResource() != null) {
			String quickLinkConfigPath = GlobalConfigUtil
					.getGlobalConfigPath(getResource().getPath())
					+ GlobalConfigConstants.QUICK_LINK_PAR_PATH;

			if (quickLinkConfigPath.equalsIgnoreCase(getResource().getPath())) {
				Iterable<Resource> resIter = getResource().getChildren();
				Iterator<Resource> it = resIter.iterator();

//				quickLinkConfigMap = new HashMap<String,List<QuickLinkConfigProvider>>();
				quickLinkConfigList = new ArrayList<QuickLinkConfigProvider>();
				while (it.hasNext()) {
					Resource res = (Resource) it.next();

					if (IntlUtils.checkResource(res, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, GenericConstants.QUICKLINK_CONFIG_TYPE)) {

						QuickLinkConfigProvider quickLinkConfig = getQuickLinkConfigProv(res);
						
						quickLinkConfigList.add(quickLinkConfig);
//						if(quickLinkConfigMap.containsKey(quickLinkConfig.getQuickLinkId())){
//							quickLinkConfigMap.get(quickLinkConfig.getQuickLinkId()).add(quickLinkConfig);
//						}else{
//							List<QuickLinkConfigProvider> configList = new ArrayList<QuickLinkConfigProvider>();
//							
//							configList.add(quickLinkConfig);
//							
//							quickLinkConfigMap.put(quickLinkConfig.getQuickLinkId(),configList);
//						}
					}
				}
				if (quickLinkConfigList.isEmpty()) {
					addErrorMsg("No quick link configuration retrieved");
				}
			} else {
				addErrorMsg("Please use GlobalConfigProvider to get quick link Config");
			}
		} else {
			addErrorMsg("please configure global quick link config component.");
		}
	}

	private QuickLinkConfigProvider getQuickLinkConfigProv(Resource res) {
		QuickLinkConfigProvider provider = new QuickLinkConfigProvider();

		SimpleBindings bindings = new SimpleBindings();

		bindings.put("resource", res);

		provider.init(bindings);

		return provider;
	}

	/**
	 * @return the quickLinkConfigMap
	 */
	public MultiMap getQuickLinkConfigMap() {
		MultiMap multipMap = new MultiValueMap();
		if(quickLinkConfigList != null){
			quickLinkConfigMap = new HashMap<String,QuickLinkConfigProvider>();
			for (QuickLinkConfigProvider quickLinkConfigProvider : quickLinkConfigList) {
				quickLinkConfigMap.put(quickLinkConfigProvider.getQuickLinkStyle(),quickLinkConfigProvider);
				multipMap.put(quickLinkConfigProvider.getQuickLinkStyle(),quickLinkConfigProvider);
			}
		}
		
		return multipMap;
	}

	/**
	 * @return the quickLinkConfigList
	 */
	public List<QuickLinkConfigProvider> getQuickLinkConfigList() {
		return quickLinkConfigList;
	}

	/**
	 * @return the quickLinkIdSet
	 */
	public Set<String> getQuickLinkIdSet() {
		if(quickLinkConfigMap != null && !quickLinkConfigMap.isEmpty()){
			this.quickLinkIdSet = quickLinkConfigMap.keySet();
		}
		
		return this.quickLinkIdSet;
	}



}

package com.wmt.intl.bean;

/**
 * SegmentBean for TrendingPageConfigProvider
 * 
 * @author vn67566
 *
 */
public class SegmentBean {
	private String id;
	private String title;
	private String analyticsId;

	/**
	 * To get id
	 * 
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * Setting id
	 * 
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * To get Title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Setting Title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * To get AnalyticsId
	 * 
	 * @return
	 */
	public String getAnalyticsId() {
		return analyticsId;
	}

	/**
	 * Setting AnalyticsId
	 * 
	 * @param analyticsId
	 */
	public void setAnalyticsId(String analyticsId) {
		this.analyticsId = analyticsId;
	}

}

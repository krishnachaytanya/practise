package com.wmt.intl.bean;

public class LanguageItem implements Comparable<LanguageItem>{

	private String langIso;
	private String name;
	private Boolean selected;
	private String path;
	private String countryIso;

	public LanguageItem(String langIso, String name, Boolean selected, String path, String countryIso) {
		super();
		this.langIso = langIso;
		this.name = name;
		this.selected = selected;
		this.path = path;
		this.countryIso = countryIso;
	}
	
	public String getLangIso() {
		return langIso;
	}

	public void setLangIso(String langIso) {
		this.langIso = langIso;
	}
	
	public String getCountryIso() {
		return countryIso;
	}

	public void setCountryIso(String countryIso) {
		this.countryIso = countryIso;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getSelected() {
		return selected;
	}
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String rootPath) {
		this.path = rootPath;
	}

	@Override
	public int compareTo(LanguageItem o) {
		if(name == null || o.getName() == null)
			return 0;
		return getName().compareTo(o.getName());
	}
	
}

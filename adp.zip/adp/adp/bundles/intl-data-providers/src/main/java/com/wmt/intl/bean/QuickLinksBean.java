package com.wmt.intl.bean;


/**
 * QuickLinksBean for QuickLinksProvider
 * 
 * @author vn67566
 *
 */

public class QuickLinksBean {

	/**
	 * quickLinksTitle contains quickLink title
	 */
	private String quickLinksTitle;
	/**
	 * quickLinks contains quickLink page link
	 */
	private String quickLinks;
	/**
	 * image file contains quickLink image path
	 */
	private String imagefile;
	/**
	 * color contains quickLink background color
	 */
	private String color;
	
	/**
	 * Border color of the Quick link box.
	 */
	private String borderColor;

	/**
	 * getter method for getting quicklink title
	 * 
	 * @return quickLinksTitle
	 */
	public String getQuickLinksTitle() {
		return quickLinksTitle;
	}

	/**
	 * setter method for setting quicklink title
	 * 
	 * @param quickLinksTitle
	 * 
	 */
	public void setQuickLinksTitle(String quickLinksTitle) {
		this.quickLinksTitle = quickLinksTitle;
	}

	/**
	 * getter method for getting quicklink page link
	 * 
	 * @return the quickLinks
	 */
	public String getQuickLinks() {
		return quickLinks;
	}

	/**
	 * setter method for setting quicklink page link
	 * 
	 * @param quickLinks
	 * 
	 */
	public void setQuickLinks(String quickLinks) {
		this.quickLinks = quickLinks;
	}

	/**
	 * getter method for getting quicklink image path
	 * 
	 * @return the image file
	 */
	public String getImagefile() {
		return imagefile;
	}

	/**
	 * setter method for setting quicklink image path
	 * 
	 * @param imagefile
	 * 
	 */
	public void setImagefile(String imagefile) {
		this.imagefile = imagefile;
	}

	/**
	 * getter method for getting quicklinks bg color
	 * 
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * setter method for setting quicklink bg color
	 * 
	 * @param color
	 * 
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * To get the border color.
	 * @return the borderColor
	 */
	public String getBorderColor() {
		return borderColor;
	}

	/**
	 * To set the border color.
	 * @param borderColor the borderColor to set
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}

}
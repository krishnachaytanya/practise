package com.wmt.intl.data_providers.pages;

import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wmt.intl.bean.EventBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.utils.IntlUtils;

/**
 * EventPageProvider for Event Page
 * 
 * @author vn67566
 *
 */
public class EventPageProvider extends BasePageProvider {

	private static final String LOCATION = "location";
	private static final String STARTDATE = "startDate";
	private static final String ENDDATE = "endDate";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(EventPageProvider.class);

	private String location;
	private Calendar eventStart;
	private Calendar eventEnd;
	private String formattedEventStartDate;
	private String formattedEventEndDate;

	private EventBean event;

	/**
	 * To get Event
	 * 
	 * @return
	 */
	public EventBean getEvent() {
		return event;
	}

	/**
	 * To get formattedEventStartDate
	 * 
	 * @return
	 */
	public String getFormattedEventStartDate() {
		return formattedEventStartDate;
	}

	/**
	 * To get formattedEventEndDate
	 * 
	 * @return
	 */
	public String getFormattedEventEndDate() {
		return formattedEventEndDate;
	}

	@Override
	protected void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		populateEventpage();

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * Populating Event page
	 */
	private void populateEventpage() {
		if (getCurrentPage() != null) {
			super.process();
			ValueMap valueMap = getCurrentPage().getContentResource()
					.getValueMap();

			location = valueMap.get(LOCATION, null);

			eventStart = valueMap.get(STARTDATE, null);
			eventEnd = valueMap.get(ENDDATE, null);

			if (eventStart != null && eventEnd != null) {
				formattedEventStartDate = IntlUtils.getFormattedDate(
						eventStart,
						GenericConstants.DATE_FORMAT_D_MMMMM_YYYY_HH_MM_AA);
				formattedEventEndDate = IntlUtils.getFormattedDate(eventEnd,
						GenericConstants.DATE_FORMAT_D_MMMMM_YYYY_HH_MM_AA);
				if (eventEnd.before(eventStart)) {
					addErrorMsg("Please configure valid Event Start Date and End Date");
				}
			}

			if (StringUtils.isEmpty(location)) {
				addErrorMsg("Please configure Event Location");
			}
			if (eventStart == null) {
				addErrorMsg("Please configure Event Start Date ");
			}
			if (eventEnd == null) {
				addErrorMsg("Please configure Event End Date ");
			}

			if (this.isValid()) {

				populateEvent();
			}

		} else {
			addErrorMsg("Event page not found");
		}
	}

	/**
	 * To populate event
	 */
	private void populateEvent() {

		event = new EventBean();

		event.setTitle(getTitle());
		event.setLink(getPagePath());
		event.setDescription(getDescription());
		event.setLocation(location);
		event.setStartDate(eventStart);
		event.setEndDate(eventEnd);
		event.setFormattedStartDate(IntlUtils.getFormattedDate(eventStart,
				GenericConstants.DATE_FORMAT_D_MMMMM_YYYY));
		event.setFormattedEndDate(IntlUtils.getFormattedDate(eventEnd,
				GenericConstants.DATE_FORMAT_D_MMMMM_YYYY));

	}
}

package com.wmt.intl.data_providers.content;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.intl.bean.NavigationBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * Navigation Provider class For Navigation Component
 * 
 * @author vn76375
 *
 */
public class NavigationProvider extends IntlBaseProvider {

	private static final int MENU_LEVEL = 2;

	private List<NavigationBean> pageList;

	public List<NavigationBean> getPageList() {
		return pageList;
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(NavigationProvider.class);

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);
		ResourceResolver resourceResolver = getResourceResolver();
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

		String homePagePath = IntlUtils
				.getHomePagePath(getResource().getPath());

		Page homePage = pageManager.getPage(homePagePath);

		if (homePage == null) {
			addErrorMsg("Please create your home page in " + homePagePath);
		} else {
			pageList = getNavigationLevels(homePage, 1);
			// Adding Home Page to the top
			pageList.add(0, getNavigationBean(homePage));
		}
		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	/**
	 * To get the navigation details
	 * 
	 * @param homePage
	 * @param currentLevel
	 * @return
	 */
	private List<NavigationBean> getNavigationLevels(Page homePage,
			int currentLevel) {
		List<NavigationBean> childList = new ArrayList<NavigationBean>();
		Iterator<Page> rootPageIterator;

		rootPageIterator = homePage.listChildren();

		while (rootPageIterator.hasNext()) {

			Page childPage = rootPageIterator.next();
			if (!childPage.getProperties().get("hideInNav", false)) {
				NavigationBean navigationBean = getNavigationBean(childPage);

				if (currentLevel < MENU_LEVEL) {
					navigationBean.setChildList(getNavigationLevels(childPage,
							currentLevel + 1));
				}
				childList.add(navigationBean);
			}
		}
		return childList;
	}

	private NavigationBean getNavigationBean(Page page) {
		NavigationBean navigationBean = new NavigationBean();

		navigationBean.setPagePath(page.getPath());
		navigationBean.setPageTitle(page.getTitle());

		return navigationBean;
	}
}

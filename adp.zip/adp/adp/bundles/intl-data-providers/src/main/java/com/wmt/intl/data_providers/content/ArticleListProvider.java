package com.wmt.intl.data_providers.content;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.wmt.intl.bean.ArticleBean;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.data_providers.pages.ArticlePageProvider;
import com.wmt.intl.utils.IntlUtils;

/**
 * Provider for Article List
 *
 */
public class ArticleListProvider extends IntlBaseProvider {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ArticleListProvider.class);

	private static final String PARENT_PAGE = "parentPath";
	private static final String ARTICLE_LIST_TYPE = "articleListType";
	private static final String ARTICLE_LIST_MANUAL = "articleListManual";
	private static final String LIMIT = "limit";
	private static final String ITEMS_PER_PAGE = "itemsPerPage";
	private static final String ARTICLE_TYPE_TAGS = "articleTypeTags";

	String articleListJson;
	int itemsPerPage;
	List<ArticleBean> articleList = new ArrayList<ArticleBean>();

	/**
	 * To get Article bean list.
	 * 
	 * @return
	 */
	public List<ArticleBean> getArticleList() {
		return articleList;
	}

	/**
	 * To get Items per page
	 * 
	 * @return
	 */
	public int getItemsPerPage() {
		return itemsPerPage;
	}

	@Override
	public void process() {
		LOGGER.debug(GenericConstants.LOG_START_PROCESS_TXT);

		ValueMap valueMap = getResource().getValueMap();

		String articleListType = valueMap.get(ARTICLE_LIST_TYPE, (String) null);
		
		int articleListLimit = valueMap.get(LIMIT, 0);
		itemsPerPage = valueMap.get(ITEMS_PER_PAGE, 0);
		
		if (articleListLimit <= 0) {
			addErrorMsg("Please provide a valid limit");
		}
		if (itemsPerPage <= 0) {
			addErrorMsg("Please provide valid items per page");
		}

		
		if (StringUtils.isEmpty(articleListType)) {
			addErrorMsg("Please provide an article list type");
		} else if (articleListType.equals("parent")) {
			

			String articleListParentPage = valueMap.get(PARENT_PAGE,
					(String) null);
			List<String> articleListTags = Arrays.asList(valueMap.get(
					ARTICLE_TYPE_TAGS, new String[] {}));

			
			if (StringUtils.isEmpty(articleListParentPage)) {
				addErrorMsg("Please provide a parent path");
			}

			if (this.isValid()) {

				LOGGER.info(" " + articleListLimit + " "
						+ articleListParentPage);

				Page localePath = IntlUtils.getPage(getResourceResolver(),
						articleListParentPage);

				populateArticleList(localePath, articleListLimit,
						articleListTags);
			}
		} else if (articleListType.equals("manual")) {
			String[] articleListManualArr = getResource().getValueMap().get(
					ARTICLE_LIST_MANUAL, new String[] {});

			if (articleListManualArr.length > 0) {

				for (int index = 0; index < articleListManualArr.length; index++) {
					JSONObject jsonObj = new JSONObject(
							articleListManualArr[index]);
					String articlePagePath = jsonObj.getString("path");

					Page page = IntlUtils.getPage(getResourceResolver(),
							articlePagePath);

					if (IntlUtils.checkResource(page, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, GenericConstants.ARTICLE_PAGE_TYPE)) {

						ArticleBean article = getArticleDetails(page);

						if (article != null) {
							articleList.add(article);
						}
					} else {
						addErrorMsg(String.format(
								"Page - %s is not an article page.",
								page.getPath()));
					}
				}
			} else {
				addErrorMsg("No articles found");
			}
		}
		sortList(articleList);

		LOGGER.debug(GenericConstants.LOG_END_PROCESS_TXT);
	}

	private void populateArticleList(Page currentPage, int limit,
			List<String> articleListTags) {
		Iterator<Page> rootPageIterator = currentPage.listChildren();
		while (rootPageIterator.hasNext()) {
			// To stop the list items based on the limit.
			if (articleList.size() >= limit) {
				break;
			}

			Page childPage = rootPageIterator.next();
			if (IntlUtils.checkResource(childPage, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, GenericConstants.ARTICLE_PAGE_TYPE)) {
				ArticleBean articleBean = getArticleDetails(childPage,
						articleListTags);
				if (articleBean != null) {
					articleList.add(articleBean);
				}
			}
			populateArticleList(childPage, limit, articleListTags);
		}

	}

	private ArticleBean getArticleDetails(Page page) {
		return getArticleDetails(page, null);
	}

	private ArticleBean getArticleDetails(Page page,
			List<String> articleListTags) {

		ArticleBean articleBean = null;

		ArticlePageProvider articlePageProvider = new ArticlePageProvider();

		articlePageProvider.init(IntlUtils.getBindingForPage(page));

		if (articlePageProvider.isValid()) {
			if ((articleListTags == null || articleListTags.isEmpty())
					|| (isArticleTagMatch(articleListTags,
							articlePageProvider.getArticleTypeList()))) {

				articleBean = new ArticleBean();

				articleBean
						.setDescription(articlePageProvider.getDescription());
				articleBean.setTitle(articlePageProvider.getTitle());
				articleBean.setArticleImageRendition(articlePageProvider.getArticleImageRenditions());
				articleBean.setLink(IntlUtils.addExtension(page.getPath()));
				articleBean.setPubDate(IntlUtils.getFormattedDate(
						articlePageProvider.getDate(),
						GenericConstants.DATE_FORMAT_D_MMMMM_YYYY));
			}
		} else {
			addErrorMsg("Please make sure the article configuration is correct" + page.getPath());
		}
		return articleBean;
	}

	private boolean isArticleTagMatch(List<String> articleListTags,
			List<String> articleTags) {
		boolean matchStatus = false;

		if (articleListTags != null && articleTags != null) {
			matchStatus = CollectionUtils.containsAny(articleListTags,
					articleTags);
		}
		return matchStatus;
	}

	private List<ArticleBean> sortList(List<ArticleBean> articleList) {
		Collections.sort(articleList);
		return articleList;
	}

	/**
	 * To get JSON data of the article list.
	 * 
	 * @return
	 */
	public String getArticleListJson() {

		Gson gson = new Gson();
		Type type = new TypeToken<List<ArticleBean>>() {
		}.getType();

		articleListJson = gson.toJson(this.articleList, type);
		
		return IntlUtils.escapeJson(articleListJson);
	}

}

package com.wmt.intl.servlet;

import java.io.IOException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.json.JSONArray;

import com.wmt.intl.data_providers.siteconfig.TimeZoneConfigProvider;
import com.wmt.intl.utils.GlobalConfigUtil;

@SuppressWarnings("serial")
@SlingServlet(
	    resourceTypes = "intl/components/content/timezone",
	    selectors = "zonelist",
	    extensions = "html",
	    methods = "GET")
public class TimeZoneServlet extends SlingSafeMethodsServlet {

	private static final String APPLICATION_JSON = "application/json";

	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException{
		JSONArray jsonArray = null;
		try {
			TimeZoneConfigProvider timezoneConfigProvider = GlobalConfigUtil.getProvider(request.getResource()).getTimeZoneConfig();
			jsonArray = new JSONArray(timezoneConfigProvider.getTimeZoneList());
		} catch (Exception e) {
			jsonArray = new JSONArray();
		}
		response.setContentType(APPLICATION_JSON);
		response.getWriter().println(jsonArray);
	}
}

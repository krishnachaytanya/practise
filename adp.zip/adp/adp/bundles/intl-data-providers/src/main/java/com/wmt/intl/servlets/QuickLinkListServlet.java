package com.wmt.intl.servlets;

import com.wmt.intl.data_providers.siteconfig.QuickLinkListConfigProvider;
import com.wmt.intl.utils.IntlUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.script.SimpleBindings;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.Iterator;

/**
 * Created by dcrajan on 10/24/2017.
 * Servlet for returning quicklink list global configuration details
 */
@SlingServlet(
        resourceTypes = "intl/components/content/quicklinks",
        selectors = "qucklinkproperties",
        extensions = "json",
        methods = "GET")
public class QuickLinkListServlet extends SlingSafeMethodsServlet {
    final static String CONFIG_LIST_RESOURCE_PATH = "/content/icp/en_us/site-config/global-configuration/jcr:content/par";
    final static String ERROR_KEY = "errormessage";
    final static String ERROR_MESSAGE = "Unable to fetch quick link list data.";
    final static String JSON_KEY_ID = "id";
    final static String JSON_KEY_PATH = "path";

    private String quickLinkListDetails;
    private JSONObject quickLinkJson;

    private static final Logger LOGGER = LoggerFactory
            .getLogger(FbGroupFeedServlet.class);
    /**
     *doget method for returning the servlets response
     *
     *@param request,response
     */
    @Override
    protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws
            ServletException, IOException {
        try {
            Resource parNodeResource = request
                    .getResourceResolver()
                    .getResource(CONFIG_LIST_RESOURCE_PATH);

            QuickLinkListConfigProvider quickLinkListProvider;
            JSONArray quickLInkListCollection = new JSONArray();

            if (parNodeResource != null && parNodeResource.hasChildren()) {
                Iterator<Resource> children = parNodeResource.listChildren();
                while (children.hasNext()) {
                    quickLinkListProvider =  new QuickLinkListConfigProvider();
                    Resource quickLinkList = children.next();
                    SimpleBindings qlListBinding = IntlUtils.getBindingByPath(quickLinkList, quickLinkList.getPath());
                    quickLinkListProvider.init(qlListBinding);
                    quickLinkListProvider.setGlobalConfigResourcePath(quickLinkList.getPath());

                    if (quickLinkListProvider != null) {
                        quickLinkJson = new JSONObject();
                        quickLinkJson.put(JSON_KEY_ID,quickLinkListProvider.getQuickLinkId());
                        quickLinkJson.put(JSON_KEY_PATH,quickLinkListProvider.getGlobalConfigResourcePath());
                        quickLInkListCollection.put(quickLinkJson);
                    }
                }
            }

            if (quickLInkListCollection.length() > 0){
                quickLinkListDetails = quickLInkListCollection.toString();

            }
            else{
                quickLinkListDetails = setErrorJSONResponse(response);
            }
            response.getWriter().write(quickLinkListDetails.toString());
        }
        catch(Exception e)
        {
            LOGGER.error("ERROR : ",e);

        }
    }

    /**
     *method for create and return error JSON response
     *
     *@param response
     * @return String
     */
    private String setErrorJSONResponse(SlingHttpServletResponse response) throws JSONException {
        response.setStatus(SlingHttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        JSONObject errorJSON = new JSONObject();
        errorJSON.put(ERROR_KEY,ERROR_MESSAGE);

        return errorJSON.toString();
    }
}

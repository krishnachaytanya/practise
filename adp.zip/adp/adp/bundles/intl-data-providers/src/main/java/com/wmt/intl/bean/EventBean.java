package com.wmt.intl.bean;

import java.util.Calendar;
import java.util.Comparator;

/**
 * EventBean for EventPageProvider
 * 
 * @author vn67566
 *
 */
public class EventBean implements Comparable<EventBean> {

	private String title;
	private String description;
	private String location;
	private String formattedStartDate;
	private String formattedEndDate;
	private String link;
	private Calendar startDate;
	private Calendar endDate;

	/**
	 * To get Description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Setting Description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * To get Location
	 * 
	 * @return
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Setting Location
	 * 
	 * @param location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * To get startDate
	 * 
	 * @return
	 */
	public Calendar getStartDate() {
		return startDate;
	}

	/**
	 * Setting end Date
	 * 
	 * @param startDate
	 */
	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	/**
	 * To get formattedEndDate
	 * 
	 * @return
	 */
	public String getFormattedEndDate() {
		return formattedEndDate;
	}

	/**
	 * Setting formattedEndDate
	 * 
	 * @param formattedEndDate
	 */
	public void setFormattedEndDate(String formattedEndDate) {
		this.formattedEndDate = formattedEndDate;
	}

	/**
	 * To get formattedStartDate
	 * 
	 * @return
	 */
	public String getFormattedStartDate() {
		return formattedStartDate;
	}

	/**
	 * Setting formattedStartDate
	 * 
	 * @param date
	 */
	public void setFormattedStartDate(String date) {
		this.formattedStartDate = date;
	}

	/**
	 * To get the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * To set the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * To get endDate
	 * 
	 * @return
	 */
	public Calendar getEndDate() {
		return endDate;
	}

	/**
	 * setting endDate
	 * 
	 * @param endDate
	 */
	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	@Override
	public int compareTo(EventBean articleTo) {
		return Comparators.DATE_DESC.compare(this, articleTo);
	}

	static class Comparators {

		private static int compareInternal(Calendar calendar,
				Calendar calendar2, Boolean isDescending) {
			int order = 1;

			if ((calendar == null) && (calendar2 == null)) {
				return 0;
			}
			if (calendar == null) {
				return 1;
			}
			if (calendar2 == null) {
				return -1;
			}
			order = calendar2.compareTo((calendar));
			if (!isDescending) {
				order = order * -1;
			}
			return order;
		}

		public static Comparator<EventBean> DATE = new Comparator<EventBean>() {
			@Override
			public int compare(EventBean itemA, EventBean itemB) {
				return compareInternal(itemA.getStartDate(),
						itemB.getStartDate(), false);
			}
		};

		public static Comparator<EventBean> DATE_DESC = new Comparator<EventBean>() {
			@Override
			public int compare(EventBean itemA, EventBean itemB) {
				return compareInternal(itemA.getStartDate(),
						itemB.getStartDate(), true);
			}
		};
	}

}
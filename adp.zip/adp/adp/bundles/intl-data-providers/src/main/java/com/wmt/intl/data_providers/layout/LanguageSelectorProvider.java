package com.wmt.intl.data_providers.layout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.wmt.intl.bean.LanguageItem;
import com.wmt.intl.constants.GenericConstants;
import com.wmt.intl.data_providers.IntlBaseProvider;
import com.wmt.intl.utils.IntlUtils;
/**
 * Language Selector Provider
 *
 */
public class LanguageSelectorProvider extends IntlBaseProvider{

	private LanguageItem selectedLang;
	private List<LanguageItem> defaultLanguages;
	private ResourceResolver resourceResolver;
	
	@Override
	public void process() {
		resourceResolver = getResourceResolver();
		loadAvailablesLangs(getCurrentPage(), getPageManager());
	}
	/**
	 * To get Selected Language
	 * @return
	 */
	public LanguageItem getSelectedLang() {
		return selectedLang;
	}

	/**
	 * To get the Default Languages
	 * @return List<LanguageItem>
	 */
	public List<LanguageItem> getDefaultLanguages() {
		return defaultLanguages;
	}
	
	/**
	 * Add the children under the path: {@code /content/icp/}
	 * that respect the Locale standard name format as available
	 * language option. i.e: en-us, en-ca, fr-ca
	 * @param currentPage
	 * @param pageManager
	 */
	private void loadAvailablesLangs(Page currentPage, PageManager pageManager){
		defaultLanguages = new ArrayList<LanguageItem>();
		Page rootPath = IntlUtils.getSiteRoot(getCurrentPage());
		Iterator<Page> languagePages = rootPath.listChildren();
		while (languagePages.hasNext()) {
			Page page = languagePages.next();
			if(page.getName().contains("-")){
				Locale locale = page.getLanguage(true);
				String urlToForward = getForwardLanguagePage(currentPage, page);
				boolean isSelected = (locale.getLanguage() == currentPage.getLanguage(true).getLanguage() && locale.getCountry() ==  currentPage.getLanguage(true).getCountry());
				LanguageItem langPage = new LanguageItem(locale.getLanguage(), locale.getDisplayLanguage(locale), isSelected, urlToForward, locale.getCountry().toLowerCase());
				if(isSelected){
					this.selectedLang = langPage;
				}
				this.defaultLanguages.add(langPage);
			}
		}
		Collections.sort(defaultLanguages);
	}
	
	/**
	 * Check if exists the currentPage in the corresponding language
	 * if not returns the homePage in the other language
	 * @param currentPage The page to evaluate
	 * @param page The attempting language
	 * @return The page in the corresponding language
	 */
	private String getForwardLanguagePage(Page currentPage, Page page){
		String langPrefix = currentPage.getLanguage(true).getLanguage()+"-"+currentPage.getLanguage(true).getCountry().toLowerCase();
		String langSelected = page.getLanguage(true).getLanguage()+"-"+page.getLanguage(true).getCountry().toLowerCase();
		if(!langPrefix.equals("")){
			String pathToAttempt = currentPage.getPath().replaceFirst(Pattern.quote("/"+langPrefix), "/"+langSelected);
			Resource resource = resourceResolver.getResource(pathToAttempt);
			if(resource != null){
				return IntlUtils.formatLink(pathToAttempt, resourceResolver);
			}
		}
		String homePagePath = page.getPath()+ GenericConstants.FORWARD_SLASH + GenericConstants.HOME_PAGE_NAME;
		return IntlUtils.formatLink(homePagePath, resourceResolver);
	}
}

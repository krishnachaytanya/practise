(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.LinkList');
  ADP.Components.Classes.LinkList = new ADP.Class();
  ADP.Components.Classes.LinkList.include({

    init: function ($component) {
      this.$linkList = $component;
      this.bindEvents();
    },
    bindEvents: function () {
      var _this = this;
      _this.$linkList.on("click", function(e){
          var mainTitle = $(e.target);
          var linksMenu = mainTitle.next("ul");

          if (linksMenu.height()){
              linksMenu.css("max-height","0");
          } else {
              linksMenu.css("max-height", linksMenu.prop('scrollHeight') + "px");
          }

          mainTitle.toggleClass("actived");
      });
    }
  });

  //jQuery Document Ready
  jQuery(function () {
    var linkList = new ADP.Components.Classes.LinkList(jQuery(".link-list-title-mobile"));
  });
}(ADP, jQuery));
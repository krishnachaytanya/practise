(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.CurrencyConverter');
  ADP.Components.Classes.CurrencyConverter = new ADP.Class();
  ADP.Components.Classes.CurrencyConverter.include({

    init: function ($component) {
      this.$currencyConverter = $component;
      this.$ccCalcOptions = this.$currencyConverter.find('.cc-dropdown-option');
      this.$ccForm = this.$currencyConverter.find('.from-input-form');
      this.$ccFormInput = this.$ccForm.find('.from-input');
      this.$exchangeData = this.$currencyConverter.find('.exchange-data');
      this.$calcResult = this.$currencyConverter.find('.cc-tile-calc .to-result');

      this.$fromCurrency = this.$currencyConverter.find('.cc-tile-calc-from .dropdown-toggle');
      this.$toCurrency = this.$currencyConverter.find('.cc-tile-calc-to .dropdown-toggle');

      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;

      jQuery(window).on('load', function() {
        jQuery.getJSON('/bin/adp/currencyexchange.json', function(json) {
          var currencyData = json.serviceEngineResponse.businessResponse.currencyChanges;

          for (var i = 0; i < currencyData.length; i++) {
            var currencyExchange = currencyData[i],
                cBuy = currencyExchange.Buy,
                cSale = currencyExchange.Sale,
                currencyValue = 0;

            if (currencyExchange.Sale === 0) {
              currencyValue = cBuy;
            } else if (currencyExchange.Buy === 0) {
              currencyValue = cSale;
            } else {
              currencyValue = (cBuy + cSale) / 2;
            }

            currencyValue = currencyValue.toFixed(2);

            _this.$exchangeData.filter('.exchange-data-' + currencyExchange.CountryCode.toLowerCase()).text(currencyValue);
          }

          _this.calculateCurrency();
        });
      });

      this.$ccCalcOptions.on('click', function(e) {
        e.preventDefault();

        var $this = jQuery(this),
            $dropdownButton = $this.parents('.dropdown-menu').siblings('.dropdown-toggle');

        $dropdownButton.data('countryCode', $this.data('countryCode'));
        $dropdownButton.find('.selected-content').html($this.html());

        _this.calculateCurrency();
      });

      this.$ccForm.on('submit', function(e) {
        e.preventDefault();

        _this.calculateCurrency();
      });
    },

    calculateCurrency: function() {
      var calculateAmount = this.$ccFormInput.removeClass('cc-input-error').val().replace(',', '');

      if (calculateAmount.search(/[^0-9.]/) >= 0) {
        this.$ccFormInput.addClass('cc-input-error');
        return;
      }

      var fromCurrency = this.$fromCurrency.data('countryCode'),
          toCurrency = this.$toCurrency.data('countryCode'),
          fromCurrencyValue = fromCurrency === 'usd' ? 1 : parseFloat(this.$exchangeData.filter('.exchange-data-' + fromCurrency).text()),
          toCurrencyValue = toCurrency === 'usd' ? 1 : parseFloat(this.$exchangeData.filter('.exchange-data-' + toCurrency).text()),

          dollarValue = calculateAmount / fromCurrencyValue,
          currencyResult = dollarValue * toCurrencyValue;

      this.$calcResult.text(currencyResult.toFixed(2));
    }

  });

  jQuery(function () {
    var $currencyConverter = jQuery('.currency-converter-component');
    jQuery.each($currencyConverter, function () {
      var currencyConverter = new ADP.Components.Classes.CurrencyConverter(jQuery(this));
    });
  });
}(ADP, jQuery));
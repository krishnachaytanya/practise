// list.js pagination only works with id's
(function (ADP, jQuery) {
  'use strict';

	ADP.Namespace(ADP, 'ADP.Components.Classes.DownloadList');
	ADP.Components.Classes.DownloadList = new ADP.Class();

	ADP.Components.Classes.DownloadList.include({

    CONST: {
      CSS: {
        SHOWN_ITEM              : 'shown-item',
        SEE_MORE_PAGINATION     : 'see-more-pagination'
      }
    },

		init: function ($component) {
			this.$component           = $component;
      this.$items               = $component.find(".list-item");
      this.$seeMore             = $component.find(".see-more-items");
      this.seeMorePagination    = $component.hasClass(this.CONST.CSS.SEE_MORE_PAGINATION);

			this.bindEvents();
		},

		showMore: function(e) {
		// shows ten more items
      var CSS           = this.CONST.CSS;
			var $hiddenItems  = this.$items.not("." + CSS.SHOWN_ITEM);

      $hiddenItems.slice(0, 10).addClass(CSS.SHOWN_ITEM);
			$hiddenItems = this.$items.not("." + CSS.SHOWN_ITEM);

			if (!$hiddenItems.length) {
			  this.$seeMore.addClass('hidden');
			}
		},

		showAll: function() {
		// shows all the items of the list
			this.$items.addClass(this.CONST.CSS.SHOWN_ITEM);
			this.$seeMore.addClass('hidden');
		},

		bindEvents: function() {
      var _this = this;

      this.$seeMore.on('click', function(e) {
        if (_this.seeMorePagination) {
          _this.showMore();
        } else {
          _this.showAll();
        }        
      });
		}
  });

  jQuery(function () {
    var $downloadList = jQuery('.download-list-component');
    jQuery.each($downloadList, function () {
      var downloadList = new ADP.Components.Classes.DownloadList(jQuery(this));
    });
  });

}(ADP, jQuery));

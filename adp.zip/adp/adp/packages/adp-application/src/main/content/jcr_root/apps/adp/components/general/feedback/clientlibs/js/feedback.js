(function (ADP, jQuery) {
  'use strict';

  const CONSTS = {
    CSS: {
      OPENED              : "opened",
      CLOSED              : "closed",
      WRONG               : "wrong",
      SENDING             : "sending",
      MSG_SENT            : "msg-sent"
    },
    ERROR_MSGS : {
      EMPTY               : "Please enter your message",
      TOO_LONG            : "Max length 250"
    }
  }

  ADP.Namespace(ADP, 'ADP.Components.Classes.Feedback');
  ADP.Components.Classes.Feedback = new ADP.Class();

  ADP.Components.Classes.Feedback.include({

    init: function ($component) {
 
      this.$component             = $component;
      this.$buttonCapt            = $component.find(".btn.dropdown-toggle > .btn-capt");
      this.$items                 = $component.find(".drop-item");
      this.$floatIcon             = $component.find(".feed-float-icon");
      this.$closeIcon             = $component.find(".close-feed");
      this.$feedTextarea          = $component.find(".feed-msg");
      this.$feedTextareaError     = $component.find(".feed-msg + .err-msg");
      this.$submitBtn             = $component.find(".feed-btn");
      this.$feedBox               = $component.find(".feed-box");

      this.closeInterval          = null;
      this.sendingInterval        = null;

      this.bindEvents();
    },

    cleanForm: function() {
      this.$feedBox.removeClass(CONSTS.CSS.MSG_SENT).removeClass(CONSTS.CSS.SENDING);
      this.$feedTextarea.removeClass(CONSTS.CSS.WRONG).val("");

      this.setDropdownTitle(this.$items.first().text());
    },

    showHideFeedbox: function() {
      this.$component.toggleClass(CONSTS.CSS.OPENED);

      if (this.$component.hasClass(CONSTS.CSS.OPENED)) {
          this.cleanForm();
          this.$component.removeClass(CONSTS.CSS.CLOSED);
      } else {
          this.$component.addClass(CONSTS.CSS.CLOSED);
      }

      if (this.closeInterval) {
        clearTimeout(this.closeInterval);
        this.closeInterval = null;
      }

      if (this.sendingInterval) {
        clearTimeout(this.sendingInterval);
        this.sendingInterval = null;
      }
    },

    messageSent: function() {
      this.$feedBox.removeClass(CONSTS.CSS.SENDING).addClass(CONSTS.CSS.MSG_SENT);
      this.closeInterval = setTimeout(this.showHideFeedbox.bind(this), 5000);
    },

    submit: function() {
    // event handler of the click event of the submit button
        var _this = this;
      var val = this.$feedTextarea.val().trim();

      if (val.length == 0 || val.length > 250) {
        this.$feedTextarea.addClass(CONSTS.CSS.WRONG);

        if (val.length == 0) {
          this.$feedTextareaError.html(CONSTS.ERROR_MSGS.EMPTY);
        } else {
          this.$feedTextareaError.html(CONSTS.ERROR_MSGS.TOO_LONG);
        }
      } else {
        this.$feedTextarea.removeClass(CONSTS.CSS.WRONG);
        this.$feedBox.addClass(CONSTS.CSS.SENDING);
        var url = this.$submitBtn.data('post-url');
        jQuery.ajax({
          url: url,
          method: 'GET',
          data: {
            message: _this.$feedTextarea.val(),
            category: _this.$buttonCapt.html()
          },
          success: function(){
              _this.sendingInterval = setTimeout(_this.messageSent.bind(_this), 2000);
          }
        });
      }
    },

    bindEvents: function () {
      var _this               = this;
      var showHide            = this.showHideFeedbox.bind(this);

      this.$floatIcon.click(showHide);
      this.$closeIcon.click(showHide);

      this.$items.click(function() {
        _this.setDropdownTitle($(this).text());
      });

      this.$submitBtn.click(this.submit.bind(this));
    },

    setDropdownTitle: function(title) {
    // sets the title of the dropdown
      this.$buttonCapt.html(title);
    }
  });

  jQuery(function () {
    var $feedback = jQuery('.dv-feedback-component');

    jQuery.each($feedback, function () {
      var feedback = new ADP.Components.Classes.Feedback(jQuery(this));
    });
  });

}(ADP, jQuery));
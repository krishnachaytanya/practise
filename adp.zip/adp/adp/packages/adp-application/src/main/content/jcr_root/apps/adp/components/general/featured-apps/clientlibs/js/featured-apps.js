var CONSTANTS = {
    CAROUSEL_WRAP       : ".fa-carousel-wrapper",
    CAROUSEL            : ".fa-carousel",
    PREV_ARROW          : ".fa-prev",
    NEXT_ARROW          : ".fa-next",
    FA_ITEM             : ".fa-item",
    HIDE                : "hide"
}

function showHideArrows(carousel) {
// shows or hides the arrows of the carousel depending whether the first and last items are visisble or not
    var $carousel       = carousel.$slider;
    var $prev           = carousel.$prevArrow;
    var $next           = carousel.$nextArrow;
    var $first          = $carousel.find(CONSTANTS.FA_ITEM + ":first-of-type");
    var $last           = $carousel.find(CONSTANTS.FA_ITEM + ":last-of-type");
    
    if ($first.offset().left < $carousel.offset().left) {
        $prev.removeClass(CONSTANTS.HIDE);
    } else {
        $prev.addClass(CONSTANTS.HIDE);
    }

    if (($last.offset().left + $last.width()) > ($carousel.offset().left + $carousel.width())) {
        $next.removeClass(CONSTANTS.HIDE);
    } else {
        $next.addClass(CONSTANTS.HIDE);
    }
}

$(function() {

    $(CONSTANTS.CAROUSEL_WRAP).each(function() {
    // assigns javascript functionallity to each featured apps carousel
        var $carousel   = $(this).find(CONSTANTS.CAROUSEL);
        var $items      = $(this).find(CONSTANTS.FA_ITEM); 
        
        if ($items.length) {
            $carousel.on("init", function(e, carousel) {
                showHideArrows(carousel);

                $(window).resize(function() {
                    showHideArrows(carousel);
                });
            });

            $carousel.on("afterChange", function(e, carousel) {
                showHideArrows(carousel);
            });
        }

        $carousel.slick({
            infinite            : false,
            variableWidth       : true,
            prevArrow           : $(this).find(CONSTANTS.PREV_ARROW),
            nextArrow           : $(this).find(CONSTANTS.NEXT_ARROW)
        });
    });
});
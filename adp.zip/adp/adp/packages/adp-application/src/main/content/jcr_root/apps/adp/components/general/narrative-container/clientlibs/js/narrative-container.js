(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.NarrativeContainer');
  ADP.Components.Classes.NarrativeContainer = new ADP.Class();
  ADP.Components.Classes.NarrativeContainer.include({

    goToNextSection: function() {
    // scrolls to the following section
      var $nextSection = $(this).parents(".section.flow-frame").next();

      if ($nextSection.length) {
        $("html").animate({
          scrollTop: $nextSection.offset().top - ($("#header-container").outerHeight() + $("#global-alert").outerHeight() + 20)
        }, 300);
      }
    },
    
    setBackgroundColor: function(a, carousel, currentSlide, nextSlide) {

      if ($(carousel.$slides[nextSlide]).hasClass("bg-white")) {
        this.$narrativeContainer.addClass("white-bck");
      } else {
        this.$narrativeContainer.removeClass("white-bck");        
      }
    },

    init: function ($component) {
      this.$narrativeContainer = $component;

      // Removes the parsys inside this container accordingly
      var $slidesCount = this.$narrativeContainer.attr('data-slidesCount');
      if ($slidesCount >= 10) {
        var $parsysElement = this.$narrativeContainer.find('div.parsys');
        $parsysElement.children().eq(-2).attr('style', 'display: none !important');
      }

      this.authorMode = this.$narrativeContainer.hasClass("author-mode");
      
      if (!this.authorMode) {
        this.$narrativeContainer.find('.narrative-slider.parbase').contents().unwrap();
      }
      
      this.$firstSlide = this.$narrativeContainer.find(".narrative-slider-component").eq(0);
      this.$prevArrow = this.$narrativeContainer.find(".ns-prev");
      this.$nextArrow = this.$narrativeContainer.find(".ns-next");
      this.$firstSlideParent = this.$firstSlide ? this.$firstSlide.parent() : this.$narrativeContainer;
      this.$gotIt = this.$narrativeContainer.find(".got-it");

      this.slickConfig = {
            dots: true,
            slide: ".narrative-slider-component",
            appendArrows: this.$firstSlideParent,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            prevArrow: this.$prevArrow,
            nextArrow: this.$nextArrow,
            responsive : [
                {
                    breakpoint: 768,
                    settings: {
                        slide: ".narrative-slider-component-mobile"
                    }
                }
            ]
        };
      if(!this.authorMode) {
        this.bindEvents();
      }
    },

    bindEvents: function () {
      var _this = this;

      if(this.$firstSlide) {

          _this.$firstSlideParent.on("init", function(a, carousel) {
            _this.setBackgroundColor(a, carousel, 0, 0);
          });

          _this.$firstSlideParent.on("beforeChange", function(a, carousel, currentSlide, nextSlide) {
            _this.setBackgroundColor(a, carousel, currentSlide, nextSlide);
          });

          _this.$firstSlideParent.slick(_this.slickConfig);
      }

      this.$gotIt.click(this.goToNextSection);
    }
  });

  //jQuery Document Ready
  jQuery(function () {
    var $narrativeContainer = jQuery('.narrative-container-component');
    jQuery.each($narrativeContainer, function() {
        var narrativeContainer = new ADP.Components.Classes.NarrativeContainer(jQuery(this));
    });

  });
}(ADP, jQuery));
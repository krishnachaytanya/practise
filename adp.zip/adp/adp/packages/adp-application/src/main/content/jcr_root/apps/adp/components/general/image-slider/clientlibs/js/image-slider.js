(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.ImageSlider');
  ADP.Components.Classes.ImageSlider = new ADP.Class();
  ADP.Components.Classes.ImageSlider.include({

    CONSTS: {
        ELEMENTS: {
            ITEM            : '.carousel-item-wrapper',
            ITEMS           : '.carousel-items',
            LEFT_ARROW      : '.img-prev-slide',
            RIGHT_ARROW     : '.img-next-slide'
        },
        CSS: {
            CAROUSEL_ITEM   : 'carousel-item-wrapper',
            HIDE            : 'hide',
            FAKE_ITEM       : 'fake-item'
        }
    },

    init: function ($component) {
        this.$component             = $component;
        this.$items                 = $component.find(this.CONSTS.ELEMENTS.ITEMS);
        this.$leftArrow             = $component.find(this.CONSTS.ELEMENTS.LEFT_ARROW);
        this.$rightArrow            = $component.find(this.CONSTS.ELEMENTS.RIGHT_ARROW);
        this.$carousel              = this.$items;
        this.itemCount              = this.$items.find('.carousel-item').length;

        this.initCarousel();
        this.bindEvents();
    },

    bindEvents: function () {
        var _this = this;
        //slide incremented by slideAmount
        var slideAmount = 3;
        var lastSlideIndex = _this.itemCount - slideAmount;
        this.$carousel.on('afterChange', function(event, slick, currentSlide){
            if (lastSlideIndex === currentSlide) {
                slick.slickGoTo('initialSlide');
            }
        });

        this.$rightArrow.off().on('click', function(event){
            var currentSlide = _this.$carousel.slick('slickCurrentSlide');
            var newRightSlideIndex = currentSlide + slideAmount;
            if (newRightSlideIndex < _this.itemCount) {
                if (newRightSlideIndex > lastSlideIndex) {
                    _this.$carousel.slick('slickGoTo', lastSlideIndex);
                } else {
                    _this.$carousel.slick('slickGoTo', newRightSlideIndex);
                }
            } else {
                _this.$carousel.slick('slickGoTo','initialSlide');
            }
        });

        this.$leftArrow.off().on('click', function(event){
            var currentSlide = _this.$carousel.slick('slickCurrentSlide');
            var newLeftSlideIndex = currentSlide - slideAmount;
            if (newLeftSlideIndex === -slideAmount) {
                _this.$carousel.slick('slickGoTo',lastSlideIndex);
            } else {
                if (newLeftSlideIndex <= -1) {
                    _this.$carousel.slick('slickGoTo', 'initialSlide');
                } else {
                    _this.$carousel.slick('slickGoTo', newLeftSlideIndex);
                }
            }
        });
    },

    initCarousel: function () {
        // initialize the functionality of the carousel
        this.$carousel.slick({
            autoplay            : true,
            autoplaySpeed       : 3000,
            infinite            : false,
            initialSlide        : 0,
            nextArrow           : this.$rightArrow,
            pauseOnHover        : true,
            prevArrow           : this.$leftArrow,
            slidesToScroll      : 1,
            slidesToShow        : 3,
            speed               : 1000,
            variableWidth       : false,

            responsive: [{
                breakpoint: 767,
                settings: {
                    slidesToScroll  : 1,
                    slidesToShow    : 1,
                    centerMode      : true
                }
            }]
        });
    }
  });

  jQuery(function () {
    var $imageSlider = jQuery('.image-slider-component');

    jQuery.each($imageSlider, function() {
        var imageSlider = new ADP.Components.Classes.ImageSlider(jQuery(this));
    });
  });

}(ADP, jQuery));
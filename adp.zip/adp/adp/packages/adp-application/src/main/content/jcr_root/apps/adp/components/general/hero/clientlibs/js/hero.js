(function (ADP, jQuery) {
    'use strict';

    ADP.Namespace(ADP, 'ADP.Components.Classes.Hero');
    ADP.Components.Classes.Hero = new ADP.Class();

    ADP.Components.Classes.Hero.include({

        CONSTS: {
            ELEMENTS: {
                HEADER            : '#header-container'
            },

            CSS: {
                AUTHOR_MODE         : 'author-mode',
                NO_CONTENT_PADDING  : 'no-content-padding',
                TRANSPARENT_HEADER  : 'transparent-header'
            },

            ATTR: {
                TRANSPARENT_HEADER  : 'transparent-header'
            },

            NORMAL_HEADER         : 1,
            TRANSPARENT_HEADER    : 2
        },

        init: function ($component) {
            this.$component           = $component;
            this.$body                = $('body');
            this.$header              = $(this.CONSTS.ELEMENTS.HEADER);
            this.$window              = $(window);
            this.currentHeaderStyle   = this.CONSTS.NORMAL_HEADER;
            this.authorMode           = this.$component.hasClass(this.CONSTS.CSS.AUTHOR_MODE);

            if (!this.authorMode && this.showTransparentHeader()) {
                this.$body.addClass(this.CONSTS.CSS.NO_CONTENT_PADDING);
                this.$window.scroll(this.updateHeaderAppearance.bind(this));

                this.calculateHeaderChangeAppearancePosition();
                this.updateHeaderAppearance();
            }
        },

        updateHeaderAppearance: function() {
            // checks the position of the scroll and, if the header is over Hero component, gives the header a white
            // appareance (white font, background transparent and no shadow). Otherwise, gives the header the normal style
            var scrollPos   = this.$window.scrollTop();
            var newStyle    = scrollPos >= this.changeAppearancePosition ? this.CONSTS.NORMAL_HEADER : this.CONSTS.TRANSPARENT_HEADER;

            if (newStyle != this.currentHeaderStyle) {
                this.currentHeaderStyle = newStyle;

                if (newStyle == this.CONSTS.NORMAL_HEADER) {
                    this.$body.removeClass(this.CONSTS.CSS.TRANSPARENT_HEADER);
                } else {
                    this.$body.addClass(this.CONSTS.CSS.TRANSPARENT_HEADER);
                }
            }
        },

        calculateHeaderChangeAppearancePosition: function() {
            // calculates the position of the scroll in which the header changes its appearance (from normal to transparent)
            // That position is at the end of Hero component
            var firstHero = $('.hero-component').first();

            this.changeAppearancePosition = firstHero.offset().top + firstHero.outerHeight() - this.$header.outerHeight();
        },

        showTransparentHeader: function() {
            // checks if Hero is the first component of the page and the author choosed to show Hero
            // under transparent header. Returns true if so
            var $firstSection               = $('.section').first();
            var heroIsFirtst               = this.$component.parents('.section').is($firstSection);
            var transparentOptionSelected   = this.$component.attr(this.CONSTS.ATTR.TRANSPARENT_HEADER) == "yes";

            return heroIsFirtst && transparentOptionSelected;
        },

        scrollToNextSection: function() {
            // scrolls the page to the next section (if it exists)
            var $nextSection = this.$component.parents('.section').next();

            if ($nextSection.length) {
                $("html").animate({
                    scrollTop: $nextSection.offset().top - ($(this.CONSTS.ELEMENTS.HEADER).outerHeight() + $(this.CONSTS.ELEMENTS.GLOBAL_ALERT).outerHeight())
                }, 300);
            }
        }
    });

    jQuery(function () {
        var $Hero = jQuery('.hero-component');

        jQuery.each($Hero, function () {
            var Hero = new ADP.Components.Classes.Hero(jQuery(this));
        });
    });

}(ADP, jQuery));
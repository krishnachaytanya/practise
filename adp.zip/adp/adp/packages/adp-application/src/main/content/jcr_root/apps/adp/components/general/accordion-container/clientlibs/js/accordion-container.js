(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.AccordionContainer');
  ADP.Components.Classes.AccordionContainer = new ADP.Class();
  ADP.Components.Classes.AccordionContainer.include({

    init: function ($component) {
      this.$accordionContainer = $component;

      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;

    }

  });

  jQuery(function () {
    var $accordionContainer = jQuery('.accordion-container-component');
    jQuery.each($accordionContainer, function () {
      new ADP.Components.Classes.AccordionContainer(jQuery(this));
    });
  });
}(ADP, jQuery));
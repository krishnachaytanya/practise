(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.AccordionItem');
  ADP.Components.Classes.AccordionItem = new ADP.Class();
  ADP.Components.Classes.AccordionItem.include({

    init: function ($component) {
      this.$accordionItem = $component;
      this.$itemTitle = this.$accordionItem.find('.item-title');

      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;
      if(_this.$accordionItem.hasClass('expanded')) {
        _this.$accordionItem.children('.item-content').slideDown();
      }
      this.$itemTitle.on('click', function(e) {
        e.preventDefault();

        var $this = jQuery(this);

        $this.parent('.accordion-item-component').toggleClass('expanded');
        $this.nextAll('.item-content').slideToggle();
      });
    }

  });

  jQuery(function () {
    var $accordionItem = jQuery('.accordion-item-component');
    jQuery.each($accordionItem, function () {
      new ADP.Components.Classes.AccordionItem(jQuery(this));
    });
  });
}(ADP, jQuery));
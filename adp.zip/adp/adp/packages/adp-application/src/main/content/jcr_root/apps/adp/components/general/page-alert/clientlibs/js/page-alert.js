(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.PageAlert');
  ADP.Components.Classes.PageAlert = new ADP.Class();
  ADP.Components.Classes.PageAlert.include({

    init: function ($component) {
      this.$pageAlert = $component;
      this.hidePageAlert = sessionStorage.getItem("hidePageAlert");
      this.$alertVisible = this.$pageAlert.find("#isAlertVisible");
      this.isAlertVisible = this.$alertVisible.val() === undefined ? false : JSON.parse(this.$alertVisible.val());
      this.$pageAlertClose = this.$pageAlert.find(".page-alert-wrap .page-alert-close");
        if(this.hidePageAlert == null && this.isAlertVisible) {
            this.$pageAlert.show();
        }
      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;
      _this.$pageAlertClose.on("click",function(){
          if (window.sessionStorage) {
              sessionStorage.setItem("hidePageAlert", true);
              _this.$pageAlert.hide();
          }
      });
    }

  });

  //jQuery Document Ready
  jQuery(function () {
    var pageAlert = new ADP.Components.Classes.PageAlert(jQuery(".page-alert-component"));
  });
}(ADP, jQuery));
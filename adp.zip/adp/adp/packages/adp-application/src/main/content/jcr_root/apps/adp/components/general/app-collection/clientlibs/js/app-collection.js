(function(ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.AppCollection');
  ADP.Components.Classes.AppCollection = new ADP.Class();
  ADP.Components.Classes.AppCollection.include({
    init: function($component) {
      var _this = this
      this.currentUser = null;
      this.$appCollection = $component;
      this.$appCollectionSearch = this.$appCollection.find('.app-collection-search-form');
      this.$appGroups = this.$appCollection.find('.app-collection-group');
      this.$apps = this.$appGroups.find('.app-collection-app');
      this.$appTitles = this.$apps.find('.app-title');
      this.appsCookieKey = 'ADP-APPS';
      this.appsFromLearningLocker = [];
      this.$savedApps = jQuery('#app-drawer-container, #app-drawer-container-mobile').find('.saved-apps');
      this.bindEvents();
    },

    bindEvents: function() {
      var _this = this;
      
      jQuery(window).on('load', function() {
        if (typeof ContextHub !== 'undefined') {
          var profileStore = ContextHub.getStore('profile'),
              wmIdn = profileStore.getTree()['wm-identificationNumber'];
          
          if (typeof wmIdn !== 'undefined') {
            _this.currentUser = wmIdn;
          }
        }

        var appCookie = Cookies.get(_this.appsCookieKey);
        if (typeof appCookie !== 'undefined') {
          _this.appsFromLearningLocker = JSON.parse(appCookie).apps;
          _this.setAppsFavorited().bind(_this);
        } else {
          _this.getAppsFromServer(_this.setAppsFavorited.bind(_this));
        }
      });

      this.$apps.on('click', function(e) {
        e.preventDefault();
        var $app = jQuery(e.target).parent('.app-collection-app');
        var link = $app.data("path");
        var favorited = jQuery.inArray(link, _this.appsFromLearningLocker) < 0;
        $app.attr("data-favorite", favorited);
        var appDrawerApp = {
          appPath: $app.data('path'),
          appLink: $app.data('link'),
          appColor: $app.data('color'),
          icon: $app.data('icon'),
          title: $app.data('title')
        };

        if (favorited) {
          _this.$apps.filter('.app-collection-app[data-path="' + $app.data('path') + '"]').addClass("remove").attr('data-favorite', true);
          if (appDrawerApp.appPath && appDrawerApp.appColor && appDrawerApp.title) {
            _this.addApp(appDrawerApp);
          }
        } else {
          _this.$apps.filter('.app-collection-app[data-path="' + $app.data('path') + '"]').removeClass("remove").attr('data-favorite', false);
          _this.removeApp(link);
        }
        _this.pushAppsToServer();
      });

      this.$appCollectionSearch.on('submit', function(e) {
        e.preventDefault();
        var searchValue = jQuery(this).find('.app-collection-search-input').val();
        if (searchValue.length <= 0 || searchValue.length >= 3) {
          _this.$appGroups.removeClass('hidden');
          _this.$apps.removeClass('hidden');
        } else if (searchValue.length < 3) {
          return;
        }

        var r = new RegExp(searchValue, 'i');
        _this.$appTitles.not(function() {
          return jQuery(this).text().match(r);
        }).parents('.app-collection-app').addClass('hidden');

        _this.$appGroups.each(function() {
          var $appGroup = jQuery(this);
          // if the number of visible apps is 0, hide the group
          if ($appGroup.find('.app-collection-app').not('.hidden').length <= 0) {
            $appGroup.addClass('hidden');
          }
        });
      });
    },

    addApp: function(app) {
      var data = {apps: [app]};
      this.$savedApps.append(HBS.app(data));
    },

    removeApp: function(path) {
      this.$savedApps.find("a.app-collection-app[data-path='" + path + "']").remove();
    },

    setAppsFavorited: function() {
      for (var i = 0; i < this.appsFromLearningLocker.length; i++) {
        this.$apps.filter('.app-collection-app[data-path="' + this.appsFromLearningLocker[i] + '"]').addClass('remove').attr('data-favorite', true);
      }
    },

    getAppsFromServer: function(callback) {
      var _this = this;
      jQuery.ajax({
        url: '/bin/adp/apps/paths.json',
        method: 'GET',
        data: {
          user: _this.currentUser
        },
        success: function(data) {
          if (data['apps']) {
            _this.appsFromLearningLocker = data["apps"];
            // Cookies.set(_this.appsCookieKey, data);
            callback();          
          }
        }
      });
    },

    pushAppsToServer: function(callback) {
      var callback = typeof callback === 'undefined' ? function(){} : callback;
      var _this = this;

      this.appsFromLearningLocker = uniqueArray(jQuery.map(this.$apps, function(app) {
        var $app = jQuery(app);
        if ($app.attr("data-favorite") === 'true') {
          return $app.data("path");
        }
      }));

      jQuery.ajax({
        url: '/bin/adp/apps/paths.json',
        method: 'PUT',
        data: {
          apps: this.appsFromLearningLocker,
          user: this.currentUser
        },
        success: function(data) {
          // Cookies.set(_this.appsCookieKey, {'apps': _this.appsFromLearningLocker});
          callback(data);
        }
      });
    }
  });

  jQuery(function() {
    var $appCollection = jQuery('.app-collection-component');
    jQuery.each($appCollection, function() {
      new ADP.Components.Classes.AppCollection(jQuery(this));
    });
  });
}(ADP, jQuery));
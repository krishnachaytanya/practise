(function (ADP, jQuery) {
	'use strict';
	ADP.Namespace(ADP, 'ADP.Components.Classes.DropDownList');
	ADP.Components.Classes.DropDownList = new ADP.Class();
	ADP.Components.Classes.DropDownList.include({
		init: function ($component) {
			this.$dropDownList = $component;
			this.bindEvents();
		},
		bindEvents: function () {
			var _this = this;
			_this.$dropDownList.on("click", function(e){
				var mainTitle = $(e.target);
				mainTitle.parent().toggleClass("open");
			});
		}
	});
	//jQuery Document Ready
	jQuery(function () {
		var dropDownList = new ADP.Components.Classes.DropDownList(jQuery(".drop-down-list"));
		});
}(ADP, jQuery));
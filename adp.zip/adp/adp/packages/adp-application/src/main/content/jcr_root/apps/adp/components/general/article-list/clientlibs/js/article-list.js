(function (ADP, jQuery) {
  'use strict';

  ADP.Namespace(ADP, 'ADP.Components.Classes.ArticleList');
  ADP.Components.Classes.ArticleList = new ADP.Class();
  
  ADP.Components.Classes.ArticleList.include({

    init: function ($component) {
      this.$articleList           = $component;
      this.$articles              = this.$articleList.find('.article');
      this.$articleListMoreLink   = this.$articleList.find('.article-list-more a');
      this.seeMorePagination      = $component.hasClass("see-more-pagination");

      this.bindEvents();
    },

    showMore: function(e) {
    // shows five more items
      e.preventDefault();

      var $hiddenArticles = this.$articles.not('.show');

      if ($hiddenArticles.length) {
        $hiddenArticles.slice(0, 5).addClass('show');
      }

      $hiddenArticles = this.$articles.not('.show');

      if (!$hiddenArticles.length) {
        this.$articleListMoreLink.addClass('hidden');
      }
    },

    showAll: function() {
    // shows all the items of the list
      this.$articles.addClass("show");
      this.$articleListMoreLink.addClass('hidden');
    },

    bindEvents: function () {

      if (this.seeMorePagination) {
        this.$articleListMoreLink.click(this.showMore.bind(this));
      } else {
        this.$articleListMoreLink.click(this.showAll.bind(this));
      }
    }
  });

  jQuery(function () {
    var $articleList = jQuery('.article-list-component');

    jQuery.each($articleList, function () {
      var articleList = new ADP.Components.Classes.ArticleList(jQuery(this));
    });
  });

}(ADP, jQuery));
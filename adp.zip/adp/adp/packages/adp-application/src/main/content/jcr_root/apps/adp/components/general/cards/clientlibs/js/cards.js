'use strict';
var App = (function(self) {
  var $select = $('[name="./show"]');
	self.tabsFunction = function(valueSelect,tabs) {
        if(valueSelect=='card-two-column'){
				$(tabs[3]).hide();
                $(tabs[4]).hide();
            }
            if(valueSelect=='card-three-column'){
				console.log(valueSelect);
                $(tabs[3]).show();
                $(tabs[4]).hide();
            }
            if(valueSelect=='card-four-column'){
				$(tabs[3]).show();
                $(tabs[4]).show();
            }
    };
    self.init = function() {
        $(document).on("selected",$select, function(e) {
			var valueSelect = $('[name="./show"]').val();
            var $form = $('.cq-dialog');
			var tabs = $form.find('.coral-TabPanel-tab');
            self.tabsFunction(valueSelect,tabs);
        });
        $(document).on("dialog-ready", function(){
            var $dialog = $('.cq-dialog');
            if($dialog.find(".tab-configuration-tile").length >0){
                var tabs = $dialog.find('.coral-TabPanel-tab');
                 var actionUrl = $dialog.attr("action")+".infinity.json";
                $.ajax({
                    type: 'GET', 
                    url:actionUrl,

                  }).done(function( data ) {
                    postProcesss(data)
                });
                function postProcesss(data){
                     self.tabsFunction(data.show,tabs);
                }
			}
        });
    };
    return self;
})(App || {}).init();
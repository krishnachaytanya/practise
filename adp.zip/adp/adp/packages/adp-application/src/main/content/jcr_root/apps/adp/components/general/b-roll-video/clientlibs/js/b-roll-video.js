(function (ADP, jQuery) {
  'use strict';

  ADP.Namespace(ADP, 'ADP.Components.Classes.BRoll');
  ADP.Components.Classes.BRoll = new ADP.Class();

  ADP.Components.Classes.BRoll.include({

    CONSTS: {
      ELEMENTS: {
        VIDEO             : '.b-roll-video',
        HEADER            : '#header-container',
        PAGE_ALERT        : '#isAlertVisible',
        GLOBAL_ALERT      : '#global-alert',
        PLAY_BUTTON       : '.b-roll-play',
        DOWN_ARROW        : '.b-roll-down-arr'
      },

      CSS: {
        AUTHOR_MODE         : 'author-mode',
        NO_CONTENT_PADDING  : 'no-content-padding',
        TRANSPARENT_HEADER  : 'transparent-header',
        BROLL_SECTION       : 'b-roll-section'
      },

      ATTR: {
        TRANSPARENT_HEADER  : 'transparent-header'
      },

      MIN_RES_DESKTOP       : 768,
      NORMAL_HEADER         : 1,
      TRANSPARENT_HEADER    : 2,
      GLOBAL_ALERT_HEIGHT   : 68  
    },

    init: function ($component) {
      this.$component           = $component;
      this.$video               = $component.find(this.CONSTS.ELEMENTS.VIDEO);
      this.$playButton          = $component.find(this.CONSTS.ELEMENTS.PLAY_BUTTON);
      this.$downArrow           = $component.find(this.CONSTS.ELEMENTS.DOWN_ARROW);
      this.$body                = $('body');
      this.$header              = $(this.CONSTS.ELEMENTS.HEADER);
      this.$window              = $(window);
      this.currentHeaderStyle   = this.CONSTS.NORMAL_HEADER;
      this.pageAlertVisible     = $(this.CONSTS.ELEMENTS.PAGE_ALERT).val() == 'true';
      this.globalAlertVisible   = $(this.CONSTS.ELEMENTS.GLOBAL_ALERT).length > 0;
      this.authorMode           = this.$component.hasClass(this.CONSTS.CSS.AUTHOR_MODE);
      this.thereIsVideo         = typeof videojs != 'undefined';

      this.initVideoPlayer();

      if (!this.authorMode && this.showTransparentHeader()) {
        this.$body.addClass(this.CONSTS.CSS.NO_CONTENT_PADDING);
        this.$window.scroll(this.updateHeaderAppearance.bind(this));

        this.calculateHeaderChangeAppearancePosition();
        this.updateHeaderAppearance();
      }

      this.$playButton.click(this.switchToFullsceen.bind(this));
      this.$downArrow.click(this.scrollToNextSection.bind(this));
    },

    initVideoPlayer: function() {
    // auto play video on page load if:
    //    - it's desktop
    //    - it's not in author mode
      if (!this.thereIsVideo) {
        return;
      }

      var _this             = this;
      var autoPlayVideo     = !this.authorMode && $(window).width() > this.CONSTS.MIN_RES_DESKTOP;
                          
      videojs(this.$video.attr('id')).ready(function(){  
        _this.player = this;   
        _this.player.controls(false);
        _this.player.muted(true);

        _this.player.on('fullscreenchange', _this.fullscreenChange.bind(_this));
        _this.player.on('playing', _this.calculateHeaderChangeAppearancePosition.bind(_this));

        if (autoPlayVideo) {
          _this.player.play();
        }
      });
    },

    updateHeaderAppearance: function() {
    // checks the position of the scroll and, if the header is over broll component, gives the header a white
    // appareance (white font, background transparent and no shadow). Otherwise, gives the header the normal style
      var scrollPos   = this.$window.scrollTop();
      var newStyle    = scrollPos >= this.changeAppearancePosition ? this.CONSTS.NORMAL_HEADER : this.CONSTS.TRANSPARENT_HEADER;

      if (newStyle != this.currentHeaderStyle) {
        this.currentHeaderStyle = newStyle;

        if (newStyle == this.CONSTS.NORMAL_HEADER) {
          this.$body.removeClass(this.CONSTS.CSS.TRANSPARENT_HEADER);
        } else {
          this.$body.addClass(this.CONSTS.CSS.TRANSPARENT_HEADER);
        }
      }
    },

    calculateHeaderChangeAppearancePosition: function() {
    // calculates the position of the scroll in which the header changes its appearance (from normal to transparent)
    // That position is at the end of broll component
      if (this.player && this.player.isFullscreen()) {
        return;
      }

      var firstBroll = $('.b-roll-video-comp').first();

      this.changeAppearancePosition = firstBroll.offset().top + firstBroll.outerHeight() - this.$header.outerHeight();
    
      if (this.globalAlertVisible) {
        this.changeAppearancePosition -= this.CONSTS.GLOBAL_ALERT_HEIGHT;
      }
    },

    showTransparentHeader: function() {
    // checks if broll is the first component of the page and the author choosed to show b-roll
    // under transparent header. Returns true if so
      var $firstSection               = $('.section').first();
      var brollIsFirtst               = this.$component.parents('.section').is($firstSection);
      var transparentOptionSelected   = this.$component.attr(this.CONSTS.ATTR.TRANSPARENT_HEADER) == "yes";

      return brollIsFirtst && transparentOptionSelected && !this.pageAlertVisible;
    },

    switchToFullsceen: function() {
    // makes the video fullscreen
      if (this.player) {
        this.player.requestFullscreen();
      }
    },

    setControlsVisibility: function() {
    // shows video controls only on fullscreen
      this.player.controls(this.player.isFullscreen());
    },

    fullscreenChange: function() {
    // executed when fullscreen mode is toggled to or from. Executes video on fullscreen or in desktop. Otherwise
    // stops it 
      var isOnFullscreen = this.player.isFullscreen();

      this.setControlsVisibility();
      this.player.muted(!isOnFullscreen);

      if (isOnFullscreen) {
        this.player.play();
      } else {
        if (this.$window.width() > this.CONSTS.MIN_RES_DESKTOP) {
          this.player.play();
        } else {
          this.player.pause();
        }
      }
    },

    scrollToNextSection: function() {
    // scrolls the page to the next section (if it exists)
      var $nextSection = this.$component.parents('.section').next();

      if ($nextSection.length) {
        $("html").animate({
          scrollTop: $nextSection.offset().top - ($(this.CONSTS.ELEMENTS.HEADER).outerHeight() + $(this.CONSTS.ELEMENTS.GLOBAL_ALERT).outerHeight())
        }, 300);
      }
    }
  });

  jQuery(function () {
    var $BRoll = jQuery('.b-roll-video-comp');

    jQuery.each($BRoll, function () {
      var BRoll = new ADP.Components.Classes.BRoll(jQuery(this));
    });
  });

}(ADP, jQuery));



(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.LearningCheckList');
  ADP.Components.Classes.LearningCheckList = new ADP.Class();
  ADP.Components.Classes.LearningCheckList.include({

    init: function ($component) {
      this.$learningCheckList = $component;
      this.$checkListCheckbox = this.$learningCheckList.find(".checkList-checkbox");

      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;
      this.$checkListCheckbox.click(function(){
           $(this).toggleClass("check-off");
            $(this).toggleClass("check-on");
        });
     
    }

  });

  jQuery(function () {
    var $checkList = jQuery('.learning-checklist-component');
    jQuery.each($checkList, function () {
      var checkList = new ADP.Components.Classes.LearningCheckList(jQuery(this));
    });
  });
}(ADP, jQuery));


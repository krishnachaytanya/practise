function durationFieldBlur(e) {
// event handler of the blur evenet of the duration field. Checks if the value entered is valid.
// If itsn't, adds a red border to the field
  var $element    = $(e.target);
  var val         = $element.val();
  var converted   = convertToHHMMSS(val);

  if (converted) {
    $element.val(converted);
  }
}

function format00(val) {
// returns the received value (an integer) with at least two digits
  if (val < 10) {
    return "0" + val;
  }

  return val;
}

function convertToHHMMSS(val) {
// tries to convert the received value to format HH:MM:SS. Returns the converted value (if it can be
// done), null in other case
  var time        = val.split(":");
  var cantPoints  = time.length - 1;
  var ok          = false;
  var numbers     = /^[0-9]+$/;
  var t1, t2, t3;

  if (time.length <= 3) {

    t1 = time[0];
    t2 = time[1] || "0";
    t3 = time[2] || "0";
    
    if (t1.match(numbers) && t2.match(numbers) && t3.match(numbers)) {
      t1 = parseInt(t1);
      t2 = parseInt(t2);
      t3 = parseInt(t3);

      if (cantPoints == 0) {
        ok = true;
      } else if (cantPoints == 1 && t2 < 60) {
        ok = true;
      } else if (t2 < 60 && t3 < 60) {
        ok = true;
      }
    }
  } 

  if (ok) {
    var hh, mm, ss;

    if (cantPoints == 2) {
      hh = t1;
      mm = t2;
      ss = t3;

    } else if (cantPoints == 1) {
      hh = Math.floor(t1 / 60);
      mm = t1 % 60;
      ss = t2;

    } else {
      hh = Math.floor(t1 / 3600);
      mm = Math.floor((t1 - 3600 * hh) / 60);
      ss = t1 - 3600 * hh - 60 * mm;
    }

    return format00(hh) + ":" + format00(mm) + ":" + format00(ss);

  } else {
    return null;
  }
}

function assignDurationFieldHandlers($element) {
// assigns the neccesary event handlers to the received $element to work as a duration field

  $element.off("blur");
  $element.blur(durationFieldBlur);
}

// validation for duration field
jQuery.validator.register({
  selector: "[data-duration-validation]",
  validate: function($element) {
    var val = $element.val();

    if (val.trim() != "" && !convertToHHMMSS(val)) {
      return "Invalid duration. It should be entered in format HH:MM:SS or in seconds";
    }

    return;
  }
});
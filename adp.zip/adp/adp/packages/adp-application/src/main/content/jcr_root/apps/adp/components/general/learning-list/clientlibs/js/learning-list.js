(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.LearningList');
  ADP.Components.Classes.LearningList = new ADP.Class();
  ADP.Components.Classes.LearningList.include({

    init: function ($component) {
      this.$learningList = $component;
      this.$filterWrapper = this.$learningList.find("ul.learning-list-filter");
      this.$showMore = this.$learningList.find('.learning-list-more a').first();
      this.bindEvents();
    },

    bindEvents: function () {
      var _this = this;

      _this.$filterWrapper.on('click', 'li.learning-list-filter-item.active, li.open-filters', function() {
          _this.$filterWrapper.children('li:not(.active)').toggleClass("expand");
          if(!_this.$filterWrapper.children('li').hasClass('expand')) {
              _this.$filterWrapper.removeClass('filters-open');
          } else {
              _this.$filterWrapper.addClass('filters-open');
          }
       });
      _this.$filterWrapper.on('click', 'li.learning-list-filter-item:not(.active)', function(e){
          var $clicked = jQuery(e.target);
          _this.$filterWrapper.children().removeClass('expand');
          $clicked.siblings().removeClass('active');
          $clicked.addClass('active');
          if(!_this.$filterWrapper.children('li').hasClass('expand')) {
              _this.$filterWrapper.removeClass('filters-open');
          } else {
              _this.$filterWrapper.addClass('filters-open');
          }
      });
      _this.$showMore.on('click', function(){
            console.log('TO-DO: CALL ALL RESULTS');
      });
    }
  });

  jQuery(function () {
    var $LearningList = jQuery('.learning-list-component');
    jQuery.each($LearningList, function () {
      var learningList = new ADP.Components.Classes.LearningList(jQuery(this));
    });
  });
}(ADP, jQuery));
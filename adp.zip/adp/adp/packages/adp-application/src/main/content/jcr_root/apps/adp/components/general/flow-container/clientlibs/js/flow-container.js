(function (ADP, jQuery) {
  'use strict';

  ADP.Namespace(ADP, 'ADP.Components.Classes.LearningFlowContainer');
  ADP.Components.Classes.LearningFlowContainer = new ADP.Class();

  ADP.Components.Classes.LearningFlowContainer.include({

    init: function ($component) {
 
      this.$component             = $component;
      this.$header                = $("#header-container");
      this.$globalAlert           = $("#global-alert");
      this.$navigation            = $component.find(".lng-navigation");
      this.$button                = $component.find(".btn.dropdown-toggle");
      this.$buttonCapt            = $component.find(".btn.dropdown-toggle > .btn-capt");
      this.$items                 = $component.find(".drop-item");
      this.$itemsCheckbox         = $component.find(".drop-check");
      this.$firstFrame            = $(".section.flow-frame").first();
      this.$lastFrame             = $(".section.flow-frame").last();
      this.$downArrow             = $component.find(".scroll-next");
      this.$frames                = $component.find(".section.flow-frame");
      this.$dropDownMenu          = $component.find("ul.dropdown-menu");
      this.$dropDownArrow         = $component.find(".dropdown .down-arr");

      this.enableDisableDropdown();
      this.removeHeaderShadow();
      this.showHideDownArrow();
      this.bindEvents();
    },

    enableDisableDropdown: function() {
    // enables/disables dropdown options depending wether there are options to show or not
      if (!this.$dropDownMenu.children().length) {
        this.$button.attr("data-toggle", "");
        this.$dropDownArrow.hide();
      }
    },
    
    showHideDownArrow: function() {
    // shows or hides the down arrow depending on the position of the scroll. If the last frame 
    // is visible, hides the down arrow, otherwise, shows it  
      var scrollPos   = $(document).scrollTop();
      var winHeight   = $(window).height();
      var docHeight   = $(document).height();
      var hOffset     = this.getHeaderOffset();

      if (!this.$lastFrame.length || 
          (scrollPos + winHeight == docHeight) ||
          (scrollPos + hOffset < this.$firstFrame.offset().top) ||
          (scrollPos + hOffset >= this.$lastFrame.offset().top)) {
        this.$downArrow.hide();
      } else {
        this.$downArrow.show();
      }
    },

    scrollToNextFrame: function() {
    // scrolls the page to the next frame
      this.scrollToFrame(this.getCurrentFrame().next());
    },

    scrollToFrame: function($frame) {
    // scrolls the page to the received frame
      var offset = this.getHeaderOffset();

      $("html,body").animate({
        scrollTop: $frame.offset().top - offset
      }, 300);
    },

    frameClick: function($item) {
    // event handler of the click event of the items. Sets the text of clicked item as the label of the
    // drodown
      var $frame = $("#" + $item.attr("frame-id"));

      this.scrollToFrame($frame);
    },

    onScroll: function() {
      if (this.$lastFrame.length)  {
        this.showHideDownArrow();
        this.setDropdownTitle(this.getCurrentFrame().children(".flow-frame-component").attr("title"));
        this.setDropdownCheckbox(this.getCurrentFrame());
      }
    },

    onLoad: function () {
      this.setDropdownCheckbox(this.getCurrentFrame());
    },

    bindEvents: function () {
      var _this           = this;
      var scrollFunc      = this.onScroll.bind(this);
      var loadFunc        = this.onLoad.bind(this);

      this.$items.click(function() {
		$('.drop-item').removeClass('checked-item');
        $(this).addClass('checked-item');
        $('.btn.btn-primary.dropdown-toggle').find('span').text($(this).find('span').text());
        _this.frameClick($(this));
      });

      this.$downArrow.click(this.scrollToNextFrame.bind(this));

      $(document).scroll(scrollFunc);
      $(window).resize(scrollFunc);
      $(window).on('load', loadFunc)
    },

    removeHeaderShadow: function() {
    // removes the bottom shadow of the header
      $("#header-container").css("boxShadow", "none");
    },

    getHeaderOffset: function() {
      return this.$globalAlert.outerHeight() + this.$header.outerHeight() + this.$navigation.outerHeight() + 20;
    },

    getCurrentFrame: function() {
    // returns the currently visible frame
      var found         = false;
      var scrollPos     = $(document).scrollTop() + this.getHeaderOffset();
      var $cFrame;

      this.$frames.each(function() {
        if (found) {
          return;
        }

        $cFrame       = $(this);
        var top       = $cFrame.offset().top;
        // trigger change when next frame is scrolled to 20% from the top of the viewport
        var twentyDown = scrollPos + ($(window).height() * 0.2);
        
        found = top <= twentyDown && top + $cFrame.outerHeight() > twentyDown;
      });

      return $cFrame;
    },

    setDropdownTitle: function(title) {
    // sets the title of the dropdown
      this.$buttonCapt.html(title);
    },

    setDropdownCheckbox: function ($element) {
      var id = $element.find('.flow-frame-component').attr('id');
      $('.drop-item[frame-id="' + id + '"]').addClass('checked-item');
    }
  });

  jQuery(function () {
    var $learningFlowContainer = jQuery('.lng-flow-container-component');

    jQuery.each($learningFlowContainer, function () {
      var learningFlowContainer = new ADP.Components.Classes.LearningFlowContainer(jQuery(this));
    });
  });

}(ADP, jQuery));
(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.Contact-Info');
  ADP.Components.Classes.ContactInfo = new ADP.Class();
  ADP.Components.Classes.ContactInfo.include({

    init: function ($component) {
      this.profile = ContextHub.getStore('profile');
      this.$contactInfo = $component;
      this.$userName = this.$contactInfo.find('.name');
      this.$title = this.$contactInfo.find('.title');
      this.$department = this.$contactInfo.find('.department');
      this.$contactInfoInitials = this.$contactInfo.find('.contact-info-initials');
      this.$profileEmail = this.$contactInfo.find('.profile-email');
      this.$profilePhone1 = this.$contactInfo.find('.profile-phone-1');
      this.$profilePhone2 = this.$contactInfo.find('.profile-phone-2');
      this.$profileUserID = this.$contactInfo.find('.profile-user-id');
      this.$profileSlack = this.$contactInfo.find('.profile-slack');

      this.bindEvents();

    },

    bindEvents: function () {
      var _this = this;
      var defaultWMUser = "Walmart Associate";

      if(_this.profile !== null) {
        _this.userID = _this.profile.getItem('sAMAccountName');
        _this.jobTitle = _this.profile.getItem('jobTitle');
        _this.displayName = _this.profile.getItem('displayName');
        if(_this.displayName == "anonymous"){
          this.displayName = defaultWMUser;
        }
        var nameArray = _this.displayName.split(" ");
      }else {
        _this.displayName = defaultWMUser;
      }


      if(nameArray.length){
        var firstInitial = nameArray[0].substring(0,1);
        var secondInitial = nameArray[nameArray.length-1].substring(0,1);
        _this.initialIcon = firstInitial+secondInitial;
      }else {
        _this.initialIcon = "WA";
      }

      jQuery(window).on('load', function() {
        if(_this.userID !== null) {
          _this.$profileUserID.parent().removeClass('hidden');
          _this.$profileUserID.text(_this.userID);
        }
        _this.$userName.text(_this.displayName);
        _this.$contactInfoInitials.text(_this.initialIcon);
        if(_this.jobTitle !== null){
          _this.$title.text(_this.jobTitle);
        }

      });
     }

  });

  jQuery(function () {
    var $contactInfo = jQuery('.contact-info-component');
    if ($contactInfo.length) {
        var contactInfo = new ADP.Components.Classes.ContactInfo($contactInfo);
    }
  });
}(ADP, jQuery));
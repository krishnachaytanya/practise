(function (ADP, jQuery) {
  'use strict';
  ADP.Namespace(ADP, 'ADP.Components.Classes.EventList');
  ADP.Components.Classes.EventList = new ADP.Class();
  ADP.Components.Classes.EventList.include({

    init: function ($component) {
      this.$component             = $component;
      this.$buttonCapt            = $component.find(".btn.dropdown-toggle > .btn-capt");
      this.$items                 = $component.find(".drop-item");
      this.$events                = $component.find(".event");
      this.$eventsList            = $component.find(".event-list-items");
      this.$noResults             = $component.find(".no-results");
 
      this.bindEvents();
      this.showHideNoResultsText();
    },

    bindEvents: function () {
      var _this = this;

      this.$items.click(function() {
        var $clickedItem = $(this);

        _this.setDropdownTitle($clickedItem.text());
        _this.filter($clickedItem.attr("data-tag"));
      });
    },

    setDropdownTitle: function(title) {
    // sets the title of the dropdown
      this.$buttonCapt.html(title);
    },

    filter: function(tag) {
    // filters the list of events by the received tag
      var selector = "[data-tags~=" + tag + "]";

      if (tag == "all") {
        this.$events.removeClass("hide");  
      } else {

        this.$events.each(function() {
          var $event = $(this);

          if ($event.is(selector)) {
            $event.removeClass("hide");
          } else {
            $event.addClass("hide");
          }
        });
      }

      this.showHideNoResultsText();
    },

    showHideNoResultsText: function() {
    // shows or hides "No results found" text depending on whether there are results to show or not
      var $notHiddenEvents = this.$eventsList.find(".event:not(.hide)");

      if ($notHiddenEvents.length) {
        this.$component.removeClass("no-events");
      } else {
        this.$component.addClass("no-events");
      }
    }
  });

  jQuery(function () {
    var $eventList = jQuery('.event-list-component');

    jQuery.each($eventList, function () {
      var eventList = new ADP.Components.Classes.EventList(jQuery(this));
    });
  });

}(ADP, jQuery));
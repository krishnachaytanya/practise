package com.adobe.aem.intranet.models;

public interface Image {

	String getPagePath();

}

package com.adobe.aem.intranet.models;

import com.adobe.aem.intranet.core.beans.FourBoxHelper;

public interface FourBox {

	FourBoxHelper getFourBoxElements();

}
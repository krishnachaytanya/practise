package com.adobe.aem.intranet.models.impl;

import com.adobe.aem.intranet.models.SocialShare;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Model(adaptables = SlingHttpServletRequest.class, adapters = SocialShare.class, resourceType = "intranet/components/content/social-page-share")

public class SocialShareImpl implements SocialShare {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private String publishLink;

    @ScriptVariable
    private Page currentPage;

    @SlingObject
    private ResourceResolver resourceResolver;


    @PostConstruct
    private void initModel() {
        setValues();
    }

    public String getPublishLink() {
        return safeURLEncode(publishLink);
    }

    public void setValues() {
        Externalizer externalizer = resourceResolver.adaptTo(Externalizer.class);
        if(externalizer != null){
            publishLink = externalizer.externalLink(resourceResolver, "publish", currentPage.getPath() + ".html");
        }
    }

    private String safeURLEncode(String string){
        if(string != null){
            try {
                return URLEncoder.encode(string, StandardCharsets.UTF_8.name()).replace("+", "%20");
            }
            catch (UnsupportedEncodingException e){
                log.error("Exception", e);
            }
        }
        return null;
    }

}
package com.adobe.aem.intranet.core.beans;

import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BannerHelper {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
	private String bannerImage;
	private String bannerImageAltText;
	private String bannerLink;
	private String bannerWeight;
	private Calendar offTime;
	private Calendar onTime;
	
	
	public String getBannerImage() {
		return bannerImage;
	}
	public void setBannerImage(String bannerImage) {
		this.bannerImage = bannerImage;
	}
	public String getBannerImageAltText() {
		return bannerImageAltText;
	}
	public void setBannerImageAltText(String bannerImageAltText) {
		this.bannerImageAltText = bannerImageAltText;
	}
	public String getBannerLink() {
		return bannerLink;
	}
	public void setBannerLink(String bannerLink) {
		this.bannerLink = bannerLink;
	}
	public String getBannerWeight() {
		return bannerWeight;
	}
	public void setBannerWeight(String bannerWeight) {
		this.bannerWeight = bannerWeight;
	}
	public Calendar getOffTime() {
		return offTime;
	}
	public void setOffTime(Calendar calendar) {
		this.offTime = calendar;
	}
	public Calendar getOnTime() {
		return onTime;
	}
	public void setOnTime(Calendar onTime) {
		this.onTime = onTime;
	}

	
	
}

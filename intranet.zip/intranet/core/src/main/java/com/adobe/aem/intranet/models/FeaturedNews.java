package com.adobe.aem.intranet.models;
import com.day.cq.wcm.api.Page;

import java.util.List;
public interface FeaturedNews {
	List<Page> getPages();
}

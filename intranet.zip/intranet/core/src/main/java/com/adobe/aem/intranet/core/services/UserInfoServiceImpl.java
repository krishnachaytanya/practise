package com.adobe.aem.intranet.core.services;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.bson.Document;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.models.User;
import com.adobe.aem.intranet.models.UserFavorite;
import com.adobe.aem.intranet.models.impl.UserFavoriteImpl;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

@Component(label = "US Bank User Information Service", description = "US Bank User Information Service", metatype = true, immediate = true)
@Service(value = { UserInfoService.class })
@Properties({
		@Property(name = "photoURL", value = "", description = "URL for photos"),
		@Property(name = "photoURLSuffix", value = "", description = "Suffix for small resolution photo"),
		@Property(name = "photoURLSuffixLarge", value = "", description = "Suffix for large resolution photo"),
		@Property(name = "quickLinksNode", value = "", description = "Node where initial default links are configured") })
public class UserInfoServiceImpl implements UserInfoService {

	@Reference
	private DBService dBService;

	@Reference
	private ResourceResolverFactory resolverFactory;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	@SuppressWarnings("rawtypes")
	Dictionary properties = null;

	private String PHOTO_URL = null;
	private String PHOTO_SUFFIX = null;
	private String PHOTO_SUFFIX_LARGE = null;
	private String QUICK_LINKS_NODE = null;

	@Activate
	public void activate(ComponentContext componentContext) throws Exception {

		this.properties = componentContext.getProperties();
		this.PHOTO_URL = (String) properties.get("photoURL");
		this.PHOTO_SUFFIX = (String) properties.get("photoURLSuffix");
		this.PHOTO_SUFFIX_LARGE = (String) properties
				.get("photoURLSuffixLarge");
		this.QUICK_LINKS_NODE = (String) properties.get("quickLinksNode");
	}

	@Override
	public User getUser(String userId) {
		
		User user = new User();
		user.setUserId(userId);
		Node userNode = getUserNode(userId);

		if (userNode != null) {
			try {

				javax.jcr.Property p = null;

				if (userNode.hasProperty("nickname") && !userNode.getProperty("nickname").getString().isEmpty()) {
					user.setNickName(userNode.getProperty("nickname")
							.getString());
				}
				if (userNode.hasProperty("firstName") && !userNode.getProperty("firstName").getString().isEmpty()) {
					user.setFirstName(userNode.getProperty("firstName")
							.getString());
				}
				if (userNode.hasProperty("lastName") && !userNode.getProperty("lastName").getString().isEmpty()) {
					user.setLastName(userNode.getProperty("lastName")
							.getString());
				}
				if (userNode.hasProperty("HashedUser") && !userNode.getProperty("HashedUser").getString().isEmpty()) {
					user.setHashedUser(userNode.getProperty("HashedUser")
							.getString());
				}
				if (userNode.hasProperty("City") && !userNode.getProperty("City").getString().isEmpty()) {
					user.setCity(userNode.getProperty("City").getString());
				}
				if (userNode.hasProperty("State") && !userNode.getProperty("State").getString().isEmpty()) {
					user.setState(userNode.getProperty("State").getString());
				}
				if (userNode.hasProperty("country") && !userNode.getProperty("country").getString().isEmpty()) {
					user.setCountry(userNode.getProperty("country").getString());
				}
				if (userNode.hasProperty("MailLocationCD") && !userNode.getProperty("MailLocationCD").getString()
						.isEmpty()) {
					user.setMailCode(userNode.getProperty("MailLocationCD")
							.getString());
				}
				if (userNode.hasProperty("BusinessLine") && !userNode.getProperty("BusinessLine").getString().isEmpty()) {
					user.setBusinessLine(userNode.getProperty("BusinessLine")
							.getString());
				}
				if (userNode.hasProperty("AddressLine1") && !userNode.getProperty("AddressLine1").getString().isEmpty()) {
					user.setAddressLine1(userNode.getProperty("AddressLine1")
							.getString());
				}
				if (userNode.hasProperty("AddressLine2") && !userNode.getProperty("AddressLine2").getString().isEmpty()) {
					user.setAddressLine2(userNode.getProperty("AddressLine2")
							.getString());
				}

			} catch (RepositoryException e) {
				log.error(e.getMessage(), e);
			}
		}
		user.setPhoto(PHOTO_URL + userId + PHOTO_SUFFIX);
		user.setPhotoLarge(PHOTO_URL + userId + PHOTO_SUFFIX_LARGE);
		user.setSelectedTags(getDBValue(userId, "tags"));
		user.setFavorites(getFavorites(userId));
		
		return user;

	}

	private List<UserFavorite> getFavorites(String userId) {
		List<UserFavorite> favorites = new ArrayList<UserFavorite>();

		String userFavs = getDBValue(userId, "favorites");
		if (!userFavs.isEmpty()) {
			String[] favoriteList = userFavs.split(",");
			for (int i = 0; i < favoriteList.length; i++) {
				if (favoriteList[i].split("::").length > 1) {
					favorites.add(new UserFavoriteImpl(
						favoriteList[i].split("::")[0], favoriteList[i]
								.split("::")[1]));
				}
			}
		}

		if (favorites.size() < 3) {
			
			Node linksNode = getNode(QUICK_LINKS_NODE);

			if (linksNode != null) {
				NodeIterator children = null;

				try {
					children = linksNode.getNodes();

					while (children.hasNext()) {
						Node child = (Node) children.next();
						favorites.add(new UserFavoriteImpl(child.getProperty(
								"name").getString()
								+ "_DEFAULT", child.getProperty("url")
								.getString()));
						if (favorites.size() == 3) {
							break;
						}
					}
				} catch (RepositoryException e) {
					log.error(e.getMessage(), e);
				}
			} 			
		}

		return favorites;
	}

	private Node getUserNode(String userId) {
		if (userId == null || userId.length() < 1)
			return null;
		Node userNode = null;

		String path = "/etc/users/";

		String topFolder = userId.split("")[0].toLowerCase();

		if (topFolder.equals("c") && userId.split("")[1].matches("\\d")) {
			topFolder += userId.split("")[1];
		}

		String secondLevelFolder = userId.toLowerCase();

		if (secondLevelFolder.matches("^c\\d+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 5);
		} else if (secondLevelFolder.matches("^\\w+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 3);
		}

		userNode = getNode(path + topFolder + "/" + secondLevelFolder + "/"
				+ userId);

		return userNode;
	}

	private Node getNode(String path) {
		Node node = null;

		ResourceResolver resourceResolver;
		try {

			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "readService");
			resourceResolver = resolverFactory
					.getServiceResourceResolver(param);

			Resource resource = resourceResolver.getResource(path);
			if (resource != null) {
				node = resource.adaptTo(Node.class);

			}

		} catch (LoginException e) {
			log.error(e.getMessage(), e);
		}
		return node;
	}

	private String getDBValue(String userId, String name) {
		StringBuilder values = new StringBuilder();

		try {
			MongoClient mongo = dBService.getConnection();

			if (mongo != null) {
				MongoDatabase db = mongo.getDatabase("intranet");

				MongoCollection<Document> table = db.getCollection("users");

				Document searchQuery = new Document();
				searchQuery.put("uid", userId);

				FindIterable<Document> cursor = table.find(searchQuery);

				MongoCursor<Document> it = cursor.iterator();

				if (it.hasNext()) {
					Document user = it.next();

					if (user.containsKey(name)) {
						values.append(user.get(name));
					}
				}

				mongo.close();
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return values.toString();
	}
}

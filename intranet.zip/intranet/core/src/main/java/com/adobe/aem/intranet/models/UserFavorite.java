package com.adobe.aem.intranet.models;

public interface UserFavorite {
	String getName();
	
	String getUrl();
}

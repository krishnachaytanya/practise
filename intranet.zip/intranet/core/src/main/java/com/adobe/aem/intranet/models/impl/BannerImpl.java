package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;

import com.adobe.aem.intranet.core.beans.BannerHelper;
import com.adobe.aem.intranet.core.utils.LinkUtils;
import com.adobe.aem.intranet.models.Banner;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Banner.class, resourceType = "intranet/components/content/mainBanner")
public class BannerImpl implements Banner {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private List<BannerHelper> bannerElements = new ArrayList<BannerHelper>();

    @ScriptVariable
    private Node currentNode;

    @PostConstruct
    private void initModel() {
        setValues();
    }
    
    @Override
    public List<BannerHelper> getBannerElements() {
        return bannerElements;
    }

    public void setValues() {	
	    try {
	        NodeIterator nodeIterator =  currentNode.getNodes();
	        while (nodeIterator.hasNext()) {
	           Node childNode = (Node) nodeIterator.next();
	           NodeIterator childNodeIterator =  childNode.getNodes();
	           while(childNodeIterator.hasNext()){
	               Node propsNode = (Node)childNodeIterator.next();
	               if(propsNode.hasProperties()){
	            	   BannerHelper helper = new BannerHelper();

	            	   helper.setBannerImage(propsNode.hasProperty("bannerImage") ? propsNode.getProperty("bannerImage").getString() : null);
	            	   helper.setBannerImageAltText(propsNode.hasProperty("bannerImageAltText") ? propsNode.getProperty("bannerImageAltText").getString() : null);
	            	   helper.setBannerLink(LinkUtils.formatLink(propsNode.hasProperty("bannerLink") ? propsNode.getProperty("bannerLink").getString() : null));
	            	   helper.setBannerWeight(propsNode.hasProperty("bannerWeight") ? propsNode.getProperty("bannerWeight").getString() : null);
	            	   helper.setOffTime(propsNode.hasProperty("offTime") ? propsNode.getProperty("offTime").getDate() : null);
	            	   helper.setOnTime(propsNode.hasProperty("onTime") ? propsNode.getProperty("onTime").getDate() : null);

	    	           bannerElements.add(helper);
	               } 
	           }

	        }
	    }catch (Exception e){
	        log.error("exception",e);
	    }
	}


}
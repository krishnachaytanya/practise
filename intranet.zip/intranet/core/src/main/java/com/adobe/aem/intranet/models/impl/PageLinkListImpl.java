package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;

import com.adobe.aem.intranet.models.PageLinkList;
import com.day.cq.commons.RangeIterator;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.day.cq.wcm.api.Page;

import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = PageLinkList.class, resourceType = "intranet/components/content/linkList")
public class PageLinkListImpl implements PageLinkList {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private static final String BASE_PATH = "/content/intranet";
    private static final String PAGE_PATH = "/content";
    private List<Page> taggedPages = new ArrayList<Page>();
    private List<PageLinkListHelper> iLinkPages = new ArrayList<PageLinkListHelper>();

    @Inject @Optional @Via("resource")
    private String[] tags;

    @ScriptVariable
    private Node currentNode;

    @SlingObject
    private ResourceResolver resourceResolver;

    @PostConstruct
    private void initModel() {
        setValues();
    }

    @Override
    public List<Page> getTaggedPages() {
        return taggedPages;
    }

    @Override
    public List<PageLinkListHelper> getILinkPages() {
        return iLinkPages;
    }

    public void setValues() {
	
	    TagManager tm = resourceResolver.adaptTo(TagManager.class);
	    PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	    if (tags != null) {
	        try {
	            List<String[]> tagsList = new ArrayList<>();
	            tagsList.add(tags);
	            RangeIterator<Resource> tagsIt = tm.find(BASE_PATH, tagsList);
	            while (tagsIt.hasNext()) {
	                Page containingPage = pageManager.getContainingPage(tagsIt.next());
	                taggedPages.add(containingPage);
	            }
	        } catch (Exception e) {
	            log.error("Exception", e);
	        }
	    }
	    try {
	        NodeIterator nodeIterator =  currentNode.getNodes();
	        while (nodeIterator.hasNext()) {
	           Node childNode = (Node) nodeIterator.next();
	           NodeIterator childNodeIterator =  childNode.getNodes();
	           while(childNodeIterator.hasNext()){
	               Node propsNode = (Node)childNodeIterator.next();
	               if(propsNode.hasProperty("iLink")){
	                   PageLinkListHelper helper = new PageLinkListHelper();
	                   String pageLink = propsNode.getProperty("iLink").getString();
	                    if(pageLink.startsWith(PAGE_PATH)){
	                        Page containingPage = pageManager.getContainingPage(pageLink);
	                        if(null != containingPage) {
	                            helper.setInternal(true);
	                            helper.setInternalPage(containingPage);
	                            log.info("internal page");
	                        }
	                    }else{
	                        helper.setInternal(false);
	                        helper.setExtpath(pageLink);
	                        helper.setPageTitle(propsNode.getProperty("iName").getString());
	                        log.info("external page");
	                    }
	                    if(propsNode.hasProperty("requiredPageTarget")){
	                        String pageTarget = propsNode.getProperty("requiredPageTarget").getString();
	    	                helper.setPageTarget(pageTarget);   
	                    }
	                iLinkPages.add(helper);
	                
	               }
	           }
	        }
	    }catch (Exception e){
	        log.error("exception",e);
	    }
	}


}

package com.adobe.aem.intranet.core.services;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Dictionary;
import java.util.Scanner;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true)
@Service(StockTickerServiceImpl.class)
@Properties({
	@Property(name = "folder", value = "", description = "Folder path location of stock ticker info file"),
	@Property(name = "fileName", value = "", description = "Stock ticker info file name") 
})

public class StockTickerServiceImpl implements StockTickerService{
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@SuppressWarnings("rawtypes")
	Dictionary properties = null;
	
	private String folder = null;
	private String fileName = null;
	
	@Activate
	public void activate(ComponentContext componentContext){
		log.info("Activating StockTickerServiceImpl.active()");
		
		properties = componentContext.getProperties();
		folder = (String) properties.get("folder");
		fileName = (String) properties.get("fileName");		
				
		try {
			getQuote();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		log.info("Exiting StockTickerServiceImpl.activate()");
	}
	
	@Override
	public void getQuote() {
		log.info("StockTickerServiceImpl: executing getQuote");
		
		FileWriter fileWriter = null;
		
		//String folder = "c:/Users/hwharr1/AEM/63/author/crx-quickstart/intranet"; //"D:/aem/intranet";
	            
		String file = folder + fileName;		
	     
		try {
			log.info("StockTickerServiceImpl: getting FileWriter for " + file);
			
			File folderPath = new File(folder);

			if(!folderPath.exists()){
				folderPath.mkdirs();
			}
			
			fileWriter = new FileWriter(file);
		} catch (IOException e) {
			log.error("StockTickerServiceImpl: get FileWriter: " + e.toString());
		} catch (Exception e) {
			log.error("StockTickerServiceImpl: get FileWriter: " + e.toString());
		}
	     
		if(fileWriter != null){			
	        
			try {
				log.info("StockTickerServiceImpl: calling web service for values");
				
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("web-proxymain.us.bank-dns.com", 3128));
				
				URL url = new URL("http://investor.shareholder.com/USB/ascii.cfm");
		        URLConnection con = url.openConnection(proxy);
		        InputStream response = con.getInputStream();
		        
		        Scanner scanner = new Scanner(response);
		        String responseBody = scanner.useDelimiter("\\A").next().replaceAll("(\\|\\s[\\+\\-]?[\\.\\d]+)\\s([\\+\\-]?[\\.\\d]+\\s\\|)", "$1 \\| $2");
		        
		        scanner.close();
		        
		        log.info("StockTickerServiceImpl: write to file response: " + responseBody);
		        
		        fileWriter.write(responseBody);		        
		        
		        fileWriter.flush();
		        fileWriter.close();
        	} catch (MalformedURLException e){
        		log.info("StockTickerServiceImpl: get stock values: " + e.toString());
        	} catch (IOException e) {
        		log.info("StockTickerServiceImpl: get stock values: " + e.toString());
        	}
		}
		else{
			log.info("StockTickerServiceImpl: FileWriter is null");
		}
	}

}

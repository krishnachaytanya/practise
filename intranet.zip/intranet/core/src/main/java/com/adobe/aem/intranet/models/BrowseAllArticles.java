package com.adobe.aem.intranet.models;

import java.util.Collection;

public interface BrowseAllArticles {
    String PN_START_LEVEL = "depth";
    
    String PN_START_PATH = "startPath";
   Collection<NavigationItem> getItems();
    
    Collection<NavigationFamilyItem> getFamily();
}

package com.adobe.aem.intranet.models.impl;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;

import com.adobe.aem.intranet.models.FooterHelper;
import com.adobe.aem.intranet.models.StockTickerHelper;

@Model(adaptables = SlingHttpServletRequest.class, adapters = StockTickerHelper.class, resourceType = "intranet/components/content/stockTicker")
@Exporter(name = "jackson", extensions = "json")
public class StockTickerHelperImpl implements StockTickerHelper {

	private String[] values;
	
	@PostConstruct
    private void initModel() {
		// Read value from file
		String filename = "D:/aem/intranet/stock_info.txt";
		String line = null;
		
		BufferedReader bufferedReader;
		try {
			bufferedReader = new BufferedReader(new FileReader(filename));
			line = bufferedReader.readLine();
			
			if(line != null){
				// Split value string into array and assign to values
				
				values = line.split("\\s?\\|\\s?");
				
			}
		} catch (FileNotFoundException e) {
			System.err.println("StockTickerHelperImpl error: " + e.toString());
		} catch (IOException e) {
			System.err.println("StockTickerHelperImpl error: " + e.toString());
		}
	}
	
	@Override
	public String getCurrentprice() {
		
		return values[0];
	}

	@Override
	public String getDayhighprice() {
		return values[1];
	}

	@Override
	public String getDaylowprice() {
		return values[2];
	}

	@Override
	public String getFiftytwoweekhigh() {
		return values[3];
	}

	@Override
	public String getFiftytwoweeklow() {
		return values[4];
	}

	@Override
	public String getPricechange() {
		return values[5];
	}

	@Override
	public String getPercentchange() {
		return values[6];
	}

	@Override
	public String getVolume() {
		return values[7];
	}

	@Override
	public String getE100() {
		return values[8];
	}

	@Override
	public String getPeratio() {
		return values[9];
	}

	@Override
	public String getDividend() {
		return String.format(java.util.Locale.US,"%.2f", Float.parseFloat(values[10]));
	}

	@Override
	public String getDividendyield() {
		return values[11];
	}

	@Override
	public String getExchange() {
		return values[12];
	}

	@Override
	public String getLastupdatedate() {
		return values[13];
	}

}

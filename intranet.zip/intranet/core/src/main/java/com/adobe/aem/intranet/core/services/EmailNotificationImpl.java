package com.adobe.aem.intranet.core.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import javax.crypto.SecretKey;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.HtmlEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.adobe.aem.intranet.core.services.EmailNotification;


@Component(label = "U.S.Bank Intranet Email Notification Service", description = "U.S.Bank Intranet Email Notification Service", metatype = true, immediate = true)
@Service
public class EmailNotificationImpl implements EmailNotification {
	
	@Reference
	MessageGatewayService messageGateWayService;
	
	public static SecretKey secretKey = null; 
	
	
	
	@Property(label = "Enter From Email Id", name = "emailFrom", description = "Enter From email Id", value = "ecm.donotreply@usbank.com")
	private static String emailFrom;
	
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailNotificationImpl.class);
	
	
	@Property(label = "Enter Default Email Recipient List", unbounded = PropertyUnbounded.ARRAY, name = "defaultRecipient", description = "Enter Default Email Recipient list", value = "")
	private static String defaultRecipient; 
	
	private static String[] defaultRecipientList;
	
	
	@Activate
	protected void activate(final Map<String, Object> config) {

		LOGGER.debug("Entered activate of EmailNotificationImpl");
		try{
		EmailNotificationImpl.emailFrom = PropertiesUtil.toString(config.get("emailFrom"),
				"aem_admin@usbank.com");
		
		defaultRecipientList = PropertiesUtil.toStringArray(config.get("defaultRecipient"));
			LOGGER.debug("defaultRecipientList:==>[{}]", EmailNotificationImpl.defaultRecipientList);
		
				
		}catch(Exception e){
			LOGGER.error("Some exception caught:==> {}", e); 
		}
		 
		
		LOGGER.debug("Exiting activate of EmailNotificationImpl");
		 
	}
	

	@Override
	public boolean sendNotificationEmail(String subject,
			String[] toEmailIdArray, String message) {
		
		LOGGER.debug("Entered sendNotificationEmail method");		
    	
		try{
			
			
			java.util.List<String> toEmailIdList=new ArrayList<String>();
	        toEmailIdList=Arrays.asList(EmailNotificationImpl.defaultRecipientList);
	        
	        if(null!=toEmailIdArray && toEmailIdArray.length>0){
	        	
	         toEmailIdList.addAll(Arrays.asList(toEmailIdArray)); 
	         
	        }
	        
	        if(StringUtils.isNotBlank(EmailNotificationImpl.emailFrom.trim()) && (toEmailIdList.size() > 0) ) {
		    	 //Declare a MessageGateway service
		        MessageGateway<Email> messageGateway;
		        
		       
		        Email email = new HtmlEmail();
		        email.setContent(message, "text/html");

		      //From email will be taken from SMTP configuration.
		        
		        email.setFrom(EmailNotificationImpl.emailFrom.trim());
		        
		        
		        	for(String mailId : toEmailIdList){
		        		if(null != mailId && mailId.trim().length() > 0){
		        			LOGGER.info("Loop condition check successfull");
		        			LOGGER.info("check Id Values"+mailId);
		        			email.addTo(mailId.trim());
		        			LOGGER.info("check Id Values"+mailId);
		        		}        	
		            }
		        	
		         email.setSubject(subject);
		         email.setMsg(message);
		         LOGGER.info("Subject to send is"+subject);
		         LOGGER.info("email data to send is"+message);	         
		         LOGGER.info("Message Gate Way Service object is "+messageGateWayService);
		         //Inject a MessageGateway Service and send the message
		         messageGateway = messageGateWayService.getGateway(Email.class);
		         
		         //email = mailTemplate.getEmail(StrLookup.mapLookup(mailTokens), HtmlEmail.class);
		         
		         // Check the logs to see that messageGateway is not null
		         LOGGER.info("MessageGateway Object: "+ messageGateway);
		         
		         LOGGER.info("Before Email Send");
		         messageGateway.send((Email) email);
		         LOGGER.info("Intranet Refresh Notification Email sent successfully"); 
	        }else{
	        	
	        	 LOGGER.info("Email From or to id not configured."); 
	        	
	        }
	 }
	 catch (Exception e) {
		LOGGER.error("Exception while sending Intranet notification email. [{}]", e);
       
    }
		return true;
		
 }


	
	
		

}


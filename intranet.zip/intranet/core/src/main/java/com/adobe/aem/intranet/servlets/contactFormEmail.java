package com.adobe.aem.intranet.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.Map;

import org.apache.commons.mail.ByteArrayDataSource;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;

@SlingServlet(paths = "/bin/contactFormEmail", methods = "POST", metatype = true)
public class contactFormEmail extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	HtmlEmail email;
	
	MessageGateway messageGateway;
	
	@Reference
	MessageGatewayService messageGatewayService;

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		doPost(request, response);
	}

	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		log.error("Inside contactFormEmail");
		
		PrintWriter writer = null;
		
		String htmlResponse = null;
		
		try {
			writer = response.getWriter();
			
			emailAttachment(request);
			
			htmlResponse = " Successful";
			
		} catch (IOException e) {
			log.error("ContactFormEmail build success message: " + e.toString());
		}
		
		if(htmlResponse == null){
			htmlResponse += " An error occurred. Please contact the admiinistrator ";
		}

		writer.println(htmlResponse);
	}

	protected int emailAttachment(SlingHttpServletRequest request) {
		log.info("Inside emailAttachment ");
		
		email = new HtmlEmail();
		
		int returnVal = 1;
		String mailId = "";
		
		String emailTextToSend = "";
		
			
		try {
			for (Map.Entry<String, RequestParameter[]> param : request.getRequestParameterMap().entrySet()) {
				RequestParameter rpm = param.getValue()[0];
				
				log.info("Parameter name : " + rpm.getName());
				log.info("Parameter is form field : " + rpm.isFormField());				
				
				if(rpm.isFormField() && rpm.getName().equalsIgnoreCase("message")) {
					emailTextToSend += "<p>Message: " + rpm.getString() + "</p>";
				}
				else if(rpm.isFormField() && rpm.getName().equalsIgnoreCase("subject")) {
					email.setSubject(rpm.getString());
				}
				else if(rpm.isFormField() && rpm.getName().equalsIgnoreCase("mailto")) {
					email.addTo(rpm.getString());
				}
				else if(!rpm.isFormField()) {
					log.error("Inside emailAttachment3 : " + rpm.getFileName());
					ByteArrayDataSource fileDS = new ByteArrayDataSource(rpm.get(), rpm.getContentType());
					email.attach(fileDS, rpm.getFileName(), "attachment");
				}
				else if(rpm.isFormField()) {
					emailTextToSend += "<p>" + rpm.getName() + ": " + rpm.getString() + "</p>";
				} 
					
				returnVal = 0;
							
			}
			
			email.setHtmlMsg(emailTextToSend);
			email.setFrom("ecm.donotreply@usbank.com");		
			
		} catch (EmailException | IOException e) {
			log.error("ContactFormEmail: " + e.toString());
			returnVal = 1;
		}
		
		
		MessageGateway messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
		messageGateway.send(email);
		
		return returnVal;

	}
}

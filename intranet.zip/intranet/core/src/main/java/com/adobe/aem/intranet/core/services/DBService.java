package com.adobe.aem.intranet.core.services;

import com.mongodb.MongoClient;

public interface DBService {
	 public MongoClient getConnection();
}

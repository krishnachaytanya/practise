package com.adobe.aem.intranet.core.services;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;


public class URLTest {
     
	public static void main(String[] args) {
		
		try {
		URL aURL = new URL("http://localhost:4563/bin/newsForYouServlet");
		URLConnection aConnection = aURL.openConnection();
		aConnection.setDoInput(true);
		aConnection.setDoOutput(true);
		aConnection.setUseCaches(false);
		aConnection.setDefaultUseCaches(false);
		aConnection.setRequestProperty("Content-Type",
		"application/octet-stream");
		List aList = new ArrayList();
		aList.add("1");
		aList.add("2");
		aList.add("3");
		aList.add("4");
		aList.add("5");
		aList.add("6");
		aList.add("7");
		aList.add("8");
		aList.add("9");
		ObjectOutputStream out = new ObjectOutputStream(aConnection
		.getOutputStream());
		out.writeObject(aList);
		out.flush();
		out.close();
		ObjectInputStream in = new ObjectInputStream(aConnection
		.getInputStream());
		String text = (String) in.readObject();
		System.err.println(text);
		} catch (MalformedURLException e) {
		e.printStackTrace();
		} catch (IOException e) {
		e.printStackTrace();
		} catch (ClassNotFoundException e) {
		e.printStackTrace();
		}
		}
    }
     
         
     
 


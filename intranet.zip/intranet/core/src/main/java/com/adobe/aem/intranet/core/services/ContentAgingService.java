package com.adobe.aem.intranet.core.services;

import com.day.cq.search.result.SearchResult;

public interface ContentAgingService {
      public void getFirstReminder();
      public void getSecondReminder();
      public SearchResult deactivateOldPages();
}

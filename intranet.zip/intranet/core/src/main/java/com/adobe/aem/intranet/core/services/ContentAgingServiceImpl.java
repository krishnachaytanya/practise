package com.adobe.aem.intranet.core.services;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.beans.PageInfoDto;
import com.adobe.aem.intranet.core.constants.Constants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

@Component(label = "U.S.Bank Intranet Content Aging Notification Service", description = "U.S.Bank Intranet Content Aging Notification Service", metatype = true, immediate = true)
@Service(ContentAgingService.class)
public class ContentAgingServiceImpl implements ContentAgingService {
	@Reference
	private EmailNotification emailNotification;
	@Reference
	private ResourceResolverFactory resolverFactory;
	@Reference
	private QueryBuilder builder;
	@Reference
	private Replicator replicator;
	private Session session;
	@Property(label = "Enter Domain Name ", name = "domainName", description = "Enter Domain Name", value = "")
	private static String domainName;

	private static final Logger log = LoggerFactory
			.getLogger(ContentAgingServiceImpl.class);

	@Activate
	public void activate(final Map<String, Object> config) {
		log.debug("Activating ContentAgingServiceImpl.active()");
		ContentAgingServiceImpl.domainName = PropertiesUtil.toString(config.get("domainName"),
				"intranet.us.bank-dns.com");
		log.debug("Exiting .activate()");
	}

	@Override
	public void getFirstReminder() {
		try {
			try {
				Map<String, Object> param = new HashMap<String, Object>();
				log.debug("sub service for resource resolver content aging" + ResourceResolverFactory.SUBSERVICE);
				param.put(ResourceResolverFactory.SUBSERVICE, "readService");
				log.debug("resouce resolver get service email util content aging" + resolverFactory.getServiceResourceResolver(param));
				ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param);
				session = resourceResolver.adaptTo(Session.class);
				Map<String, String> map = new HashMap<String, String>();

				map.put("1_group.p.or", "true");
				map.put("1_group.1_group.p.and", "true");
				map.put("1_group.1_group.path", "/content/intranet");
				map.put("1_group.1_group.type", "cq:Page");
				map.put("1_group.1_group.property", "@jcr:content/cq:template");
				map.put("1_group.1_group.property.value", "/conf/intranet/settings/wcm/templates/article");
				map.put("1_group.1_group.property.operation", "unequals");
				map.put("1_group.1_group.relativedaterange.property", "jcr:content/cq:lastReplicated");
				map.put("1_group.1_group.relativedaterange.upperBound", "-1M");
				map.put("1_group.2_group.p.and", "true");
				map.put("1_group.2_group.path", "/content/dam/moviecomponent");
				map.put("1_group.2_group.type", "dam:Asset");
				map.put("1_group.2_group.property.and", "true");
				map.put("1_group.2_group.property", "@jcr:content/metadata/dc:format");
				map.put("1_group.2_group.property.2_value", "image/jpeg");
				map.put("1_group.2_group.property.1_value", "image/png");
				map.put("1_group.2_group.property.operation", "unequals");
				map.put("1_group.2_group.relativedaterange.property", "jcr:content/cq:lastReplicated");
				map.put("1_group.2_group.relativedaterange.lowerBound", "-10M");
				map.put("p.offset", "0");
				map.put("p.limit", "-1");
				log.info("MAP IS" + map);
				// Create Query from Map
				Query query = builder.createQuery(PredicateGroup.create(map), session);
				log.info("QUERY FIRED IS :::" + query);
				SearchResult result = query.getResult();

				log.info("MAP IS" + map);
				Iterator<Node> nodeIter = result.getNodes();
				Node currentNode = null;
				log.debug("RESULT SIZE  " + result.getTotalMatches());
				HashMap<String, ArrayList<PageInfoDto>> userPageInfoMap = new HashMap<String, ArrayList<PageInfoDto>>();
				ArrayList<PageInfoDto> pageList = null;
				PageInfoDto pageInfoDto = null;
				String key;
				String path;
				Resource userResource = null;
				Resource nodeResource = null;
				Resource damResource = null;
				Resource currentNodeResource = null;
				String currentNodePath;
				String damNodePath;
				String nodePath;
				String myPath;
				String editPath;
				String myTitle;
				String createdBy;
				String lastReplicatedDateString;
				String lastReplicatedDate;
				String damTitle;
				ValueMap pageJcrProperties;
				ValueMap pageProperties;
				ValueMap damProperties;
				while (nodeIter.hasNext()) {
					pageInfoDto = new PageInfoDto();
					currentNode = nodeIter.next();

					try {
						currentNodePath = currentNode.getPath().toString() + Constants.JCR_CONENT;///content/abc/xyz/jcr:content
						nodePath = currentNode.getPath().toString();
						damNodePath = currentNode.getPath().toString() + Constants.META_DATA;//  /content/abc/xyz/jcr:content/metadata
						currentNodeResource = resourceResolver.getResource(currentNodePath);
						damResource = resourceResolver.getResource(damNodePath);
						nodeResource = resourceResolver.getResource(nodePath);

						if (nodeResource != null) {

							pageJcrProperties = currentNodeResource.adaptTo(ValueMap.class);
							pageProperties = nodeResource.adaptTo(ValueMap.class);
							myPath = "<a href='http://" + domainName + currentNode.getPath().toString() + ".html'>" + "http://" + domainName + currentNode.getPath().toString() + ".html" + "</a>";
							editPath = "<a href='http://localhost:4502/editor.html" + currentNode.getPath().toString() + ".html'>" + "Edit" + "</a>";
							myTitle = pageJcrProperties.get(Constants.JCR_TITLE, "Title Not Set");
							createdBy = pageProperties.get(Constants.JCR_CREATEDBY, "");
							lastReplicatedDateString = pageJcrProperties.get(Constants.LAST_REPLICATED, "Unpublished").toString();
							lastReplicatedDate = lastReplicatedDateString.substring(0, Math.min(lastReplicatedDateString.length(), 10));
							if (damResource != null) {
								damProperties = damResource.adaptTo(ValueMap.class);
								damTitle = damProperties.get("dc:title", "Title Not Set");
								editPath = "<a href='http://localhost:4502" + currentNode.getPath().toString() + "'>" + "Edit" + "</a>";
								if (myTitle.equalsIgnoreCase("Title Not Set")) {
									log.info("inside the dam if");
									myTitle = damTitle;
								}
							}
							pageInfoDto.setPath(myPath);
							pageInfoDto.setTitle(myTitle);
							pageInfoDto.setEditPath(editPath);
							pageInfoDto.setLastReplicatedOn(lastReplicatedDate);

							if (userPageInfoMap.containsKey(createdBy)) {
								pageList = userPageInfoMap.get(createdBy);
							} else {
								pageList = new ArrayList<PageInfoDto>();
							}
							pageList.add(pageInfoDto);

							userPageInfoMap.put(createdBy, pageList);

							log.info("user and pages map :==> :" + userPageInfoMap);
						}
					} catch (RepositoryException e1) {
						log.error("NewsForYouServlet:: " + e1.toString());
					}
				}


				log.info("user and pages final map :==> :" + userPageInfoMap);
				Set<Entry<String, ArrayList<PageInfoDto>>> entrySet = userPageInfoMap.entrySet();


				for (Entry<String, ArrayList<PageInfoDto>> entry : entrySet) {
					key = entry.getKey();
					//Remove Commented Code below to Use the actual User Email 
					
					/*
					path = getUserPath(key);
					userResource = resourceResolver.getResource(path);
					ValueMap userProperties = userResource.adaptTo(ValueMap.class);
					String userEmail = userProperties.get(Constants.EMAIL_ID,"");
					
					*/
					StringBuilder email = new StringBuilder();
					ArrayList<PageInfoDto> pageinfoDto = entry.getValue();
					email.append("<html><body style='font-size: 15px'>" +
							"<p>As part of a new, and now ongoing, project sponsored by Internal Communications and Technology & Operations Services to keep content on the intranet current, you have been identified as the person who last modified the following USBnetPortal site page(s) that have not been updated within 12 months."
							+ " If you are no longer associated with the page(s) or site(s) listed below, please forward this email to the portal site contact listed below. If the site contact is incorrect or not listed, reply to this email and include the new primary contact for the site if you know who it is or indicate you do not know.<br>"
							+ "<br>The current portal site contact for these pages are:<br><br>HR &nbsp &nbsp<a href ='mailto:william.martinez2@usbank.com'>william.martinez2@usbank.com</a><br>OurCompany TechnologyService &nbsp &nbsp<a href='mailto:janell.johnson@usbank.com'>janell.johnson@usbank.com</a><br>"
							+ "<br>Please review and update the following pages as necessary. If the content is still valid, reworkflow each page within Teamsite to update the Last Modified Date record. If the page(s) is no longer needed, delete the page within Teamsite and reworkflow it to remove it."
							+ " If you require assistance with this, please review this (I added this in...probably easier if we link to directions). If you require additional assistance within Teamsite, contact TeamSite Support at \"Teamsite Support Shared/MN/USB\"</p><br>"
							+ "<table style='border:2px solid black;border-collapse:collapse;'>");
					email.append("<tr>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Page Title");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Page Path");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Link To Edit");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Last Reviewed");
					email.append("</b></td>");
					email.append("</tr>");
					String title;
					String editDtoPath;
					String publishDate;
					String webUrl;
					for (PageInfoDto dto : pageinfoDto) {
						title = dto.getTitle();
						editDtoPath = dto.getEditPath();
						publishDate = dto.getLastReplicatedOn();
						webUrl = dto.getPath();
						log.info("TITLE :" + title + "EDIT PATH :" + editDtoPath + "PUBLISHED DATE :" + publishDate + "WEB URL :" + webUrl);
						email.append("<tr>");
						email.append("<td style='border:1px solid black'>");
						email.append(title);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(webUrl);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(editDtoPath);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(publishDate);
						email.append("</td>");
						email.append("</tr>");
					}

					email.append("</table></body></html>");
					emailNotification.sendNotificationEmail("Content Pages / Dam Assets you have modified in USBIntranet site :" + "(" + key + ")", null, email.toString());
				}


			} catch (LoginException e) {

				log.error("unable to get login details" + e.toString());
			}


		} catch (Exception e) {
			log.error("unable to send mail" + e.toString());
		}

	}

	@Override
	public void getSecondReminder() {
		try {
			try {
				Map<String, Object> param = new HashMap<String, Object>();
				param.put(ResourceResolverFactory.SUBSERVICE, "readService");
				ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param);
				session = resourceResolver.adaptTo(Session.class);
				Map<String, String> map = new HashMap<String, String>();

				map.put("1_group.p.or", "true");
				map.put("1_group.1_group.p.and", "true");
				map.put("1_group.1_group.path", "/content/intranet");
				map.put("1_group.1_group.type", "cq:Page");
				map.put("1_group.1_group.property", "@jcr:content/cq:template");
				map.put("1_group.1_group.property.value", "/conf/intranet/settings/wcm/templates/article");
				map.put("1_group.1_group.property.operation", "unequals");
				map.put("1_group.1_group.relativedaterange.property", "jcr:content/cq:lastReplicated");
				map.put("1_group.1_group.relativedaterange.upperBound", "-11M");
				map.put("1_group.2_group.p.and", "true");
				map.put("1_group.2_group.path", "/content/dam/moviecomponent");
				map.put("1_group.2_group.type", "dam:Asset");
				map.put("1_group.2_group.property.and", "true");
				map.put("1_group.2_group.property", "@jcr:content/metadata/dc:format");
				map.put("1_group.2_group.property.2_value", "image/jpeg");
				map.put("1_group.2_group.property.1_value", "image/png");
				map.put("1_group.2_group.property.operation", "unequals");
				map.put("1_group.2_group.relativedaterange.property", "jcr:content/cq:lastReplicated");
				map.put("1_group.2_group.relativedaterange.lowerBound", "-2M");
				map.put("p.offset", "0");
				map.put("p.limit", "-1");
				log.info("MAP IS" + map);
				// Create Query from Map
				Query query = builder.createQuery(PredicateGroup.create(map), session);
				log.info("QUERY FIRED IS :::" + query);
				SearchResult result = query.getResult();

				log.info("MAP IS" + map);
				Iterator<Node> nodeIter = result.getNodes();
				Node currentNode = null;
				log.debug("RESULT SIZE  " + result.getTotalMatches());
				HashMap<String, ArrayList<PageInfoDto>> userPageInfoMap = new HashMap<String, ArrayList<PageInfoDto>>();
				ArrayList<PageInfoDto> pageList = null;
				PageInfoDto pageInfoDto = null;
				String key;
				String path;
				Resource userResource = null;
				Resource nodeResource = null;
				Resource damResource = null;
				Resource currentNodeResource = null;
				String currentNodePath;
				String damNodePath;
				String nodePath;
				String myPath;
				String editPath;
				String myTitle;
				String createdBy;
				String lastReplicatedDateString;
				String lastReplicatedDate;
				String damTitle;
				ValueMap pageJcrProperties;
				ValueMap pageProperties;
				ValueMap damProperties;
				while (nodeIter.hasNext()) {
					pageInfoDto = new PageInfoDto();
					currentNode = nodeIter.next();

					try {
						currentNodePath = currentNode.getPath().toString() + Constants.JCR_CONENT;
						nodePath = currentNode.getPath().toString();
						damNodePath = currentNode.getPath().toString() + Constants.META_DATA;
						currentNodeResource = resourceResolver.getResource(currentNodePath);
						damResource = resourceResolver.getResource(damNodePath);
						nodeResource = resourceResolver.getResource(nodePath);

						if (nodeResource != null) {

							pageJcrProperties = currentNodeResource.adaptTo(ValueMap.class);
							pageProperties = nodeResource.adaptTo(ValueMap.class);
							myPath = "<a href='http://" + domainName + currentNode.getPath().toString() + ".html'>" + "http://" + domainName + currentNode.getPath().toString() + ".html" + "</a>";
							editPath = "<a href='http://localhost:4502/editor.html" + currentNode.getPath().toString() + ".html'>" + "Edit" + "</a>";
							myTitle = pageJcrProperties.get(Constants.JCR_TITLE, "Title Not Set");
							createdBy = pageProperties.get(Constants.JCR_CREATEDBY, "");
							lastReplicatedDateString = pageJcrProperties.get(Constants.LAST_REPLICATED, "Unpublished").toString();
							lastReplicatedDate = lastReplicatedDateString.substring(0, Math.min(lastReplicatedDateString.length(), 10));
							if (damResource != null) {
								damProperties = damResource.adaptTo(ValueMap.class);
								damTitle = damProperties.get("dc:title", "Title Not Set");
								editPath = "<a href='http://localhost:4502" + currentNode.getPath().toString() + "'>" + "Edit" + "</a>";
								if (myTitle.equalsIgnoreCase("Title Not Set")) {
									log.info("inside the dam if");
									myTitle = damTitle;
								}
							}
							pageInfoDto.setPath(myPath);
							pageInfoDto.setTitle(myTitle);
							pageInfoDto.setEditPath(editPath);
							pageInfoDto.setLastReplicatedOn(lastReplicatedDate);

							if (userPageInfoMap.containsKey(createdBy)) {
								pageList = userPageInfoMap.get(createdBy);
							} else {
								pageList = new ArrayList<PageInfoDto>();
							}
							pageList.add(pageInfoDto);

							userPageInfoMap.put(createdBy, pageList);

							log.info("user and pages map :==> :" + userPageInfoMap);
						}
					} catch (RepositoryException e1) {
						log.error("NewsForYouServlet:: " + e1.toString());
					}
				}


				log.info("user and pages final map :==> :" + userPageInfoMap);
				Set<Entry<String, ArrayList<PageInfoDto>>> entrySet = userPageInfoMap.entrySet();


				for (Entry<String, ArrayList<PageInfoDto>> entry : entrySet) {
					key = entry.getKey();
					//Remove Commented Code below to Use the actual User Email 
					
					/*
					path = getUserPath(key);
					userResource = resourceResolver.getResource(path);
					ValueMap userProperties = userResource.adaptTo(ValueMap.class);
					String userEmail = userProperties.get(Constants.EMAIL_ID,"");
					
					*/
					StringBuilder email = new StringBuilder();
					ArrayList<PageInfoDto> pageinfoDto = entry.getValue();
					email.append("<html><body style='font-size: 15px'>" +
							"<p>As part of a new, and now ongoing, project sponsored by Internal Communications and Technology & Operations Services to keep content on the intranet current, you have been identified as the person who last modified the following USBnetPortal site page(s) that have not been updated within 12 months."
							+ " If you are no longer associated with the page(s) or site(s) listed below, please forward this email to the portal site contact listed below. If the site contact is incorrect or not listed, reply to this email and include the new primary contact for the site if you know who it is or indicate you do not know.<br>"
							+ "<br>The current portal site contact for these pages are:<br><br>HR &nbsp &nbsp<a href ='mailto:william.martinez2@usbank.com'>william.martinez2@usbank.com</a><br>OurCompany TechnologyService &nbsp &nbsp<a href='mailto:janell.johnson@usbank.com'>janell.johnson@usbank.com</a><br>"
							+ "<br>Please review and update the following pages as necessary. If the content is still valid, reworkflow each page within Teamsite to update the Last Modified Date record. If the page(s) is no longer needed, delete the page within Teamsite and reworkflow it to remove it."
							+ " If you require assistance with this, please review this (I added this in...probably easier if we link to directions). If you require additional assistance within Teamsite, contact TeamSite Support at \"Teamsite Support Shared/MN/USB\"</p><br>"
							+ "<table style='border:2px solid black;border-collapse:collapse;'>");
					email.append("<tr>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Page Title");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Page Path");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Link To Edit");
					email.append("</b></td>");
					email.append("<td style='border:1px solid black'><b>");
					email.append("Last Reviewed");
					email.append("</b></td>");
					email.append("</tr>");
					String title;
					String editDtoPath;
					String publishDate;
					String webUrl;
					for (PageInfoDto dto : pageinfoDto) {
						title = dto.getTitle();
						editDtoPath = dto.getEditPath();
						publishDate = dto.getLastReplicatedOn();
						webUrl = dto.getPath();
						log.info("TITLE :" + title + "EDIT PATH :" + editDtoPath + "PUBLISHED DATE :" + publishDate + "WEB URL :" + webUrl);
						email.append("<tr>");
						email.append("<td style='border:1px solid black'>");
						email.append(title);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(webUrl);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(editDtoPath);
						email.append("</td>");
						email.append("<td style='border:1px solid black'>");
						email.append(publishDate);
						email.append("</td>");
						email.append("</tr>");
					}

					email.append("</table></body></html>");
					emailNotification.sendNotificationEmail("Reminder - Content Pages / Dam Assets you have modified in USBIntranet site :" + "(" + key + ")", null, email.toString());
				}


			} catch (LoginException e) {

				log.error("unable to get login details" + e.toString());
			}


		} catch (Exception e) {
			log.error("unable to send mail" + e.toString());
		}

	}

	private String getUserPath(String user) {
		// Build user path from user
		String path = "/etc/users/";

		String topFolder = user.split("")[0].toLowerCase();

		if (topFolder.equals("c") && user.split("")[1].matches("\\d")) {
			topFolder += user.split("")[1];
		}

		String secondLevelFolder = user.toLowerCase();

		if (secondLevelFolder.matches("^c\\d+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 5);
		} else if (secondLevelFolder.matches("^\\w+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 3);
		}

		path += topFolder + "/" + secondLevelFolder + "/" + user;

		log.info("New For You Servlet-  current user node path: " + path);

		return path;
	}

	@Override
	public SearchResult deactivateOldPages() {
		SearchResult result = null;
		try {
			try {
				Map<String, Object> param = new HashMap<String, Object>();
				param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
				ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param);
				session = resourceResolver.adaptTo(Session.class);
				Map<String, String> map = new HashMap<String, String>();

				map.put("1_group.p.or", "true");
				map.put("1_group.1_group.p.and", "true");
				map.put("1_group.1_group.path", "/content/intranet");
				map.put("1_group.1_group.type", "cq:Page");
				map.put("1_group.1_group.property", "@jcr:content/cq:template");
				map.put("1_group.1_group.property.value", "/conf/intranet/settings/wcm/templates/article");
				map.put("1_group.1_group.property.operation", "unequals");
				map.put("1_group.1_group.relativedaterange.property", "jcr:content/cq:lastReplicated");
				map.put("1_group.1_group.relativedaterange.upperBound", "-1y");
				map.put("p.offset", "0");
				map.put("p.limit", "-1");
				// Create Query from Map
				Query query = builder.createQuery(PredicateGroup.create(map), session);
				result = query.getResult();
			} catch (LoginException e) {

				log.error("unable to get login details", e);
			}

		} catch (Exception e) {
			log.error("unable to send mail" + e.toString());
		}
		return result;
	}

}

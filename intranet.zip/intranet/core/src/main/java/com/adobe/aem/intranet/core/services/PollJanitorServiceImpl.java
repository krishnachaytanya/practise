package com.adobe.aem.intranet.core.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true)
@Service(PollJanitorServiceImpl.class)
@Properties({
	@Property(name = "pollsPath", value = "", description = "Node path location of polls container")
})

public class PollJanitorServiceImpl implements PollJanitorService {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
	
	@SuppressWarnings("rawtypes")
	Dictionary properties = null;
	
	private String pollsPath = null;

	@Reference
	private ResourceResolverFactory resolverFactory;
	private Session session;

	@Activate
	public void activate(ComponentContext componentContext){
		log.info("Activating PollJanitorServiceImpl.active()");
		
		properties = componentContext.getProperties();
		pollsPath = (String) properties.get("pollsPath");
		
		try {
			cleanPolls();
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Exiting PollJanitorServiceImpl.activate()");
	}
	
	@Override
	public void cleanPolls() {
		// Get session object to access JCR structure
		Map<String, Object> param = new HashMap<String, Object>();
        param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
        ResourceResolver resourceResolver = null;
		
        try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			
			session = resourceResolver.adaptTo(Session.class);
		} catch (LoginException e) {
			log.error(e.toString());
		}

        log.info("PollJanitorServiceImpl: session object is null = " + (session == null));
        
        if(session != null){
        	Calendar today = Calendar.getInstance();
        	
        	Node page = null;
            
            try {
            	page = session.getNode(pollsPath);
    		} catch (RepositoryException e) {
    			log.error("PollJanitorServiceImpl: Get components parent node: " + e.toString());
    		}
            
            if(page != null){
            	NodeIterator children = null;
    			
    			try {
    				children = page.getNodes();
    				
    				while(children.hasNext()){
    	        		Node child = (Node) children.next();
    	        		
    	        		Calendar createDate = Calendar.getInstance();
    	        		
    	        		createDate.setTime(timestampFormat.parse(child.getProperty("jcr:created").getString()));
    	        		
    	        		// Add 55 weeks (55 * 7 days = 385) to create date and check to see if that date is before today
    	        		createDate.add(Calendar.DAY_OF_YEAR, 385);
    	        		
    	        		if(createDate.before(today)){
    	        			log.info("PollJanitorServiceImpl: Node " + child.getName() + " is targeted for deletion.");
    	        			
    	        			session.removeItem(pollsPath + "/" + child.getName());
    	        			session.save();
    	        		}    	        		
    				}
    			} catch (RepositoryException e) {
    				System.err.println("PollsImpl poll node children: " + e.toString());
    			} catch (ParseException e) {
    				System.err.println("PollsImpl poll node children: " + e.toString());
    			}
            }
            
            session.logout();
        }
	}

}

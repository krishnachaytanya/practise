package com.adobe.aem.intranet.core.beans;

public class PageInfoDto {
	private String path;
	private String title;
	private String editPath;
	private String date;
	private String synopsis;
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEditPath() {
		return editPath;
	}
	public void setEditPath(String editPath) {
		this.editPath = editPath;
	}
	public String getLastReplicatedOn() {
		return date;
	}
	public void setLastReplicatedOn(String lastReplicatedOn) {
		this.date = lastReplicatedOn;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	
}

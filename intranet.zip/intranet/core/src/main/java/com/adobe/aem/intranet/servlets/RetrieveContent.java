package com.adobe.aem.intranet.servlets;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.ServerException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Dictionary;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.jcr.api.SlingRepository;
import org.bson.Document;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.services.DBService;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

@SlingServlet(paths="/bin/retrieveContent", methods = "POST", metatype=true)
public class RetrieveContent extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;
	
	protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/en-US";
	
	final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Reference
    private SlingRepository repository;
	
	@Reference
	private DBService dBService;
	
	@SuppressWarnings("rawtypes")
	Dictionary properties = null;
	
	private String filename = null;
    
	@Activate
	public void activate(ComponentContext componentContext){
		properties = componentContext.getProperties();
		filename = (String) properties.get("filename");
	}
	
    public void bindRepository(SlingRepository repository) {
    	this.repository = repository; 
	}
    
    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
    	boolean alerts = Boolean.parseBoolean(request.getParameter("alerts"));
    	boolean polls = Boolean.parseBoolean(request.getParameter("polls"));
    	boolean alertIDs = Boolean.parseBoolean(request.getParameter("alertIDs"));
    	boolean ticker = Boolean.parseBoolean(request.getParameter("ticker"));
    	
    	String alertID = request.getParameter("alertID");
    	
    	StringBuilder message = new StringBuilder("{");
    	
    	Session session = null;
    	
    	try {
    		session = repository.loginService("writeService", null);
		} catch (RepositoryException e) {
			log.error("RetrieveContent Get session: " + e.toString());
		}
    	
    	if(ticker){
    		String[] values = null;
    		
    		String line = null;
    		
    		BufferedReader bufferedReader;
    		try {
    			bufferedReader = new BufferedReader(new FileReader(filename));
    			line = bufferedReader.readLine();
    			
    			if(line != null){
    				// Split value string into array and assign to values    				
    				values = line.split("\\s?\\|\\s?");
    				
    			}
    		} catch (FileNotFoundException e) {
    			System.err.println("StockTickerHelperImpl error: " + e.toString());
    		} catch (IOException e) {
    			System.err.println("StockTickerHelperImpl error: " + e.toString());
    		}
    		
    		if(values.length > 0){
    			message.append("\"currentPrice\":\"" + values[0] + "\",");
        		message.append("\"dayHighPrice\":\"" + values[1] + "\",");
        		message.append("\"dayLowPrice\":\"" + values[2] + "\",");
        		message.append("\"highPrice52\":\"" + values[3] + "\",");
        		message.append("\"lowPrice52\":\"" + values[4] + "\",");
        		message.append("\"priceChange\":\"" + values[5] + "\",");
        		message.append("\"percentChange\":\"" + values[6] + "\",");
        		message.append("\"volume\":\"" + values[7] + "\",");
        		message.append("\"E100\":\"" + values[8] + "\",");
        		message.append("\"peratio\":\"" + values[9] + "\",");
        		message.append("\"dividend\":\"" + String.format(java.util.Locale.US,"%.2f", Float.parseFloat(values[10])) + "\",");
        		message.append("\"dividendYield\":\"" + values[11] + "\",");
        		message.append("\"exchange\":\"" + values[12] + "\",");
        		message.append("\"lastUpdate\":\"" + values[13] + "\"");
    		}
    	}
    	else if(alerts){
    		if(session != null){
    			Node alertsNode = null;
        		
        		try {
        			alertsNode = session.getNode(PROP_START_PATH_DEFAULT + "/alerts/jcr:content/root/responsivegrid/alerts/alerts");
				} catch (RepositoryException e) {
					log.error("RetrieveContent: " + e.toString());
				}
        		
        		if(alertsNode != null){
        			ArrayList<Node> popups = new ArrayList<Node>();
        			
        			ArrayList<Node> banners = new ArrayList<Node>();
        			
        			NodeIterator children = null;
        			
        			try {
        				children = alertsNode.getNodes();
        				
        				while(children.hasNext()){
        	        		Node child = (Node) children.next();
        	        		
        	        		Date startDate = timestampFormat.parse(child.getProperty("onTime").getString());
        	        		Date endDate = timestampFormat.parse(child.getProperty("offTime").getString());
        	        		
        	        		Date today = new Date();
        	        		
        	        		if(child.getProperty("alertType").getString().equalsIgnoreCase("popup")){
        	        			if(startDate.compareTo(today) <= 0 && endDate.compareTo(today) > 0){
        	        				popups.add(child);
        	        			}
        	        		}
        	        		else{
        	        			if(startDate.compareTo(today) <= 0 && endDate.compareTo(today) > 0){
        	        				banners.add(child);	        				
        	        			}
        	        		}
        				}
        			} catch (RepositoryException e) {
        				log.error("RetrieveContent alertsNode children: " + e.toString());
        			} catch (ParseException e) {
        				log.error("RetrieveContent alertsNode children: " + e.toString());
        			}
        			
        			// Get newest eligible banner alert and popup alert
        			if(popups.size() > 0){
        				// Sort lists of viable alerts by end date ending soonest
        				Collections.sort(popups, new Comparator<Node>() {
        				    @Override
        				    public int compare(Node o1, Node o2) {
        				    	Date date1 = null;
        				    	Date date2 = null;
        				    	
        				    	try {
        							date1 = timestampFormat.parse(o1.getProperty("offTime").getString());
        							date2 = timestampFormat.parse(o2.getProperty("offTime").getString());
        						} catch (ValueFormatException e) {
        							log.error("RetrieveContent: popups date sort: " + e.toString());
        						} catch (PathNotFoundException e) {
        							log.error("RetrieveContent: popups date sort: " + e.toString());
        						} catch (ParseException e) {
        							log.error("RetrieveContent: popups date sort: " + e.toString());
        						} catch (RepositoryException e) {
        							log.error("RetrieveContent: popups date sort: " + e.toString());
        						}
        				    	
        				    	return date1.compareTo(date2);
        				    }
        				});
        				
        				Node popupAlert = popups.get(0);
        				
        				String id = null;
        				String alertTitle = null;
        				String alertText = null;
        				String acknowledgeText = null;
        				
        				final SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMddhhmmss");
        				
        				try {
        					id = idFormat.format(timestampFormat.parse(popupAlert.getProperty("onTime").getString()));
        					alertTitle = popupAlert.getProperty("alertTitle").getString();
        					alertText = popupAlert.getProperty("alertText").getString().trim();
        					acknowledgeText = popupAlert.getProperty("acknowledgeText").getString();		
						} catch (ValueFormatException e) {
							log.error("RetrieveContent: get node properties: " + e.toString());
						} catch (PathNotFoundException e) {
							log.error("RetrieveContent: get node properties: " + e.toString());
						} catch (RepositoryException e) {
							log.error("RetrieveContent: get node properties: " + e.toString());
						} catch (ParseException e) {
							log.error("RetrieveContent: get node properties: " + e.toString());
						}
        				
        				if(id != null && alertTitle != null && alertText != null && acknowledgeText != null){
        					message.append("\"popup\":{");
            				message.append("\"id\":\"ALERT_" + id + "_" + alertTitle.replaceAll("[^A-Za-z0-9]", "").toLowerCase() + "\",");
            				message.append("\"alertTitle\":\"" + alertTitle.replaceAll("\"", "&quot;").replaceAll("'", "&apos;") + "\",");
            				message.append("\"alertText\":\"" + alertText.replaceAll("<a href", "<a x-cq-linkchecker=\"skip\" href") + "\",");
            				message.append("\"acknowledgeText\":\"" + acknowledgeText + "\"}");
        				}
        				else{
        					log.error("RetrieveContent: popup values missing");
        				}
        				
        			}
        			
        			if(banners.size() > 0){
        				// Sort lists of viable alerts by end date ending soonest
        				Collections.sort(banners, new Comparator<Node>() {
        				    @Override
        				    public int compare(Node o1, Node o2) {
        				    	Date date1 = null;
        				    	Date date2 = null;
        				    	
        				    	try {
        							date1 = timestampFormat.parse(o1.getProperty("offTime").getString());
        							date2 = timestampFormat.parse(o2.getProperty("offTime").getString());
        						} catch (ValueFormatException e) {
        							System.err.println("AlertsImpl banners date sort: " + e.toString());
        						} catch (PathNotFoundException e) {
        							System.err.println("AlertsImpl banners date sort: " + e.toString());
        						} catch (ParseException e) {
        							System.err.println("AlertsImpl banners date sort: " + e.toString());
        						} catch (RepositoryException e) {
        							System.err.println("AlertsImpl banners date sort: " + e.toString());
        						}
        				    	
        				    	return date1.compareTo(date2);
        				    }
        				});
        				System.err.println("AlertsImpl banners size: " + banners.size());
        				
        				if(popups.size() > 0){
        					message.append(",");
        				}
        				
        				message.append("\"banners\":[");
        				
        				for(int i = 0; i < banners.size(); i++){
        					Node banner = banners.get(i);
        					
        					String id = null;
        					String alertType = null;
            				String alertTitle = null;
            				String alertText = null;
            				
            				final SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMddhhmmss");
            				
            				try {
            					id = idFormat.format(timestampFormat.parse(banner.getProperty("onTime").getString()));
            					alertTitle = banner.getProperty("alertTitle").getString();
            					alertText = banner.getProperty("alertText").getString().trim();
            					alertType = banner.getProperty("alertType").getString();		
    						} catch (ValueFormatException e) {
    							log.error("RetrieveContent: get node properties: " + e.toString());
    						} catch (PathNotFoundException e) {
    							log.error("RetrieveContent: get node properties: " + e.toString());
    						} catch (RepositoryException e) {
    							log.error("RetrieveContent: get node properties: " + e.toString());
    						} catch (ParseException e) {
    							log.error("RetrieveContent: get node properties: " + e.toString());
    						}
            				
            				if(id != null && alertTitle != null && alertText != null && alertType != null){
            					message.append("{\"id\":\"BANNER_" + id + "_" + alertTitle.replaceAll("[^A-Za-z0-9]", "").toLowerCase() + "\",");
                				message.append("\"alertTitle\":\"" + alertTitle.replaceAll("\"", "&quot;").replaceAll("'", "&apos;") + "\",");
                				message.append("\"alertText\":\"" + alertText.replaceAll("<a href", "<a x-cq-linkchecker=\"skip\" href") + "\",");
                				message.append("\"alertType\":\"" + alertType + "\"}");
                				
                				if(i+1 < banners.size()){
                					message.append(",");
                				}
            				}
        				}
        				
        				message.append("]");
        			}
        		}
        		
    		}
    		else{
    			log.error("RetrieveContent: session object is null, alerts cannot be accessed.");
    		}
    	}
    	else if(polls){
    		if(session != null){
    			Node pollsNode = null;
        		
        		try {
        			pollsNode = session.getNode(PROP_START_PATH_DEFAULT + "/polls/jcr:content/root/responsivegrid");
				} catch (RepositoryException e) {
					log.error("RetrieveContent: " + e.toString());
				}
        		
        		ArrayList<Node> pollsList = new ArrayList<Node>();
        		
        		if(pollsNode != null){
        			NodeIterator children = null;
        			
        			try {
        				children = pollsNode.getNodes();
        				
        				while(children.hasNext()){
        	        		Node child = (Node) children.next();
        	        		
        	        		// Only check active polls
        	        		if(!child.hasProperty("inactivatePoll") || (child.hasProperty("inactivatePoll") && ! child.getProperty("inactivatePoll").getBoolean())){
        	        			if(child.hasProperty("onTime") && child.getProperty("onTime").getString() != null){
        	        				Date startDate = timestampFormat.parse(child.getProperty("onTime").getString());
            		        		
            		        		Date today = new Date();
            		        		
            		        		if(startDate.compareTo(today) <= 0 ){
            		        			pollsList.add(child);
            		        		}
        	        			}
        	        		}
        				}
        			} catch (RepositoryException e) {
        				log.error("RetrieveContent: poll node children: " + e.toString());
        			} catch (ParseException e) {
        				log.error("RetrieveContent: poll node children: " + e.toString());
        			}
        			
        			// Get newest eligible banner alert and popup alert
        			if(pollsList.size() > 0){
        				// Sort lists of viable alerts by end date ending soonest
        				Collections.sort(pollsList, new Comparator<Node>() {
        				    @Override
        				    public int compare(Node o1, Node o2) {
        				    	Date date1 = null;
        				    	Date date2 = null;
        				    	
        				    	try {
        							date1 = timestampFormat.parse(o1.getProperty("onTime").getString());
        							date2 = timestampFormat.parse(o2.getProperty("onTime").getString());
        						} catch (ValueFormatException e) {
        							log.error("RetrieveContent: poll date sort: " + e.toString());
        						} catch (PathNotFoundException e) {
        							log.error("RetrieveContent: poll date sort: " + e.toString());
        						} catch (ParseException e) {
        							log.error("RetrieveContent: poll date sort: " + e.toString());
        						} catch (RepositoryException e) {
        							log.error("RetrieveContent: poll date sort: " + e.toString());
        						}
        				    	
        				    	return date2.compareTo(date1);
        				    }
        				});
        				
        				try {        					
        					
        					Node poll = pollsList.get(0);
        					
        					String id = null;
        					String pollQuestion = null;
        					StringBuilder pollAnswers = new StringBuilder("[");
        					
        					NodeIterator answers = ((Node)poll.getNodes().next()).getNodes();
        					
        					while(answers.hasNext()){
        						Node answer = (Node) answers.next();
        						
        						pollAnswers.append("{\"answer\":\"" + answer.getProperty("answer").getString().trim().replaceAll("<a href", "<a x-cq-linkchecker=\"skip\" href") + "\"}");
        						
        						if(answers.hasNext()){
        							pollAnswers.append(",");
        						}
        					}
        					
        					pollAnswers.append("]");
        					
        					pollQuestion = poll.getProperty("pollQuestion").getString().trim();
        					
        					id = poll.getName() + "_" + (timestampFormat.parse(poll.getProperty("jcr:created").getString())).getTime();
        					
        					message.append("\"pollID\":\"" + id + "\",");
        					message.append("\"pollQuestion\":\"" + pollQuestion.replaceAll("<a href", "<a x-cq-linkchecker=\"skip\" href") + "\",");
        					message.append("\"answers\":" + pollAnswers.toString() + "");
        					
        				} catch (RepositoryException e) {
        					log.error("RetrieveContent: poll get path: " + e.toString());
        				} catch (ParseException e) {
        					log.error("RetrieveContent: poll get path: " + e.toString());
						}
        			}
        		}
    		}
    	}
    	else if(alertIDs){
    		MongoClient mongo = dBService.getConnection();
    		
    		MongoDatabase db = mongo.getDatabase("intranet");
    		
    		MongoCollection<Document> collection = db.getCollection("alerts");
            
    		FindIterable<Document> cursor = collection.find();
    		
    		MongoCursor<Document> it = cursor.iterator();
    		
    		message.append("\"alertIDs\":\"");
            
            while(it.hasNext()) {
                message.append((it.next()).get("uid"));
                
                if(it.hasNext()){
                	message.append("|");
                }
            }
            
            message.append("\"");
    	}
    	else if(alertID != null){
    		MongoClient mongo = dBService.getConnection();
    		
    		MongoDatabase db = mongo.getDatabase("intranet");
    		
    		MongoCollection<Document> collection = db.getCollection("alerts");
            
    		BasicDBObject alertQuery = new BasicDBObject();
    		alertQuery.put("uid", alertID);
            FindIterable<Document> cursor = collection.find(alertQuery);
            
            MongoCursor<Document> it = cursor.iterator();
            
            while(it.hasNext()) {
                message.append(it.next().toJson());
            }
    	}
    	
    	if(session != null){
    		session.logout();
    	}
    	
    	// Return updated node value
    	message.append("}");
    	
    	response.getWriter().write(message.toString());
    }
}

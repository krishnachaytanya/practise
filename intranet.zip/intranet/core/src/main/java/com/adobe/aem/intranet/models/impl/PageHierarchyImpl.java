package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.adobe.aem.intranet.models.NavigationFamilyItem;
import com.adobe.aem.intranet.models.NavigationItem;
import com.adobe.aem.intranet.models.PageHierarchy;
 
@Model(adaptables = SlingHttpServletRequest.class, adapters = PageHierarchy.class, resourceType = "intranet/components/structure/header")
@Exporter(name = "jackson", extensions = "json")
public class PageHierarchyImpl implements PageHierarchy {
 
    protected static final boolean PROP_SHOW_HIDDEN_DEFAULT = false;
    protected static final int PROP_START_LEVEL_DEFAULT = 2;
    protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/home";
    protected static final String PROP_REDIRECT_TYPE = "foundation/components/redirect";
    protected static final String PROP_REDIRECT_NAME = "redirectTarget";
 
    @ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
 
    private int depth;
    
    private Page startPage;
    
    private List<NavigationItem> items;
    
    private List<NavigationFamilyItem> family;
 
    @PostConstruct
    private void initModel() {
        depth = currentStyle.get(PN_START_LEVEL, PROP_START_LEVEL_DEFAULT);
        
        startPage = currentPage.getPageManager().getPage(currentStyle.get(PN_START_PATH, PROP_START_PATH_DEFAULT));
    }
 
    @Override
    public Collection<NavigationItem> getItems() {
        if (items == null) {
            items = new ArrayList<>();
            createNavigation();
            buildNavigationFamily();
        }
        return items;
    }

	@Override
	public Collection<NavigationFamilyItem> getFamily() {
		this.getItems();
		return family;
	}
 
    private void createNavigation() {
        Page rootPage = startPage; 
        
        String currentPagePath = currentPage.getPath();
        
        if (rootPage != null) {
            Iterator<Page> childPages = rootPage.listChildren();
            while (childPages.hasNext()) {
                Page navigationPage = childPages.next();
 
                // if navigation page is the current page
                boolean isActivePage = navigationPage.equals(currentPage);
 
                // if currentPage is a descendant of Navigation Page
                boolean isHierarchyActive = currentPagePath.startsWith(navigationPage.getPath());
 
                // don't include pages marked to be hidden in navigation
                if (!navigationPage.isHideInNav() && navigationPage.getContentResource() != null) {
                	
                    //look for NavigationTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(navigationPage.getNavigationTitle()) ? navigationPage.getNavigationTitle() : navigationPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(navigationPage.getVanityUrl()) ? navigationPage.getVanityUrl() : navigationPage.getPath();
                    
                    if(navigationPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) navigationPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                                        
                    List<NavigationItem> children = getChildren(navigationPage, depth);
                    
                    
                    NavigationItem navItem = new NavigationItemImpl(navigationPage, isActivePage, isHierarchyActive, null, url, text, children);
                    items.add(navItem);               
                    
                }
            } // end while
        } // end if
    }
    
    private List<NavigationItem> getChildren(Page navigationPage, int depth){
    	Page rootPage = navigationPage;
    	
    	if(rootPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
        	// page is type redirect, get redirect page
        	rootPage = rootPage.getPageManager().getPage(rootPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME, PROP_REDIRECT_NAME));
        }
        
        depth--;
    	
    	List<NavigationItem> children = new ArrayList<NavigationItem>();
    	
    	if (rootPage != null) {
    		Iterator<Page> childPages = rootPage.listChildren();
    		
    		while (childPages.hasNext()) {
        		Page childPage = childPages.next();
        		 
                // if navigation page is the current page
                boolean isActivePage = childPage.equals(currentPage);

                // if currentPage is a descendant of Navigation Page
                boolean isHierarchyActive = currentPage.getPath().startsWith(childPage.getPath());
                
                // don't include pages marked to be hidden in navigation
                if (!childPage.isHideInNav() && childPage.getContentResource() != null) {
                    //look for NavigationTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(childPage.getNavigationTitle()) ? childPage.getNavigationTitle() : childPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(childPage.getVanityUrl()) ? childPage.getVanityUrl() : childPage.getPath();
                    
                    if(childPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) childPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                    
                    List<NavigationItem> grandchildren = new ArrayList<NavigationItem>();
                    
                    if(depth > 0 && childPage.listChildren().hasNext()){
                    	grandchildren = getChildren(childPage, depth);
                    }
                    
                    
                    NavigationItem navItem = new NavigationItemImpl(childPage, isActivePage, isHierarchyActive, null, url, text, grandchildren);
                    children.add(navItem);               
                    
                }
            }
    	}
    	
    	return children;
    }
    
    private void buildNavigationFamily(){
    	
    	family = new ArrayList<NavigationFamilyItem>();
    	
    	for(int i = 0; i < items.size(); i++){
    		// Get a total count of level 2 and level 3 links for each parent
    		int totalLinks = 0;
    		
    		System.err.println("Index i: " + i);
    		
    		List<NavigationItem> children = items.get(i).getItems();
    		
    		System.err.println("Parent[" + i + "] children count " + children.size());
    		
    		totalLinks += children.size(); // Level 2 links    		 
    		
    		for(int j = 0; j < children.size(); j++){
    			totalLinks += children.get(j).getItems().size();
    		}
    		
    		// Set column maximum links based on total
    		
    		int maxLinks = 6;
    		
    		if(totalLinks > 39){
    			maxLinks = 15;
    		}
    		else if(totalLinks > 27){
    			maxLinks = 12;
    		}
    		else if(totalLinks > 15){
    			maxLinks = 9;
    		}
    		else if(totalLinks > 10){
    			maxLinks = 5;
    		}
    		
    		System.err.println("Total # links: " + totalLinks + " Max links: " + maxLinks);
    		
    		// Build NavigationFamilyItem with Level 2 children combined as needed
    		List<List<NavigationItem>> level2 = new ArrayList<List<NavigationItem>>();
    		
    		if(children.size() > 0){
    			for(int j = 0; j < children.size(); j++){
        			int columnLinkCount = 0;
        			int listStart = j;
        			int listEnd = j;
        			
        			System.err.println("Child page: " + children.get(j).getText());
        			columnLinkCount += children.get(j).getItems().size();
        			System.err.println("Index " + j + " columnLinkCount: " + columnLinkCount);
        			
        			if(children.size() > 1 && (j + 1) < children.size()){
        				while(children.get(j+1).getItems().size() + 1 < maxLinks - columnLinkCount){ // + 1 for child/Level 2 item itself
            				System.err.println("Added to column: " + children.get(j+1).getText());
            				columnLinkCount += children.get(j+1).getItems().size() + 1;
            				listEnd++;
            				System.err.println("j: " + j + "columnLinkCount: " + columnLinkCount + " listEnd:" + listEnd);
            				j++;
            				
            				if(j == children.size()-1){
            					break;
            				}
            			}
        			}
        			
        			System.err.println("Sublist: " + listStart + " - " + (listEnd+1));
        			
        			List<NavigationItem> column = children.subList(listStart, listEnd + 1);
        			
        			System.err.println("Column size: " + column.size());
        			
        			level2.add(column);
        			
        		}
    		}
    		
    		System.err.println("Creating family item");
    		NavigationFamilyItem familyItem = new NavigationFamilyItemImpl(items.get(i), level2);
    		System.err.println("Adding family item to family");
    		
    		try {
    			System.err.println("family is null " + (family == null));
    			
    			family.add(familyItem);
    		} catch(Exception e) {
    			System.err.println("Add family item error: " + e.toString());
    		}
    		
    		System.err.println("Adding family item");
    		
    	}
    	
    	for(int i = 0; i < family.size(); i++){
    		NavigationFamilyItem level1 = family.get(i);
    		
    		System.err.println("\nParent: " + level1.getParent().getText());
    		
    		List<List<NavigationItem>> children = level1.getChildren();
    		
    		for(int j = 0; j < children.size(); j++){
    			List<NavigationItem> column = children.get(j);
    			
    			for(int k = 0; k < column.size(); k++){
    				NavigationItem level2 = column.get(k);
    				System.err.println("\tChild: " + level2.getText());
    				
    				List<NavigationItem> grandchildren = level2.getItems();
    				for(int x = 0; x < grandchildren.size(); x++){
    					System.err.println("\t\tGrandchild: " + grandchildren.get(x).getText());
    				}
    			}
    		}
    	}
    	
    	System.err.println("Build Family complete");
    }
 
}
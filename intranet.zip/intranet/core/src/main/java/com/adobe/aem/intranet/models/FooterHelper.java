package com.adobe.aem.intranet.models;

public interface FooterHelper {
	
	String getServername();
	
	String getLastmodifier();

}

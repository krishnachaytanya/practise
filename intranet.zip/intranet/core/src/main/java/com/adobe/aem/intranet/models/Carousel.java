package com.adobe.aem.intranet.models;

import java.util.List;

import com.adobe.aem.intranet.core.beans.CarouselBean;

public interface Carousel {

	List<CarouselBean> getCarouselElements();
}

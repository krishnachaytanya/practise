package com.adobe.aem.intranet.models.impl;

import java.util.List;

import com.adobe.aem.intranet.models.NavigationFamilyItem;
import com.adobe.aem.intranet.models.NavigationItem;

public class NavigationFamilyItemImpl implements NavigationFamilyItem{

	private NavigationItem parent;
	
	private List<List<NavigationItem>> children;
	
	public NavigationFamilyItemImpl(NavigationItem parent, List<List<NavigationItem>> children){
		this.parent = parent;
		this.children = children;
	}
	
	@Override
	public NavigationItem getParent() {
		
		return parent;
	}

	@Override
	public List<List<NavigationItem>> getChildren() {
		
		return children;
	}

}

package com.adobe.aem.intranet.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class User {
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private String userId;	
	private String nickName;
	private String firstName;
	private String lastName;
	private String hashedUser ;
	private String city;
	private String state;
	private String country;
	private String mailCode;
	private String businessLine;
	private String businessLineId;
	private String addressLine1;
	private String addressLine2;
	private String photo;
	private String photoLarge;
	private List<UserFavorite> favorites ;
	private String selectedTags;
	
	public User() {
		super();
		favorites = new ArrayList<UserFavorite>();
	}
		
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getHashedUser() {
		return hashedUser;
	}
	public void setHashedUser(String hashedUser) {
		this.hashedUser = hashedUser;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getMailCode() {
		return mailCode;
	}
	public void setMailCode(String mailCode) {
		this.mailCode = mailCode;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getPhotoLarge() {
		return photoLarge;
	}
	public void setPhotoLarge(String photoLarge) {
		this.photoLarge = photoLarge;
	}
	public List<UserFavorite> getFavorites() {
		return favorites;
	}
	public void setFavorites(List<UserFavorite> favorites) {
		this.favorites = favorites;
	}
	public String getSelectedTags() {
		return selectedTags;
	}
	public void setSelectedTags(String selectedTags) {
		this.selectedTags = selectedTags;
	}
	public String toJSON(){
		
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("userId", userId);
			jsonObject.put("nickName", nickName);
			jsonObject.put("firstName", firstName);
			jsonObject.put("lastName", lastName);
			jsonObject.put("hashedUser", hashedUser);
			jsonObject.put("city", city);
			jsonObject.put("state", state);
			jsonObject.put("country", country);
			jsonObject.put("mailCode", mailCode);
			jsonObject.put("businessLine", businessLine);
			jsonObject.put("businessLineId", businessLineId);
			jsonObject.put("addressLine1", addressLine1);
			jsonObject.put("addressLine2", addressLine2);
			jsonObject.put("photo", photo);
			jsonObject.put("photoLarge", photoLarge);
			jsonObject.put("selectedTags", selectedTags);
			
			JSONArray jsonArrayFavorites = new JSONArray();
			if (favorites != null ) {
				for (UserFavorite favorite : favorites) {
					if (favorite == null ) continue;
					JSONObject jsonObjectFavorite = new JSONObject();
					jsonObjectFavorite.put("name", favorite.getName() );
					jsonObjectFavorite.put("url", favorite.getUrl() );
					jsonArrayFavorites.put(jsonObjectFavorite);
				}
			}
			jsonObject.put("favorites", jsonArrayFavorites);
			
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
		}
		return jsonObject.toString();
	}
	

}

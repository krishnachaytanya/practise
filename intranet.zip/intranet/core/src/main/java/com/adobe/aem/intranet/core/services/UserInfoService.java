package com.adobe.aem.intranet.core.services;

import java.util.List;

import com.adobe.aem.intranet.models.User;
import com.adobe.aem.intranet.models.UserFavorite;

public interface UserInfoService {
	public User getUser(String userId);
}

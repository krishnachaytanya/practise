package com.adobe.aem.intranet.models.impl;

import com.day.cq.wcm.api.Page;

public class PageLinkListHelper {
    private boolean isInternal;
    private Page internalPage;
    private String extpath;
    private String pageTitle;
    private String pageTarget;


	public String getPageTarget() {
		return pageTarget;
	}

	public void setPageTarget(String pageTarget) {
		this.pageTarget = pageTarget;
	}

	public String getPageTitle() {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }

    public boolean isInternal() {
        return isInternal;
    }

    public void setInternal(boolean internal) {
        isInternal = internal;
    }

    public Page getInternalPage() {
        return internalPage;
    }

    public void setInternalPage(Page internalPage) {
        this.internalPage = internalPage;
    }

    public String getExtpath() {
        return extpath;
    }

    public void setExtpath(String extpath) {
        this.extpath = extpath;
    }
}

package com.adobe.aem.intranet.models;

import com.adobe.aem.intranet.core.beans.TileHelper;

import java.util.List;

public interface Tile {


	List<TileHelper> getLinkPages();
}

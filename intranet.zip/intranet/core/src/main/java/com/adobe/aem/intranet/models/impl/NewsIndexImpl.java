package com.adobe.aem.intranet.models.impl;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.adobe.aem.intranet.models.NavigationFamilyItem;
import com.adobe.aem.intranet.models.NavigationItem;
import com.adobe.aem.intranet.models.NewsIndex;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = NewsIndex.class, resourceType = "intranet/components/content/newsIndex")
@Exporter(name = "jackson", extensions = "json")
public class NewsIndexImpl implements NewsIndex {

    protected static final String PROP_REDIRECT_TYPE = "foundation/components/redirect";
    protected static final String PROP_REDIRECT_NAME = "redirectTarget";
    
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    @ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    @ScriptVariable
    private Node currentNode;
 
    private int depth;
    
    private Page startPage;
    
    private List<NavigationItem> items;
    
    @PostConstruct
    private void initModel() {
        depth = 3;       
		startPage = currentPage;
    }
 
    @Override
    public Collection<NavigationItem> getItems() {
        if (items == null) {
            items = new ArrayList<>();
            createNavigation();
            Collections.sort(items,new DateComparator());
        }
        return items;
    }

    class DateComparator implements Comparator<NavigationItem>
    {
    	@Override
    	public int compare(NavigationItem arg0,NavigationItem arg1) {
    		String arg0Url = arg0.getUrl();
    		String arg1Url =  arg1.getUrl();
    		if(StringUtils.isNotBlank(arg0Url) && StringUtils.isNotBlank(arg1Url))
    		{
    			String arg0Year = arg0Url.substring(arg0Url.lastIndexOf("/")+1, arg0Url.length());
    			String arg1Year = arg1Url.substring(arg1Url.lastIndexOf("/")+1, arg1Url.length());
    			try
    			{
        			int arg0YearinInt = Integer.parseInt(arg0Year);
        			int arg1YearinInt = Integer.parseInt(arg1Year);
        	        if (arg0YearinInt > arg1YearinInt) return -1;
        	        if (arg0YearinInt < arg1YearinInt) return 1;
            	        else return 0;    				
 				
    			}
    			catch(NumberFormatException ne)
    			{
    				return 0;
    			}
    		}
    		return 0;
    	}
    }

	@Override
	public Collection<NavigationFamilyItem> getFamily() {
		this.getItems();
		return null;
	}
 
    private void createNavigation() {
        Page rootPage = startPage; 
        
        if (rootPage != null) {
            Iterator<Page> childPages = rootPage.listChildren();
            while (childPages.hasNext()) {
                Page navigationPage = childPages.next();
                
                log.debug("createNavigation navigationPage = "+navigationPage.getPath());
 
 
                if ( navigationPage.getContentResource() != null) {
                	log.debug("createNavigation including");
                    //look for NavigationTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(navigationPage.getNavigationTitle()) ? navigationPage.getNavigationTitle() : navigationPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(navigationPage.getVanityUrl()) ? navigationPage.getVanityUrl() : navigationPage.getPath();
                    
                    if(navigationPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) navigationPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                                        
                    List<NavigationItem> children = getChildren(navigationPage, depth);
                    Calendar createdDate = null;
                    ValueMap props = navigationPage.getProperties();
                    if(props.containsKey("jcr:created"))
                    {
                    	createdDate = props.get("jcr:created", Calendar.getInstance());
                    }
                    NavigationItem navItem = new NavigationItemImpl(navigationPage, false, false, null, url, text, children, createdDate);
                    items.add(navItem);               
                    
                }
            } // end while
        } // end if
    }
    
    private List<NavigationItem> getChildren(Page navigationPage, int depth){
    	Page rootPage = navigationPage;
    	
    	if(rootPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
        	// page is type redirect, get redirect page
        	rootPage = rootPage.getPageManager().getPage(rootPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME, PROP_REDIRECT_NAME));
        }
        
        depth--;
    	
    	List<NavigationItem> children = new ArrayList<NavigationItem>();
    	
    	if (rootPage != null) {
    		Iterator<Page> childPages = rootPage.listChildren();
    		
    		while (childPages.hasNext()) {
        		Page childPage = childPages.next();
        		 
                // if article page is the current page
                boolean isActivePage = childPage.equals(currentPage);

                // if currentPage is a descendant of Article Page
                boolean isHierarchyActive = currentPage.getPath().startsWith(childPage.getPath());

                if ( childPage.getContentResource() != null) {
                    //look for ArticleTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(childPage.getNavigationTitle()) ? childPage.getNavigationTitle() : childPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(childPage.getVanityUrl()) ? childPage.getVanityUrl() : childPage.getPath();
                    
                    if(childPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) childPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                    
                    List<NavigationItem> grandchildren = new ArrayList<NavigationItem>();
                    
                    if(depth > 0 && childPage.listChildren().hasNext()){
                    	grandchildren = getChildren(childPage, depth);
                    	if (grandchildren.size() > 0) log.debug("SORTED Children are"+grandchildren.get(0).getText());
                    }
                    Calendar createdDate = null;
                    ValueMap props = childPage.getProperties();
                    if(props.containsKey("jcr:created"))
                    {
                    	createdDate = props.get("jcr:created", Calendar.getInstance());
                    }
                    NavigationItem navItem = new NavigationItemImpl(childPage, isActivePage, isHierarchyActive, null, url, text, grandchildren, createdDate);
                    children.add(navItem);    
                    Collections.sort(children, new CreatedDateComparator());
                    
                }
            }
    	}
    	return children;
    }
    
    class CreatedDateComparator implements Comparator<NavigationItem>
    {

		@Override
		public int compare(NavigationItem arg0, NavigationItem arg1) {
			if(null != arg0 && null != arg1)
			{
				Calendar arg0CreatedDate = arg0.getCreatedDate();
				Calendar arg1CreatedDate = arg1.getCreatedDate();
				if(null != arg0CreatedDate && null != arg1CreatedDate)
				{
					return arg1CreatedDate.compareTo(arg0CreatedDate);
				}
			}
			return 0;
		}	
    }
}

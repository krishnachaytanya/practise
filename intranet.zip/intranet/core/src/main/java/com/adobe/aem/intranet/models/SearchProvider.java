package com.adobe.aem.intranet.models;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

@SuppressWarnings("deprecation")
public class SearchProvider extends WCMUsePojo {

	private static final Logger log = LoggerFactory.getLogger(SearchProvider.class);

	public String getLink() {
		return link;
	}

	private String link;

	@Override
	public void activate() throws Exception {

		ValueMap properties = getProperties();
		log.info("value map "+properties);
		link = "/content/intranet/en-US/home/search.html";
		log.info("search path "+link);
		
	}

}








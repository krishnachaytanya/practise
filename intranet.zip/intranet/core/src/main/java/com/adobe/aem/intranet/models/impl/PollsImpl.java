package com.adobe.aem.intranet.models.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.Polls;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Polls.class, resourceType = "intranet/components/content/pollDisplay")
@Exporter(name = "jackson", extensions = "json")
public class PollsImpl implements Polls {
	protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/en-US/polls";
	
	@ScriptVariable
    private Style currentStyle;
	
	@ScriptVariable
    private Page currentPage;
	
	private Page startPage;
	
	private String poll = "";
	
	@PostConstruct
    private void initModel() {
        startPage = currentPage.getPageManager().getPage(currentStyle.get(PN_START_PATH, PROP_START_PATH_DEFAULT));
        
        setPoll();
    }
	
	@Override
	public String getPoll() {
		return poll;
	}
	
	private void setPoll(){
		Node alertsNode = startPage.getContentResource("root/responsivegrid") != null ? startPage.getContentResource("root/responsivegrid").adaptTo(Node.class) : null;
		
		final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		
		ArrayList<Node> polls = new ArrayList<Node>();
		
		if(alertsNode != null){
			NodeIterator children = null;
			
			try {
				children = alertsNode.getNodes();
				
				while(children.hasNext()){
	        		Node child = (Node) children.next();
	        		
	        		// Only check active polls
	        		if(!child.hasProperty("inactivatePoll") || (child.hasProperty("inactivatePoll") && ! child.getProperty("inactivatePoll").getBoolean())){
	        			Date startDate = timestampFormat.parse(child.getProperty("onTime").getString());
		        		//Date endDate = timestampFormat.parse(child.getProperty("offTime").getString());
		        		
		        		Date today = new Date();
		        		
		        		if(startDate.compareTo(today) <= 0 ){//&& endDate.compareTo(today) > 0){
		        			polls.add(child);
		        		}
	        		}
				}
			} catch (RepositoryException e) {
				System.err.println("PollsImpl poll node children: " + e.toString());
			} catch (ParseException e) {
				System.err.println("PollsImpl poll node children: " + e.toString());
			}
			
			// Get newest eligible banner alert and popup alert
			if(polls.size() > 0){
				// Sort lists of viable alerts by end date ending soonest
				Collections.sort(polls, new Comparator<Node>() {
				    @Override
				    public int compare(Node o1, Node o2) {
				    	Date date1 = null;
				    	Date date2 = null;
				    	
				    	try {
							date1 = timestampFormat.parse(o1.getProperty("onTime").getString());
							date2 = timestampFormat.parse(o2.getProperty("onTime").getString());
						} catch (ValueFormatException e) {
							System.err.println("PollsImpl poll date sort: " + e.toString());
						} catch (PathNotFoundException e) {
							System.err.println("PollsImpl poll date sort: " + e.toString());
						} catch (ParseException e) {
							System.err.println("PollsImpl poll date sort: " + e.toString());
						} catch (RepositoryException e) {
							System.err.println("PollsImpl poll date sort: " + e.toString());
						}
				    	
				    	return date2.compareTo(date1);
				    }
				});
				
				try {
					poll = polls.get(0).getPath();
				} catch (RepositoryException e) {
					System.err.println("PollsImpl poll get path: " + e.toString());
				}
			}
		}
	}

}

package com.adobe.aem.intranet.models;

import java.util.List;

public interface UserHelper {
	String getUser();
	
	String getTags();

}

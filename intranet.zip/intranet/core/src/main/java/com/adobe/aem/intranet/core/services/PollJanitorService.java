package com.adobe.aem.intranet.core.services;

public interface PollJanitorService {
	void cleanPolls();
}

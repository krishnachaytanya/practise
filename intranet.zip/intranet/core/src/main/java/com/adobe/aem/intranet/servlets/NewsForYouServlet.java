package com.adobe.aem.intranet.servlets;

import java.io.IOException;
import java.rmi.ServerException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.commons.lang.ArrayUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.beans.PageInfoDto;
import com.adobe.aem.intranet.core.constants.Constants;
import com.adobe.aem.intranet.core.services.NewsForYouService;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;

@SlingServlet(paths = "/bin/newsForYouServlet", selectors = { "monthsCapped", "tags", "user" }, methods = "GET", metatype = true)
public class NewsForYouServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	@ScriptVariable
	private SlingHttpServletRequest request;

	@Reference
	private SlingRepository repository;

	@Reference
	private NewsForYouService newsForYouService;

	List<Page> pages = new ArrayList<Page>();

	public void bindRepository(SlingRepository repository) {
		this.repository = repository;
	}

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException,
			IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException,
			IOException {
		String[] selectors = request.getRequestPathInfo().getSelectors();
		// Get selectorsMap from selectorsToMap method
		Map<String, String> selectorsmap = selectorsToMap(request.getPathInfo());
		
		String months = selectorsmap.get("monthsCapped");
		
		String excludeTagsAr[] = null;
		if (selectorsmap.get("excludeTag") !=null) {
			byte[] byteArray = Base64.getDecoder().decode(selectorsmap.get("excludeTag"));
			String excludeTagList = new String(byteArray);
			log.info("exclude tags list: "+excludeTagList);
			excludeTagsAr = excludeTagList.split(",");
		}
		
		String includeTagsAr[] = null;
				
		if (selectorsmap.get("includeTag")!=null) {
			byte[] byteArray = Base64.getDecoder().decode(selectorsmap.get("includeTag"));
			String includeTagsList = new String(byteArray);
			log.info("include tags list: "+includeTagsList);
			includeTagsAr = includeTagsList.split(",");
		}
		
		String user = selectorsmap.get("user");
		
		String message = this.newsForYouService.getMessage(months, user, excludeTagsAr, includeTagsAr);

		response.setCharacterEncoding("UTF-16");
		response.getWriter().write(message);
	}

	// Method to generate SelectorsMap from pathinfo
	private Map<String, String> selectorsToMap(String requestPath) {
		Map<String, String> selectorMap = new HashMap<String, String>();
		StringTokenizer stk = new StringTokenizer(requestPath, ".");
		while (stk.hasMoreTokens()) {
			log.info("inside stk has more tokens()");
			String[] elements = stk.nextToken().split("=");
			if (elements.length > 1) {
				selectorMap.put(elements[0], elements[1]);
			}
		}
		return selectorMap;
	}


}
package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;

import com.adobe.aem.intranet.core.beans.TileHelper;
import com.adobe.aem.intranet.core.utils.LinkUtils;
import com.adobe.aem.intranet.models.Tile;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Tile.class, resourceType = "intranet/components/content/tile")
public class TileImpl implements Tile {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private List<TileHelper> linkPages = new ArrayList<TileHelper>();

    @ScriptVariable
    private Node currentNode;

	@Override
	public List<TileHelper> getLinkPages() {
		return linkPages;
	}

    @PostConstruct
    private void initModel() {
        setValues();
    }

    public void setValues() {

	    try {
	        NodeIterator nodeIterator =  currentNode.getNodes();
	        while (nodeIterator.hasNext()) {
	           Node childNode = (Node) nodeIterator.next();
	           NodeIterator childNodeIterator =  childNode.getNodes();
	           while(childNodeIterator.hasNext()){
	               Node propsNode = (Node)childNodeIterator.next();
	               if(propsNode.hasProperties()){
	            	   TileHelper helper = new TileHelper();
	                   
	                   helper.setLink(LinkUtils.formatLink(propsNode.hasProperty("bottomlink") ?propsNode.getProperty("bottomlink").getString() : null));
	                   helper.setLinkButton(propsNode.hasProperty("bottomlinkbutton") ?propsNode.getProperty("bottomlinkbutton").getString() : null); 
	                   helper.setLinkText(propsNode.hasProperty("bottomlinktext") ?propsNode.getProperty("bottomlinktext").getString() : null);

	                   
	                   linkPages.add(helper);
	               } 
	           }

	        }
	    }catch (Exception e){
	        log.error("exception",e);
	    }
	}




}

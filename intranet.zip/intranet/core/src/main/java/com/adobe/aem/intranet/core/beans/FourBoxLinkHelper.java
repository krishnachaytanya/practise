package com.adobe.aem.intranet.core.beans;

public class FourBoxLinkHelper {

	private String link;
	private String linkText;
	private String linkbutton;
	
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getLinkText() {
		return linkText;
	}
	public void setLinkText(String linkText) {
		this.linkText = linkText;
	}
	public String getLinkbutton() {
		return linkbutton;
	}
	public void setLinkbutton(String linkbutton) {
		this.linkbutton = linkbutton;
	}
	
}

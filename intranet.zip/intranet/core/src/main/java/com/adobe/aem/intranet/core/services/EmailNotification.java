package com.adobe.aem.intranet.core.services;



public interface EmailNotification {    
	
	
	public boolean sendNotificationEmail(String subject,
			String[] toEmailIdArray, String message) throws Exception;

}

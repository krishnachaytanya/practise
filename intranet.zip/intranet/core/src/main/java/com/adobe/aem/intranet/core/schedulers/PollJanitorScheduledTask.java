package com.adobe.aem.intranet.core.schedulers;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.services.PollJanitorServiceImpl;

@Component(metatype = true, label = "Poll Janitor Scheduled Task", description = "Poll Janitor Scheduled Task")
@Service(value = Runnable.class)
@Properties({
	@Property(name = "scheduler.expression", value = "0 0 6 ? * MON", description = "Cron-job expression"),
	@Property(name = "scheduler.concurrent", boolValue=false, description = "Whether or not to schedule this task concurrently")
})
public class PollJanitorScheduledTask implements Runnable{
	@Reference
	private PollJanitorServiceImpl pollJanitorServiceImpl;

    private final Logger logger = LoggerFactory.getLogger(getClass());
    
    @Override
    public void run() {
        logger.debug("PollJanitorScheduledTask is now running, myParameter='{}'", myParameter);
        try {
        	System.err.println("pollJanitorServiceImpl is null " + (pollJanitorServiceImpl == null));
        	pollJanitorServiceImpl.cleanPolls();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    @Property(label = "A parameter", description = "Can be configured in /system/console/configMgr")
    public static final String MY_PARAMETER = "myParameter";
    private String myParameter;
    
    @Activate
    protected void activate(final Map<String, Object> config) {
        configure(config);
    }

    private void configure(final Map<String, Object> config) {
        myParameter = PropertiesUtil.toString(config.get(MY_PARAMETER), null);
        logger.debug("PollJanitorScheduledTask configure: myParameter='{}''", myParameter);
    }
}

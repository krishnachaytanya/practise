package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;

import com.adobe.aem.intranet.core.beans.FourBoxHelper;
import com.adobe.aem.intranet.core.beans.FourBoxLinkHelper;
import com.adobe.aem.intranet.core.utils.LinkUtils;
import com.adobe.aem.intranet.models.FourBox;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = FourBox.class, resourceType = "intranet/components/content/fourBox")
@Exporter(name = "jackson", extensions = "json")
public class FourBoxImpl implements FourBox {												

    private final Logger log = LoggerFactory.getLogger(this.getClass());    
    
    private FourBoxHelper fourBoxElements = new FourBoxHelper();
    
    @ScriptVariable
    private Node currentNode;
    
    @Override
    public FourBoxHelper getFourBoxElements() {	
		return fourBoxElements;
    }
    
    @PostConstruct
    private void initModel() {
	    try {
	    	 
	    	fourBoxElements.setBannerImageLink1(currentNode.hasProperty("bannerImageLink1") ? LinkUtils.formatLink(currentNode.getProperty("bannerImageLink1").getString()): null);
	        fourBoxElements.setBannerImageLink2(currentNode.hasProperty("bannerImageLink2") ? LinkUtils.formatLink(currentNode.getProperty("bannerImageLink2").getString()): null);
	        fourBoxElements.setBannerImageLink3(currentNode.hasProperty("bannerImageLink3") ? LinkUtils.formatLink(currentNode.getProperty("bannerImageLink3").getString()): null);
	        fourBoxElements.setBannerImageLink4(currentNode.hasProperty("bannerImageLink4") ? LinkUtils.formatLink(currentNode.getProperty("bannerImageLink4").getString()): null);
	        
	        	if(currentNode.hasNode("links1")){
	        		Node childNode = (Node)currentNode.getNode("links1");
	        		 fourBoxElements.setFourBoxLinkHelperList1(buildLinkHelperList(childNode));
	        	}
	        	if(currentNode.hasNode("links2")){
	        		Node childNode = (Node)currentNode.getNode("links2");
	        		 fourBoxElements.setFourBoxLinkHelperList2(buildLinkHelperList(childNode));
	        	}
	        	if(currentNode.hasNode("links3")){
	        		Node childNode = (Node)currentNode.getNode("links3");
	        		 fourBoxElements.setFourBoxLinkHelperList3(buildLinkHelperList(childNode));
	        	}
	        	if(currentNode.hasNode("links4")){
	        		Node childNode = (Node)currentNode.getNode("links4");
	        		 fourBoxElements.setFourBoxLinkHelperList4(buildLinkHelperList(childNode));
	        	}
	        		 
	    }catch (Exception e){
	        log.error("exception",e);
	    }
    }
    
    private List<FourBoxLinkHelper> buildLinkHelperList(Node childNode) throws Exception{
    	
	           List<FourBoxLinkHelper> fourBoxList = new ArrayList<FourBoxLinkHelper>();
	           NodeIterator childNodeIterator =  childNode.getNodes();
	           while(childNodeIterator.hasNext()){
	               Node propsNode = (Node)childNodeIterator.next();
	               if(propsNode.hasProperties()){
	            	   FourBoxLinkHelper linkHelper = new FourBoxLinkHelper(); 
	            	   
	            	   linkHelper.setLink(propsNode.hasProperty("link") ? LinkUtils.formatLink(propsNode.getProperty("link").getString()) : null);
	            	   linkHelper.setLinkbutton(propsNode.hasProperty("linkbutton") ? propsNode.getProperty("linkbutton").getString() : null);
	            	   linkHelper.setLinkText(propsNode.hasProperty("linkText") ? propsNode.getProperty("linkText").getString() : null);
	            	   
	            	   fourBoxList.add(linkHelper);
	               } 
	           }
	           return fourBoxList;
	        }
}
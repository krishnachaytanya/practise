package com.adobe.aem.intranet.core.utils;

public class LinkUtils {
	public static String formatLink(String linkStr) {
		if (linkStr == null || linkStr.length() < 2) {
			return "";
		} else if (linkStr.startsWith("/content/intranet/en-US")){
			return linkStr + ".html";
		
		}
		return linkStr;
	}
}

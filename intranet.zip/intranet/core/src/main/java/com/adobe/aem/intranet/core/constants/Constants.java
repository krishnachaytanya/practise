package com.adobe.aem.intranet.core.constants;

public final class Constants {
	public static final int PROP_START_LEVEL_DEFAULT = 60;
	public static final String PROP_START_PATH_DEFAULT = "/content/intranet/en-US/home";
    public static final String PN_START_LEVEL = "results";
    public static final String PN_START_PATH = "startPath";
    
    //Constants for NewsForYou Component and Tab
    public static final String JCR_LAST_MODIFIED = "@jcr:content/cq:lastModified";
    public static final String PROP_TITLE = "@jcr:content/cq:lastModified";
    public static final String PROP_TAGS = "@jcr:content/cq:tags";
    public static final String CONSTANT_TAGS = "Tags";
    public static final String JCR_TITLE = "jcr:title";
    public static final String JCR_DESCRIPTION = "jcr:description";
    public static final String JCR_CONENT="/jcr:content";
    public static final String META_DATA="/jcr:content/metadata";
    public static final String JCR_CREATEDBY = "jcr:createdBy";
    public static final String JCR_CREATED ="jcr:created";
    public static final String LAST_REPLICATED = "cq:lastReplicated";
    public static final String EMAIL_ADDRESS = "WorkEmailADDR";
    public static final String SENDER_EMAIL_ADDRESS = "senderEmailAddress";
    public static final String SENDER_NAME = "senderName";
    public static final String SUBJECT = "subject";
}

package com.adobe.aem.intranet.models;

import java.util.List;

import com.day.cq.wcm.api.Page;

public interface NewsForYou {
	List<Page> getPages();
}

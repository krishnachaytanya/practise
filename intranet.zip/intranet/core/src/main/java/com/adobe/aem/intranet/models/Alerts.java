package com.adobe.aem.intranet.models;

import java.util.List;

import javax.jcr.Node;

public interface Alerts {
	String PN_START_PATH = "startPath";
	
	List<Node> getBanneralert();
	
	String getPopupalert();
}

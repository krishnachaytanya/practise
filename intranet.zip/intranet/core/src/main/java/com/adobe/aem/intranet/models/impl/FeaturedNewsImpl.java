package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.FeaturedNews;
import com.adobe.aem.intranet.core.constants.Constants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = FeaturedNews.class, resourceType = "intranet/components/content/allnews")
@Exporter( extensions = "json", name = "jackson")
public class FeaturedNewsImpl implements FeaturedNews{
	
	@ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    
    @ScriptVariable
    private Node currentNode;
 
    private int results;
    
    private String startPath;
    
    private List<Page> pages;
    
    @PostConstruct
    private void initModel() {
    	try {
			results = Integer.parseInt(currentNode.getProperty(Constants.PN_START_LEVEL).getValue().getString());
		} catch (NumberFormatException | IllegalStateException | RepositoryException e) {
			System.err.println("FeaturedNewsImpl results: " + e.toString());
		}
    	
    	System.err.println("Number of Results: " + results);
    	
    	
    	startPath = Constants.PROP_START_PATH_DEFAULT;
    }
    @Override
   	public List<Page> getPages() {
   		pages = new ArrayList<Page>();
   		buildPages();
   		
   		return pages;
   	}
	private void buildPages() {
		QueryBuilder queryBuilder = currentPage.getContentResource().getResourceResolver().adaptTo(QueryBuilder.class);
    	Session session = currentPage.getContentResource().getResourceResolver().adaptTo(Session.class);
    	
    	// create query description as hash map (simplest way, same as form post)
        Map<String, String> map = new HashMap<String, String>();

        // create query description as hash map (simplest way, same as form post)
        map.put("path", startPath);
        map.put("type", "cq:Page");
        map.put("orderby", "@jcr:content/cq:lastModified");
        map.put("orderby.sort", "desc");
        map.put("property", "jcr:content/jcr:title"); 
        map.put("property.operation", "unequals"); 
        map.put("property.value", currentPage.getTitle());
        map.put("tagid.property", "jcr:content/cq:tags");
        
        Tag[] tags = null;
        try {
			if(currentNode.getName().contains("allnews")){
									
				if(currentNode.getProperty("selectedtags") != null){
					TagManager tm = currentPage.getContentResource().getResourceResolver().adaptTo(TagManager.class);
					
					Value[] newsTags = currentNode.getProperty("selectedtags").getValues();
					
					tags = new Tag[newsTags.length];
					
					for(int i = 0; i < newsTags.length; i++){
						tags[i] = tm.resolve(newsTags[i].getString());
					}
				}
			}
			else{
				tags = currentPage.getTags();
			}
		} catch (RepositoryException e) {
			System.err.println("FeaturedNews currentNode getName: " + e.toString());
		}
        System.err.println("FeaturedNewsImpl: tags: " + tags.length);
        
        if(tags != null && tags.length > 0){
        	try {
        		for(int i = 0; i < tags.length; i++){
            		map.put("tagid." + (i+1) + "_value", tags[i].getNamespace().getName() + ":" +  tags[i].getLocalTagID());
            		System.err.println("Tag: " + tags[i].getNamespace().getName() + ":" + tags[i].getLocalTagID());
                }
                
                map.put("tagid.and", "true");
              
                // can be done in map or with Query methods
                map.put("p.offset", "0"); // same as query.setStart(0) below
                map.put("p.limit", Integer.toString(results)); // same as query.setHitsPerPage(20) below
                                 
                Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
                                   
                SearchResult result = query.getResult();
                
                // If no pages have all the tags, look for pages with any of the tags
                if(result.getTotalMatches() == 0){
                	map.remove("tagid.and");
                	map.put("tagid.or", "true");
                	query = queryBuilder.createQuery(PredicateGroup.create(map), session);
                	result = query.getResult();            	
                }
                
               // iterating over the results
                for (Hit hit : result.getHits()) {
                	Page found = null;
                	
                	found = currentPage.getPageManager().getPage(hit.getPath());
        				
        			pages.add(found);
                }
        	} catch (RepositoryException e) {
				System.err.println("FeaturedNewsImpl::buildPages: " + e.toString());
			} catch (NullPointerException e) {
				System.err.println("FeaturedNewsImpl::buildPages: Tags not published? - " + e.toString());
			}
        }
        else{
        	System.err.println("FeaturedNewsImpl::buildPages: currentPage.getTags() returned null");
        }
		
	}
       
}

package com.adobe.aem.intranet.models.impl;

import com.adobe.aem.intranet.models.UserFavorite;

public class UserFavoriteImpl implements UserFavorite {

	private String name;
	
	private String url;
	
	public UserFavoriteImpl(String name, String url){
		this.name = name;
		this.url = url;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getUrl() {
		return url;
	}

}

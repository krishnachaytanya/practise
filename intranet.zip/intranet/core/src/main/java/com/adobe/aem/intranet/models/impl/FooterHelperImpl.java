package com.adobe.aem.intranet.models.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.annotation.PostConstruct;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.FooterHelper;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = FooterHelper.class, resourceType = "intranet/components/structure/footer")
@Exporter(name = "jackson", extensions = "json")
public class FooterHelperImpl implements FooterHelper {

	@ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    
    private String servername;
    
    private String lastmodifier;
    
    @PostConstruct
    private void initModel() {
    	acquireServername();
    	acquireLastmodifier();
    }
    
    private void acquireServername() {
		try {
			this.servername = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			
			System.err.println("FooterInfoImpl::acquireServername error: " + e.toString());
		}
		
		return;
	}
    
    private void acquireLastmodifier() {
		try {
			UserManager userManager = currentPage.getContentResource().getResourceResolver().adaptTo(UserManager.class);
			
			Authorizable user = userManager.getAuthorizable(currentPage.getLastModifiedBy());			
			
			String lastName = user.getProperty("./profile/familyName")!=null ? user.getProperty("./profile/familyName")[0].getString() : null;

			String firstName = user.getProperty("./profile/givenName")!=null ? user.getProperty("./profile/givenName")[0].getString() : null;

			System.err.println("Last name: " + lastName);

			this.lastmodifier = firstName + " " + lastName;
		} catch (ValueFormatException e) {
			System.err.println("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		} catch (IllegalStateException e) {
			System.err.println("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		} catch (RepositoryException e) {
			System.err.println("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		} catch(Exception e){
			System.err.println("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		}
	}
    
    @Override
	public String getServername() {
		
    	return servername;
	}

	@Override
	public String getLastmodifier() {
		
		return lastmodifier;
	}

}

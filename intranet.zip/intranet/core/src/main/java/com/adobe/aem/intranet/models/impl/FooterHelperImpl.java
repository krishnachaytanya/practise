package com.adobe.aem.intranet.models.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.services.UserInfoService;
import com.adobe.aem.intranet.models.FooterHelper;
import com.adobe.aem.intranet.models.User;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = FooterHelper.class, resourceType = "intranet/components/structure/footer")
@Exporter(name = "jackson", extensions = "json")
public class FooterHelperImpl implements FooterHelper {
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	@ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    
    @Inject
    private UserInfoService userInfoService;
    
    
    private String servername;
    
    private String lastmodifier;
    
    
    @PostConstruct
    private void initModel() {
    	acquireServername();
    	acquireLastmodifier();
    }
    
    private void acquireServername() {
		try {
			this.servername = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			
			log.error("FooterInfoImpl::acquireServername error: " + e.toString());
		}
		
		return;
	}
    
    private void acquireLastmodifier() {
		try {
/*			UserManager userManager = currentPage.getContentResource().getResourceResolver().adaptTo(UserManager.class);
			
			Authorizable user = userManager.getAuthorizable(currentPage.getLastModifiedBy());

			String lastName = user.getProperty("./profile/familyName")!=null ? user.getProperty("./profile/familyName")[0].getString() : null;

			String firstName = user.getProperty("./profile/givenName")!=null ? user.getProperty("./profile/givenName")[0].getString() : null;

			System.err.println("Last name: " + lastName);*/
			
			User user = userInfoService.getUser(currentPage.getLastModifiedBy());
			log.info("user node "+user.getLastName()+" "+user.getFirstName()+" "+user.getUserId());
			
			if(user.getFirstName() != null && user.getLastName() != null){
				this.lastmodifier = user.getFirstName() + " " + user.getLastName();
			}else{
				this.lastmodifier = user.getUserId();
			}

		} catch (IllegalStateException e) {
			log.error("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		} catch(Exception e){
			log.error("FooterInfoImpl::acquireLastModifier error: " + e.toString());
		}
	}
    
	
    
    @Override
	public String getServername() {
		
    	return servername;
	}

	@Override
	public String getLastmodifier() {
		
		return lastmodifier;
	}

}

package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.RelatedPages;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;


@Model(adaptables = SlingHttpServletRequest.class, adapters = RelatedPages.class, resourceType = "intranet/components/content/relatedpages")
@Exporter(name = "jackson", extensions = "json")
public class RelatedPagesImpl implements RelatedPages{
	
	protected static final int PROP_START_LEVEL_DEFAULT = 2;
	protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/home";

	@ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    
    @ScriptVariable
    private Node currentNode;
 
    private int results;
    
    private String startPath;
    
    private List<Page> pages;
    
    @PostConstruct
    private void initModel() {
    	try {
			results = Integer.parseInt(currentNode.getProperty(PN_START_LEVEL).getValue().getString());
		} catch (NumberFormatException | IllegalStateException | RepositoryException e) {
			System.err.println("RelatedPagesImpl results: " + e.toString());
		}
    	
    	System.err.println("Number of Results: " + results);
    	
    	
    	startPath = currentStyle.get(PN_START_PATH, PROP_START_PATH_DEFAULT);
    }
 
    @Override
	public List<Page> getPages() {
		pages = new ArrayList<Page>();
		buildPages();
		
		return pages;
	}
    
    private void buildPages(){
    	// Look for manual pages first
    	//Resource manualPages = findResource(currentPage.getContentResource(), "manualPages");
    	
    	Node manualPages = null;
    	
    	try {
			manualPages = currentNode.getNode("manualPages");
		} catch (RepositoryException e) {
			System.err.println("RelatedPagesImpl manualPages: " + e.toString());
		}
    	
    	if(manualPages != null){
    		NodeIterator children = null;
			try {
				children = manualPages.getNodes();
				
				while(children.hasNext()){
	        		Node child = (Node) children.next();
	        		
	        		System.err.println("Manual Page: " + child.getProperty("link").getValue().getString());
	        		
	        		pages.add(currentPage.getPageManager().getPage(child.getProperty("link").getValue().getString()));
	        	}
			} catch (RepositoryException e) {
				System.err.println("RelatedPagesImpl manualPages children: " + e.toString());
			}
    	}
    	else{
    		System.err.println("Related Pages not found, will attempt tag search.");
    		
    		QueryBuilder queryBuilder = currentPage.getContentResource().getResourceResolver().adaptTo(QueryBuilder.class);
        	Session session = currentPage.getContentResource().getResourceResolver().adaptTo(Session.class);
        	
        	// create query description as hash map (simplest way, same as form post)
            Map<String, String> map = new HashMap<String, String>();

            // create query description as hash map (simplest way, same as form post)
            map.put("path", startPath);
            map.put("type", "cq:Page");
            //map.put("cq:template", "/conf/intranet/settings/wcm/templates/two-column");
            map.put("orderby", "@jcr:content/cq:lastModified");
            map.put("orderby.sort", "desc");
            
            // Ignore current page
            map.put("property", "jcr:content/jcr:title"); 
            map.put("property.operation", "unequals"); 
            map.put("property.value", currentPage.getTitle());
            
            map.put("tagid.property", "jcr:content/cq:tags");
            
            Tag[] tags = null;
            
            try {
				if(currentNode.getName().contains("horizontalrelatedpag")){
										
					if(currentNode.getProperty("selectedtags") != null){
						TagManager tm = currentPage.getContentResource().getResourceResolver().adaptTo(TagManager.class);
						
						Value[] horizontalTags = currentNode.getProperty("selectedtags").getValues();
						
						tags = new Tag[horizontalTags.length];
						
						for(int i = 0; i < horizontalTags.length; i++){
							tags[i] = tm.resolve(horizontalTags[i].getString());
						}
					}
				}
				else{
					tags = currentPage.getTags();
				}
			} catch (RepositoryException e) {
				System.err.println("Related Pages currentNode getName: " + e.toString());
			}
            
            System.err.println("RelatedPagesImpl: tags: " + tags.length);
            
            if(tags != null && tags.length > 0){
            	try {
            		for(int i = 0; i < tags.length; i++){
                		map.put("tagid." + (i+1) + "_value", tags[i].getNamespace().getName() + ":" +  tags[i].getLocalTagID());
                		System.err.println("Tag: " + tags[i].getNamespace().getName() + ":" + tags[i].getLocalTagID());
                    }
                    
                    map.put("tagid.and", "true");
                  
                    // can be done in map or with Query methods
                    map.put("p.offset", "0"); // same as query.setStart(0) below
                    map.put("p.limit", Integer.toString(results)); // same as query.setHitsPerPage(20) below
                                     
                    Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
                                       
                    SearchResult result = query.getResult();
                    
                    // If no pages have all the tags, look for pages with any of the tags
                    if(result.getTotalMatches() == 0){
                    	map.remove("tagid.and");
                    	map.put("tagid.or", "true");
                    	query = queryBuilder.createQuery(PredicateGroup.create(map), session);
                    	result = query.getResult();            	
                    }
                    
                   // iterating over the results
                    for (Hit hit : result.getHits()) {
                    	Page found = null;
                    	
                    	found = currentPage.getPageManager().getPage(hit.getPath());
            				
            			pages.add(found);
                    }
            	} catch (RepositoryException e) {
    				System.err.println("RelatedPagesImpl::buildPages: " + e.toString());
    			} catch (NullPointerException e) {
    				System.err.println("RelatedPagesImpl::buildPages: Tags not published? - " + e.toString());
    			}
            }
            else{
            	System.err.println("RelatedPagesImpl::buildPages: currentPage.getTags() returned null");
            }
    	}   	
    }

}

package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;

import com.adobe.aem.intranet.core.beans.CarouselBean;
import com.adobe.aem.intranet.core.utils.LinkUtils;
import com.adobe.aem.intranet.models.Carousel;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Carousel.class, resourceType = "intranet/components/content/carousel")
public class CarouselImpl implements Carousel {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private List<CarouselBean> carouselElements = new ArrayList<CarouselBean>();

    @ScriptVariable
    private Node currentNode;

    @PostConstruct
    private void initModel() {
        setValues();
    }
    
    @Override
    public List<CarouselBean> getCarouselElements() {
        return carouselElements;
    }

    public void setValues() {	
	    try {
	        NodeIterator nodeIterator =  currentNode.getNodes();
	        while (nodeIterator.hasNext()) {
	           Node childNode = (Node) nodeIterator.next();
	           NodeIterator childNodeIterator =  childNode.getNodes();
	           while(childNodeIterator.hasNext()){
	               Node propsNode = (Node)childNodeIterator.next();
	               if(propsNode.hasProperties()){
	            	   CarouselBean bean = new CarouselBean();
	                   bean.setPagePath(LinkUtils.formatLink(propsNode.hasProperty("pagepath") ?propsNode.getProperty("pagepath").getString() : null));
	                   bean.setImage(propsNode.hasProperty("image") ? propsNode.getProperty("image").getString() : null);
	                   bean.setImgAlt(propsNode.hasProperty("imgAlt") ? propsNode.getProperty("imgAlt").getString() : null);
	                   bean.setTitle(propsNode.hasProperty("title") ? propsNode.getProperty("title").getString() : null);
	                   
	    	           carouselElements.add(bean);
	               } 
	           }

	        }
	    }catch (Exception e){
	        log.error("exception",e);
	    }
	}


}
package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.models.BrowseAllArticles;
import com.adobe.aem.intranet.models.NavigationFamilyItem;
import com.adobe.aem.intranet.models.NavigationItem;
import com.adobe.aem.intranet.models.NewsForYouArticles;
import com.adobe.aem.intranet.models.impl.BrowseAllArticlesImpl.CreatedDateComparator;
import com.adobe.aem.intranet.models.impl.BrowseAllArticlesImpl.DateComparator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
@Model(adaptables = SlingHttpServletRequest.class, adapters = NewsForYouArticles.class, resourceType = "intranet/components/content/allNews")
@Exporter(name = "jackson", extensions = "json")
public class NewsForYouArticlesImpl implements NewsForYouArticles {
	protected static final boolean PROP_SHOW_HIDDEN_DEFAULT = false;
    protected static final int PROP_START_LEVEL_DEFAULT = 2;
    protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/home/articles";
    protected static final String PROP_REDIRECT_TYPE = "foundation/components/redirect";
    protected static final String PROP_REDIRECT_NAME = "redirectTarget";
    
    @ScriptVariable
    private Style currentStyle;
 
    @ScriptVariable
    private Page currentPage;
    @ScriptVariable
    private Node currentNode;
 
    private int depth = 3;
    
    private Page startPage;
    ResourceResolver resourceResolver;
	String remTag;
	final Logger log = LoggerFactory.getLogger(NewsForYouArticlesImpl.class);
	private int results;
	private String startPath;
	private String userTags;
	String resourcePath = "/etc/users/c0/c0375/c037533";
	Node userNode = null;


	public static String PN_START_LEVEL = "results";

	private List<Page> pages;
	
    
    private List<NavigationItem> items;
    
    private List<NavigationFamilyItem> family;
    @PostConstruct
    private void initModel() {
    	System.err.println("...........INSIDE NEWSFORYOUARTICLESIMPL CLASS........");
    	ResourceResolver rr = currentPage.getContentResource().getResourceResolver();
    	startPage = currentPage.getPageManager().getPage(PROP_START_PATH_DEFAULT);
		Resource resource = rr.getResource(resourcePath);

		if (resource != null) {
			userNode = resource.adaptTo(Node.class);
		}
		
		try {
			if (userNode != null && userNode.hasProperty("Tags")) {
				log.info("User Node Value"+userNode);
				userTags = userNode.getProperty("Tags").getValue().getString();
				log.info("User Node Value"+userTags);
				
			} else {
				userTags = "";
			}
		} catch (RepositoryException e) {
			System.err.println("NEWSFORYOU Full Name not set: "
					+ e.toString());
		}
		
       log.info("News For You Impl");
        log.info("The user Property is : "+ userTags);
		

		startPath = PROP_START_PATH_DEFAULT;
		 
    }
    @Override
    public Collection<NavigationItem> getItems() {
        if (items == null) {
        	log.info("Inside getItems Items value is null"+items);
            items = new ArrayList<>();
            createNavigation();
            buildNavigationFamily();
            Collections.sort(items,new DateComparator());
            log.info("Outside getItems Items value is null"+items);
        }
        return items;
    }

    class DateComparator implements Comparator<NavigationItem>
    {
    	@Override
    	public int compare(NavigationItem arg0,NavigationItem arg1) {
    		String arg0Url = arg0.getUrl();
    		String arg1Url =  arg1.getUrl();
    		if(StringUtils.isNotBlank(arg0Url) && StringUtils.isNotBlank(arg1Url))
    		{
    			String arg0Year = arg0Url.substring(arg0Url.lastIndexOf("/")+1, arg0Url.length());
    			String arg1Year = arg1Url.substring(arg1Url.lastIndexOf("/")+1, arg1Url.length());
    			try
    			{
        			int arg0YearinInt = Integer.parseInt(arg0Year);
        			int arg1YearinInt = Integer.parseInt(arg1Year);
        	        if (arg0YearinInt > arg1YearinInt) return -1;
        	        if (arg0YearinInt < arg1YearinInt) return 1;
            	        else return 0;    				
 				
    			}
    			catch(NumberFormatException ne)
    			{
    				return 0;
    			}
    		}
    		return 0;
    	}
    }
    @Override
	public Collection<NavigationFamilyItem> getFamily() {
		this.getItems();
		
		return family;
		
	}
 
    private void createNavigation() {
        Page rootPage = startPage; 
        
        log.info("RootPage"+rootPage);
        
        String currentPagePath = currentPage.getPath();
        
        log.info("currentPagePath Value"+currentPagePath);
        
        if (rootPage != null) {
            Iterator<Page> childPages = rootPage.listChildren();
            while (childPages.hasNext()) {
                Page navigationPage = childPages.next();
 
                // if navigation page is the current page
                boolean isActivePage = navigationPage.equals(currentPage);
 
                // if currentPage is a descendant of Navigation Page
                boolean isHierarchyActive = currentPagePath.startsWith(navigationPage.getPath());
 
                // don't include pages marked to be hidden in navigation
                if (!navigationPage.isHideInNav() && navigationPage.getContentResource() != null) {
                	
                    //look for NavigationTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(navigationPage.getNavigationTitle()) ? navigationPage.getNavigationTitle() : navigationPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(navigationPage.getVanityUrl()) ? navigationPage.getVanityUrl() : navigationPage.getPath();
                    
                    if(navigationPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) navigationPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                    log.info("Calling Children method");                
                    List<NavigationItem> children = getChildren(navigationPage, depth);
                   
                    Calendar createdDate = null;
                    ValueMap props = navigationPage.getProperties();
                    if(props.containsKey("jcr:created"))
                    {
                    	createdDate = props.get("jcr:created", Calendar.getInstance());
                    }
                    NavigationItem navItem = new NavigationItemImpl(navigationPage, isActivePage, isHierarchyActive, null, url, text, children, createdDate);
                    items.add(navItem);               
                    
                }
            } // end while
        } // end if
    }
    private List<NavigationItem> getChildren(Page navigationPage, int depth){
    	Page rootPage = navigationPage;
    	
    	log.info("Inside children rootPage"+navigationPage);
    	
    	if(rootPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
        	// page is type redirect, get redirect page
        	rootPage = rootPage.getPageManager().getPage(rootPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME, PROP_REDIRECT_NAME));
        }
        
        depth--;
    	
    	List<NavigationItem> children = new ArrayList<NavigationItem>();
    	
    	if (rootPage != null) {
    		Iterator<Page> childPages = rootPage.listChildren();
    		
    		while (childPages.hasNext()) {
        		Page childPage = childPages.next();
        		 
                // if article page is the current page
                boolean isActivePage = childPage.equals(currentPage);

                // if currentPage is a descendant of Article Page
                boolean isHierarchyActive = currentPage.getPath().startsWith(childPage.getPath());
                
                // don't include pages marked to be hidden in navigation
                if (!childPage.isHideInNav() && childPage.getContentResource() != null) {
                    //look for ArticleTitle if blank, fall back to jcr:title
                    String text = StringUtils.isNotBlank(childPage.getNavigationTitle()) ? childPage.getNavigationTitle() : childPage.getTitle();
                    
                    String url = StringUtils.isNotBlank(childPage.getVanityUrl()) ? childPage.getVanityUrl() : childPage.getPath();
                    
                    if(childPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
                		// page is type redirect, set url as redirect page
                		url = (String) childPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                    }
                    
                    if(! StringUtils.isNotBlank(url)){
                    	url = "error";
                    }
                    
                    List<NavigationItem> grandchildren = new ArrayList<NavigationItem>();
                    
                    if(depth > 0 && childPage.listChildren().hasNext()){
                    	grandchildren = getGrandChildren(childPage);
                    	System.err.println("SORTED NEWS FOR YOU  CHILDREN are"+grandchildren.get(1).getText());
                    }
                    Calendar createdDate = null;
                    ValueMap props = childPage.getProperties();
                    if(props.containsKey("jcr:created"))
                    {
                    	createdDate = props.get("jcr:created", Calendar.getInstance());
                    }
                    NavigationItem navItem = new NavigationItemImpl(childPage, isActivePage, isHierarchyActive, null, url, text, grandchildren, createdDate);
                    children.add(navItem);    
                    //Collections.sort(children, new CreatedDateComparator());
                    
                }
            }
    	}
    	
    	return children;
    	
    }
    private List<NavigationItem> getGrandChildren(Page childPage) {
    	
    	startPath=childPage.getPath().toString();
    	log.info("Start page Path"+startPath);
    	QueryBuilder queryBuilder = currentPage.getContentResource()
				.getResourceResolver().adaptTo(QueryBuilder.class);
		Session session = currentPage.getContentResource()
				.getResourceResolver().adaptTo(Session.class);
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("path", startPath);
		querymap.put("type", "cq:Page");
		querymap.put("orderby", "@jcr:content/cq:lastModified");
		querymap.put("orderby.sort", "desc");
		querymap.put("property", "jcr:content/jcr:title");
		querymap.put("property.operation", "unequals");
		querymap.put("property.value", currentPage.getTitle());
		querymap.put("tagid.property", "jcr:content/cq:tags");
		Tag[] userTags = null;
		Tag[] tags = null;
        try {
			if(currentNode.getName().contains("allnews")){
									
				if(currentNode.getProperty("selectedtags") != null){
					TagManager tm = currentPage.getContentResource().getResourceResolver().adaptTo(TagManager.class);
					
					Value[] newsTags = currentNode.getProperty("selectedtags").getValues();
					
					tags = new Tag[newsTags.length];
					
					for(int i = 0; i < newsTags.length; i++){
						tags[i] = tm.resolve(newsTags[i].getString());
					}
				}
			}
			else{
				tags = currentPage.getTags();
			}
		} catch (RepositoryException e) {
			System.err.println("FeaturedNews currentNode getName: " + e.toString());
		}
        System.err.println("NewsForYouImpl: tags: " + tags.length);
		try {
			

				if (userNode.getProperty("Tags") != null) {
					TagManager tm = currentPage.getContentResource()
							.getResourceResolver().adaptTo(TagManager.class);

					Value[] userNodeTags = userNode.getProperty("Tags").getValues();

					userTags = new Tag[userNodeTags.length];

					for (int i = 0; i < userNodeTags.length; i++) {
						userTags[i] = tm.resolve(userNodeTags[i].getString());
					}
				}
			
		} catch (RepositoryException e) {
			System.err.println("NewsForYouImpl currentNode getName: "
					+ e.toString());
		}
		System.err.println("NewsForYouImpl: userTags: " + userTags.length);

		if (userTags != null && userTags.length > 0) {
			try {
				for (int i = 0; i < userTags.length; i++) {
					querymap.put("tagid." + (i + 1) + "_value",userTags[i].getNamespace().getName() + ":"+ userTags[i].getLocalTagID());
					System.err.println("USERTAG: "+ userTags[i].getNamespace().getName() + ":"+ userTags[i].getLocalTagID());
					
				}
				
				for (int i = 0; i < tags.length; i++) {
					for(Iterator<Map.Entry<String, String>> it = querymap.entrySet().iterator(); it.hasNext(); ) {
					      Map.Entry<String, String> entry = it.next();
					      if(entry.getValue().equals(tags[i].getNamespace().getName() + ":"+ tags[i].getLocalTagID())) {
					        it.remove();
					        
					      }
					    }
					System.err.println("TAG REMOVED: "+ tags[i].getNamespace().getName() + ":"+ tags[i].getLocalTagID());
					
				}
				

				querymap.put("tagid.and", "true");

				// can be done in querymap or with Query methods
				querymap.put("p.offset", "0"); // same as query.setStart(0) below
				querymap.put("p.limit", "30"); // same as
																// query.setHitsPerPage(20)
																// below
				System.err.println("querymap IS :::::::::::::::::"+querymap);
				Query query = queryBuilder.createQuery(
						PredicateGroup.create(querymap), session);

				SearchResult result = query.getResult();

				// If no pages have all the tags, look for pages with any of the
				// tags
				if (result.getTotalMatches() == 0) {
					querymap.remove("tagid.and");
					querymap.put("tagid.or", "true");
					query = queryBuilder.createQuery(
							PredicateGroup.create(querymap), session);
					result = query.getResult();
				}

				// iterating over the results
				for (Hit hit : result.getHits()) {
					Page found = null;

					found = currentPage.getPageManager().getPage(hit.getPath());
					System.err.println("............................PAGES FOUND ARE......................."+pages);
					pages.add( found);
				}
			} catch (RepositoryException e) {
				System.err.println("NewsForYouImpl::buildPages: "
						+ e.toString());
			} catch (NullPointerException e) {
				System.err.println("NewsForYouImpl::buildPages: Tags not published? - "+ e.toString());
			}
		} else {
			System.err.println("NewsForYouImpl::buildPages: currentPage.getTags() returned null");
		}
		List<NavigationItem> children = new ArrayList<NavigationItem>();
		Iterator<Page> childPages =pages.iterator();
		
		while (childPages.hasNext()) {

    		Page childnPage = childPages.next();
    		 
            // if article page is the current page
            boolean isActivePage = childnPage.equals(currentPage);

            // if currentPage is a descendant of Article Page
            boolean isHierarchyActive = currentPage.getPath().startsWith(childnPage.getPath());
            
            // don't include pages marked to be hidden in navigation
            if (!childnPage.isHideInNav() && childnPage.getContentResource() != null) {
                //look for ArticleTitle if blank, fall back to jcr:title
                String text = StringUtils.isNotBlank(childnPage.getNavigationTitle()) ? childnPage.getNavigationTitle() : childnPage.getTitle();
                
                String url = StringUtils.isNotBlank(childnPage.getVanityUrl()) ? childnPage.getVanityUrl() : childnPage.getPath();
                
                if(childnPage.getContentResource().isResourceType(PROP_REDIRECT_TYPE)){
            		// page is type redirect, set url as redirect page
            		url = (String) childnPage.getContentResource().getValueMap().get(PROP_REDIRECT_NAME);
                }
                
                if(! StringUtils.isNotBlank(url)){
                	url = "error";
                }
                
                
                List<NavigationItem> grandchildren = new ArrayList<NavigationItem>();
               
                Calendar createdDate = null;
                ValueMap props = childPage.getProperties();
                if(props.containsKey("jcr:created"))
                {
                	createdDate = props.get("jcr:created", Calendar.getInstance());
                }
                NavigationItem navItem = new NavigationItemImpl(childPage, isActivePage, isHierarchyActive, null, url, text, grandchildren, createdDate);
                children.add(navItem);    
                //Collections.sort(children, new CreatedDateComparator());
                
            }
        
			
		}
	log.info("GRAND CHILDREN ARE" + children);
		return children;
    	
    }

	class CreatedDateComparator implements Comparator<NavigationItem>
    {

		@Override
		public int compare(NavigationItem arg0, NavigationItem arg1) {
			if(null != arg0 && null != arg1)
			{
				Calendar arg0CreatedDate = arg0.getCreatedDate();
				Calendar arg1CreatedDate = arg1.getCreatedDate();
				if(null != arg0CreatedDate && null != arg1CreatedDate)
				{
					return arg1CreatedDate.compareTo(arg0CreatedDate);
				}
			}
			return 0;
		}
    	
    }
private void buildNavigationFamily(){
    	
    	family = new ArrayList<NavigationFamilyItem>();
    	
    	for(int i = 0; i < items.size(); i++){
    		// Get a total count of level 2 and level 3 links for each parent
    		int totalLinks = 0;
    		
    		System.err.println("Index i: " + i);
    		
    		List<NavigationItem> children = items.get(i).getItems();
    		
    		System.err.println("Parent[" + i + "] children count " + children.size());
    		
    		totalLinks += children.size(); // Level 2 links    		 
    		
    		for(int j = 0; j < children.size(); j++){
    			totalLinks += children.get(j).getItems().size();
    		}
    		
    		// Set column maximum links based on total
    		
    		int maxLinks = 6;
    		
    		if(totalLinks > 39){
    			maxLinks = 15;
    		}
    		else if(totalLinks > 27){
    			maxLinks = 12;
    		}
    		else if(totalLinks > 15){
    			maxLinks = 9;
    		}
    		else if(totalLinks > 10){
    			maxLinks = 5;
    		}
    		
    		System.err.println("Total # links: " + totalLinks + " Max links: " + maxLinks);
    		
    		// Build ArticleFamilyItem with Level 2 children combined as needed
    		List<List<NavigationItem>> level2 = new ArrayList<List<NavigationItem>>();
    		
    		if(children.size() > 0){
    			for(int j = 0; j < children.size(); j++){
        			int columnLinkCount = 0;
        			int listStart = j;
        			int listEnd = j;
        			System.err.println("Inside BROWSEALLARTICLES");
        			System.err.println("Child page: " + children.get(j).getText());
        			columnLinkCount += children.get(j).getItems().size();
        			System.err.println("Index " + j + " columnLinkCount: " + columnLinkCount);
        			
        			if(children.size() > 1 && (j + 1) < children.size()){
        				while(children.get(j+1).getItems().size() + 1 < maxLinks - columnLinkCount){ // + 1 for child/Level 2 item itself
        					System.err.println("Added to column: " + children.get(j+1).getText());
            				columnLinkCount += children.get(j+1).getItems().size() + 1;
            				listEnd++;
            				System.err.println("j: " + j + "columnLinkCount: " + columnLinkCount + " listEnd:" + listEnd);
            				j++;
            				
            				if(j == children.size()-1){
            					break;
            				}
            			}
        			}
        			
        			System.err.println("Sublist: " + listStart + " - " + (listEnd+1));
        			
        			List<NavigationItem> column = children.subList(listStart, listEnd + 1);
        			
        			System.err.println("Column size: " + column.size());
        			
        			level2.add(column);
        			
        		}
    		}
    		
    		System.err.println("Creating family item");
    		NavigationFamilyItem familyItem = new NavigationFamilyItemImpl(items.get(i), level2);
    		System.err.println("Adding family item to family");
    		
    		try {
    			System.err.println("family is null " + (family == null));
    			
    			family.add(familyItem);
    		} catch(Exception e) {
    			System.err.println("Add family item error: " + e.toString());
    		}
    		
    		System.err.println("Adding family item");
    		
    	}
    	
    	for(int i = 0; i < family.size(); i++){
    		NavigationFamilyItem level1 = family.get(i);
    		
    		System.err.println("\nParent: " + level1.getParent().getText());
    		
    		List<List<NavigationItem>> children = level1.getChildren();
    		
    		for(int j = 0; j < children.size(); j++){
    			List<NavigationItem> column = children.get(j);
    			
    			for(int k = 0; k < column.size(); k++){
    				NavigationItem level2 = column.get(k);
    				System.err.println("\tChild: " + level2.getText());
    				
    				List<NavigationItem> grandchildren = level2.getItems();
    				for(int x = 0; x < grandchildren.size(); x++){
    					System.err.println("\t\tGrandchild: " + grandchildren.get(x).getText());
    					System.err.println("\t\tGrandchild: " + grandchildren.get(x).getCreatedDate().getTime());
    				}
    			}
    		}
    	}
    	
    	System.err.println("Build Family complete");
}
}

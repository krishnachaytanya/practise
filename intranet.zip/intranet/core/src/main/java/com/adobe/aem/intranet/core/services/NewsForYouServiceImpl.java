package com.adobe.aem.intranet.core.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.bson.Document;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.beans.PageInfoDto;
import com.adobe.aem.intranet.core.constants.Constants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.google.gson.Gson;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;


@Component(label = " US Bank News For You Service", description = "US Bank News For You Service", metatype = true, immediate = true)
@Service(value = { NewsForYouService.class })
@Properties({
	@Property(name = "businessTagPrefix", value = "intranet-generated:business/", description = "Folder path location of employee extract info file"),
	@Property(name = "locationTagPrefix", value = "intranet-generated:location/", description = "Folder path location of employee extract info file")
})

public class NewsForYouServiceImpl implements NewsForYouService{
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Reference
	private DBService dBService;
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	@Reference
	private QueryBuilder builder;
	
    @SuppressWarnings("rawtypes")
    Dictionary properties = null;    
   
    String businessTagPrefix;
    String locationTagPrefix;
    
	@Activate
	public void activate(ComponentContext componentContext) throws Exception {
		properties = componentContext.getProperties();
		businessTagPrefix = (String) properties.get("businessTagPrefix");
		locationTagPrefix = (String) properties.get("locationTagPrefix");

	}

	public String getMessage(String months, String user, String tagsAr[], String allTagsAr[] ) {
		
		StringBuilder message = new StringBuilder();

		ResourceResolver resourceresolver = null;
		try {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "readService");
			resourceresolver = resolverFactory
					.getServiceResourceResolver(param);

		} catch (LoginException e) {
			log.error(e.getMessage(), e);
			return null;
		}
		
		Session session = resourceresolver.adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();

		// To get Query results for NewsForYou Component

		String todate = null;
		String fromdate = null;
		if (months != null) {
			log.info("News For You Servlet- Inside News for You Tab");
			int monthCount = Integer.parseInt(months);
			DateFormat cdateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'");
			TimeZone tz = TimeZone.getTimeZone("UTC");
			cdateFormat.setTimeZone(tz);
			Date cdate = new Date();
			todate = cdateFormat.format(cdate);
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -monthCount);
			Date todate1 = cal.getTime();
			fromdate = cdateFormat.format(todate1);
		}
		// To get User Node Path Based on the Current User
		// Create Query from Map
		Query query = builder.createQuery(PredicateGroup.create(createQueryMap(todate, fromdate, resourceresolver, tagsAr, allTagsAr, user)), session);
		SearchResult result = query.getResult();

		if (result.getTotalMatches() == 0) {
			map.remove("tagid.and");
			map.put("tagid.or", "true");
			query = builder.createQuery(PredicateGroup .create(createQueryMap(todate, fromdate, resourceresolver, tagsAr, allTagsAr, user)), session);
			result = query.getResult();
		}
		
		List<String> selectedTagsAsList = new ArrayList<String>();

		if (tagsAr != null)
			selectedTagsAsList = Arrays.asList((tagsAr));
		message.append(iterateResults(result, resourceresolver, selectedTagsAsList).toString());

		return message.toString();
		
	}


	// Method to Create a Map from query parameters
	private Map<String, String> createQueryMap(String todate, String fromdate, ResourceResolver resourceresolver, String tagsAr[], String allTagsAr[], String user) {
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("path", Constants.PROP_START_PATH_DEFAULT + "/articles");
		querymap.put("type", "cq:Page");
		querymap.put("orderby", Constants.JCR_LAST_MODIFIED);
		querymap.put("orderby.sort", "desc");
		querymap.put("1_property", "@jcr:content/cq:template");
		querymap.put("1_property.value", "/conf/intranet/settings/wcm/templates/article");
		querymap.put("daterange.property", Constants.JCR_LAST_MODIFIED);
		if (fromdate != null) {
			querymap.put("daterange.lowerBound", fromdate);
			querymap.put("daterange.upperBound", todate);
		}
		ArrayList <Tag> userTags = getUserTags(resourceresolver,  user, allTagsAr );
		
		
		// Add UserTags to map and remove FeaturedNews Tag from map

		if (userTags != null && userTags.size() > 0) {
			log.info("inside user tags are not null " + userTags.size());
			querymap.put("2_property", Constants.PROP_TAGS);
			try {
				for (int i = 0; i < userTags.size(); i++) {
					Tag userTag = userTags.get(i);
					if (null != userTag) {
						querymap.put("2_property." + (i + 1) + "_value", userTag.getNamespace().getName() + ":" + userTag.getLocalTagID());
					}
				}
				if (tagsAr != null) {
					for (int i = 0; i < tagsAr.length; i++) {
						for (Iterator<Map.Entry<String, String>> it = querymap.entrySet().iterator(); it.hasNext();) {
							Map.Entry<String, String> entry = it.next();
							if (entry.getValue().equals(tagsAr[i])) {
								it.remove();
							}
						}
					}
				}
			} catch (NullPointerException e) {
				log.error("NewsForYouServlet:: Tags not published? - ", e);
			}
		} else {
			if (tagsAr != null) {
				for (int i = 0; i < tagsAr.length; i++) {
					log.info("inside user tags are null");
					querymap.put("group.2_property", Constants.PROP_TAGS);
					querymap.put("group.2_property." + (i + 1) + "_value",tagsAr[i]);
					querymap.put("group.2_property.operation", "unequals");
					querymap.put("group.3_property", Constants.PROP_TAGS);
					querymap.put("group.3_property.operation", "not");
					querymap.put("group.p.or", "true");
				}
			}
		}
		querymap.put("p.offset", "0");
		querymap.put("p.limit", "20");
		return querymap;
	}

	

	//returns a list of tags for the user to search on, including the ones automatically given based on their user data
	private ArrayList<Tag> getUserTags(ResourceResolver resourceresolver, String user, String allTagsAr[]) {
		ArrayList <Tag> userTags = new ArrayList<Tag>();
		TagManager tm = resourceresolver.adaptTo(TagManager.class);
		
		try {
			String[] tagsFromDB = getSelectedtags(user);
			log.info("tags from DB " + tagsFromDB);
			
			if (null != tagsFromDB) {
				log.info("tags from DB lenght in servlet " + tagsFromDB.length);

				for (int i = 0; i < tagsFromDB.length; i++) {
					String tagValue= tagsFromDB[i].trim();
					
					log.info("tags from DB " + tagValue);
            		if (tagValue.indexOf("location:")== 0) {
            			tagValue=locationTagPrefix+tagValue.substring(9);
            		} else if (tagValue.indexOf("business:")== 0){
            			tagValue=businessTagPrefix+tagValue.substring(9);
            		}
            		
            		log.info("tags from DB processes " + tagValue);
            		
	            	Tag tag = tm.resolve(tagValue);
	            	
	            	
	            	if (tag != null) {
	            		log.info("Adding tag " + tag.getName()); 
	            		userTags.add(tag);
	            	}
				}
				log.info("user tags length in servlet " + userTags.size());
			}

		} catch (Exception e) {
			log.error("Exception thrown "+e.getMessage(), e);
		}

		
		for (int i = 0; allTagsAr!=null && i < allTagsAr.length ; i++ ) {
			log.info("all tag " +  allTagsAr[i]);
			
        	Tag tag = tm.resolve(allTagsAr[i].trim());
        	if (tag != null)
        		userTags.add(tag);
        	else
        		log.info("notag " + allTagsAr[i].trim());
			
		}

		Node userNode = null;
		String path = "/etc/users/";
		String topFolder = user.split("")[0].toLowerCase();

		if (topFolder.equals("c") && user.split("")[1].matches("\\d")) {
			topFolder += user.split("")[1];
		}

		String secondLevelFolder = user.toLowerCase();

		if (secondLevelFolder.matches("^c\\d+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 5);
		} else if (secondLevelFolder.matches("^\\w+")) {
			secondLevelFolder = secondLevelFolder.substring(0, 3);
		}

		Resource resource = resourceresolver.getResource(path + topFolder + "/" + secondLevelFolder + "/"
				+ user);
		if (resource != null) {
			userNode = resource.adaptTo(Node.class);
		}

		if (userNode != null) {
			try{
				if (userNode.hasProperty("State")){
					String state = userNode.getProperty("State").getString();
					String country = userNode.getProperty("country").getString();
					Tag tag = null;
					if (state == null || "".equals(state)) {
						tag = tm.resolve(locationTagPrefix+country);
					} else {
						tag = tm.resolve(locationTagPrefix+country+"-"+state);
					}
	            	if (tag != null)
	            		userTags.add(tag);
	            	else
	            		log.info("notag " + locationTagPrefix+country+"-"+state);
				}
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			
			try{
				if (userNode.hasProperty("BusinessLineCD")){
					String businessLineCode = userNode.getProperty("BusinessLineCD").getString();

	            	Tag tag = tm.resolve(businessTagPrefix+businessLineCode);
	            	if (tag != null)
	            		userTags.add(tag);
	            	else
	            		log.info("notag " + businessTagPrefix+businessLineCode);
				}
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		
		log.info("selected tags ");
		for (Tag tag: userTags) {
			log.info(tag.getPath()+""+tag.getName());
		}
		return userTags;
				
	}
	
	
	
	// Method to Iterate the results from the query
	private String iterateResults(SearchResult result, ResourceResolver resourceresolver, List selectedTags) {

		Iterator<Node> nodeIter = result.getNodes();
		Node currentNode = null;
		PageInfoDto pageInfoDto = null;
		ArrayList<PageInfoDto> pageList = new ArrayList<PageInfoDto>();
		HashMap<String, ArrayList<PageInfoDto>> userPageInfoMap = new HashMap<String, ArrayList<PageInfoDto>>();
		while (nodeIter.hasNext()) {
			pageInfoDto = new PageInfoDto();
			currentNode = nodeIter.next();
			Resource nodeResource = null;
			String currentNodePath;
			try {
				currentNodePath = currentNode.getPath().toString() + Constants.JCR_CONENT;
				nodeResource = resourceresolver.getResource(currentNodePath);

				if (nodeResource != null && !hasSelectedTags(selectedTags, currentNode)) {
					// Get node properties from result nodes
					ValueMap pageProperties = nodeResource.adaptTo(ValueMap.class);
					// String myPath = currentNode.getPath().toString();
					String myPath = resourceresolver.map( currentNode.getPath());
					Date date = currentNode.getProperty("jcr:created").getDate().getTime();
					SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");// dd/MM/yyyy
					String strDate = sdfDate.format(date);
					String myTitle = pageProperties.get(Constants.JCR_TITLE, "");
					log.info("Got title "+myTitle);
					String mySynopsis = pageProperties.get(Constants.JCR_DESCRIPTION, "");
					pageInfoDto.setTitle(myTitle);
					pageInfoDto.setPath(myPath);
					pageInfoDto.setSynopsis(mySynopsis);
					pageInfoDto.setLastReplicatedOn(strDate);
					pageList.add(pageInfoDto);

				}
			} catch (RepositoryException e1) {
				log.error("NewsForYouServlet:: " + e1.toString());
			}

		}
		userPageInfoMap.put("stories", pageList);
		Gson gson = new Gson();
		String resultJson = gson.toJson(userPageInfoMap);
		// Return json data with node properties
		return resultJson;

	}
	
    private MongoClient getConnection(){
    	
    	return dBService.getConnection();

    }
    
	private List<String> getDBValue(String key, String userId){
		List<String> values = new ArrayList<String>();
		
		try {
			MongoClient mongo = getConnection();
			
			if(mongo != null){
				
				MongoDatabase db = mongo.getDatabase("intranet");
				
				MongoCollection<Document> table = db.getCollection("users");
				
				Document searchQuery = new Document();
				searchQuery.put("uid", userId);
				
				FindIterable<Document> cursor = table.find(searchQuery);
				
				MongoCursor<Document> it = cursor.iterator();

				if(it.hasNext()) {
					Document user = it.next();

					if(user.containsKey(key)){
						if(user.getString(key).contains(",")){
							values.addAll(Arrays.asList(user.getString(key).split(",")));
						}
						else if(null != user.getString(key) && !user.getString(key).equals("")){
							values.add(user.getString(key));
						}
						
					}
				}
				
				mongo.close();
			}
		} catch (Exception e){
			log.error("UserHelper getDBValue for " + key + ": " + e.toString());
		}

		return values;
	}
	
	public String[] getSelectedtags(String userId){
		String[] userTags = null;
		
		try{
			List<String> tagsList = getDBValue("tags", userId);
			
			if(null != tagsList && tagsList.size() > 0){
				userTags = tagsList.toArray(new String[0]);
			}
			//log.info("user tags length "+userTags.length);
			
		} catch (Exception e){
			log.error("user tags are null ", e);
		}
		return userTags;
	}
    
	private Boolean hasSelectedTags(List<String> selectedTags, Node pageNode) {
		
		log.info("selcted tags " + selectedTags);
		try {
			log.info("selcted tags " + selectedTags + " content path " + pageNode.getPath());
			if (pageNode.hasNode("jcr:content") && null != selectedTags && !selectedTags.isEmpty()) {
				Node pageContentNode = pageNode.getNode("jcr:content");

				if (pageContentNode.hasProperty("cq:tags")) {

					Value[] values = pageContentNode.getProperty("cq:tags").getValues();
					for (Value v : values) {
						log.info("values of path " + v.getString());

						if (selectedTags.contains(v.getString())) {
							return true;
						}
					}
					;
				}
			}

		} catch (Exception e) {
			log.error("Exception from hasSelected Tags", e);
		}

		return false;
	}


}

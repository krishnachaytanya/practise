package com.adobe.aem.intranet.core.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.version.VersionException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true)
@Service(UserSyncServiceImpl.class)
@Properties({
	@Property(name = "folder", value = "", description = "Folder path location of employee extract info file"),
	@Property(name = "fileName", value = "", description = "Employee extract info file name"),
    @Property(name = "rebuild", value = "false", description = "Rebuild all user entries when service is loaded"),
})


public class UserSyncServiceImpl implements UserSyncService {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@SuppressWarnings("rawtypes")
	Dictionary properties = null;
	
	private String folder = null;
	private String fileName = null;
	private boolean rebuild = false;
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	private Session session;
	
	private static String salt = "f8qZqXvD0R";

	@Activate
	public void activate(ComponentContext componentContext){
		log.info("Activating UserSyncServiceImpl.active()");
		
		properties = componentContext.getProperties();
		folder = (String) properties.get("folder");
		fileName = (String) properties.get("fileName");
		rebuild = "true".equals( (String) properties.get("rebuild"));
		log.info("UserSyncServiceImpl rebuild is "+ rebuild);
		try {
			syncUsers();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		rebuild = false;
		log.info("Exiting UserSyncServiceImpl.activate()");
	}
	
	@Override
	public void syncUsers() {
		log.info("UserSyncServiceImpl: executing userSync");
		
		//String folder = "c:/Users/hwharr1/AEM/63/author/crx-quickstart/CommonData"; //"D:/aem/CommonData";
        
		String file = folder + fileName;
		
		File myfile = new File(file);
		
		Map<String, Integer> idCount = new HashMap<String, Integer>();
        Map<String, Integer> letterCount = new HashMap<String, Integer>();
        ArrayList<String> ids = new ArrayList<String>();
        TreeMap<String, String> locationTags = new TreeMap<String, String>();
        TreeMap<String, String> businessLineTags = new TreeMap<String, String>();
        List<String> countryTags = new ArrayList<String>();
        BufferedReader reader = null;
        
        try {
			reader = new BufferedReader(new FileReader(myfile));
			
			int count = 0;
			String line;
			
						
		    while ((line = reader.readLine()) != null){
		    			    	
		    	if(count > 0){
		    		String id = line.split("\\|")[0].toLowerCase();
                    
                    if(id.matches("^c\\d+")){
                    	ids.add(line);
                    	
                    	// user id is a contractor id
                    	id = id.substring(0, 5);		    				    		
		    		    
                        if(idCount.containsKey(id)){
                            idCount.replace(id, idCount.get(id), idCount.get(id)+1);
                        }
                        else{
                            idCount.put(id, new Integer(1));
                        } 
                    }
                    else if(id.matches("^\\w+")){
                    	ids.add(line);
                    	
                        id = id.substring(0, 3);		    				    		
		    		    
                        if(idCount.containsKey(id)){
                            idCount.replace(id, idCount.get(id), idCount.get(id)+1);
                        }
                        else{
                            idCount.put(id, new Integer(1));
                        }               
                        
                    }                    
		    	}
		    	
                count++;
		    }
            
            int total = 0;
            
            List<String> keys = new ArrayList<String>(idCount.keySet());
            Collections.sort(keys);
		
            for(String key : keys) {
                                    
                total += idCount.get(key);
                
                String chars = key.split("")[0];
                
                if(chars.equals("c") && key.split("")[1].matches("\\d")){
                    chars += key.split("")[1];
                }
                
                if(letterCount.containsKey(chars)){
                    letterCount.replace(chars, letterCount.get(chars), letterCount.get(chars)+1);
                }
                else{
                    letterCount.put(chars, new Integer(1));
                }
            }

            log.debug("\nTotal users: " + total);
            
            for (Map.Entry<String, Integer> entry : letterCount.entrySet()) {
            	log.debug("UserSyncServiceImpl userSync: " + entry.getKey() + " has " + entry.getValue() + " entries");
            }
            
            log.debug("Total top folders: " + letterCount.size());

            
		} catch (FileNotFoundException e) {
			log.error("Data file processing: " + e.toString());
		} catch (IOException e) {
			log.error("Data file processing: " + e.toString());
		}
        
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
        ResourceResolver resourceResolver = null;
		
        try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			
			session = resourceResolver.adaptTo(Session.class);
		} catch (LoginException e) {
			log.error(e.toString());
		}
        
        // Look for users node and create if needed
        Node etc = null;
        
        Node users = null;
        
        try {
			users = session.getNode("/etc/users");
		} catch (RepositoryException e) {
			log.error("Get users node: " + e.toString());
		}
        
        if(users == null){
        	
        	try {
				etc = session.getNode("/etc");
				users = etc.addNode("users", "nt:unstructured");
				
				log.error("Users created = " + (users != null));
				session.save();
			} catch (ItemExistsException e) {
				log.error("Add users node: " + e.toString());
			} catch (PathNotFoundException e) {
				log.error("Add users node: " + e.toString());
			} catch (VersionException e) {
				log.error("Add users node: " + e.toString());
			} catch (ConstraintViolationException e) {
				log.error("Add users node: " + e.toString());
			} catch (LockException e) {
				log.error("Add users node: " + e.toString());
			} catch (RepositoryException e) {
				log.error("Add users node: " + e.toString());
			}
        }        

    	if(users != null){
        	// Loop through top level letter folders and create
        	for(Map.Entry<String, Integer> entry : letterCount.entrySet()) {
                try {
					if(!users.hasNode(entry.getKey())){
						users.addNode(entry.getKey(), "nt:unstructured");
						session.save();
					}
				} catch (ItemExistsException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (PathNotFoundException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (NoSuchNodeTypeException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (LockException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (VersionException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (ConstraintViolationException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				} catch (RepositoryException e) {
					log.error("Top level node creation for " + entry.getKey() + ": " + e.toString());
				}
            }
        	
        	// Loop through 2nd level folders and create in correct top level folder
			List<String> keys = new ArrayList<String>(idCount.keySet());
            Collections.sort(keys);
		
            for(String key : keys) {
        		String idFolder = key;
        		
        		String parentFolderID = idFolder.split("")[0];
                
                // contractor IDs go in c0 top folder
        		if(parentFolderID.equals("c") && idFolder.split("")[1].matches("\\d")){
                	parentFolderID += idFolder.split("")[1];
                }
                
                try {
                	Node parentFolder = users.getNode(parentFolderID);
                	
                	if(!parentFolder.hasNode(key)){
                		parentFolder.addNode(key, "nt:unstructured");
                		session.save();        				
					}
				} catch (ItemExistsException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (PathNotFoundException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (NoSuchNodeTypeException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (LockException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (VersionException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (ConstraintViolationException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
				} catch (RepositoryException e) {
					log.error("2nd level node creation for " + key + ": " + e.toString() + " Session:" + (session == null));
					break;
				}
        	}
            log.info("Reading user records " + ids.size());
            int totalAdded=0;
            int totalUpdated=0;

            // Add ids into 2nd level folders
            for(int i = 0; i < ids.size(); i++){
            	String[] userValues = ids.get(i).split("\\|");
            	
            	String topFolder = userValues[0].split("")[0].toLowerCase();
            	
            	if(topFolder.equals("c") && userValues[0].split("")[1].matches("\\d")){
            		topFolder += userValues[0].split("")[1];
                }
            	
            	String secondLevelFolder = userValues[0].toLowerCase();
            	
            	if(secondLevelFolder.matches("^c\\d+")){
            		secondLevelFolder = secondLevelFolder.substring(0, 5);
            	}
            	else if(secondLevelFolder.matches("^\\w+")){
            		secondLevelFolder = secondLevelFolder.substring(0, 3);
            	}
            	
            	try {
            		
            		if (userValues.length >= 28){
            			if (userValues[13].length()>0 && userValues[14].length()>0) {
            				locationTags.put(userValues[14]+"-"+userValues[13], userValues[14]+"-"+userValues[13]);
            				countryTags.add(userValues[14]);
            			}
            			else if (userValues[14].length()>0)
            				locationTags.put(userValues[14], userValues[14]);

            			if (userValues[27].length()>0 && userValues[26].length()>0) {
             				businessLineTags.put(userValues[27], userValues[26]);
            			}
            		}
					
					if(!users.hasNode(topFolder + "/" + secondLevelFolder + "/" + userValues[0].toLowerCase())){
						
						log.debug("UserSyncServiceImpl: Creating User " + userValues[1] +" "+ userValues[2]);
						totalAdded++;
						Node user = users.addNode(topFolder + "/" + secondLevelFolder + "/" + userValues[0].toLowerCase(), "nt:unstructured");

						user.setProperty("firstName", (userValues.length >= 2) ? userValues[1] : "");
						user.setProperty("lastName", (userValues.length >= 3) ? userValues[2] : "");
						user.setProperty("middleName", (userValues.length >= 4) ? userValues[3] : "");
						user.setProperty("fullName", (userValues.length >= 5) ? userValues[4] : "");
						user.setProperty("nickname", (userValues.length >= 6) ? userValues[5] : "");
						user.setProperty("WorkEmailADDR", (userValues.length >= 7) ? userValues[6] : "");
						user.setProperty("MailLocationCD", (userValues.length >= 8) ? userValues[7] : "");
						user.setProperty("mailCodeDescription", (userValues.length >= 9) ? userValues[8] : "");
						user.setProperty("AddressLine1", (userValues.length >= 10) ? userValues[9] : "");
						user.setProperty("AddressLine2", (userValues.length >= 11) ? userValues[10] : "");
						user.setProperty("City", (userValues.length >= 12) ? userValues[11] : "");
						user.setProperty("postalCode", (userValues.length >= 13) ? userValues[12] : "");
						user.setProperty("State", (userValues.length >= 14) ? userValues[13] : "");
						user.setProperty("country", (userValues.length >= 15) ? userValues[14] : "");
						user.setProperty("CountryCD", (userValues.length >= 16) ? userValues[15] : "");
						user.setProperty("EstablishmentCD", (userValues.length >= 17) ? userValues[16] : "");
						user.setProperty("EstablishmentDESC", (userValues.length >= 18) ? userValues[17] : "");
						user.setProperty("MGRPreferredID", (userValues.length >= 19) ? userValues[18] : "");
						user.setProperty("employeeType", (userValues.length >= 20) ? userValues[19] : "");
						user.setProperty("CostCenter", (userValues.length >= 21) ? userValues[20] : "");
						user.setProperty("CostCenterDescription", (userValues.length >= 22) ? userValues[21] : "");
						user.setProperty("Division", (userValues.length >= 23) ? userValues[22] : "");
						user.setProperty("BusinessLine", (userValues.length >= 24) ? userValues[23] : "");
						user.setProperty("BusinessLineID", (userValues.length >= 27) ? userValues[26] : "");
						user.setProperty("BusinessLineCD", (userValues.length >= 28) ?userValues[27] : "");
						
						String saltedUser = userValues[0].toLowerCase() + salt;
						
						MessageDigest digest = null;
						byte[] encodedhash = null;
						
						try {
							digest = MessageDigest.getInstance("SHA-256");
							encodedhash = digest.digest(saltedUser.getBytes(StandardCharsets.UTF_8));
						} catch (NoSuchAlgorithmException e) {
							log.error("UserHelper getUser: " + e.getMessage(), e);
						}
						
						user.setProperty("HashedUser", encodedhash.toString());
						
						session.save();
					}
					else{
						// Check the date in userValues - if newer than yesterday, update values
						String update = (userValues.length >= 25) ? userValues[24] : "";
						
						if(!"".equals(update)){
							Calendar today = Calendar.getInstance();
							today.add(Calendar.DAY_OF_YEAR, -4);
							
							final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");							
							Date updateDate = timestampFormat.parse(update);
							Calendar updated = Calendar.getInstance();
							updated.setTime(updateDate);
							
							if(rebuild || updated.after(today)){
								// Update user values
								log.debug("UserSyncServiceImpl: Updating User " + userValues[1] +" "+ userValues[2]);
								totalUpdated++;
								Node user = users.getNode(topFolder + "/" + secondLevelFolder + "/" + userValues[0].toLowerCase());
								
								user.setProperty("firstName", (userValues.length >= 2) ? userValues[1] : "");
								user.setProperty("lastName", (userValues.length >= 3) ? userValues[2] : "");
								user.setProperty("middleName", (userValues.length >= 4) ? userValues[3] : "");
								user.setProperty("fullName", (userValues.length >= 5) ? userValues[4] : "");
								user.setProperty("nickname", (userValues.length >= 6) ? userValues[5] : "");
								user.setProperty("WorkEmailADDR", (userValues.length >= 7) ? userValues[6] : "");
								user.setProperty("MailLocationCD", (userValues.length >= 8) ? userValues[7] : "");
								user.setProperty("mailCodeDescription", (userValues.length >= 9) ? userValues[8] : "");
								user.setProperty("AddressLine1", (userValues.length >= 10) ? userValues[9] : "");
								user.setProperty("AddressLine2", (userValues.length >= 11) ? userValues[10] : "");
								user.setProperty("City", (userValues.length >= 12) ? userValues[11] : "");
								user.setProperty("postalCode", (userValues.length >= 13) ? userValues[12] : "");
								user.setProperty("State", (userValues.length >= 14) ? userValues[13] : "");
								user.setProperty("country", (userValues.length >= 15) ? userValues[14] : "");
								user.setProperty("CountryCD", (userValues.length >= 16) ? userValues[15] : "");
								user.setProperty("EstablishmentCD", (userValues.length >= 17) ? userValues[16] : "");
								user.setProperty("EstablishmentDESC", (userValues.length >= 18) ? userValues[17] : "");
								user.setProperty("MGRPreferredID", (userValues.length >= 19) ? userValues[18] : "");
								user.setProperty("employeeType", (userValues.length >= 20) ? userValues[19] : "");
								user.setProperty("CostCenter", (userValues.length >= 21) ? userValues[20] : "");
								user.setProperty("CostCenterDescription", (userValues.length >= 22) ? userValues[21] : "");
								user.setProperty("Division", (userValues.length >= 23) ? userValues[22] : "");
								user.setProperty("BusinessLine", (userValues.length >= 24) ? userValues[23] : "");
								user.setProperty("BusinessLineID", (userValues.length >= 27) ? userValues[26] : "");
								user.setProperty("BusinessLineCD", (userValues.length >= 28) ?userValues[27] : "");

								session.save();
							}
						}
					}
				} catch (RepositoryException e) {
					log.error("user level node creation for " + userValues[0] + ": " + e.toString());
				} catch (ParseException e) {
					log.error("user level node creation for " + userValues[0] + ": " + e.toString());
				}
            }
        	
            log.info("Total Users added:" +totalAdded+" updated:"+totalUpdated);
            
            Node tagsNode = null;

        	if (tagsNode == null) {
        		try {
					Node etcTagNode = session.getNode("/etc/tags/");
					if (etcTagNode.hasNode("intranet-generated")) {
						
						tagsNode = etcTagNode.getNode("intranet-generated");
					} else {
						tagsNode = etcTagNode.addNode("intranet-generated", "cq:Tag");
						tagsNode.setProperty("sling:resourceType", "cq/tagging/components/tag");
						tagsNode.setProperty("jcr:title", "Intranet Generated Tags");
						tagsNode.setProperty("jcr:description", "");
						session.save();
					}
	    		} catch (RepositoryException e) {
	    			log.error("Get users node: " + e.getMessage(), e);
	    		}
        	}
            //clean countries used in states out of locations tags
        	
        	for (String country : countryTags) {
        		locationTags.remove(country);
        	}
            
            Node businessTagsNode = null;
            
            try {  	
            	if (tagsNode.hasNode("business"))
            	{
            		businessTagsNode = tagsNode.getNode("business");   
            	} else {
					businessTagsNode = tagsNode.addNode("business", "cq:Tag");
					businessTagsNode.setProperty("sling:resourceType", "cq/tagging/components/tag");
					businessTagsNode.setProperty("jcr:title", "Business");
					businessTagsNode.setProperty("jcr:description", "Business");
					session.save();
            	}
            	
    		} catch (RepositoryException e) {
    			log.error("Get business node: " + e.getMessage(), e);
    		}
        	            
            Node locationTagsNode = null;
            
            try {
            	if (tagsNode.hasNode("location"))
            	{
            		locationTagsNode = tagsNode.getNode("location"); 
            	} else {
    				locationTagsNode = tagsNode.addNode("location", "cq:Tag");
    				locationTagsNode.setProperty("sling:resourceType", "cq/tagging/components/tag");
    				locationTagsNode.setProperty("jcr:title", "Location");
    				locationTagsNode.setProperty("jcr:description", "Location");
    				session.save();
            	}
    		} catch (RepositoryException e) {
    			log.error("Get location node: " + e.getMessage(), e);
    		}
            
            
            for ( String key: businessLineTags.keySet()) {
            	String value = key;

            	try {
            		Node tagNode = null;
            		if (businessTagsNode.hasNode(value)) {
            			tagNode = businessTagsNode.getNode(value);
            		}
            		else {
            			tagNode = businessTagsNode.addNode(value, "cq:Tag");
            		}
            		tagNode.setProperty("sling:resourceType", "cq/tagging/components/tag");
            		tagNode.setProperty("jcr:title", key);
            		tagNode.setProperty("jcr:description", "");
            		session.save();
				} catch (ItemExistsException e) {
					log.error( e.getMessage(), e);
				} catch (PathNotFoundException e) {
					log.error( e.getMessage(), e);
				} catch (NoSuchNodeTypeException e) {
					log.error( e.getMessage(), e);
				} catch (LockException e) {
					log.error( e.getMessage(), e);
				} catch (VersionException e) {
					log.error( e.getMessage(), e);
				} catch (ConstraintViolationException e) {
					log.error( e.getMessage(), e);
				} catch (RepositoryException e) {
					log.error( e.getMessage(), e);
				}
            }
            
            for ( String key: locationTags.keySet()) {
            	String value = locationTags.get(key);
            	log.info(key+":"+value);
            	try {
            		Node tagNode = null;
            		if (locationTagsNode.hasNode(value)) {
            			tagNode = locationTagsNode.getNode(value);
            		}
            		else {
            			tagNode = locationTagsNode.addNode(value, "cq:Tag");
            		}
            		
            		tagNode.setProperty("sling:resourceType", "cq/tagging/components/tag");
            		tagNode.setProperty("jcr:title", key);
            		tagNode.setProperty("jcr:description", "");
            		session.save();
				} catch (ItemExistsException e) {
					log.error( e.getMessage(), e);
				} catch (PathNotFoundException e) {
					log.error( e.getMessage(), e);
				} catch (NoSuchNodeTypeException e) {
					log.error( e.getMessage(), e);
				} catch (LockException e) {
					log.error( e.getMessage(), e);
				} catch (VersionException e) {
					log.error( e.getMessage(), e);
				} catch (ConstraintViolationException e) {
					log.error( e.getMessage(), e);
				} catch (RepositoryException e) {
					log.error( e.getMessage(), e);
				}
            }
            
            
        	session.logout();
		    resourceResolver.close();
			
        }
    	
    	try {
			reader.close();
		} catch (IOException e) {
			log.error("File reader close: " + e.toString());
		}
    	
    	
    	
	}
	
}

package com.adobe.aem.intranet.models.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.Alerts;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Alerts.class, resourceType = "intranet/components/content/alertsDisplay")
@Exporter(name = "jackson", extensions = "json")
public class AlertsImpl implements Alerts {
	protected static final String PROP_START_PATH_DEFAULT = "/content/intranet/en-US/alerts";

	@ScriptVariable
    private Style currentStyle;
	
	@ScriptVariable
    private Page currentPage;
	
	private Page startPage;
	
	private List<Node> bannerAlert = new ArrayList<Node>();
	
	private String popupAlert = "";
	
	@PostConstruct
    private void initModel() {
        startPage = currentPage.getPageManager().getPage(currentStyle.get(PN_START_PATH, PROP_START_PATH_DEFAULT));
        
        setValues();
    }
	
	@Override
	public List<Node> getBanneralert() {
		return bannerAlert;
	}

	@Override
	public String getPopupalert() {
		return popupAlert;
	}
	
	public void setValues(){
		// Get alerts from alert page
		Node alertsNode = startPage.getContentResource("root/responsivegrid/alerts/alerts") != null ? startPage.getContentResource("root/responsivegrid/alerts/alerts").adaptTo(Node.class) : null;
		
		ArrayList<Node> popups = new ArrayList<Node>();
		
		ArrayList<Node> banners = new ArrayList<Node>();
		
		final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		
		if(alertsNode != null){
			NodeIterator children = null;
			
			try {
				children = alertsNode.getNodes();
				
				while(children.hasNext()){
	        		Node child = (Node) children.next();
	        		
	        		Date startDate = timestampFormat.parse(child.getProperty("onTime").getString());
	        		Date endDate = timestampFormat.parse(child.getProperty("offTime").getString());
	        		
	        		Date today = new Date();
	        		
	        		if(child.getProperty("alertType").getString().equalsIgnoreCase("popup")){
	        			if(startDate.compareTo(today) <= 0 && endDate.compareTo(today) > 0){
	        				popups.add(child);
	        			}
	        		}
	        		else{
	        			if(startDate.compareTo(today) <= 0 && endDate.compareTo(today) > 0){
	        				banners.add(child);	        				
	        			}
	        		}
				}
			} catch (RepositoryException e) {
				System.err.println("AlertsImpl alertsNode children: " + e.toString());
			} catch (ParseException e) {
				System.err.println("AlertsImpl alertsNode children: " + e.toString());
			}
		}
		
		// Get newest eligible banner alert and popup alert
		if(popups.size() > 0){
			// Sort lists of viable alerts by end date ending soonest
			Collections.sort(popups, new Comparator<Node>() {
			    @Override
			    public int compare(Node o1, Node o2) {
			    	Date date1 = null;
			    	Date date2 = null;
			    	
			    	try {
						date1 = timestampFormat.parse(o1.getProperty("offTime").getString());
						date2 = timestampFormat.parse(o2.getProperty("offTime").getString());
					} catch (ValueFormatException e) {
						System.err.println("AlertsImpl popups date sort: " + e.toString());
					} catch (PathNotFoundException e) {
						System.err.println("AlertsImpl popups date sort: " + e.toString());
					} catch (ParseException e) {
						System.err.println("AlertsImpl popups date sort: " + e.toString());
					} catch (RepositoryException e) {
						System.err.println("AlertsImpl popups date sort: " + e.toString());
					}
			    	
			    	return date1.compareTo(date2);
			    }
			});
			
			try {
				popupAlert = popups.get(0).getPath();
			} catch (RepositoryException e) {
				System.err.println("AlertsImpl popups get path: " + e.toString());
			}
		}
		
		if(banners.size() > 0){
			// Sort lists of viable alerts by end date ending soonest
			Collections.sort(banners, new Comparator<Node>() {
			    @Override
			    public int compare(Node o1, Node o2) {
			    	Date date1 = null;
			    	Date date2 = null;
			    	
			    	try {
						date1 = timestampFormat.parse(o1.getProperty("offTime").getString());
						date2 = timestampFormat.parse(o2.getProperty("offTime").getString());
					} catch (ValueFormatException e) {
						System.err.println("AlertsImpl banners date sort: " + e.toString());
					} catch (PathNotFoundException e) {
						System.err.println("AlertsImpl banners date sort: " + e.toString());
					} catch (ParseException e) {
						System.err.println("AlertsImpl banners date sort: " + e.toString());
					} catch (RepositoryException e) {
						System.err.println("AlertsImpl banners date sort: " + e.toString());
					}
			    	
			    	return date1.compareTo(date2);
			    }
			});
			System.err.println("AlertsImpl banners size: " + banners.size());
			bannerAlert = banners;
		}
	}
}

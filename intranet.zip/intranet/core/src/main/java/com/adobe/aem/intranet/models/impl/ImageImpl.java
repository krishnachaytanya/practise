package com.adobe.aem.intranet.models.impl;


import javax.annotation.PostConstruct;
import javax.jcr.Node;

import com.adobe.aem.intranet.models.Image;
import com.adobe.aem.intranet.core.utils.LinkUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = SlingHttpServletRequest.class, adapters = Image.class, resourceType = "intranet/components/content/image")
public class ImageImpl implements Image {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

	private String PagePath = null;
 
    @ScriptVariable
    private Node currentNode;
      
    @PostConstruct
    private void initModel() {  	
    	setValues();
    }
    
    @Override
    public String getPagePath() {
        return PagePath;
    } 

    public void setValues(){
    	
  	try{
  		PagePath = LinkUtils.formatLink(currentNode.getProperty("linkURL").getValue().getString());
	}catch (Exception e) {
		log.error("Exception ",e);
		}
	  
    }
}
    	



package com.adobe.aem.intranet.models;

public interface StockTickerHelper {
	String getCurrentprice();
	
	String getDayhighprice();
	
	String getDaylowprice();
	
	String getFiftytwoweekhigh();
	
	String getFiftytwoweeklow();
	
	String getPricechange();
	
	String getPercentchange();
	
	String getVolume();
	
	String getE100();
	
	String getPeratio();
	
	String getDividend();
	
	String getDividendyield();
	
	String getExchange();
	
	String getLastupdatedate();
}

package com.adobe.aem.intranet.core.services;

import java.util.List;


public interface NewsForYouService {
	
	public String getMessage(String months, String user, String tagsAr[], String allTagsAr[] );
}

package com.adobe.aem.intranet.servlets;

import java.io.IOException;
import java.rmi.ServerException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.models.User;
import com.adobe.aem.intranet.core.services.UserInfoService;

@SlingServlet(paths = "/bin/userInfo", methods = "GET", metatype = true)
public class UserInfoServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 1683690139169819515L;
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private Session session;

	@Reference
	private UserInfoService userInfoService;
	
	@Override
	protected void doGet(SlingHttpServletRequest request,SlingHttpServletResponse response) throws ServerException,IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(SlingHttpServletRequest request,SlingHttpServletResponse response) throws ServerException,IOException {
		ResourceResolver resourceResolver = request.getResourceResolver();
		Session session = resourceResolver.adaptTo(Session.class);
		String userId = session.getUserID();
		User user = userInfoService.getUser(userId);
		
		response.getWriter().write(user.toJSON());
	}
}
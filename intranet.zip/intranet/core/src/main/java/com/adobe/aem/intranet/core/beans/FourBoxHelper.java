package com.adobe.aem.intranet.core.beans;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FourBoxHelper {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private String bannerImageLink1;
	private String bannerImageLink2;
	private String bannerImageLink3;
	private String bannerImageLink4;
	
	private List<FourBoxLinkHelper> fourBoxLinkHelperList1;
	private List<FourBoxLinkHelper> fourBoxLinkHelperList2;
	private List<FourBoxLinkHelper> fourBoxLinkHelperList3;
	private List<FourBoxLinkHelper> fourBoxLinkHelperList4;
	

	public List<FourBoxLinkHelper> getFourBoxLinkHelperList1() {
		return fourBoxLinkHelperList1;
	}
	public void setFourBoxLinkHelperList1(
			List<FourBoxLinkHelper> fourBoxLinkHelperList1) {
		this.fourBoxLinkHelperList1 = fourBoxLinkHelperList1;
	}
	public List<FourBoxLinkHelper> getFourBoxLinkHelperList2() {
		return fourBoxLinkHelperList2;
	}
	public void setFourBoxLinkHelperList2(
			List<FourBoxLinkHelper> fourBoxLinkHelperList2) {
		this.fourBoxLinkHelperList2 = fourBoxLinkHelperList2;
	}
	public List<FourBoxLinkHelper> getFourBoxLinkHelperList3() {
		return fourBoxLinkHelperList3;
	}
	public void setFourBoxLinkHelperList3(
			List<FourBoxLinkHelper> fourBoxLinkHelperList3) {
		this.fourBoxLinkHelperList3 = fourBoxLinkHelperList3;
	}
	public List<FourBoxLinkHelper> getFourBoxLinkHelperList4() {
		return fourBoxLinkHelperList4;
	}
	public void setFourBoxLinkHelperList4(
			List<FourBoxLinkHelper> fourBoxLinkHelperList4) {
		this.fourBoxLinkHelperList4 = fourBoxLinkHelperList4;
	}
	public String getBannerImageLink1() {
		return bannerImageLink1;
	}
	public void setBannerImageLink1(String bannerImageLink1) {
		this.bannerImageLink1 = bannerImageLink1;
	}
	public String getBannerImageLink2() {
		return bannerImageLink2;
	}
	public void setBannerImageLink2(String bannerImageLink2) {
		this.bannerImageLink2 = bannerImageLink2;
	}
	public String getBannerImageLink3() {
		return bannerImageLink3;
	}
	public void setBannerImageLink3(String bannerImageLink3) {
		this.bannerImageLink3 = bannerImageLink3;
	}
	public String getBannerImageLink4() {
		return bannerImageLink4;
	}
	public void setBannerImageLink4(String bannerImageLink4) {
		this.bannerImageLink4 = bannerImageLink4;
	}
	
	
}

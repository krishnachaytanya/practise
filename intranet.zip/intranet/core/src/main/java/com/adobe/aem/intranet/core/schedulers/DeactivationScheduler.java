package com.adobe.aem.intranet.core.schedulers;

import java.util.*;

import com.adobe.aem.intranet.core.services.ContentAgingService;

import com.adobe.aem.intranet.core.utils.EmailUtil;
import com.day.cq.commons.Externalizer;
import com.day.cq.mailer.MessageGatewayService;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import com.day.cq.search.result.SearchResult;


@Component(metatype = true, label = "Deactivation Scheduler", description = "Deactivates the stale content")
@Service(value = Runnable.class)
@Properties({
        @Property(name = "scheduler.expression", value = "0 0 12 1 * ?", description = "Cron-job expression"),
        @Property(name = "scheduler.concurrent", boolValue=false, description = "Whether or not to schedule this task concurrently"),
        @Property(name = "emailTemplatePath",value = "/etc/workflow/notification/email/intranet/DeactivationNotification.txt",  description = "Email Template Path"),
        @Property(name = "emailNotificationGroup", value = "enterprise-communications", description = "User Group who will receive Email Notification")

})
public class DeactivationScheduler implements Runnable {

    private static final String INTRANET_DEACTIVATE_WORKFLOW = "/etc/workflow/models/intranet-auto-deactivate-page/jcr:content/model";

    private String EMAIL_TEMPLATE_PATH = null;

    private String PARTICIPANT = null;

    @SuppressWarnings("rawtypes")
    Dictionary properties = null;


    @Reference
    private ContentAgingService contentAgingServiceImpl;

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private WorkflowService workflowService;

    @Reference
    private MessageGatewayService messageGatewayService;

    @Reference
    private ConfigurationAdmin configAdmin;


    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public void run() {
        try {
            logger.info("contentAgingServiceImpl is null " + (contentAgingServiceImpl == null));
            List<String> oldPages = searchResultToList(contentAgingServiceImpl.deactivateOldPages());
            EmailUtil eUtil = new EmailUtil();
            eUtil.execute(resolverFactory, messageGatewayService, workflowService, configAdmin,EMAIL_TEMPLATE_PATH, PARTICIPANT, oldPages);
            processOldPages(oldPages);

        } catch (Exception e) {
            logger.error("error in the scheduler",e);
            e.printStackTrace();
        }
    }

    @Activate
    protected void activate(ComponentContext componentContext) throws Exception{
        logger.info("activate method called for scheduler");

        properties = componentContext.getProperties();
        EMAIL_TEMPLATE_PATH = (String) properties.get("emailTemplatePath");
        PARTICIPANT = (String) properties.get("emailNotificationGroup");
       

    }

    private List<String> searchResultToList(SearchResult result){
        Iterator<Node> nodeIter = result.getNodes();
        List<String> oldPagesList = new ArrayList<String>();
        Node currentNode = null;

        String nodePath;
        while (nodeIter.hasNext()) {
            currentNode = nodeIter.next();

            try {
                oldPagesList.add(currentNode.getPath());

            }catch (Exception e){
                logger.error("error in result path", e);
            }
        }
        return oldPagesList;
    }

    private void processOldPages(List<String> result){
        Iterator<String> pageIter = result.iterator();
        String nodePath;
        while (pageIter.hasNext()) {
            nodePath = pageIter.next();

            try {

                Map<String, Object> param = new HashMap<String, Object>();
                param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
                ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param);
                Session session = resourceResolver.adaptTo(Session.class);
                terminateWFInstances(nodePath, session);
                WorkflowSession wfSession = null;
                wfSession = workflowService.getWorkflowSession(session);
                WorkflowModel wfModel = wfSession.getModel(INTRANET_DEACTIVATE_WORKFLOW);
                // Get the workflow data
                WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", nodePath);

                // Run the Workflow.
                Workflow wf = wfSession.startWorkflow(wfModel, wfData);

            } catch (RepositoryException e1) {
                logger.error("Repository Exception in Terminate workflow ", e1);
            }catch (LoginException e){
                logger.error("Unhandled login exception in Terminate workflow", e);
            }catch (WorkflowException we){
                logger.error("Workflow exception in terminate workflow", we);
            }

        }

    }

    public boolean terminateWFInstances(String contentPath, Session session)
            throws RepositoryException, WorkflowException {
        Workflow workflowInstance = null;
        WorkflowSession wfSession = null;

        if (null != contentPath && contentPath.trim().length() > 0) {
            wfSession = workflowService.getWorkflowSession(session);
            StringBuffer querysb = new StringBuffer();
            querysb.append("/jcr:root/etc/workflow/instances//element(*,cq:Workflow)[data/payload/@path ='");
            querysb.append(contentPath);
            querysb.append("'  and modelId='" + INTRANET_DEACTIVATE_WORKFLOW + "' and status='RUNNING'] order by @jcr:score");
            QueryResult queryResult = executeQuery(querysb.toString(), session);
            NodeIterator rowIter = queryResult.getNodes();
            long resultCount = rowIter.getSize();
            logger.info("no of running workflows for the payload {} are {}", contentPath, resultCount);

            while (rowIter.hasNext()) {
                Node wfNode = (Node) rowIter.next();
                workflowInstance = wfSession.getWorkflow(wfNode.getPath());
                logger.info("terminating workflow instance {}", workflowInstance.getId());
                wfSession.terminateWorkflow(workflowInstance);
                return true;
            }
        }

        return false;
    }

    @SuppressWarnings("deprecation")
    public QueryResult executeQuery(String query, Session session) throws RepositoryException {
        long startTime = System.currentTimeMillis();
        QueryManager queryManager = session.getWorkspace().getQueryManager();
        Query xpathQuery = queryManager.createQuery(query, Query.XPATH);
        QueryResult queryResult = xpathQuery.execute();
        long endTime = System.currentTimeMillis();
        return queryResult;
    }

}


package com.adobe.aem.intranet.models;

import com.adobe.aem.intranet.models.impl.PageLinkListHelper;
import com.day.cq.wcm.api.Page;

import java.util.List;

public interface PageLinkList {
	List<Page> getTaggedPages();
	List<PageLinkListHelper> getILinkPages();
}

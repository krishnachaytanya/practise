package com.adobe.aem.intranet.models;

public interface Polls {
	String PN_START_PATH = "startPath";
	
	String getPoll();
}

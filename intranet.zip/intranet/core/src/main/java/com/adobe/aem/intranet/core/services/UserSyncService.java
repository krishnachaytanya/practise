package com.adobe.aem.intranet.core.services;

public interface UserSyncService {
	void syncUsers();
}

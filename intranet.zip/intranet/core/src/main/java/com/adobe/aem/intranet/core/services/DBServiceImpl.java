package com.adobe.aem.intranet.core.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.version.VersionException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.bson.Document;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

@Component(label = "US Bank MongoDB Connection Service", description = "US Bank MongoDB Connection Service", metatype = true, immediate = true)
@Service(value = { DBService.class })
@Properties({
		@Property(name = "MongoDB.userName", value = "", description = "MongoDB User Name"),
		@Property(name = "MongoDB.pwd", value = "", description = "MongoDB Password"),
		@Property(name = "MongoDB.dbName", value = "", description = "MongoDB Database Name"),
		@Property(name = "MongoDB.iNetAddress", value = "", description = "MongoDB Host Address"),
		@Property(name = "MongoDB.port", value = "27018", description = "MongoDB Port Number"), 
		})

public class DBServiceImpl implements DBService {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	@SuppressWarnings("rawtypes")
	Dictionary properties = null;

	private String MONGO_USERNAME = null;

	private String MONGO_PWD = null;

	private String MONGO_DBNAME = null;

	private String MONGO_INETADDRESS = null;

	private Integer MONGO_PORTNO = null;

	@Activate
	public void activate(ComponentContext componentContext) throws Exception {

		properties = componentContext.getProperties();
		MONGO_USERNAME = (String) properties.get("MongoDB.userName");
		MONGO_PWD = (String) properties.get("MongoDB.pwd");
		MONGO_DBNAME = (String) properties.get("MongoDB.dbName");
		MONGO_INETADDRESS = (String) properties.get("MongoDB.iNetAddress");
		MONGO_PORTNO = Integer
				.parseInt((String) properties.get("MongoDB.port"));

	}

	public MongoClient getConnection() {
		MongoClient mongo = null;

		try {
			if (MONGO_INETADDRESS.contains("localhost")) {
				mongo = new MongoClient();
			} else {
				List<MongoCredential> credentials = new ArrayList<MongoCredential>();

				credentials.add(MongoCredential.createCredential(
						MONGO_USERNAME, MONGO_DBNAME, MONGO_PWD.toCharArray()));
				mongo = new MongoClient(new ServerAddress(MONGO_INETADDRESS,
						MONGO_PORTNO), credentials);
			}
		} catch (MongoException e) {
			log.error("DBServiceImpl getConnection" + e.getMessage(), e);
		}
		return mongo;
	}

}

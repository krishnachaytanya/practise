package com.adobe.aem.intranet.models;


public interface SocialShare {
    String getPublishLink();

}

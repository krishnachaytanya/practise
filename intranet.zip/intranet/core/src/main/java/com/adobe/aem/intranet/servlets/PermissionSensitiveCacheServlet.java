package com.adobe.aem.intranet.servlets;

import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(paths = "/bin/permissionCheck", metatype = true)

@Service
public class PermissionSensitiveCacheServlet extends SlingSafeMethodsServlet {

    private static final Logger log = LoggerFactory.getLogger(PermissionSensitiveCacheServlet.class);

    public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
    	doHead(request, response);    	
    }
    

    public void doHead(SlingHttpServletRequest request, SlingHttpServletResponse response) {
        try{

            //retrieve the requested URL
            ResourceResolver resourceResolver = request.getResourceResolver();
            String requestUri = request.getParameter( "uri" );
            response.setStatus(SlingHttpServletResponse.SC_UNAUTHORIZED);
            Session session = resourceResolver.adaptTo(Session.class);
    		String userId = session.getUserID();
    		    		
            log.info( "Checking access for URI {}", requestUri );
            log.info( "Checking access for user {}", userId );
            if (userId == null || userId.length()<1  || userId.equals("anonymous")) {
                log.info("Current Session does not have a user", requestUri );
                response.setStatus(SlingHttpServletResponse.SC_UNAUTHORIZED);
            }
            else if( isUriValid( requestUri ) ){
                Resource requestedResource = resourceResolver.resolve( request, requestUri );

                if( !ResourceUtil.isNonExistingResource( requestedResource ) ){
                    log.info("Current Session has access to {}", requestUri );
                    response.setStatus(SlingHttpServletResponse.SC_OK);
                } else {
                    log.info("Current Session does not have access to {}", requestUri );
                    response.setStatus(SlingHttpServletResponse.SC_UNAUTHORIZED);
                }

            } else {
                log.debug( "Invalid URI {}", requestUri );
                response.setStatus( SlingHttpServletResponse.SC_UNAUTHORIZED );
            }
        } catch(Exception e) {
            log.error("Authchecker servlet exception", e);
            response.setStatus( SlingHttpServletResponse.SC_UNAUTHORIZED );
        }
    }

    public boolean isUriValid( String requestUri ){
        boolean isValidUri = true;

        if(!StringUtils.startsWith( requestUri, "/" ) ){
            isValidUri = false;
        }

        return isValidUri;
    }
}

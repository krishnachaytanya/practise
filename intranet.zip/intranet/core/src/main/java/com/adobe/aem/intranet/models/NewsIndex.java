package com.adobe.aem.intranet.models;

import java.util.Collection;

public interface NewsIndex {

   Collection<NavigationItem> getItems();
    
    Collection<NavigationFamilyItem> getFamily();
}

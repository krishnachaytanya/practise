package com.adobe.aem.intranet.servlets;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.ServerException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Dictionary;
import java.util.List;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.jcr.api.SlingRepository;
import org.bson.Document;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.services.DBService;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

@SlingServlet(paths="/bin/userPreferences", methods = "POST", metatype=true)
public class HandleUserInput extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Reference
	private DBService dBService;
	
	@Reference
    private SlingRepository repository;
	
	@SuppressWarnings("rawtypes")
	Dictionary properties = null;
	
	private String metricsURL = null;
	private boolean publishEnv = false;
     
    public void bindRepository(SlingRepository repository) {
    	this.repository = repository; 
	}
    
    private String servername;
    
    @Activate
	public void activate(ComponentContext componentContext){
		properties = componentContext.getProperties();
		metricsURL = (String) properties.get("metricsURL");
		publishEnv = Boolean.parseBoolean((String) properties.get("publishEnv"));
	}
          
    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
    	log.error("Handle User Input - Inside POST");
    	
    	String user = request.getRemoteUser();
    	
    	String favoriteURL = request.getParameter("favoriteURL");
    	String favoriteName = request.getParameter("favoriteName");
    	String existingURL = request.getParameter("existingURL");
    	String existingName = request.getParameter("existingName");
    	boolean deleteItem = Boolean.parseBoolean(request.getParameter("deleteItem"));
    	boolean updateLink = Boolean.parseBoolean(request.getParameter("updateLink"));
    	
    	String tags = request.getParameter("tags");
    	
    	String pollID = request.getParameter("pollID");
    	String pollVote = request.getParameter("pollVote");
    	boolean pollInfo = Boolean.parseBoolean(request.getParameter("pollInfo"));
    	
    	String alertID = request.getParameter("alertID");
    	
    	String nickname = request.getParameter("nickname");
    	
    	String reportingData = request.getParameter("reportingData");
    	
    	StringBuilder message = new StringBuilder();
    	
    	servername = request.getServerName().toLowerCase();
    	
    	log.error("Handle User Input: servername " + request.getServerName());
    	
    	if(alertID != null){
    		// Store alert acknowledgement
    		message.append(setAlert(user, alertID));
    	}
    	else if(reportingData != null && publishEnv){
    		try{
    			HttpURLConnection connection = null;
        		URL url = new URL(metricsURL);
        		
        		log.error("Handle User Input: metricsURL " + metricsURL);
        		
        		connection = (HttpURLConnection) url.openConnection();
        	    connection.setRequestMethod("POST");
        	    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        	    
        	    connection.setDoInput(true);
        	    connection.setDoOutput(true);
        	    
        	    DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
    	        wr.writeBytes(reportingData);
    	        wr.flush();
    	        wr.close();
    	        
    	        InputStream is = connection.getInputStream();
    	        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
    	        String line;
    	        
    	        StringBuffer returnValue = new StringBuffer();
    	        
    	        while((line = rd.readLine()) != null) {
    	        	returnValue.append(line + "\\n");
    	        }
    	        
    	        rd.close();
    	        message.append(returnValue.toString());
    	        
    	        if(connection != null) {
    	        	connection.disconnect(); 
    	        }
    		} catch(MalformedURLException e){
    			log.error("Metrics POST: " + e.toString());
    		} catch (IOException e) {
    			log.error("Metrics POST: " + e.toString());
			}
    	}
    	else if(nickname != null){
    		// update nickname
    		String userpath = getUserPath(user);
    		
    		Session session = null;
        	
        	try {
        		session = repository.loginService("writeService", null);
    		} catch (RepositoryException e) {
    			log.error("Get session: " + e.toString());
    		}
        	
        	if(session != null){
        		// Get node
            	Node userNode = null;
            	
            	try {
            		userNode = session.getNode(userpath);
    			} catch (RepositoryException e) {
    				log.error("Get user node: " + e.toString());
    			}
        		
        		if(userNode != null){
        			try {
        				userNode.setProperty("nickname", nickname);
        				
    	    			message.append("Nickname updated.");
    					    					
    					session.save();
    				} catch (RepositoryException e) {
    					log.error("HandleUserInput - add tags: " + e.toString());
    				}
        		}
        		
        		session.logout();
        	}
    	}
    	else if(pollID != null){
    		if(pollVote == null){
    			// Check if user has already voted
    			String polls = getDBValue("polls", user, "users");
    			
    			if(!polls.isEmpty() && polls.contentEquals(pollID)){
    				// User has voted - return poll answer totals
    				message.append(getDocValues(pollID, "polls"));
    			}
    			else if(pollInfo){
    				// Get info for past polls
    				message.append(getDocValues(pollID, "polls"));
    			}
    			else{
    				// User has not voted - do nothing
    			}
    		}
    		else{
    			// Vote for a poll question
        		setDBValue("polls", user, pollID, "users");
        		
        		String voteCount = getDBValue(pollVote, pollID, "polls");
        		
        		if(!voteCount.isEmpty()){
        			setDBValue(pollVote, pollID, Integer.toString(Integer.parseInt(voteCount) + 1), "polls");
        		}
        		else{
        			setDBValue(pollVote, pollID, "1", "polls");
        		}
        		
        		message.append(getDocValues(pollID, "polls"));
    		}
    	}
    	else if(tags != null){
    	
    		// Add/update favorites properties
        	System.err.println("Handle User Input - add tags");
    				
        	message.append("Topics update");
        	
        	if(setDBValue("tags", user, tags, "users").equals("succeeded")){
        		message.append("d successfully.");
        	}
        	else{
        		message.append(" failed.");
        	}
    			
    	}
    	else if(deleteItem){
    		// Delete link from favorites
			int index = -1;
			ArrayList<String> favs = new ArrayList<String>(Arrays.asList(getDBValue("favorites", user, "users").split(",")));
			
			System.err.println("Handle User Input favs size" + favs.size());
			
			for(int i = 0; i < favs.size(); i++){
				if(favs.get(i).matches(".+::" + Pattern.quote(favoriteURL))){
					index = i;
				}
			}
					
			System.err.println("Handle User Input delete index found: " + index);
			
			if(index != -1){
				favs.remove(index);
						
				System.err.println("Handle User Input favs size after delete" + favs.size());
						
				message.append("Remove favorite " + setDBValue("favorites", user, StringUtils.join(favs, ","), "users"));
			}
			else{
				message.append("Favorite not located.");
			}
		}
    	else if(updateLink){
    		// Update favorites link
    		
    		int index = -1;
			ArrayList<String> favs = new ArrayList<String>(Arrays.asList(getDBValue("favorites", user, "users").split(",")));
			
			System.err.println("Handle User Input favs size" + favs.size());
			
			for(int i = 0; i < favs.size(); i++){
				if(favs.get(i).matches(existingName + "::" + Pattern.quote(existingURL))){
					index = i;
				}
			}
					
			System.err.println("Handle User Input delete index found: " + index);
			
			if(index != -1){
				favs.remove(index);
						
				System.err.println("Handle User Input favs size after delete" + favs.size());
				
				favs.add(index, favoriteName + "::" + favoriteURL);
				
				message.append("Update favorite " + setDBValue("favorites", user, StringUtils.join(favs, ","), "users"));
			}
			else{
				message.append("Favorite not located.");
			}
    	}
		else if (favoriteName!= null && favoriteURL !=null){
			// Add favorites properties
			String favorites = getDBValue("favorites", user, "users");
    				
   			if(!favorites.isEmpty() && favorites.split(",").length == 3){
   				message.append("Favorite not added, limit of 3 reached.");
   			}
   			else if(!favorites.isEmpty()){
   				message.append("Add favorite " + setDBValue("favorites", user, favorites + "," + favoriteName + "::" + favoriteURL, "users"));
   			}
   			else{
   				System.err.println("Handle User Input - create favorites property");
    					
				message.append("Add favorite " + setDBValue("favorites", user, favoriteName + "::" + favoriteURL, "users"));
			}    				
		}

    	// Return updated node value
    	response.getWriter().write(message.toString());
    }
    
    private String setAlert(String user, String alertID){
    	StringBuilder response = new StringBuilder();
    	
    	try {
			MongoClient mongo = getConnection();
			
			if(mongo != null){
				MongoDatabase db = mongo.getDatabase("intranet");
				
				MongoCollection<Document> table = db.getCollection("alerts");
				
				Document searchQuery = new Document();
				searchQuery.put("uid", alertID);

				FindIterable<Document> cursor = table.find(searchQuery);
				
				MongoCursor<Document> it = cursor.iterator();
				
				Date dt = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

				if(it.hasNext()) {
					Document updatedAlert = new Document();
					updatedAlert.put("uid", user);
					updatedAlert.put("date", sdf.format(dt));
		            
		            Document users = new Document();
		            users.put("users", updatedAlert);
		            
		            Document update = new Document();
		            update.put("$push", users);
					
					table.updateOne(searchQuery, update);
					
					response.append("succeeded");
				}
				else{
					Document alert = new Document();
					alert.put("uid", user);
					alert.put("date", sdf.format(dt));
					
					List<Document> users = new ArrayList<Document>();
					
					users.add(alert);
		            
		            Document newUser = new Document();
					newUser.put("uid", alertID);
					newUser.put("users", users);
					
					table.insertOne(newUser);
					
					response.append("succeeded");
				}
				
				mongo.close();
			}			
			
		} catch (Exception e){
			System.err.println("HandleUserInput setAlert for " + alertID + ": " + e.toString());
			response.append("failed");
		}
    	
    	return response.toString();
    }
    
    private String setDBValue(String name, String user, String value, String collection){
    	StringBuilder response = new StringBuilder();
    	
    	try {
			MongoClient mongo = getConnection();
			
			if(mongo != null){
				MongoDatabase db = mongo.getDatabase("intranet");
				
				MongoCollection<Document> table = db.getCollection(collection);
				
				Document searchQuery = new Document();
				searchQuery.put("uid", user);

				FindIterable<Document> cursor = table.find(searchQuery);
				
				MongoCursor<Document> it = cursor.iterator();

				if(it.hasNext()) {
					Document updatedUser = new Document();
					updatedUser.put("uid", user);
					updatedUser.put(name, value);
					
					Document update = new Document();
					update.put("$set", updatedUser);
					
					table.updateOne(searchQuery, update);
					
					response.append("succeeded");
				}
				else{
					Document newUser = new Document();
					newUser.put("uid", user);
					newUser.put(name, value);
					
					table.insertOne(newUser);
					
					response.append("succeeded");
				}
				
				mongo.close();
			}			
			
		} catch (Exception e){
			System.err.println("HandleUserInput setDBValue for " + name + ": " + e.toString());
			response.append("failed");
		}
    	
    	return response.toString();
    }
    
    private String getDBValue(String name, String user, String collection){
		StringBuilder values = new StringBuilder();
		
		try {
			MongoClient mongo = getConnection();
			
			if(mongo != null){
				MongoDatabase db = mongo.getDatabase("intranet");
				
				MongoCollection<Document> table = db.getCollection(collection);
				
				Document searchQuery = new Document();
				searchQuery.put("uid", user);

				FindIterable<Document> cursor = table.find(searchQuery);
				
				MongoCursor<Document> it = cursor.iterator();

				if(it.hasNext()) {
					Document userDoc = it.next();
					
					if(userDoc.containsKey(name)){
						values.append(userDoc.get(name));
					}			
				}
				
				mongo.close();
			}
			
		} catch (Exception e){
			System.err.println("UserHelper getDBValue for " + name + ": " + e.toString());
		}
		
		return values.toString();
	}
    
    private String getDocValues(String user, String collection){
    	StringBuilder doc = new StringBuilder();
    	
    	try {
			MongoClient mongo = getConnection();
			
			if(mongo != null){
				MongoDatabase db = mongo.getDatabase("intranet");
				
				MongoCollection<Document> table = db.getCollection(collection);
				
				Document searchQuery = new Document();
				searchQuery.put("uid", user);

				FindIterable<Document> cursor = table.find(searchQuery);
				
				MongoCursor<Document> it = cursor.iterator();

				if(it.hasNext()) {
					Document userDoc = it.next();
					
					doc.append(userDoc.toJson());
				}
				
				mongo.close();
			}			
			
		} catch (Exception e){
			System.err.println("UserHelper getDocValues for " + user + ": " + e.toString());
		}
    	
    	return doc.toString();
    }
    
    private MongoClient getConnection(){
    	MongoClient mongo = dBService.getConnection();
/*		
    	try {
			if(servername.contains("localhost")){
				mongo = new MongoClient();
			}
			else if(servername.contains("dev")){
				List<MongoCredential> credentials = new ArrayList<MongoCredential>();
				
				credentials.add(MongoCredential.createCredential("AEMIntAppIDDEV", "intranet", "*Wfq81G3{C6M".toCharArray()));
				mongo = new MongoClient(new ServerAddress("VMBKSA69901MKE.us.bank-dns.com", 27018), credentials);
			}
			else if(servername.contains("it")){
				List<MongoCredential> credentials = new ArrayList<MongoCredential>();
				
				credentials.add(MongoCredential.createCredential("AEMIntAppIDIT", "intranet", "PSmkCtjwQekmR0".toCharArray()));
				mongo = new MongoClient(new ServerAddress("VMBKSA69901MKF.us.bank-dns.com", 27018), credentials);
			}
			else if(servername.contains("uat")){
				List<MongoCredential> credentials = new ArrayList<MongoCredential>();
				
				credentials.add(MongoCredential.createCredential("AEMIntAppIDUAT", "intranet", "TIn8mziLdq5G5".toCharArray()));
				mongo = new MongoClient(new ServerAddress("VMBKSA69901MLM.us.bank-dns.com", 27018), credentials);
			}
			else{ //PROD
				List<MongoCredential> credentials = new ArrayList<MongoCredential>();
				
				credentials.add(MongoCredential.createCredential("AEMIntAppIDPRD", "intranet", "51bL6CuZ*qOgk*".toCharArray()));
				mongo = new MongoClient(new ServerAddress("VMBKSA69901MLU.us.bank-dns.com", 27018), credentials);
			}
		} catch(MongoException e){
			System.err.println("HandleUserInput getConnection: " + e.toString());
		}
*/
		return mongo;
    }
    
    private String getUserPath(String user){
    	// Build user path from user
		String path = "/etc/users/";
		
		String topFolder = user.split("")[0].toLowerCase();
    	
    	if(topFolder.equals("c") && user.split("")[1].matches("\\d")){
    		topFolder += user.split("")[1];
        }
    	
    	String secondLevelFolder = user.toLowerCase();
    	
    	if(secondLevelFolder.matches("^c\\d+")){
    		secondLevelFolder = secondLevelFolder.substring(0, 5);
    	}
    	else if(secondLevelFolder.matches("^\\w+")){
    		secondLevelFolder = secondLevelFolder.substring(0, 3);
    	}
    	
    	path += topFolder + "/" + secondLevelFolder + "/" + user;
    	
    	System.err.println("Handle User Input -  node path: " + path);
    	
    	return path;
    }
}

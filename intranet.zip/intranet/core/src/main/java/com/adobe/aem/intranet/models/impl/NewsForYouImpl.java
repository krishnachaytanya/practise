package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import com.adobe.aem.intranet.models.NewsForYou;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.util.ListMap.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters = NewsForYou.class, resourceType = "intranet/components/content/allnews")
@Exporter(extensions = "json", name = "jackson")
public class NewsForYouImpl implements NewsForYou {
	@ScriptVariable
	private Page currentPage;
	@ScriptVariable
	private SlingHttpServletRequest request;
	
	@ScriptVariable
	private Node currentNode;
	ResourceResolver resourceResolver;
	String remTag;
	final Logger log = LoggerFactory.getLogger(NewsForYouImpl.class);
	private int results;
	private String startPath;
	private String userTags;
	String resourcePath = "/etc/users/c0/c0375/c037533";
	Node userNode = null;


	public static String PN_START_LEVEL = "results";

	private List<Page> pages;
	public static final String PROP_START_PATH_DEFAULT = "/content/intranet/home/articles";

	@PostConstruct
	private void initModel() {
		try {
			results = Integer.parseInt(currentNode.getProperty(PN_START_LEVEL)
					.getValue().getString());
		} catch (NumberFormatException | IllegalStateException
				| RepositoryException e) {
			System.err.println("NewsForYouImpl results: " + e.toString());
		}
		
		
    	

		ResourceResolver rr = currentPage.getContentResource().getResourceResolver();

		Resource resource = rr.getResource(resourcePath);

		if (resource != null) {
			userNode = resource.adaptTo(Node.class);
		}
		
		try {
			if (userNode != null && userNode.hasProperty("Tags")) {
				userTags = userNode.getProperty("Tags").getString();
			} else {
				userTags = "";
			}
		} catch (RepositoryException e) {
			System.err.println("NEWSFORYOU Full Name not set: "
					+ e.toString());
		}
		
       log.info("News For You Impl");
        log.info("The user Property is : "+ userTags);
		

		startPath = PROP_START_PATH_DEFAULT;
	}

	

	@Override
	public List<Page> getPages() {
		pages = new ArrayList<Page>();
		buildPages();
		System.err.println("NEWSFORYOU PAGES ARE......................."+pages);
		return pages;
	}

	private void buildPages() {
		QueryBuilder queryBuilder = currentPage.getContentResource()
				.getResourceResolver().adaptTo(QueryBuilder.class);
		Session session = currentPage.getContentResource()
				.getResourceResolver().adaptTo(Session.class);
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("path", startPath);
		querymap.put("type", "cq:Page");
		querymap.put("orderby", "@jcr:content/cq:lastModified");
		querymap.put("orderby.sort", "desc");
		querymap.put("property", "jcr:content/jcr:title");
		querymap.put("property.operation", "unequals");
		querymap.put("property.value", currentPage.getTitle());
		querymap.put("tagid.property", "jcr:content/cq:tags");
		Tag[] userTags = null;
		Tag[] tags = null;
        try {
			if(currentNode.getName().contains("allnews")){
									
				if(currentNode.getProperty("selectedtags") != null){
					TagManager tm = currentPage.getContentResource().getResourceResolver().adaptTo(TagManager.class);
					
					Value[] newsTags = currentNode.getProperty("selectedtags").getValues();
					
					tags = new Tag[newsTags.length];
					
					for(int i = 0; i < newsTags.length; i++){
						tags[i] = tm.resolve(newsTags[i].getString());
					}
				}
			}
			else{
				tags = currentPage.getTags();
			}
		} catch (RepositoryException e) {
			System.err.println("FeaturedNews currentNode getName: " + e.toString());
		}
        System.err.println("NewsForYouImpl: tags: " + tags.length);
		try {
			

				if (userNode.getProperty("Tags") != null) {
					TagManager tm = currentPage.getContentResource()
							.getResourceResolver().adaptTo(TagManager.class);

					Value[] userNodeTags = userNode.getProperty("Tags").getValues();

					userTags = new Tag[userNodeTags.length];

					for (int i = 0; i < userNodeTags.length; i++) {
						userTags[i] = tm.resolve(userNodeTags[i].getString());
					}
				}
			
		} catch (RepositoryException e) {
			System.err.println("NewsForYouImpl currentNode getName: "
					+ e.toString());
		}
		System.err.println("NewsForYouImpl: userTags: " + userTags.length);

		if (userTags != null && userTags.length > 0) {
			try {
				for (int i = 0; i < userTags.length; i++) {
					querymap.put("tagid." + (i + 1) + "_value",userTags[i].getNamespace().getName() + ":"+ userTags[i].getLocalTagID());
					System.err.println("USERTAG: "+ userTags[i].getNamespace().getName() + ":"+ userTags[i].getLocalTagID());
					
				}
				
				for (int i = 0; i < tags.length; i++) {
					for(Iterator<Map.Entry<String, String>> it = querymap.entrySet().iterator(); it.hasNext(); ) {
					      Map.Entry<String, String> entry = it.next();
					      if(entry.getValue().equals(tags[i].getNamespace().getName() + ":"+ tags[i].getLocalTagID())) {
					        it.remove();
					        
					      }
					    }
					System.err.println("TAG REMOVED: "+ tags[i].getNamespace().getName() + ":"+ tags[i].getLocalTagID());
					
				}
				

				querymap.put("tagid.and", "true");

				// can be done in querymap or with Query methods
				querymap.put("p.offset", "0"); // same as query.setStart(0) below
				querymap.put("p.limit", "30"); // same as
																// query.setHitsPerPage(20)
																// below
				System.err.println("querymap IS :::::::::::::::::"+querymap);
				Query query = queryBuilder.createQuery(
						PredicateGroup.create(querymap), session);

				SearchResult result = query.getResult();

				// If no pages have all the tags, look for pages with any of the
				// tags
				if (result.getTotalMatches() == 0) {
					querymap.remove("tagid.and");
					querymap.put("tagid.or", "true");
					query = queryBuilder.createQuery(
							PredicateGroup.create(querymap), session);
					result = query.getResult();
				}

				// iterating over the results
				for (Hit hit : result.getHits()) {
					Page found = null;

					found = currentPage.getPageManager().getPage(hit.getPath());

					pages.add(found);
					System.err.println("............................PAGES FOUND ARE......................."+pages);
				}
			} catch (RepositoryException e) {
				System.err.println("NewsForYouImpl::buildPages: "
						+ e.toString());
			} catch (NullPointerException e) {
				System.err.println("NewsForYouImpl::buildPages: Tags not published? - "+ e.toString());
			}
		} else {
			System.err.println("NewsForYouImpl::buildPages: currentPage.getTags() returned null");
		}

	}

}

package com.adobe.aem.intranet.models;

import java.util.List;

import com.adobe.aem.intranet.core.beans.BannerHelper;

public interface Banner {

	List<BannerHelper> getBannerElements();
}

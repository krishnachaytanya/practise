package com.adobe.aem.intranet.core.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CarouselBean {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
	private String pagePath;
	private String title;
	private String image;
	private String imgAlt;
	
	public String getImgAlt() {
		return imgAlt;
	}

	public void setImgAlt(String imgAlt) {
		this.imgAlt = imgAlt;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}
}

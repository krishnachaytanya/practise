package com.adobe.aem.intranet.models;

import com.day.cq.wcm.api.Page;

import java.util.List;

public interface RelatedPages {
	
	String PN_START_LEVEL = "results";
    
    String PN_START_PATH = "startPath";
    
	List<Page> getPages();
}

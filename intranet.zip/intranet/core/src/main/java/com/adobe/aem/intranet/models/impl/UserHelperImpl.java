package com.adobe.aem.intranet.models.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.intranet.core.services.DBService;
import com.adobe.aem.intranet.models.UserFavorite;
import com.adobe.aem.intranet.models.UserHelper;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

@Model(adaptables = SlingHttpServletRequest.class, adapters = UserHelper.class, resourceType = "intranet/components/structure/header")
@Exporter(name = "jackson", extensions = "json")
public class UserHelperImpl implements UserHelper {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@ScriptVariable
    private SlingHttpServletRequest request;
	
	@ScriptVariable
    private Style currentStyle;
	
	@ScriptVariable
    private Page currentPage;
		
	private String user;
	
	private String userTags;
	
	
	@PostConstruct
    private void initModel() {
		
		user = request.getRemoteUser();
		
		userTags = getTags();		
	}
    
	@Override
	public String getUser() {
		return user;
	}
	


	
	@Override
	public String getTags() {
		StringBuilder tags = new StringBuilder("[{");
		
		Node startTag = getNode("/etc/tags/intranet");		
		
		try {
			tags.append("key: \"" + startTag.getName() + "\", title: \"" + startTag.getProperty("jcr:title").getString() + "\", expanded: true");
						
			if(startTag.hasNodes()){
				tags.append(", children: [");
				
				tags.append(processTagChildren(startTag.getName() + ":", startTag));
				
				tags.append("]");
			}
		} catch (RepositoryException e) {
			log.error("UserHelper getTags: " + e.toString());
			e.printStackTrace();
		}
		

		
		startTag = getNode("/etc/tags/intranet-generated/business");		
		if (startTag != null) {
			tags.append("}, {");
			try {
				tags.append("key: \"" + startTag.getName() + "\", title: \"" + startTag.getProperty("jcr:title").getString() + "\", expanded: true");
							
				if(startTag.hasNodes()){
					tags.append(", children: [");
					
					tags.append(processTagChildren(startTag.getName() + ":", startTag));
					
					tags.append("]");
				}
			} catch (RepositoryException e) {
				log.error("UserHelper getTags: " + e.toString());
				e.printStackTrace();
			}
		}	
		startTag = getNode("/etc/tags/intranet-generated/location");		
		if (startTag != null) {
			tags.append("}, {");
			try {
				tags.append("key: \"" + startTag.getName() + "\", title: \"" + startTag.getProperty("jcr:title").getString() + "\", expanded: true");
							
				if(startTag.hasNodes()){
					tags.append(", children: [");
					
					tags.append(processTagChildren(startTag.getName() + ":", startTag));
					
					tags.append("]");
				}
			} catch (RepositoryException e) {
				log.error("UserHelper getTags: " + e.toString());
				e.printStackTrace();
			}
		}
		tags.append("}]");
		
		return tags.toString().replaceAll(":/", ":");
	}
	

	private String processTagChildren(String keyPath, Node node){
		StringBuilder output = new StringBuilder();
		
		try {
			NodeIterator children = node.getNodes();
			
			while(children.hasNext()){
				Node child = children.nextNode();
				
				if(child.getPrimaryNodeType().isNodeType("cq:Tag")){
					output.append("{key: \"" + keyPath + "/" + child.getName() + "\", title: \"" + child.getProperty("jcr:title").getString() + "\"");
										
					if(child.hasNodes()){
						String grandKids = processTagChildren(keyPath + "/" + child.getName(), child);
						
						if(grandKids.contains("selected")){
							output.append(", expanded: true");
						}
						
						output.append(", children: [" + grandKids + "]");
					}
					
					output.append("}");
					
					if(children.hasNext()){
						output.append(",");
					}
				}
			}
		} catch (RepositoryException e) {
			log.error("UserHelper processTagChildren: " + e.toString());
			e.printStackTrace();
		}
		
		return output.toString();
	}
	
	
	private Node getNode(String path){
		Node node = null;
		
		ResourceResolver rr = currentPage.getContentResource().getResourceResolver();
		
		Resource resource = rr.getResource(path);
    	
		if(resource != null){
			node = resource.adaptTo(Node.class);
		}
		
		return node;
	}
	


}

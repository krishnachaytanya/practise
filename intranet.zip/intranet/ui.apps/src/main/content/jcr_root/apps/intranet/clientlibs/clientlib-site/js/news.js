$(document).ready(function(){
	//$('.pn-ProductNav_Indicator').css('display','block');
    $('#pnProductNavContents ul li.nav-item').click(function(event){
    	event.preventDefault();
		$('.nav-item').removeClass('active');
		$(this).addClass('active');
		$('.news_cards').hide();
		var index = $( "ul.mr-auto li.nav-item" ).index( this );

		if(index==0){	
			$('.featured_news').css('display','flex');
			$('.back_to_top').show();
		} else if(index==1){
			$('.tailored_news').show();
		} else if(index==2){
			$('.all_news').show();
		}
	});
	$( ".back_to_top > a" ).click(function( event ) {
      event.preventDefault();
      $('html, body').animate({
        scrollTop: $('#pnProductNav').offset().top
      }, 500);
    });
	$( window ).load(function() {
		var currURL=window.location.href;
	    if($(".allnews").length){
	    	$('.news_cards').hide();
			if(currURL.match(/newsforyou/)) {
		    	$('ul.navbar-nav.mr-auto > :nth-child(2)').addClass('active');
		    	$('ul.navbar-nav.mr-auto > :nth-child(2) > a').attr('aria-selected','true');
		    	$('.tailored_news').show();
		    } else if(currURL.match(/allnews/)) {
		    	$('ul.navbar-nav.mr-auto > :nth-child(3)').addClass('active');
		    	$('ul.navbar-nav.mr-auto > :nth-child(3) > a').attr('aria-selected','true');
		    	$('.all_news').show();
		    } else {
		    	$('ul.navbar-nav.mr-auto > :nth-child(3)').addClass('active');
		    	$('ul.navbar-nav.mr-auto > :nth-child(3) > a').attr('aria-selected','true');
		    	$('.all_news').show();
		    	/*
				$('ul.navbar-nav.mr-auto > :nth-child(1)').addClass('active');
				$('ul.navbar-nav.mr-auto > :nth-child(1) > a').attr('aria-selected','true');
				$('.featured_news').show();
				$('.back_to_top').show();
				*/
		    }
			setIndicator(pnProductNav.querySelector("[aria-selected=\"true\"]"), "#0C2074"); 
			pnProductNavContents.addEventListener("transitionend",function() {
			        // get the value of the transform, apply that to the current scroll position (so get the scroll pos first) and then remove the transform
			        var styleOfTransform = window.getComputedStyle(pnProductNavContents, null);
			        var tr = styleOfTransform.getPropertyValue("-webkit-transform") || styleOfTransform.getPropertyValue("transform");
			        // If there is no transition we want to default to 0 and not null
			        var amount = Math.abs(parseInt(tr.split(",")[4]) || 0);
			        pnProductNavContents.style.transform = "none";
			        pnProductNavContents.classList.add("pn-ProductNav_Contents-no-transition");
			        // Now lets set the scroll position
			        if (SETTINGS.navBarTravelDirection === "left") {
			            pnProductNav.scrollLeft = pnProductNav.scrollLeft - amount;
			        } else {
			            pnProductNav.scrollLeft = pnProductNav.scrollLeft + amount;
			        }
			        SETTINGS.navBarTravelling = false;
			    },
			    false
			);
			// Handle setting the currently active link
			pnProductNavContents.addEventListener("click", function(e) {
			    var links = [].slice.call(document.querySelectorAll(".pn-ProductNav_Link"));
			    links.forEach(function(item) {
			        item.setAttribute("aria-selected", "false");
			    })
			    e.target.setAttribute("aria-selected", "true");
			    // Pass the clicked item and it's colour to the move indicator function
			    moveIndicator(e.target, colours[links.indexOf(e.target)]);
			});
	    }
	});
});

var SETTINGS = {
    navBarTravelling: false,
    navBarTravelDirection: "",
    navBarTravelDistance: 400
}
var colours = {
    0: "#0C2074"
}

document.documentElement.classList.remove("no-js");
document.documentElement.classList.add("js");

// the indicator
var pnIndicator = document.getElementById("pnIndicator");

//var pnProductNav = document.getElementById("pnProductNav");
var pnProductNavContents = document.getElementById("pnProductNavContents");

//pnProductNav.setAttribute("data-overflowing", determineOverflow(pnProductNavContents, pnProductNav));

// Set the indicator
//setIndicator(pnProductNav.querySelector("[aria-selected=\"true\"]"), colours[0]);

// Handle the scroll of the horizontal container
var last_known_scroll_position = 0;
var ticking = false;

function doSomething(scroll_pos) {
    pnProductNav.setAttribute("data-overflowing", determineOverflow(pnProductNavContents, pnProductNav));
}
function setIndicator(item, color) {
    var textPosition = item.getBoundingClientRect();
    var container = pnProductNavContents.getBoundingClientRect().left;
    var distance = textPosition.left - container;
     var scroll = pnProductNavContents.scrollLeft;
    pnIndicator.style.transform = "translateX(" + (distance + scroll) + "px) scaleX(" + textPosition.width * 0.01 + ")";
    // count = count += 100;
    // pnIndicator.style.transform = "translateX(" + count + "px)";
    
    if (color) {
        //pnIndicator.style.backgroundColor = color;
        pnIndicator.style.backgroundColor = "#0C2074";
    }
}
// var count = 0;
function moveIndicator(item, color) {
//console.log("move");
    var textPosition = item.getBoundingClientRect();
    var container = pnProductNavContents.getBoundingClientRect().left;
    var distance = textPosition.left - container;
     var scroll = pnProductNavContents.scrollLeft;
    pnIndicator.style.transform = "translateX(" + (distance + scroll) + "px) scaleX(" + textPosition.width * 0.01 + ")";
    // count = count += 100;
    // pnIndicator.style.transform = "translateX(" + count + "px)";
    
    if (color) {
        //pnIndicator.style.backgroundColor = color;
        pnIndicator.style.backgroundColor = "#0C2074";
    }
}
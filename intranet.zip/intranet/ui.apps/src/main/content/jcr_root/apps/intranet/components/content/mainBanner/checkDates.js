use(function () { 
	var sDate = this.startDate;
	var eDate = this.endDate;

    var _compareDates = function () {
        var current = new Date();
        var startDate = new Date(sDate); 
        var endDate = new Date(eDate);

        if (startDate.getTime() < current.getTime()  && current.getTime() < endDate.getTime()){  
         	return "true";  
        }  
        else {  
        	return "false";
        } 
    };

   	var compareDates = _compareDates();

 	return {
  		showBanner: compareDates
  	}; 
});
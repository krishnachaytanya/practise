use(function () { 
	var answerText = this.answer;

    var _trimAnswer = function () {
        return (answerText != null) ? answerText.replace(/<p>|<\/p>|<br>|<br\s*\/>|\n|\r/g,"") : "";
    };

   	return {
  		text: _trimAnswer()
  	}; 
});
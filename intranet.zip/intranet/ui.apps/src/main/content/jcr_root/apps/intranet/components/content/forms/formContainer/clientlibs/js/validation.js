(function (document, $, ns) {
    "use strict";
 
    $(document).on("click", ".cq-dialog-submit", function (e) {
        e.stopPropagation();
        e.preventDefault();
 
        var $form = $(this).closest("form.foundation-form"),
            formname = $form.find("[name='./formname']").val(),
               message, clazz = "coral-Button ",
         patterns = {
             formnamefield: /^[a-zA-Z]+$/
        };

        if(formname != "" && !patterns.formnamefield.test(formname) && (formname != null)) {
                ns.ui.helpers.prompt({
                title: Granite.I18n.get("Invalid Input"),
                message: "Enter a valid Form Name with no space & no numbers",
                actions: [{
                    id: "CANCEL",
                    text: "CANCEL",
                    className: "coral-Button"
                }],
            callback: function (actionId) {
                if (actionId === "CANCEL") {
                }
            }
        });

        }else{
                 $form.submit();
        }
    });
})(document, Granite.$, Granite.author);
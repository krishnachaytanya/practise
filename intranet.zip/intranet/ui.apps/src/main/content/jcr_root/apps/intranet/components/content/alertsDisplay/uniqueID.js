use(function () { 
	var title = this.alertTitle;
	
	title = title.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
    
   	return {
  		getID: title
  	}; 
});
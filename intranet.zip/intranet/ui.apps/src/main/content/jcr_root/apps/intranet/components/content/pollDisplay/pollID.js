use(function () { 
	var date = currentSession.getNode(this.poll).getProperty("jcr:created").toString();
	
	var _getDate = function () {
    	var d = new Date(date);
        return d.getTime();
    };

   	return {
  		id: _getDate()
  	}; 
});
(function($) { 
    var REGEX_SELECTOR = "phone.validation",
 
    foundationReg = $(window).adaptTo("foundation-registry");
 
    foundationReg.register("foundation.validation.validator", {
        selector: "[data-validation='phone.validation']",
        validate: function(el) {
 
            var regex_pattern = /^\d{3}\.\d{3}\.\d{4}$/i;
            var error_message = "Please Enter a valid Phone Number (xxx.xxx.xxxx), digits only";
            var result = el.value.match(regex_pattern);
 
            if (result === null) {
                return error_message;
            }
        }
    });
    
    foundationReg.register("foundation.validation.validator", {
        selector: "[data-validation='name.validation']",
        validate: function(el) {
 
            var regex_pattern = /^[a-zA-Z\s]+$/i;
            var error_message = "Please Enter a valid Contact Name (alpha and space characters)";
            var result = el.value.match(regex_pattern);
 
            if (result === null) {
                return error_message;
            }
        }
    });
    
    foundationReg.register("foundation.validation.validator", {
        selector: "[data-validation='department.validation']",
        validate: function(el) {
 
            var regex_pattern = /^[a-zA-Z\s\.]+$/i;
            var error_message = "Please Enter a valid Department Name (alpha, space and . characters)";
            var result = el.value.match(regex_pattern);
 
            if (result === null) {
                return error_message;
            }
        }
    });
    
    foundationReg.register("foundation.validation.validator", {
        selector: "[data-validation='email.validation']",
        validate: function(el) {
 
            var regex_pattern = /^[a-z\d\.]+@usbank\.com$/i;
            var error_message = "Please Enter a valid Email Address (firstname.lastname@usbank.com)";
            var result = el.value.match(regex_pattern);
 
            if (result === null) {
                return error_message;
            }
        }
    });
    
    foundationReg.register("foundation.validation.validator", {
        selector: "[data-validation='title.validation']",
        validate: function(el) {
 
            var regex_pattern = /^[a-zA-Z\s]+$/i;
            var error_message = "Please Enter a valid Title for Contact (alpha and space characters)";
            var result = el.value.match(regex_pattern);
 
            if (result === null) {
                return error_message;
            }
        }
    });
 
}(jQuery));
use(function () { 
	var sDate = this.startDate;

    var _compareDates = function () {
        var current = new Date();
        var startDate = new Date(sDate);

        if(startDate.getTime() < current.getTime()){  
         	return "true";  
        }  
        else {  
        	return "false";
        } 
    };

   	var compareDates = _compareDates();

 	return {
  		showPoll: compareDates
  	}; 
});
$(document).ready(function(){
	// Carousel double-click behavior
	var carouselLinks = [
 		$('.carousel-item:nth-child(1) a').attr('href'),
 		$('.carousel-item:nth-child(2) a').attr('href'),
 		$('.carousel-item:nth-child(3) a').attr('href')
 	];
 	$('.carousel-indicators li').dblclick(function(){
 		if ($('.carousel-indicators li').index(this) === 0) window.location = carouselLinks[0];
 		if ($('.carousel-indicators li').index(this) === 1) window.location = carouselLinks[1];
 		if ($('.carousel-indicators li').index(this) === 2) window.location = carouselLinks[2];
 	});

 	// Carousel background image for each tab:
	var carouselImages = [
		$('.carousel-item:nth-child(1) img').attr('src'),
		$('.carousel-item:nth-child(2) img').attr('src'),
		$('.carousel-item:nth-child(3) img').attr('src')
	];
	$('.carousel-indicators li:nth-child(1)').css('background-image', 'url(' + carouselImages[0] + ')');
	$('.carousel-indicators li:nth-child(2)').css('background-image', 'url(' + carouselImages[1] + ')');
	$('.carousel-indicators li:nth-child(3)').css('background-image', 'url(' + carouselImages[2] + ')');
	
	// Carousel pause/play functionality:
	$('button.btn-pause-play').on('click', function(e) {
		$('button.btn-pause-play i').toggleClass('fa-pause fa-play');

		var txt = $('button.btn-pause-play .sr-only').text();

		if (txt === 'Stop Slide Animation') {
			$('#intranetNewsCarousel').carousel('pause');
			$('button.btn-pause-play .sr-only').text('Start Slide Animation');
		}
		else {
			$('#intranetNewsCarousel').carousel('cycle');
			$('button.btn-pause-play .sr-only').text('Stop Slide Animation');
		}
	});

	// Keyboard pause on focus:
	$('#intranetNewsCarousel').on('focusin', function(e) {
		$('#intranetNewsCarousel').carousel('pause');
	});

	// Only unpause/cycle slides on focusout if the carousel was previously in an unpaused state:
	$('#intranetNewsCarousel').on('focusout', function(e) {
		if ($('button.btn-pause-play i').hasClass('fa-pause')) {
			$('#intranetNewsCarousel').carousel('cycle');
		}
		// This is supposed to prevent the live region from being updated after the carousel has lost focus:
		$('#intranetNewsCarousel #liveregion').empty();
	});

	// Announce Slide n of 3:
	// Previous slide:
	$('.carousel-control-prev').on('click', function() {
		$('#intranetNewsCarousel').on('slid.bs.carousel', function(e) {
			var slide = e.to+1;
			$('#intranetNewsCarousel #liveregion').text('Slide ' + slide + ' of ' + 3);
			$('#intranetNewsCarousel').off('slid.bs.carousel');
		});
	});

	// Next slide:
	$('.carousel-control-next').on('click', function() {
		$('#intranetNewsCarousel').on('slid.bs.carousel', function(e) {
			var slide = e.to+1;
			$('#intranetNewsCarousel #liveregion').text('Slide ' + slide + ' of ' + 3);
			$('#intranetNewsCarousel').off('slid.bs.carousel');
		});
	});
});
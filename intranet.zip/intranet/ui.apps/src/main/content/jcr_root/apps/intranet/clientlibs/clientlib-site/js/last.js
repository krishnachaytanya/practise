/*! last.js */
/*! Script expected to go at the bottom of the page, after all the libraries are loaded is included here */
$(document).ready(function(){
	var windowWidth = $(window).width();

	/* 
	 * Banner / Pop-up Alert Display Logic
	 * 
	 * Create a cookie when an alert's close/acknowledge button is clicked. When the page loads, 
	 * check each alert to see if a corresponding cookie exists and hide/show the alert as appropriate.
	 */

	// Create cookie when banner alert is closed
	$('.banner-alert button').on('click', function(){
		var bannerAlertId = $(this).closest('div .alert').attr('id');
		createCookie(bannerAlertId, 'ack', '365');
	});

	// Create cookie when pop-up alert is acknowledged
	$('.modal-alert button').on('click', function(){
		var popupAlertId = $(this).closest('div .modal').attr('id');
		createCookie(popupAlertId, 'ack', '365');
	});

	// Display logic for banner alert(s)
	$('.banner-alert .alert').each(function() {
		var bannerAlertId = this.id;
		var cookie = readCookie(bannerAlertId);
		if (!cookie) {
			$(this).closest('.banner-alert').css('display', 'block');
		}
	});

	// Display logic for pop-up alert(s)
	$('.modal-alert .modal').each(function() {
		var popupAlertId = this.id;
		var cookie = readCookie(popupAlertId);
		if (!cookie) {
			$('.modal-alert .modal').modal('show');
		}
	});

	/*
	 * Initialize Components and Reset Drop-downs
	 * 
	 * Some CSS classes need to be applied at viewport widths that do not match Bootstrap's breakpoints. 
	 * As such, the initializeComponents() function ensures that components display correctly at widths 
	 * that differ from Bootstrap's default breakpoints. It needs to run on page load and when the the
	 * browser window is resized. 
	 * 
	 * Components featuring drop-downs that hover over other page content should be collapsed when
	 * certain conditions exist. In addition to being called by the initCustomComponents() function, 
	 * the resetDropDowns() function is called when clicking anywhere on the browser window (i.e. 
	 * outside of the respective drop-down element) and when clicking on the top nav. 
	 */

	// Call functions on page load:
	initCustomComponents();
	processBanners();

	// ...and on window resize:
	$(window).on('resize', function() {
		initCustomComponents();
	});

	// Reset drop-downs when clicking anywhere on the browser window...
	$(window).on('click', function() {
		resetDropDowns();
	});

	// ...and when clicking on the top nav:
	$('.header .nav-link').on('click', function() {
		resetDropDowns();
	});

	/*
	 * BEGIN on-click behaviors
	 */
	// Expand/collapse mobile navigation submenus
	$('.submenu-header').on('click', function(e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).siblings('.submenu-header-links').toggleClass('d-none d-lg-block');
	});

	// Collections drop-down in the search menu
	$('.search-menu select').on('click', function(e) {
		e.stopPropagation();
	});

	// Open/close/scroll to Quick Link tabs:
	$('.ql-tab').on('click', function(e) {
		e.preventDefault();
		/*
		 * Get index of .nav-link's parent tab (<li>) to determine offset 
		 * position (based on tab height - each tab is 100px).
		 * E.g. tab1 offset = 0, tab2 = 100px, tab3 = 200px, tab4 = 300px.
		 */
		var i = $(this).parent().index();
		var pos = 0;
		if (i === 1) pos = 105; // 2nd tab
		if (i === 2) pos = 210; // 3rd tab
		if (i === 3) pos = 315; // 4th tab

		if ($(this).attr('class') != 'ql-tab active') {
			// Reset other items:
			$('.ql-tab').removeClass('active');
			$('.nav-link').attr('aria-expanded','false');
			// Set this item:
			$(this).addClass('active');
			$(this).children('.nav-link').attr('aria-expanded','true');

			// For mobile, scroll to top of all tabs + height of all preceding tabs:
			if (windowWidth < 634) {
				$('html, body').animate({
					scrollTop: $(this).closest('.quick-links-nav').offset().top + pos
				}, 400);
			} else {
				$('html, body').animate({
					scrollTop: $(this).closest('.quick-links-nav').offset().top
				}, 400);
			}
		} else {
			$(this).removeClass('active');
			$(this).children('.nav-link').attr('aria-expanded','false');
		}

		// For desktop, adjust top margin of sibling component:
		if (windowWidth > 634) {
			var height = $(this).siblings('.ql-content').height();
			if ($(this).attr('class') != 'ql-tab active') {
				$(this).closest('.fourBox').css('margin-bottom',0);
			} else {
				height += 51 + 15;
				$(this).closest('.fourBox').css('margin-bottom',height);
			}
		}
	});

	// Stock ticker detail hide/show
	$('.stock-ticker').on('click', function(e){
		stockExpansion();
		e.stopPropagation();
		$('.stock-detail').toggleClass('d-block');
		$('.stock-summary').toggleClass('toggle-bottom-border');
        $('.stock-summary > i').toggleClass('fa fa-angle-up');
        $('.stock-summary > i').toggleClass('fa fa-angle-down');
		// Prevents carousel buttons from remaining on top of stock detail
        // Changed to mimic block-level stock detail display behavior:
		if (windowWidth < 634) {
//			$('.carousel.slide button').toggleClass('z-0');
			$('.titleWithLink').toggleClass('toggle-title-margin');
		}
	});
	
	//accessibility for stock ticker
	
    $("#stock-expander").focus(function() { 
    	if(document.getElementById("stock-expander").getAttribute("aria-expanded") == null){
           		 document.getElementById("stock-expander").setAttribute('aria-expanded', 'false');
            }
        });

    function stockExpansion(){
        if(document.getElementById("stock-expander").getAttribute("aria-expanded") == "true"){
       		 document.getElementById("stock-expander").setAttribute('aria-expanded', 'false');
        }else{
			document.getElementById("stock-expander").setAttribute('aria-expanded', 'true');
        }
    }

	$('.stock-ticker').on('keypress', function(e){
	    if (event.keyCode == 13) {
	        $(".stock-ticker").click();
	    }
	});

	/*
	 * END on-click behaviors
	 */

	/*
	 * BEGIN megamenu keyboard accessibility link trap
	 */
	var trapNavLinks = function(selected) {
		var tabbable = selected.find('a, input, select, button').filter(':visible');
		var firstTabbable = tabbable.first();
		var lastTabbable = tabbable.last();

		// Set focus on first input:
		firstTabbable.focus();

		// Redirect last tab to first input:
		lastTabbable.on('keydown', function (e) {
			if ((e.which === 9 && !e.shiftKey)) {
				e.preventDefault();
				firstTabbable.focus();
			}
		});

		// Redirect first shift+tab to last input:
		firstTabbable.on('keydown', function (e) {
			if ((e.which === 9 && e.shiftKey)) {
				e.preventDefault();
				lastTabbable.focus();
			}
		});

		// Allow escape key to close the search menu - requires special handling due to input element behavior:
		$('.search-menu input').on('keydown', function(e){
			if (e.keyCode === 27 ) {
				$('#search').closest('.nav-item').removeClass('show');
				$('.search-menu').removeClass('show');
				$('#search').attr('aria-expanded','false');
				$('#search').focus();
			};
		});
	};

	// Call link trap function after megamenu is shown:
	$('.nav-item').on('shown.bs.dropdown', function(){
		trapNavLinks($('.dropdown-menu.show'));
	});
	/*
	 * END megamenu keyboard accessibility link trap
	 */

	// Window/viewport size-related functionality to be called on page load and when window size changes:
	function initCustomComponents(){
		var tileWidth = $("div.card-tiles").width();

		// Set window width when page loads and on window resize:
		windowWidth = $(window).width();

		// Reset drop-downs:
		resetDropDowns();

		if (windowWidth < 634) {
			// Collapsible Text
			$('.collapsible-text div:first-child').attr('data-toggle','collapse');
			$('.collapsible-text div.collapse').removeClass('show');

			// Stock ticker spacing below navigation
			if ($('.stock-ticker').length) $('.navbar').addClass('mb-55');

			// Four Box right padding to accommodate sprite:
			$('.ql-tab .nav-link span').addClass('pr-4');
		} else {
			$('.collapsible-text div:first-child').attr('data-toggle','');
			$('.collapsible-text div.collapse').addClass('show');

			// Stock ticker spacing below navigation
			if ($('.stock-ticker').length) $('.navbar').removeClass('mb-55');

			// Match height of News for You to that of Carousel:
			var carouselHeight = $('.carousel').height();
			var nfyHeight = 0;
			// header and footer height - stock ticker height - bottom margin of carousel - margin between stock ticker and news for you
			nfyHeight = carouselHeight - 106 - 47 - 15 - 5;
			if ( nfyHeight > 0 ) {
				$('.news-for-you div.card-body').css('height', nfyHeight);
			}
			// Four Box right padding to accommodate sprite:
			$('.ql-tab .nav-link span').removeClass('pr-4');
		}

		// Grid Tiles
		if (windowWidth > 634 && tileWidth < 529) {
			$(".aem-GridColumn--default--7 > .card-tiles > div").removeClass("col-sm-6");
			$(".aem-GridColumn--default--7 > .card-tiles > div").addClass("col-lg-6");
		} else {
			$(".aem-GridColumn--default--7 > .card-tiles > div").addClass("col-sm-6");
			$(".aem-GridColumn--default--7 > .card-tiles > div").removeClass("col-lg-6");
			$(".aem-GridColumn--default--12 > .card-tiles > div").addClass("col-sm-6 col-md-4 col-xl-3");
		}
	}

	function resetDropDowns() {
		//Stock Ticker
		if ($('.stock-ticker').length) {
			$('.stock-detail').removeClass('d-block');
			$('.stock-summary').removeClass('toggle-bottom-border');
			$('.titleWithLink').removeClass('toggle-title-margin');
		}
	}

	// BEGIN banner logic (processBanners() and weight(obj)
    function processBanners(){
        $(".top-banner").each(function(i){
            var obj = JSON.parse(eval($(this).attr('id')+"JSON"));
            
            if(obj.images.length > 0){
                var w = weight(obj);
                $(this).html("<a href=\"" + obj.images[w].link + "\"><div class=\"banner w-100\"><img src=\"" + obj.images[w].path + "\" alt=\"" + obj.images[w].alttext + "\" class=\"img-fluid\"></div></a>");
            }
        });
    }

    function weight(obj){
        var weights = [];
        for (var i in obj.images) {
            weights.push(Number(obj.images[i].weight));
        }

        var bannerIndexes = [];
        var totalWeight = 0;
        for(var i = 0; i < weights.length; i++){
            for(var j = 0; j < weights[i]; j++){
                bannerIndexes.push(i);
            }
            totalWeight += weights[i];
        }

        var selectedBanner = bannerIndexes[Math.floor(Math.random() * Math.floor(totalWeight))];
        return selectedBanner;
    }
    // END banner logic

    
});

//BEGIN cookies
function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}
// END cookies
/*! last.js */
/*! Script expected to go at the bottom of the page, after all the libraries are loaded is included here */
$(document).ready(function(){
	// Expand/collapse mobile submenus
	$('.submenu-header').on('click', function(e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).siblings('.submenu-header-links').toggleClass('d-none d-lg-block');
	});

	// Collapse collapsible text for mobile
	// Check on page load:
	initCustomComponents();

	// Check on window resize:
	$(window).on("resize", function () {
		initCustomComponents();

		console.log($(window).width() + " / " + $("div.card-tiles").width());
	});

	function initCustomComponents(){
		var windowWidth = $(window).width();
		var tileWidth = $("div.card-tiles").width();

		// Collapsible Text
		if (windowWidth < 634) {
			$('.collapsible-text a').attr('data-toggle','collapse');
			$('.collapsible-text div.collapse').removeClass('show');
		} else {
			$('.collapsible-text a').attr('data-toggle','');
			$('.collapsible-text div.collapse').addClass('show');
			// Prevent click event:
			$('.collapsible-text a').on('click', function(e) {
				e.preventDefault();
			});
		}

		// Grid Tiles
		if (windowWidth > 634 && tileWidth < 529) {
			console.log("true");
			$(".aem-GridColumn--default--7 > .card-tiles > div").removeClass("col-sm-6");
			$(".aem-GridColumn--default--7 > .card-tiles > div").addClass("col-lg-6");
		} else {
			$(".aem-GridColumn--default--7 > .card-tiles > div").addClass("col-sm-6");
			$(".aem-GridColumn--default--7 > .card-tiles > div").removeClass("col-lg-6");
			$(".aem-GridColumn--default--12 > .card-tiles > div").addClass("col-sm-6 col-md-4 col-xl-3");
		}
	}
});
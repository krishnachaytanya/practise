
$.validator.register({
  selector: "[data-validation='eaem.max.tags'] input",
  validate: function(el) {
    var field,
        value,
      $tagsPicker = $(el).closest(".tagspickerclass.js-cq-TagsPickerField"),
                maxTagsAllowed = $tagsPicker.attr("data-eaemmaxtags");


    field = el.closest(".coral-Form-field");
    value = el.val();

            if(!maxTagsAllowed){
                console.log("eaemMaxTags::: number not set");
                return;
            }
                      console.log("eaemMaxTags:::"+maxTagsAllowed);

      var $tagList = $tagsPicker.next(".coral-TagList");
        console.log("length:: "+$tagList.find(".coral-TagList-tag").length);
   console.log("length:: "+$tagList.length);

    if ($tagList.find(".coral-TagList-tag").length >= maxTagsAllowed) {

      return Granite.I18n.get("Max exceeded, allowed : " + maxTagsAllowed);

    }

  },
  show: function (el, message) {
    var fieldErrorEl,
        field,
        error,
        arrow;    

    fieldErrorEl = $("<span class='coral-Form-fielderror coral-Icon coral-Icon--alert coral-Icon--sizeS' data-init='quicktip' data-quicktip-type='error' />");
    field = el.closest(".coral-Form-field");

    field.attr("aria-invalid", "true")
      .toggleClass("is-invalid", true);

    field.nextAll(".coral-Form-fieldinfo")
      .addClass("u-coral-screenReaderOnly");

    error = field.nextAll(".coral-Form-fielderror");

    if (error.length === 0) {

      arrow = field.closest("form").hasClass("coral-Form--vertical") ? "right" : "top";

      fieldErrorEl
        .attr("data-quicktip-arrow", arrow)
        .attr("data-quicktip-content", message)
        .insertAfter(field);
    } else {
      error.data("quicktipContent", message);
    }
  },
  clear: function (el) {

    var field = el.closest(".coral-Form-field");

    field.removeAttr("aria-invalid").removeClass("is-invalid");
      $(".coral-TabPanel-tab").removeAttr("aria-invalid").removeClass("is-invalid");

    field.nextAll(".coral-Form-fielderror").tooltip("hide").remove();
    field.nextAll(".coral-Form-fieldinfo").removeClass("u-coral-screenReaderOnly");
  }
});
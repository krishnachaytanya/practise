use(function () { 
	var _getPath = function () {
        var domain = request.getServerName();
		var path = "";
        
        if(domain.search("dev|it|uat|localhost") != -1){
        	path = "intranetdev";
        }
        else{
        	path = "intranetprod";
        }
		
		return path;
    };

 	return {
  		getPath: _getPath()
  	}; 
});
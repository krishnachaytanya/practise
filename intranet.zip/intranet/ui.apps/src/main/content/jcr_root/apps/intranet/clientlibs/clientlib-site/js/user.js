$(document).ready(function(){
	if (sessionStorage.getItem("usBankUser") !== null && sessionStorage.getItem("granite.shell.badge.user")  !== null ) {
		var user = JSON.parse(sessionStorage.getItem('usBankUser'));
		if (user.userId !== sessionStorage.getItem("granite.shell.badge.user")) {
			sessionStorage.removeItem('usBankUser');
		}
	}
	
	
	if (!sessionStorage.getItem("usBankUser") || !sessionStorage.getItem("usBankUserExpire") ||
		new Date - new Date(sessionStorage.getItem("usBankUserExpire")) > (12*60*60*1000 )) {
		$.ajax({
	        'url' : '/bin/userInfo?nocache=true',
	        'type' : 'GET',
	        'success' : function(data) {
	            sessionStorage.setItem("usBankUser", data);
	            sessionStorage.setItem("usBankUserExpire", new Date()); 
	            $(document).trigger('usBankUserLoad',[false]);
	        },
	        'error' : function(request,error)
	        {
	            alert("Request: "+JSON.stringify(request));
	        }
	    });
	} else {
		 $(document).trigger('usBankUserLoad',[false]);
	}
});

$(document).bind("usBankUserLoad", function(e, status){
	var user = JSON.parse(sessionStorage.getItem('usBankUser'));

	var name = user.userId;
    if (user.nickName) {
		name = user.nickName;
    }
    else if (user.firstName) {
		name = user.firstName;
    }

    $("#USBankUser_name").html(name);
    $("#USBankUser_photo").attr('src', user.photo);
    $("#USBankUser_photolarge").attr('src', user.photoLarge);
    
    $.each(user.favorites, function( index, value ) {
    	if (value.url && value.name) {
        	$("#USBankUser_favorites").append(
	        	"<li>"+
				"	<a id=\"fav"+index+"\" href=\""+value.url.split('_DEFAULT')[0]+"\" class=\"btn btn-primary btn-lg\" role=\"button\">"+value.name.split('_DEFAULT')[0]+"</a>"+
				"	<span class=\"fa fa-angle-right ml-2\" aria-hidden=\"true\"></span>"+
				"</li>");
    	}
    });
});


